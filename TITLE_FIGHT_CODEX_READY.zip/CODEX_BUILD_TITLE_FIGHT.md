# Tâche Codex — Compiler TITLE FIGHT

Utilise l’archive `title-fight-android-windows-build-kit.zip` comme source du projet.

## Objectif
Produire un APK Android réellement compilé et installable pour TITLE FIGHT.

## Travail à effectuer
1. Extraire l’archive dans un dossier propre.
2. Vérifier Java 17+, Gradle 9.5.1, Android SDK API 37 et Build Tools 36.0.0.
3. Exécuter les tests Kotlin/Gradle disponibles.
4. Corriger toute erreur de configuration Gradle, AGP, Kotlin ou Compose sans modifier les règles du moteur de combat.
5. Exécuter `assembleDebug`.
6. Vérifier l’APK avec `apksigner verify --verbose`.
7. Calculer le SHA-256 de l’APK.
8. Si un appareil Android est connecté, installer avec `adb install -r`, lancer `com.titlefight.simulator`, puis vérifier que le processus reste actif.
9. Retourner :
   - l’APK final ;
   - son SHA-256 ;
   - les sorties de tests ;
   - le journal de compilation ;
   - le résultat d’installation/lancement ;
   - la liste exacte des corrections apportées.

## Contraintes
- Ne pas modifier les probabilités, profils, règles sportives ni résultats déterministes du moteur.
- Ne pas prétendre que l’installation a réussi sans preuve ADB.
- Ne pas fournir un ZIP à la place de l’APK final.
