# Jalon 2 — Étape 5 : audit statistique final

## Objet

Vérifier les chutes, comptes, relèvements, KO, TKO, biais de coin et équilibre interne sur des combats démarrant dans un état normal.

## Échantillon

- 10 fenêtres indépendantes ;
- 1 000 combats par fenêtre ;
- 10 000 combats au total ;
- coins alternés à parts égales ;
- deux profils fictifs uniquement ;
- trois rounds maximum ;
- mêmes tactiques verrouillées que lors du jalon 1.

## Observation initiale

Avec les seuils TKO de l’étape 4, le mécanisme était pratiquement dormant sur des combats démarrant à 100 %. Les chutes, comptes et KO fonctionnaient normalement.

## Correction minimale

Aucun mécanisme n’a été ajouté. L’exigence de trois impacts lourds consécutifs sans réponse a été conservée. Seuls les seuils physiques ont été ajustés :

- stabilité maximale : 42 ;
- énergie maximale : 55 ;
- dégâts tête minimum : 50 ;
- dégâts corps minimum : 60.

## Résultats de référence

- chutes : 5 061, soit 0,51 par combat ;
- relèvements : 5 046 ;
- comptes à 10 : 15 ;
- taux de relèvement : 99,70 % ;
- compte moyen : 2,65 ;
- impact moyen des chutes : 11,86 ;
- chutes sous 7 points d’impact : 10, soit 0,20 % ;
- KO : 15, soit 0,15 % ;
- TKO : 19, soit 0,19 % ;
- taux total d’arrêt : 0,34 % ;
- arrêts coin rouge / bleu : 18 / 16 ;
- avantages de performance interne à la distance : Elias Vega 4 885, Bruno Kessler 5 081 ;
- chute sur attaque manquée : 0 ;
- compte hors bornes : 0 ;
- arrêt invalide : 0 ;
- combat ou événement poursuivi après arrêt : 0.

## Bandes d’acceptation internes

Ces bandes concernent uniquement ce duel fictif de trois rounds. Elles ne prétendent pas représenter l’ensemble de la boxe réelle.

- chutes par combat : 0,30 à 0,70 ;
- chutes sous 7 points d’impact : au plus 1 % ;
- KO : 0,05 % à 1 % ;
- TKO : 0,05 % à 2 % ;
- arrêts totaux : au plus 3 % ;
- part du coin rouge parmi les arrêts : 35 % à 65 % ;
- part d’avantages Vega à la distance : 35 % à 65 %.

Toutes les bandes sont respectées.
