package titlefight

import kotlin.math.roundToInt

data class RefereeCountEvaluation(
    val countReached: Int,
    val recovered: Boolean,
    val recoveryScore: Double,
    val requiredScore: Double,
    val vulnerabilitySequences: Int,
) {
    init {
        require(countReached in 1..10)
        require(recoveryScore >= 0.0)
        require(requiredScore >= 0.0)
        require(recovered == (countReached < 10))
        require(vulnerabilitySequences in 0..4)
    }
}

/**
 * Résout le compte et le relèvement.
 *
 * Un compte à 10 est transmis au moteur, qui applique désormais l'arrêt par KO
 * au jalon 2, étape 3.
 */
object RefereeCountResolver {
    fun evaluate(
        defender: BoxerProfile,
        defenderBefore: FighterState,
        defenderAfterKnockdown: FighterState,
        knockdown: KnockdownEvent,
        roll: Double,
    ): RefereeCountEvaluation {
        require(roll in 0.0..1.0)
        require(knockdown.defenderId == defender.id)

        val bodyShot = knockdown.punch == Punch.BODY_HOOK
        val resistance = if (bodyShot) defender.bodyResistance else defender.chin
        val accumulatedDamage = if (bodyShot) defenderAfterKnockdown.bodyDamage else defenderAfterKnockdown.headDamage
        val instability = 100.0 - defenderAfterKnockdown.stability
        val fatigue = 100.0 - defenderBefore.stamina
        val previousKnockdowns = (defenderAfterKnockdown.knockdownsSuffered - 1).coerceAtLeast(0)

        val recoveryScore = (
            defender.recovery * 0.42 +
                defender.mental * 0.30 +
                resistance * 0.16 +
                defenderBefore.stamina * 0.12
            ).coerceAtLeast(0.0)

        val requiredScore = (
            knockdown.impact * 2.55 +
                knockdown.score * 0.72 +
                accumulatedDamage * 0.20 +
                instability * 0.23 +
                fatigue * 0.10 +
                previousKnockdowns * 5.0
            ).coerceAtLeast(0.0)

        val randomSwing = (roll - 0.5) * 3.2
        val rawCount = 4.0 + (requiredScore - recoveryScore) / 9.0 + randomSwing
        val count = rawCount.roundToInt().coerceIn(1, 10)
        val recovered = count < 10
        val vulnerability = when {
            !recovered -> 0
            count <= 3 -> 1
            count <= 6 -> 2
            count <= 8 -> 3
            else -> 4
        }

        return RefereeCountEvaluation(
            countReached = count,
            recovered = recovered,
            recoveryScore = recoveryScore,
            requiredScore = requiredScore,
            vulnerabilitySequences = vulnerability,
        )
    }
}
