# Jalon 7 — Étape 3 — Carrière professionnelle corrigée

## Objectif

Créer une carrière de boxe réaliste dans laquelle le joueur construit son propre athlète au lieu d'incarner directement une légende historique.

## Création du boxeur

Le joueur choisit :

- nom ;
- surnom ;
- pays ;
- catégorie de poids ;
- garde ;
- style de boxe.

Le boxeur commence à 18 ans, sans combat professionnel, sans classement mondial et sans ceinture. Ses statistiques initiales sont adaptées au style choisi et restent volontairement éloignées du niveau des champions historiques.

## Échelons de carrière

| Étape | Condition principale | Récompense |
|---|---|---|
| Prospect | Début de carrière | Combats de développement |
| Régional | 3 victoires | Ceinture régionale |
| National | 6 victoires et titre régional | Ceinture nationale |
| Continental | 10 victoires et titre national | Ceinture continentale |
| Classé mondial | Titre continental | Entrée au classement mondial, rang 15 |
| Champion du monde | Progression jusqu'au rang 3 | Combat WBA |
| Champion unifié | Défenses et unifications | WBC puis IBF |
| Champion incontesté | Dernière unification | WBO et The Ring |

## Gestion sportive

La carrière suit l'âge, le palmarès, les KO, la fatigue, la santé, la réputation, les bourses, les défenses de titre et l'historique des combats. L'entraînement permet de développer la puissance, la vitesse, la technique, la défense, l'endurance ou le mental.

## Rôle des 321 boxeurs

Les 321 boxeurs de la base officielle servent d'identités adverses et de références historiques. Ils ne sont pas des cartes à collectionner dans Title Bout.

Les éléments suivants ont été supprimés du modèle et du fichier JSON :

- rareté ;
- coût de carte ;
- charisme de collection ;
- recherche par rareté.

## Ceintures

Le moteur de carrière gère :

- régionale ;
- nationale ;
- continentale ;
- WBA ;
- WBC ;
- IBF ;
- WBO ;
- The Ring.

Une ceinture peut être perdue lors d'une défaite en défense. Un boxeur détenant une ceinture ne peut pas changer de catégorie avant de la libérer ou de la perdre.

## Validation exécutée

- création à 18 ans : PASS ;
- départ sans classement : PASS ;
- départ sans ceinture : PASS ;
- parcours régional vers mondial : PASS ;
- WBA, WBC, IBF et WBO : PASS ;
- champion incontesté : PASS ;
- entraînement, âge, fatigue, santé et bourses : PASS ;
- 321 adversaires et 15 catégories : PASS ;
- rareté absente du moteur et des données : PASS ;
- syntaxe des écrans Compose modifiés : PASS avec stubs locaux.

## Limites non masquées

La durée réelle du moteur interactif reste limitée à trois rounds. Les formats 4, 6, 8, 10 et 12 rounds sont définis dans les propositions de combat, mais leur exécution complète doit être ajoutée au moteur. La sauvegarde persistante de la carrière reste également à brancher. Aucun nouvel APK n'a été compilé dans cet environnement.
