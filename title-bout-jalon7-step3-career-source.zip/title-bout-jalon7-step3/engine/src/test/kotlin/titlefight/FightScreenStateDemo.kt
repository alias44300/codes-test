package titlefight

object FightScreenStateDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val red = TestProfiles.eliasVega
        val blue = TestProfiles.brunoKessler
        val result = FightEngine(adaptiveTacticsEnabled = true).simulateThreeRoundFight(
            red = red,
            blue = blue,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = 20260721L,
        )
        val timeline = FightScreenStateMapper.buildTimeline(result, red, blue)
        val samples = listOf(
            timeline.first(),
            timeline.first { it.phase == FightScreenPhase.ROUND_IN_PROGRESS },
            timeline.first { it.phase == FightScreenPhase.BETWEEN_ROUNDS },
            timeline.last(),
        )
        println("TITLE FIGHT — Aperçu du contrat d'écran")
        samples.forEach { state ->
            println("${state.phase} | R${state.roundNumber} S${state.sequenceNumber} | ${state.clock.display}")
            println("  ${state.red.name}: énergie ${state.red.stamina}, tête ${state.red.headDamage}, corps ${state.red.bodyDamage}, stabilité ${state.red.stability}, état ${state.red.condition}")
            println("  ${state.blue.name}: énergie ${state.blue.stamina}, tête ${state.blue.headDamage}, corps ${state.blue.bodyDamage}, stabilité ${state.blue.stability}, état ${state.blue.condition}")
            println("  Commentaire: ${state.commentary}")
            println("  Fenêtre tactique: ${state.tacticalWindowOpen}")
            state.result?.let { println("  Résultat: ${it.headline} — ${it.detail}") }
        }
    }
}
