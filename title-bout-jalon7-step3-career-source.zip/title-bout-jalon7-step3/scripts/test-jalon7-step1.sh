#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build-jalon7-step1"
rm -rf "$BUILD"
mkdir -p "$BUILD"
kotlinc -J-Xmx2048m -J-Dfile.encoding=UTF-8 \
  "$ROOT"/engine/src/main/kotlin/titlefight/*.kt \
  "$ROOT"/engine/src/test/kotlin/titlefight/Jalon7Step1Audit.kt \
  -include-runtime -d "$BUILD/title-fight-jalon7-step1.jar"
java -Xmx2g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-jalon7-step1.jar" titlefight.Jalon7Step1Test
