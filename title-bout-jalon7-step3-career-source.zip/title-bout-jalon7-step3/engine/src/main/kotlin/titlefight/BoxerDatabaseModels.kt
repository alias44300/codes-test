package titlefight

enum class WeightClass(val frenchLabel: String, val minimumKg: Double?, val maximumKg: Double?) {
    STRAWWEIGHT("Poids pailles", null, 47.6),
    SUPER_FLYWEIGHT("Poids super-mouches", 50.8, 52.2),
    BANTAMWEIGHT("Poids coqs", 52.2, 53.5),
    SUPER_BANTAMWEIGHT("Poids super-coqs", 53.5, 55.3),
    FEATHERWEIGHT("Poids plumes", 55.3, 57.2),
    SUPER_FEATHERWEIGHT("Poids super-plumes", 57.2, 59.0),
    LIGHTWEIGHT("Poids légers", 59.0, 61.2),
    SUPER_LIGHTWEIGHT("Poids super-légers", 61.2, 63.5),
    WELTERWEIGHT("Poids welters", 63.5, 66.7),
    SUPER_WELTERWEIGHT("Poids super-welters", 66.7, 69.9),
    MIDDLEWEIGHT("Poids moyens", 69.9, 72.6),
    SUPER_MIDDLEWEIGHT("Poids super-moyens", 72.6, 76.2),
    LIGHT_HEAVYWEIGHT("Poids mi-lourds", 76.2, 79.4),
    CRUISERWEIGHT("Poids lourds-légers", 79.4, 90.7),
    HEAVYWEIGHT("Poids lourds", 90.7, null),
}

enum class BoxerEra {
    PIONEER,
    GOLDEN_AGE,
    POST_WAR,
    MODERN_CLASSIC,
    CONTEMPORARY,
}

data class BoxerRatings(
    val jabPower: Int,
    val rearHandPower: Int,
    val hookPower: Int,
    val bodyPower: Int,
    val handSpeed: Int,
    val footSpeed: Int,
    val accuracy: Int,
    val timing: Int,
    val headDefense: Int,
    val bodyDefense: Int,
    val blocking: Int,
    val evasiveness: Int,
    val countering: Int,
    val pressure: Int,
    val rangeControl: Int,
    val insideFighting: Int,
    val endurance: Int,
    val recovery: Int,
    val chin: Int,
    val bodyResistance: Int,
    val balance: Int,
    val cutResistance: Int,
    val ringIq: Int,
    val adaptability: Int,
    val discipline: Int,
    val aggression: Int,
    val finishing: Int,
    val composure: Int,
) {
    init {
        values().forEach { require(it in 1..100) { "Toutes les notes avancées doivent être comprises entre 1 et 100." } }
    }

    fun values(): List<Int> = listOf(
        jabPower, rearHandPower, hookPower, bodyPower, handSpeed, footSpeed,
        accuracy, timing, headDefense, bodyDefense, blocking, evasiveness,
        countering, pressure, rangeControl, insideFighting, endurance, recovery,
        chin, bodyResistance, balance, cutResistance, ringIq, adaptability,
        discipline, aggression, finishing, composure,
    )

    fun toEngineProfile(
        id: String,
        name: String,
        nickname: String,
        stance: Stance,
        style: BoxingStyle,
        preferredRange: FightRange,
        heightCm: Int,
        reachCm: Int,
    ): BoxerProfile = BoxerProfile(
        id = id,
        name = name,
        nickname = nickname,
        stance = stance,
        style = style,
        preferredRange = preferredRange,
        heightCm = heightCm,
        reachCm = reachCm,
        power = average(rearHandPower, hookPower, bodyPower, finishing),
        speed = average(handSpeed, footSpeed),
        technique = average(accuracy, timing, ringIq, rangeControl, insideFighting),
        defense = average(headDefense, bodyDefense, blocking, evasiveness),
        endurance = endurance,
        mental = average(ringIq, adaptability, discipline, composure),
        chin = chin,
        recovery = recovery,
        accuracy = accuracy,
        mobility = average(footSpeed, rangeControl, evasiveness, balance),
        bodyResistance = bodyResistance,
        aggression = average(aggression, pressure),
    )

    private fun average(vararg values: Int): Int = values.average().toInt().coerceIn(1, 100)
}

data class BoxerTendencies(
    val jabFrequency: Int,
    val bodyAttackFrequency: Int,
    val combinationFrequency: Int,
    val counterFrequency: Int,
    val clinchFrequency: Int,
    val pressureFrequency: Int,
    val riskTolerance: Int,
    val fastStart: Int,
    val lateSurge: Int,
) {
    init {
        listOf(
            jabFrequency, bodyAttackFrequency, combinationFrequency, counterFrequency,
            clinchFrequency, pressureFrequency, riskTolerance, fastStart, lateSurge,
        ).forEach { require(it in 0..100) }
    }
}

data class BoxerDatabaseEntry(
    val databaseId: Int,
    val boxerId: String,
    val versionId: String,
    val name: String,
    val nickname: String,
    val countryCode: String,
    val countryName: String,
    val era: BoxerEra,
    val primeStartYear: Int,
    val primeEndYear: Int,
    val weightClass: WeightClass,
    val stance: Stance,
    val style: BoxingStyle,
    val secondaryStyle: BoxingStyle?,
    val preferredRange: FightRange,
    val heightCm: Int,
    val reachCm: Int,
    val ratings: BoxerRatings,
    val tendencies: BoxerTendencies,
    val signatureActions: List<String>,
    val traits: List<String>,
) {
    init {
        require(databaseId > 0)
        require(boxerId.matches(Regex("[a-z0-9]+(?:-[a-z0-9]+)*")))
        require(versionId.matches(Regex("[a-z0-9]+(?:-[a-z0-9]+)*")))
        require(name.isNotBlank())
        require(nickname.isNotBlank())
        require(countryCode.matches(Regex("[A-Z]{2}")))
        require(primeStartYear in 1880..2035)
        require(primeEndYear in primeStartYear..2035)
        require(signatureActions.isNotEmpty())
        require(traits.isNotEmpty())
    }

    val profile: BoxerProfile
        get() = ratings.toEngineProfile(
            id = versionId,
            name = name,
            nickname = nickname,
            stance = stance,
            style = style,
            preferredRange = preferredRange,
            heightCm = heightCm,
            reachCm = reachCm,
        )
}
