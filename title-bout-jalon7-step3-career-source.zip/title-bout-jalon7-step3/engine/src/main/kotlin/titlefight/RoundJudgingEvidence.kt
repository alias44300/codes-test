package titlefight

import kotlin.math.abs

/**
 * Faits bruts produits pendant un round pour un boxeur.
 *
 * Cette structure ne contient volontairement ni points, ni préférence de juge,
 * ni vainqueur de round. Elle sert uniquement de matière première vérifiable
 * aux futures cartes de pointage.
 */
data class FighterRoundJudgingEvidence(
    val fighterId: String,
    val initiatedSequences: Int,
    val effectiveSequences: Int,
    val landedPunches: Int,
    val cleanHits: Int,
    val totalImpact: Double,
    val cleanImpact: Double,
    val defensiveSuccesses: Int,
    val punchesAllowed: Int,
    val cleanHitsAllowed: Int,
    val impactAbsorbed: Double,
    val preferredRangeInitiatives: Int,
    val outsideInitiatives: Int,
    val midInitiatives: Int,
    val insideInitiatives: Int,
    val bodyShotsLanded: Int,
    val bodyImpact: Double,
    val knockdownsScored: Int,
    val knockdownsSuffered: Int,
) {
    init {
        require(fighterId.isNotBlank())
        listOf(
            initiatedSequences,
            effectiveSequences,
            landedPunches,
            cleanHits,
            defensiveSuccesses,
            punchesAllowed,
            cleanHitsAllowed,
            preferredRangeInitiatives,
            outsideInitiatives,
            midInitiatives,
            insideInitiatives,
            bodyShotsLanded,
            knockdownsScored,
            knockdownsSuffered,
        ).forEach { require(it >= 0) }
        listOf(totalImpact, cleanImpact, impactAbsorbed, bodyImpact).forEach { require(it >= 0.0) }

        require(effectiveSequences == landedPunches) {
            "À cette étape, une séquence offensive est efficace uniquement lorsqu’elle touche."
        }
        require(cleanHits <= landedPunches)
        require(landedPunches <= initiatedSequences)
        require(cleanImpact <= totalImpact + EPSILON)
        require(bodyShotsLanded <= landedPunches)
        require(bodyImpact <= totalImpact + EPSILON)
        require(knockdownsScored <= landedPunches)
        require(cleanHitsAllowed <= punchesAllowed)
        require(preferredRangeInitiatives <= initiatedSequences)
        require(outsideInitiatives + midInitiatives + insideInitiatives == initiatedSequences)
    }

    val accuracy: Double
        get() = ratio(landedPunches, initiatedSequences)

    val defensiveSuccessRate: Double
        get() = ratio(defensiveSuccesses, defensiveSuccesses + punchesAllowed)

    val preferredRangeShare: Double
        get() = ratio(preferredRangeInitiatives, initiatedSequences)

    companion object {
        private const val EPSILON = 1e-9

        private fun ratio(numerator: Int, denominator: Int): Double =
            if (denominator == 0) 0.0 else numerator.toDouble() / denominator
    }
}

data class RoundJudgingEvidence(
    val roundNumber: Int,
    val sequenceCount: Int,
    val red: FighterRoundJudgingEvidence,
    val blue: FighterRoundJudgingEvidence,
) {
    init {
        require(roundNumber in 1..3)
        require(sequenceCount >= 1)
        require(red.fighterId != blue.fighterId)
        require(red.initiatedSequences + blue.initiatedSequences == sequenceCount)

        require(red.defensiveSuccesses + red.punchesAllowed == blue.initiatedSequences)
        require(blue.defensiveSuccesses + blue.punchesAllowed == red.initiatedSequences)
        require(red.punchesAllowed == blue.landedPunches)
        require(blue.punchesAllowed == red.landedPunches)
        require(red.cleanHitsAllowed == blue.cleanHits)
        require(blue.cleanHitsAllowed == red.cleanHits)
        require(abs(red.impactAbsorbed - blue.totalImpact) <= EPSILON)
        require(abs(blue.impactAbsorbed - red.totalImpact) <= EPSILON)
        require(red.knockdownsSuffered == blue.knockdownsScored)
        require(blue.knockdownsSuffered == red.knockdownsScored)
    }

    companion object {
        private const val EPSILON = 1e-9
    }
}

object RoundJudgingEvidenceExtractor {
    fun extract(
        roundNumber: Int,
        red: BoxerProfile,
        blue: BoxerProfile,
        events: List<SequenceEvent>,
    ): RoundJudgingEvidence {
        require(roundNumber in 1..3)
        require(red.id != blue.id)
        require(events.isNotEmpty())
        require(events.all { event ->
            event.attackerId in setOf(red.id, blue.id) && event.defenderId in setOf(red.id, blue.id)
        })

        return RoundJudgingEvidence(
            roundNumber = roundNumber,
            sequenceCount = events.size,
            red = fighterEvidence(red, blue, events),
            blue = fighterEvidence(blue, red, events),
        )
    }

    private fun fighterEvidence(
        fighter: BoxerProfile,
        opponent: BoxerProfile,
        events: List<SequenceEvent>,
    ): FighterRoundJudgingEvidence {
        val attacks = events.filter { it.attackerId == fighter.id }
        val opponentAttacks = events.filter { it.attackerId == opponent.id }
        val landed = attacks.filter { it.landed }
        val clean = landed.filter { it.clean }
        val landedAgainst = opponentAttacks.filter { it.landed }

        return FighterRoundJudgingEvidence(
            fighterId = fighter.id,
            initiatedSequences = attacks.size,
            effectiveSequences = landed.size,
            landedPunches = landed.size,
            cleanHits = clean.size,
            totalImpact = landed.sumOf { it.impact },
            cleanImpact = clean.sumOf { it.impact },
            defensiveSuccesses = opponentAttacks.count { !it.landed },
            punchesAllowed = landedAgainst.size,
            cleanHitsAllowed = landedAgainst.count { it.clean },
            impactAbsorbed = landedAgainst.sumOf { it.impact },
            preferredRangeInitiatives = attacks.count { it.range == fighter.preferredRange },
            outsideInitiatives = attacks.count { it.range == FightRange.OUTSIDE },
            midInitiatives = attacks.count { it.range == FightRange.MID },
            insideInitiatives = attacks.count { it.range == FightRange.INSIDE },
            bodyShotsLanded = landed.count { it.punch == Punch.BODY_HOOK },
            bodyImpact = landed.filter { it.punch == Punch.BODY_HOOK }.sumOf { it.impact },
            knockdownsScored = attacks.count { it.knockdown != null },
            knockdownsSuffered = opponentAttacks.count { it.knockdown != null },
        )
    }
}
