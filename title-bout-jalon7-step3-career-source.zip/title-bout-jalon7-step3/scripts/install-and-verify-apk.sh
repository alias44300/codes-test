#!/usr/bin/env bash
set -euo pipefail
APK="${1:-app/build/outputs/apk/debug/app-debug.apk}"
command -v adb >/dev/null 2>&1 || { echo "adb absent" >&2; exit 2; }
test -s "$APK" || { echo "APK absent: $APK" >&2; exit 3; }
adb devices
adb install -r "$APK"
adb shell am force-stop com.titlefight.simulator
adb shell monkey -p com.titlefight.simulator -c android.intent.category.LAUNCHER 1
sleep 2
adb shell pidof com.titlefight.simulator
printf 'Installation et lancement vérifiés.\n'
