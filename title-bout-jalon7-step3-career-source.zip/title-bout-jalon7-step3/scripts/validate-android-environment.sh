#!/usr/bin/env bash
set -euo pipefail
fail=0
check() { if command -v "$1" >/dev/null 2>&1; then printf 'OK   %s: %s\n' "$1" "$(command -v "$1")"; else printf 'ABSENT %s\n' "$1"; fail=1; fi; }
check java
check curl
check unzip
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [ -z "$SDK" ]; then echo "ABSENT ANDROID_SDK_ROOT/ANDROID_HOME"; fail=1
else
  echo "SDK  $SDK"
  test -f "$SDK/platforms/android-37/android.jar" || { echo "ABSENT platforms;android-37"; fail=1; }
  test -x "$SDK/build-tools/36.0.0/aapt2" || { echo "ABSENT build-tools;36.0.0"; fail=1; }
fi
exit "$fail"
