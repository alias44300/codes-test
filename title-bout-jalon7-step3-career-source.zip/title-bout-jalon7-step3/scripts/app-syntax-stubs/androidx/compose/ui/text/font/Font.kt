package androidx.compose.ui.text.font
class FontWeight { companion object { val Black = FontWeight(); val Bold = FontWeight() } }
