package titlefight

import kotlin.math.abs

enum class TacticalPace { CAUTIOUS, MEASURED, SUSTAINED }
enum class TacticalDistance { LONG, MEDIUM, CLOSE }
enum class TacticalTarget { HEAD, BODY, MIXED }
enum class TacticalRisk { SAFE, BALANCED, AGGRESSIVE }

/**
 * Modificateurs descriptifs et bornés d'un plan tactique.
 *
 * Ils sont appliqués uniquement lorsque `FightEngine(adaptiveTacticsEnabled = true)`
 * est utilisé. Le mode par défaut reste désactivé afin de préserver exactement
 * les audits historiques des jalons précédents.
 */
data class TacticalPlanModifiers(
    val activityDelta: Double,
    val accuracyDelta: Double,
    val defenseDelta: Double,
    val impactDelta: Double,
    val staminaCostDelta: Double,
    val preferredRangeControlDelta: Double,
    val headTargetShare: Double,
    val bodyTargetShare: Double,
) {
    init {
        require(activityDelta in MIN_ACTIVITY_DELTA..MAX_ACTIVITY_DELTA)
        require(accuracyDelta in MIN_ACCURACY_DELTA..MAX_ACCURACY_DELTA)
        require(defenseDelta in MIN_DEFENSE_DELTA..MAX_DEFENSE_DELTA)
        require(impactDelta in MIN_IMPACT_DELTA..MAX_IMPACT_DELTA)
        require(staminaCostDelta in MIN_STAMINA_COST_DELTA..MAX_STAMINA_COST_DELTA)
        require(preferredRangeControlDelta in MIN_RANGE_CONTROL_DELTA..MAX_RANGE_CONTROL_DELTA)
        require(headTargetShare in MIN_TARGET_SHARE..MAX_TARGET_SHARE)
        require(bodyTargetShare in MIN_TARGET_SHARE..MAX_TARGET_SHARE)
        require(abs(headTargetShare + bodyTargetShare - 1.0) <= EPSILON) {
            "Les parts de cible tête et corps doivent totaliser 100 %."
        }
    }

    companion object {
        const val MIN_ACTIVITY_DELTA = -0.15
        const val MAX_ACTIVITY_DELTA = 0.15
        const val MIN_ACCURACY_DELTA = -0.10
        const val MAX_ACCURACY_DELTA = 0.10
        const val MIN_DEFENSE_DELTA = -0.10
        const val MAX_DEFENSE_DELTA = 0.10
        const val MIN_IMPACT_DELTA = -0.12
        const val MAX_IMPACT_DELTA = 0.12
        const val MIN_STAMINA_COST_DELTA = -0.12
        const val MAX_STAMINA_COST_DELTA = 0.18
        const val MIN_RANGE_CONTROL_DELTA = 0.04
        const val MAX_RANGE_CONTROL_DELTA = 0.12
        const val MIN_TARGET_SHARE = 0.20
        const val MAX_TARGET_SHARE = 0.80
        private const val EPSILON = 1e-9
    }
}

data class TacticalPlan(
    val anchorStyle: BoxingStyle,
    val pace: TacticalPace,
    val distance: TacticalDistance,
    val target: TacticalTarget,
    val risk: TacticalRisk,
    val modifiers: TacticalPlanModifiers = TacticalPlanModifierFactory.derive(pace, distance, target, risk),
) {
    init {
        require(modifiers == TacticalPlanModifierFactory.derive(pace, distance, target, risk)) {
            "Les modificateurs doivent correspondre exactement aux quatre choix tactiques."
        }
    }

    val id: String
        get() = listOf(anchorStyle, pace, distance, target, risk).joinToString("-") { it.name.lowercase() }
}

object TacticalPlanModifierFactory {
    fun derive(
        pace: TacticalPace,
        distance: TacticalDistance,
        target: TacticalTarget,
        risk: TacticalRisk,
    ): TacticalPlanModifiers {
        val paceEffect = when (pace) {
            TacticalPace.CAUTIOUS -> ComponentEffect(
                activity = -0.10,
                accuracy = 0.02,
                defense = 0.02,
                impact = -0.02,
                staminaCost = -0.10,
            )
            TacticalPace.MEASURED -> ComponentEffect()
            TacticalPace.SUSTAINED -> ComponentEffect(
                activity = 0.12,
                accuracy = -0.02,
                defense = -0.02,
                impact = 0.02,
                staminaCost = 0.15,
            )
        }
        val riskEffect = when (risk) {
            TacticalRisk.SAFE -> ComponentEffect(
                activity = -0.02,
                accuracy = 0.03,
                defense = 0.06,
                impact = -0.07,
                staminaCost = -0.02,
            )
            TacticalRisk.BALANCED -> ComponentEffect()
            TacticalRisk.AGGRESSIVE -> ComponentEffect(
                activity = 0.03,
                accuracy = -0.04,
                defense = -0.08,
                impact = 0.10,
                staminaCost = 0.03,
            )
        }
        val rangeControl = when (distance) {
            TacticalDistance.LONG -> 0.10
            TacticalDistance.MEDIUM -> 0.08
            TacticalDistance.CLOSE -> 0.10
        }
        val targetShares = when (target) {
            TacticalTarget.HEAD -> 0.72 to 0.28
            TacticalTarget.BODY -> 0.28 to 0.72
            TacticalTarget.MIXED -> 0.50 to 0.50
        }

        return TacticalPlanModifiers(
            activityDelta = normalized(paceEffect.activity + riskEffect.activity),
            accuracyDelta = normalized(paceEffect.accuracy + riskEffect.accuracy),
            defenseDelta = normalized(paceEffect.defense + riskEffect.defense),
            impactDelta = normalized(paceEffect.impact + riskEffect.impact),
            staminaCostDelta = normalized(paceEffect.staminaCost + riskEffect.staminaCost),
            preferredRangeControlDelta = rangeControl,
            headTargetShare = targetShares.first,
            bodyTargetShare = targetShares.second,
        )
    }

    private fun normalized(value: Double): Double = kotlin.math.round(value * 1_000_000.0) / 1_000_000.0

    private data class ComponentEffect(
        val activity: Double = 0.0,
        val accuracy: Double = 0.0,
        val defense: Double = 0.0,
        val impact: Double = 0.0,
        val staminaCost: Double = 0.0,
    )
}

object TacticalPlanCatalog {
    private val naturalPlans: Map<BoxingStyle, TacticalPlan> = mapOf(
        BoxingStyle.OUT_BOXER to TacticalPlan(
            anchorStyle = BoxingStyle.OUT_BOXER,
            pace = TacticalPace.MEASURED,
            distance = TacticalDistance.LONG,
            target = TacticalTarget.MIXED,
            risk = TacticalRisk.SAFE,
        ),
        BoxingStyle.PRESSURE_FIGHTER to TacticalPlan(
            anchorStyle = BoxingStyle.PRESSURE_FIGHTER,
            pace = TacticalPace.SUSTAINED,
            distance = TacticalDistance.CLOSE,
            target = TacticalTarget.BODY,
            risk = TacticalRisk.BALANCED,
        ),
        BoxingStyle.COUNTERPUNCHER to TacticalPlan(
            anchorStyle = BoxingStyle.COUNTERPUNCHER,
            pace = TacticalPace.CAUTIOUS,
            distance = TacticalDistance.MEDIUM,
            target = TacticalTarget.HEAD,
            risk = TacticalRisk.SAFE,
        ),
        BoxingStyle.BOXER_PUNCHER to TacticalPlan(
            anchorStyle = BoxingStyle.BOXER_PUNCHER,
            pace = TacticalPace.MEASURED,
            distance = TacticalDistance.MEDIUM,
            target = TacticalTarget.MIXED,
            risk = TacticalRisk.BALANCED,
        ),
        BoxingStyle.SWARMER to TacticalPlan(
            anchorStyle = BoxingStyle.SWARMER,
            pace = TacticalPace.SUSTAINED,
            distance = TacticalDistance.CLOSE,
            target = TacticalTarget.MIXED,
            risk = TacticalRisk.AGGRESSIVE,
        ),
        BoxingStyle.SLUGGER to TacticalPlan(
            anchorStyle = BoxingStyle.SLUGGER,
            pace = TacticalPace.MEASURED,
            distance = TacticalDistance.MEDIUM,
            target = TacticalTarget.HEAD,
            risk = TacticalRisk.AGGRESSIVE,
        ),
        BoxingStyle.DEFENSIVE_SPECIALIST to TacticalPlan(
            anchorStyle = BoxingStyle.DEFENSIVE_SPECIALIST,
            pace = TacticalPace.CAUTIOUS,
            distance = TacticalDistance.LONG,
            target = TacticalTarget.MIXED,
            risk = TacticalRisk.SAFE,
        ),
    )

    init {
        require(naturalPlans.keys == BoxingStyle.entries.toSet()) {
            "Chaque style de boxe doit posséder un plan naturel."
        }
        require(naturalPlans.values.all { it.anchorStyle in naturalPlans.keys })
        require(naturalPlans.all { (style, plan) -> style == plan.anchorStyle })
    }

    fun naturalFor(profile: BoxerProfile): TacticalPlan = naturalFor(profile.style)

    fun naturalFor(style: BoxingStyle): TacticalPlan = requireNotNull(naturalPlans[style])

    fun allNaturalPlans(): List<TacticalPlan> = BoxingStyle.entries.map(::naturalFor)
}
