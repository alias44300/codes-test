package titlefight.app
import androidx.compose.runtime.Composable
import titlefight.BoxerProfile
import titlefight.CareerCreationRequest
import titlefight.CareerOpponent
import titlefight.CareerState
import titlefight.TrainingFocus
import titlefight.WeightClass
@Composable fun HomeScreen(rosterCount: Int, databaseVersion: String, onQuickFight: () -> Unit, onCareer: () -> Unit) {}
@Composable fun RosterSelectionScreen(
    profiles: List<BoxerProfile>, query: String, red: BoxerProfile?, blue: BoxerProfile?, databaseVersion: String,
    onQueryChange: (String) -> Unit, onSelectRed: (BoxerProfile) -> Unit, onSelectBlue: (BoxerProfile) -> Unit,
    onStartFight: () -> Unit,
) {}
@Composable fun CareerCreationScreen(onCreate: (CareerCreationRequest) -> Unit, onBack: () -> Unit) {}
@Composable fun CareerDashboardScreen(
    state: CareerState, opponents: List<CareerOpponent>, onFight: (CareerOpponent) -> Unit,
    onTrain: (TrainingFocus) -> Unit, onRest: () -> Unit, onMoveDivision: (WeightClass) -> Unit,
    onRetire: () -> Unit, onBack: () -> Unit,
) {}
