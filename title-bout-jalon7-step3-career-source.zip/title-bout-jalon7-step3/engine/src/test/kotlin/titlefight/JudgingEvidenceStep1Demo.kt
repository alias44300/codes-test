package titlefight

import java.util.Locale

object JudgingEvidenceStep1Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        Locale.setDefault(Locale.FRANCE)
        val round = FightEngine(stopOnTenCount = false, stopOnTko = false).simulateRound(
            roundNumber = 1,
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redStart = FighterState(),
            blueStart = FighterState(),
            redTactic = Tactic.CONTROL,
            blueTactic = Tactic.PRESS,
            seed = 202607210427L,
        )

        println("TITLE FIGHT — PREUVES DU ROUND ${round.roundNumber}")
        println("Graine : ${round.seed}")
        println("Séquences : ${round.judgingEvidence.sequenceCount}")
        println()
        printEvidence("Coin rouge", TestProfiles.eliasVega.name, round.judgingEvidence.red)
        println()
        printEvidence("Coin bleu", TestProfiles.brunoKessler.name, round.judgingEvidence.blue)
        println()
        println("Aucun score de juge n’est calculé à cette étape.")
    }

    private fun printEvidence(corner: String, name: String, evidence: FighterRoundJudgingEvidence) {
        println("$corner — $name")
        println("Initiatives : ${evidence.initiatedSequences}")
        println("Séquences efficaces : ${evidence.effectiveSequences}")
        println("Coups nets : ${evidence.cleanHits}")
        println("Impact total : ${"%.2f".format(evidence.totalImpact)}")
        println("Impact net : ${"%.2f".format(evidence.cleanImpact)}")
        println("Réussites défensives : ${evidence.defensiveSuccesses}")
        println("Part à distance préférée : ${"%.1f".format(evidence.preferredRangeShare * 100.0)} %")
        println("Travail au corps : ${evidence.bodyShotsLanded} touches, impact ${"%.2f".format(evidence.bodyImpact)}")
        println("Knockdowns provoqués : ${evidence.knockdownsScored}")
    }
}
