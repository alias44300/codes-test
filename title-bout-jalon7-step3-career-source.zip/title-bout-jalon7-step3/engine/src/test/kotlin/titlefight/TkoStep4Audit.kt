package titlefight

import java.util.Locale
import kotlin.math.abs

data class TkoStep4AuditResult(
    val fightCount: Int,
    val tkoCount: Int,
    val koCount: Int,
    val completedWithoutStoppage: Int,
    val invalidTkoStoppages: Int,
    val fightsContinuingAfterStoppage: Int,
    val eventsAfterStoppage: Int,
    val redCornerTkos: Int,
    val blueCornerTkos: Int,
    val tkoRoundTotal: Int,
    val tkoSequenceTotal: Int,
    val minimumFailureStreakAtTko: Int,
    val maximumFailureStreakAtTko: Int,
) {
    init {
        require(fightCount == tkoCount + koCount + completedWithoutStoppage)
        require(redCornerTkos + blueCornerTkos == tkoCount)
        require(invalidTkoStoppages >= 0)
        require(fightsContinuingAfterStoppage >= 0)
        require(eventsAfterStoppage >= 0)
    }

    val averageTkoRound: Double get() = if (tkoCount == 0) 0.0 else tkoRoundTotal.toDouble() / tkoCount
    val averageTkoSequence: Double get() = if (tkoCount == 0) 0.0 else tkoSequenceTotal.toDouble() / tkoCount
    val cornerGap: Int get() = abs(redCornerTkos - blueCornerTkos)
}

object TkoStep4Scenario {
    val protectedProfile: BoxerProfile = TestProfiles.eliasVega.copy(
        defense = 52,
        mobility = 54,
        chin = 98,
        recovery = 98,
        mental = 94,
        bodyResistance = 96,
    )

    val compromisedState: FighterState = FighterState(
        stamina = 20.0,
        headDamage = 76.0,
        bodyDamage = 50.0,
        stability = 22.0,
    )

    fun fight(seed: Long, attackerInRed: Boolean): FightResult {
        val engine = FightEngine()
        return if (attackerInRed) {
            engine.simulateThreeRoundFight(
                red = TestProfiles.brunoKessler,
                blue = protectedProfile,
                redTactics = List(3) { Tactic.SEEK_KO },
                blueTactics = List(3) { Tactic.RECOVER },
                seed = seed,
                redStart = FighterState(),
                blueStart = compromisedState,
            )
        } else {
            engine.simulateThreeRoundFight(
                red = protectedProfile,
                blue = TestProfiles.brunoKessler,
                redTactics = List(3) { Tactic.RECOVER },
                blueTactics = List(3) { Tactic.SEEK_KO },
                seed = seed,
                redStart = compromisedState,
                blueStart = FighterState(),
            )
        }
    }
}

object TkoStep4Auditor {
    fun run(fightCount: Int = 1000, seedStart: Long = 2026076000L): TkoStep4AuditResult {
        require(fightCount == 1000)

        var tkoCount = 0
        var koCount = 0
        var completed = 0
        var invalidTko = 0
        var continuing = 0
        var eventsAfter = 0
        var redTkos = 0
        var blueTkos = 0
        var roundTotal = 0
        var sequenceTotal = 0
        var minimumFailure = Int.MAX_VALUE
        var maximumFailure = 0

        repeat(fightCount) { index ->
            val fight = TkoStep4Scenario.fight(seedStart + index, attackerInRed = index % 2 == 0)
            val stoppage = fight.stoppage
            if (stoppage == null) {
                completed++
                return@repeat
            }

            val stoppedRound = fight.rounds.getOrNull(stoppage.roundNumber - 1)
            val lastEvent = stoppedRound?.events?.lastOrNull()
            val laterRounds = fight.rounds.drop(stoppage.roundNumber)
            val sameRoundEventsAfter = stoppedRound?.events?.count { it.sequenceNumber > stoppage.sequenceNumber } ?: 0
            val laterEvents = laterRounds.sumOf { it.events.size }
            val after = sameRoundEventsAfter + laterEvents
            eventsAfter += after
            if (laterRounds.isNotEmpty() || after > 0) continuing++

            if (stoppage.method == FightMethod.KO) {
                koCount++
                return@repeat
            }

            tkoCount++
            if (stoppage.winnerId == fight.redId) redTkos++ else blueTkos++
            roundTotal += stoppage.roundNumber
            sequenceTotal += stoppage.sequenceNumber

            val loserState = if (stoppage.loserId == fight.redId) stoppedRound?.redState else stoppedRound?.blueState
            val failure = loserState?.defensiveFailureStreak ?: 0
            minimumFailure = minOf(minimumFailure, failure)
            maximumFailure = maxOf(maximumFailure, failure)

            val safety = if (lastEvent == null || loserState == null) null else TkoSafetyDetector.evaluate(loserState, lastEvent)
            val valid = stoppedRound != null && lastEvent != null && loserState != null && safety != null &&
                stoppage.method == FightMethod.TKO &&
                fight.rounds.size == stoppage.roundNumber &&
                fight.rounds.last().stoppage == stoppage &&
                stoppedRound.stoppage == stoppage &&
                lastEvent.sequenceNumber == stoppage.sequenceNumber &&
                lastEvent.attackerId == stoppage.winnerId &&
                lastEvent.defenderId == stoppage.loserId &&
                lastEvent.landed &&
                lastEvent.knockdown == null &&
                safety.eligible &&
                stoppage.reason == safety.reason
            if (!valid) invalidTko++
        }

        return TkoStep4AuditResult(
            fightCount = fightCount,
            tkoCount = tkoCount,
            koCount = koCount,
            completedWithoutStoppage = completed,
            invalidTkoStoppages = invalidTko,
            fightsContinuingAfterStoppage = continuing,
            eventsAfterStoppage = eventsAfter,
            redCornerTkos = redTkos,
            blueCornerTkos = blueTkos,
            tkoRoundTotal = roundTotal,
            tkoSequenceTotal = sequenceTotal,
            minimumFailureStreakAtTko = if (tkoCount == 0) 0 else minimumFailure,
            maximumFailureStreakAtTko = maximumFailure,
        )
    }
}

object TkoStep4AuditFormatter {
    fun format(result: TkoStep4AuditResult): String = buildString {
        appendLine("TITLE FIGHT — Jalon 2, étape 4")
        appendLine("Audit technique de l’arrêt de sécurité par TKO")
        appendLine()
        appendLine("Scénarios à haut risque : ${result.fightCount}")
        appendLine("Combats terminés par TKO : ${result.tkoCount}")
        appendLine("Combats terminés par KO : ${result.koCount}")
        appendLine("Combats sans arrêt : ${result.completedWithoutStoppage}")
        appendLine("TKO invalides : ${result.invalidTkoStoppages}")
        appendLine("Combats ayant continué après arrêt : ${result.fightsContinuingAfterStoppage}")
        appendLine("Événements calculés après arrêt : ${result.eventsAfterStoppage}")
        appendLine("TKO coin rouge / bleu : ${result.redCornerTkos} / ${result.blueCornerTkos}")
        appendLine("Écart absolu entre les coins : ${result.cornerGap}")
        appendLine("Round moyen du TKO : ${decimal(result.averageTkoRound)}")
        appendLine("Séquence moyenne du TKO : ${decimal(result.averageTkoSequence)}")
        appendLine("Échecs défensifs consécutifs au TKO, min / max : ${result.minimumFailureStreakAtTko} / ${result.maximumFailureStreakAtTko}")
        appendLine()
        appendLine("Seuils techniques : au moins ${TkoSafetyDetector.MIN_FAILURE_STREAK} impacts lourds sans réponse, stabilité ≤ ${decimal(TkoSafetyDetector.MAX_STABILITY)}, énergie ≤ ${decimal(TkoSafetyDetector.MAX_STAMINA)}, dégâts tête ≥ ${decimal(TkoSafetyDetector.MIN_HEAD_DAMAGE)} ou corps ≥ ${decimal(TkoSafetyDetector.MIN_BODY_DAMAGE)}.")
        appendLine("Cet audit utilise un état volontairement compromis. L’équilibrage final des fréquences reste réservé à l’étape 5.")
        appendLine("Les juges restent désactivés.")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
}

object TkoStep4AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        print(TkoStep4AuditFormatter.format(TkoStep4Auditor.run()))
    }
}
