# Jalon 5 — Étape 1 — Catalogue des dix profils

## Objectif

Étendre le roster fictif de deux à dix boxeurs sans lancer encore d’audit de confrontation ni modifier l’équilibrage du moteur.

## Profils ajoutés

- Malik Okoro, counterpuncher, garde southpaw ;
- Tomas Aranda, boxer-puncher, garde orthodoxe ;
- Darius Cole, swarmer, garde orthodoxe ;
- Viktor Sokolov, slugger, garde orthodoxe ;
- Kenji Mori, defensive specialist, garde southpaw ;
- Luca Moretti, out-boxer, garde switch ;
- Idris Kane, pressure fighter, garde southpaw ;
- Mateo Silva, boxer-puncher, garde switch.

Elias Vega et Bruno Kessler sont conservés sans modification de leurs statistiques de combat.

## Modèle enrichi

`BoxerProfile` possède maintenant une taille et une allonge. Les limites sont validées à la construction, en plus des douze valeurs statistiques déjà bornées entre 1 et 100.

## Catalogue

`BoxerCatalog` garantit :

- exactement dix profils ;
- dix identifiants, noms et surnoms uniques ;
- les sept styles représentés ;
- les trois gardes représentées ;
- une distance préférée cohérente avec le style ;
- une recherche stable par identifiant.

## Validation

- 95 tests automatisés ;
- audit dédié du catalogue ;
- 0 dimension invalide ;
- 0 statistique invalide ;
- 0 incohérence style/distance ;
- 0 erreur de recherche ;
- 0 empreinte historique modifiée.

## Hors périmètre

- aucun combat de matrice ;
- aucune comparaison de puissance entre profils ;
- aucune calibration ;
- aucun boxeur réel ;
- aucun écran Android ;
- aucun APK.
