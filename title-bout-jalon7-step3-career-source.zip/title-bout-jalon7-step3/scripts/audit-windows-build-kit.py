#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
checks: list[tuple[str, bool, str]] = []

def check(name: str, ok: bool, detail: str = "") -> None:
    checks.append((name, bool(ok), detail))

def text(path: str) -> str:
    return (ROOT / path).read_text(encoding="utf-8")

required = [
    "BUILD_TITLE_FIGHT_WINDOWS.ps1",
    "BUILD_TITLE_FIGHT_WINDOWS.cmd",
    "COMPILATION_WINDOWS.md",
    "APRES_COMPILATION_ENVOYER_CES_FICHIERS.txt",
    "scripts/bootstrap-android-sdk.ps1",
    "scripts/audit-windows-build-kit.py",
    "gradlew.bat",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
]
for path in required:
    check(f"file:{path}", (ROOT / path).is_file())

ps1 = text("BUILD_TITLE_FIGHT_WINDOWS.ps1")
cmd = text("BUILD_TITLE_FIGHT_WINDOWS.cmd")
manifest = text("app/src/main/AndroidManifest.xml")
checks_expected = {
    "strict-mode": "Set-StrictMode -Version Latest" in ps1,
    "java-17": "Temurin.17.JDK" in ps1 and "major -lt 17" in ps1,
    "sdk-bootstrap": "bootstrap-android-sdk.ps1" in ps1,
    "sdk-37": "android-37" in ps1,
    "build-tools-36": 'BuildToolsVersion = "36.0.0"' in ps1,
    "engine-tests": ":engine:test" in ps1,
    "ui-tests": ":android-ui-compose:testDebugUnitTest" in ps1,
    "app-tests": ":app:testDebugUnitTest" in ps1,
    "assemble-debug": ":app:assembleDebug" in ps1,
    "apk-exists": "app\\build\\outputs\\apk\\debug\\app-debug.apk" in ps1,
    "sha256": "Get-FileHash" in ps1 and "SHA256" in ps1,
    "apksigner": "apksigner.bat" in ps1 and "--print-certs" in ps1,
    "adb-install": '"install", "-r", "-t"' in ps1,
    "adb-launch": '"am", "start", "-W"' in ps1,
    "process-check": "shell pidof" in ps1,
    "double-click-launcher": "BUILD_TITLE_FIGHT_WINDOWS.ps1" in cmd,
    "correct-package": 'PackageName = "com.titlefight.simulator"' in ps1,
    "correct-activity": 'ActivityName = "titlefight.app.MainActivity"' in ps1,
    "manifest-package-launcher": 'android.intent.category.LAUNCHER' in manifest,
    "no-network-permission": "android.permission.INTERNET" not in manifest,
    "reports-json": "build-report.json" in ps1,
    "reports-text": "build-report.txt" in ps1,
    "no-fake-success": 'Status = "FAILED"' in ps1 and "BUILD_INSTALL_LAUNCH_VERIFIED" in ps1,
}
for name, ok in checks_expected.items():
    check(name, ok)

# Basic delimiter sanity, not a PowerShell compiler replacement.
check("balanced-braces", ps1.count("{") == ps1.count("}"), f"{ps1.count('{')} / {ps1.count('}')}")
check("balanced-parentheses", ps1.count("(") == ps1.count(")"), f"{ps1.count('(')} / {ps1.count(')')}")
check("no-placeholder", not re.search(r"TODO|FIXME|CHANGEME", ps1, re.I))

failed = [(n, d) for n, ok, d in checks if not ok]
digest = hashlib.sha256("\n".join(f"{n}:{ok}:{d}" for n, ok, d in checks).encode()).hexdigest()
result = {
    "checks": len(checks),
    "passed": len(checks) - len(failed),
    "failed": len(failed),
    "digest": digest,
    "failures": [{"name": n, "detail": d} for n, d in failed],
}
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(1 if failed else 0)
