package titlefight

import java.security.MessageDigest
import java.util.Locale

data class Jalon6Step1AuditResult(
    val fights: Int,
    val screenStates: Int,
    val actionStates: Int,
    val betweenRoundStates: Int,
    val completedStates: Int,
    val decisionFights: Int,
    val koFights: Int,
    val tkoFights: Int,
    val reproducibilityChecks: Int,
    val reproducibilityErrors: Int,
    val frameErrors: Int,
    val phaseErrors: Int,
    val clockErrors: Int,
    val tacticalWindowErrors: Int,
    val judgeLeakFields: Int,
    val legacyFingerprintMismatches: Int,
    val digest: String,
)

object Jalon6Step1Auditor {
    fun run(fights: Int = 500): Jalon6Step1AuditResult {
        require(fights >= 100)
        val roster = BoxerCatalog.all
        var screenStates = 0
        var actionStates = 0
        var betweenRoundStates = 0
        var completedStates = 0
        var decisions = 0
        var kos = 0
        var tkos = 0
        var reproducibilityChecks = 0
        var reproducibilityErrors = 0
        var frameErrors = 0
        var phaseErrors = 0
        var clockErrors = 0
        var tacticalWindowErrors = 0
        val digestLines = mutableListOf<String>()

        repeat(fights) { index ->
            val red = roster[index % roster.size]
            var blue = roster[(index * 3 + 1) % roster.size]
            if (blue.id == red.id) blue = roster[(roster.indexOf(blue) + 1) % roster.size]
            val seed = 6_000_000L + index
            val result = fight(red, blue, seed)
            val timeline = FightScreenStateMapper.buildTimeline(result, red, blue)

            screenStates += timeline.size
            actionStates += timeline.count { it.currentAction != null }
            betweenRoundStates += timeline.count { it.phase == FightScreenPhase.BETWEEN_ROUNDS }
            completedStates += timeline.count { it.phase == FightScreenPhase.COMPLETE }
            when (result.stoppage?.method) {
                FightMethod.KO -> kos++
                FightMethod.TKO -> tkos++
                null -> decisions++
            }

            if (result.rounds.any { it.sequenceFrames.size != it.events.size }) frameErrors++
            if (timeline.first().phase != FightScreenPhase.PRE_FIGHT || timeline.last().phase != FightScreenPhase.COMPLETE ||
                timeline.count { it.phase == FightScreenPhase.COMPLETE } != 1
            ) phaseErrors++
            if (timeline.any { it.clock.remainingSeconds !in 0..180 }) clockErrors++
            if (timeline.any { it.tacticalWindowOpen != (it.phase == FightScreenPhase.BETWEEN_ROUNDS) }) tacticalWindowErrors++

            timeline.filter { it.currentAction != null }.groupBy { it.roundNumber }.values.forEach { roundStates ->
                if (roundStates.zipWithNext().any { (a, b) -> b.clock.remainingSeconds > a.clock.remainingSeconds }) {
                    clockErrors++
                }
            }

            if (index < 100) {
                reproducibilityChecks++
                val replay = fight(red, blue, seed)
                val replayTimeline = FightScreenStateMapper.buildTimeline(replay, red, blue)
                if (result != replay || timeline != replayTimeline) reproducibilityErrors++
            }

            digestLines += listOf(
                red.id,
                blue.id,
                seed,
                result.stoppage?.method ?: result.officialDecision?.type,
                timeline.size,
                timeline.last().result?.headline,
                timeline.last().red.stamina,
                timeline.last().blue.stamina,
            ).joinToString("|")
        }

        val forbidden = listOf("judge", "scorecard", "redcards", "bluecards", "drawcards")
        val judgeLeakFields = listOf(
            FightScreenState::class.java,
            FighterScreenState::class.java,
            FightResultScreenState::class.java,
            FightActionScreenState::class.java,
        ).flatMap { it.declaredFields.toList() }
            .count { field -> forbidden.any { token -> token in field.name.lowercase(Locale.ROOT) } }

        return Jalon6Step1AuditResult(
            fights = fights,
            screenStates = screenStates,
            actionStates = actionStates,
            betweenRoundStates = betweenRoundStates,
            completedStates = completedStates,
            decisionFights = decisions,
            koFights = kos,
            tkoFights = tkos,
            reproducibilityChecks = reproducibilityChecks,
            reproducibilityErrors = reproducibilityErrors,
            frameErrors = frameErrors,
            phaseErrors = phaseErrors,
            clockErrors = clockErrors,
            tacticalWindowErrors = tacticalWindowErrors,
            judgeLeakFields = judgeLeakFields,
            legacyFingerprintMismatches = legacyFingerprintMismatches(),
            digest = sha256(digestLines.joinToString("\n")),
        )
    }

    private fun legacyFingerprintMismatches(): Int {
        val expected = mapOf(
            1L to "5e0dac367189c13856a78537660bad7edad12e30040961406e86350db022def4",
            20260720L to "fc3c6380916855f11798432a3f61e6a8ddea2de2164c9754a82878825e5a2461",
            999999L to "98539b55b5b4dfc5cf00cc12bba192bebf7abd82ab0553c1fb1ad0d74b4e6788",
        )
        return expected.count { (seed, expectedHash) -> legacyFingerprint(seed) != expectedHash }
    }

    private fun legacyFingerprint(seed: Long): String {
        val fight = FightEngine().simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = seed,
        )
        val canonical = buildString {
            append(fight.redId).append('|').append(fight.blueId).append('|').append(fight.seed).append('\n')
            fight.rounds.forEach { round ->
                append(round.roundNumber).append('|').append(round.seed).append('|')
                append(round.redState).append('|').append(round.blueState).append('|')
                append(round.redRoundScore).append('|').append(round.blueRoundScore).append('|')
                append(round.stoppage).append('\n')
                round.events.forEach { event ->
                    append(event.sequenceNumber).append('|').append(event.attackerId).append('|').append(event.defenderId).append('|')
                    append(event.range).append('|').append(event.punch).append('|').append(event.landed).append('|').append(event.clean).append('|')
                    append(event.impact).append('|').append(event.knockdown).append('\n')
                }
            }
            append(fight.finalRedState).append('|').append(fight.finalBlueState).append('|')
            append(fight.redPerformanceTotal).append('|').append(fight.bluePerformanceTotal).append('|')
            append(fight.stoppage).append('|').append(fight.officialDecision)
        }
        return sha256(canonical)
    }

    private fun fight(red: BoxerProfile, blue: BoxerProfile, seed: Long): FightResult =
        FightEngine(adaptiveTacticsEnabled = true).simulateThreeRoundFight(
            red = red,
            blue = blue,
            redTactics = List(3) { legacyTactic(red.style) },
            blueTactics = List(3) { legacyTactic(blue.style) },
            seed = seed,
        )

    private fun legacyTactic(style: BoxingStyle): Tactic = when (style) {
        BoxingStyle.OUT_BOXER -> Tactic.CONTROL
        BoxingStyle.PRESSURE_FIGHTER -> Tactic.PRESS
        BoxingStyle.COUNTERPUNCHER -> Tactic.COUNTER
        BoxingStyle.BOXER_PUNCHER -> Tactic.CONTROL
        BoxingStyle.SWARMER -> Tactic.PRESS
        BoxingStyle.SLUGGER -> Tactic.SEEK_KO
        BoxingStyle.DEFENSIVE_SPECIALIST -> Tactic.RECOVER
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray())
        .joinToString("") { "%02x".format(it) }
}

object Jalon6Step1Test {
    @JvmStatic
    fun main(args: Array<String>) {
        timelineIsDeterministicAndComplete()
        everySequenceHasAnExactObservationFrame()
        tacticalWindowOpensOnlyBetweenRounds()
        clockIsBoundedAndMonotonic()
        exactJudgeCardsAreNeverExposed()
        officialDecisionIsRepresentedWithoutScorecards()
        koIsRepresentedAtTheStoppingSequence()
        tkoIsRepresentedAtTheStoppingSequence()
        auditIsCleanAndReproducible()
        println("9 tests Jalon 6 étape 1 réussis")
    }

    private fun timelineIsDeterministicAndComplete() {
        val (result, red, blue) = distanceFight(20260721L)
        val first = FightScreenStateMapper.buildTimeline(result, red, blue)
        val second = FightScreenStateMapper.buildTimeline(distanceFight(20260721L).first, red, blue)
        check(first == second)
        check(first.first().phase == FightScreenPhase.PRE_FIGHT)
        check(first.last().phase == FightScreenPhase.COMPLETE)
        check(first.count { it.phase == FightScreenPhase.BETWEEN_ROUNDS } == 2)
        check(first.count { it.currentAction != null } == 36)
        check(first.size == 40)
    }

    private fun everySequenceHasAnExactObservationFrame() {
        val (result, red, blue) = distanceFight(20260722L)
        val timeline = FightScreenStateMapper.buildTimeline(result, red, blue)
        result.rounds.forEach { round ->
            check(round.sequenceFrames.size == round.events.size)
            val screenActions = timeline.filter { it.roundNumber == round.roundNumber && it.currentAction != null }
            check(screenActions.size == round.sequenceFrames.size)
            round.sequenceFrames.zip(screenActions).forEach { (frame, screen) ->
                check(screen.sequenceNumber == frame.sequenceNumber)
                check(screen.red.stamina == frame.redState.stamina.roundPercent())
                check(screen.blue.stamina == frame.blueState.stamina.roundPercent())
                check(screen.red.headDamage == frame.redState.headDamage.roundPercent())
                check(screen.blue.bodyDamage == frame.blueState.bodyDamage.roundPercent())
                check(screen.currentAction?.punch == frame.event.punch)
            }
        }
    }

    private fun tacticalWindowOpensOnlyBetweenRounds() {
        val (result, red, blue) = distanceFight(20260723L)
        val timeline = FightScreenStateMapper.buildTimeline(result, red, blue)
        check(timeline.filter { it.tacticalWindowOpen }.all { it.phase == FightScreenPhase.BETWEEN_ROUNDS })
        check(timeline.filter { it.phase == FightScreenPhase.BETWEEN_ROUNDS }.all { it.tacticalWindowOpen })
        check(timeline.last().tacticalWindowOpen.not())
    }

    private fun clockIsBoundedAndMonotonic() {
        val (result, red, blue) = distanceFight(20260724L)
        val timeline = FightScreenStateMapper.buildTimeline(result, red, blue)
        check(timeline.all { it.clock.remainingSeconds in 0..180 })
        timeline.filter { it.currentAction != null }.groupBy { it.roundNumber }.forEach { (_, states) ->
            check(states.zipWithNext().all { (a, b) -> b.clock.remainingSeconds <= a.clock.remainingSeconds })
            check(states.last().clock.remainingSeconds == 0)
        }
    }

    private fun exactJudgeCardsAreNeverExposed() {
        val forbidden = listOf("judge", "scorecard", "redcards", "bluecards", "drawcards")
        val fields = listOf(
            FightScreenState::class.java,
            FighterScreenState::class.java,
            FightResultScreenState::class.java,
            FightActionScreenState::class.java,
        ).flatMap { it.declaredFields.toList() }
        check(fields.none { field -> forbidden.any { it in field.name.lowercase(Locale.ROOT) } })
    }

    private fun officialDecisionIsRepresentedWithoutScorecards() {
        val (result, red, blue) = distanceFight(20260725L)
        val final = FightScreenStateMapper.buildTimeline(result, red, blue).last()
        check(final.phase == FightScreenPhase.COMPLETE)
        val screenResult = requireNotNull(final.result)
        check(screenResult.kind in setOf(FightResultKind.DECISION, FightResultKind.DRAW))
        check(result.officialDecision != null)
        check("points" in screenResult.headline.lowercase(Locale.ROOT) || screenResult.kind == FightResultKind.DRAW)
        check(screenResult.detail.isNotBlank())
    }

    private fun koIsRepresentedAtTheStoppingSequence() {
        val (result, red, blue) = findKoFight()
        val final = FightScreenStateMapper.buildTimeline(result, red, blue).last()
        val stop = requireNotNull(result.stoppage)
        check(final.result?.kind == FightResultKind.KO)
        check(final.roundNumber == stop.roundNumber)
        check(final.sequenceNumber == stop.sequenceNumber)
        check(final.currentAction?.knockdown == true)
        check(final.currentAction?.refereeCount == 10)
    }

    private fun tkoIsRepresentedAtTheStoppingSequence() {
        val (result, red, blue) = findTkoFight()
        val final = FightScreenStateMapper.buildTimeline(result, red, blue).last()
        val stop = requireNotNull(result.stoppage)
        check(final.result?.kind == FightResultKind.TKO)
        check(final.roundNumber == stop.roundNumber)
        check(final.sequenceNumber == stop.sequenceNumber)
        check(final.currentAction != null)
    }

    private fun auditIsCleanAndReproducible() {
        val first = Jalon6Step1Auditor.run(500)
        val second = Jalon6Step1Auditor.run(500)
        check(first == second)
        check(first.completedStates == first.fights)
        check(first.reproducibilityChecks == 100)
        check(first.reproducibilityErrors == 0)
        check(first.frameErrors == 0)
        check(first.phaseErrors == 0)
        check(first.clockErrors == 0)
        check(first.tacticalWindowErrors == 0)
        check(first.judgeLeakFields == 0)
        check(first.legacyFingerprintMismatches == 0)
    }

    private fun distanceFight(seed: Long): Triple<FightResult, BoxerProfile, BoxerProfile> {
        val red = TestProfiles.eliasVega
        val blue = TestProfiles.brunoKessler
        for (candidate in seed until seed + 2_000L) {
            val result = FightEngine(adaptiveTacticsEnabled = true).simulateThreeRoundFight(
                red = red,
                blue = blue,
                redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
                blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
                seed = candidate,
            )
            if (result.stoppage == null) return Triple(result, red, blue)
        }
        error("Aucun combat à la distance trouvé.")
    }

    private fun findKoFight(): Triple<FightResult, BoxerProfile, BoxerProfile> {
        val red = TestProfiles.brunoKessler
        val blue = TestProfiles.eliasVega
        for (seed in 1L..20_000L) {
            val result = FightEngine(stopOnTko = false, adaptiveTacticsEnabled = true).simulateThreeRoundFight(
                red = red,
                blue = blue,
                redTactics = List(3) { Tactic.SEEK_KO },
                blueTactics = List(3) { Tactic.RECOVER },
                seed = seed,
                blueStart = FighterState(stamina = 3.0, headDamage = 94.0, bodyDamage = 80.0, stability = 3.0),
            )
            if (result.stoppage?.method == FightMethod.KO) return Triple(result, red, blue)
        }
        error("Aucun KO de test trouvé.")
    }

    private fun findTkoFight(): Triple<FightResult, BoxerProfile, BoxerProfile> {
        val red = TestProfiles.brunoKessler
        val blue = TestProfiles.eliasVega.copy(
            id = "elias-vega-tko-screen",
            defense = 35,
            chin = 35,
            recovery = 35,
            bodyResistance = 35,
        )
        for (seed in 1L..20_000L) {
            val result = FightEngine(adaptiveTacticsEnabled = true).simulateThreeRoundFight(
                red = red,
                blue = blue,
                redTactics = List(3) { Tactic.SEEK_KO },
                blueTactics = List(3) { Tactic.RECOVER },
                seed = seed,
                blueStart = FighterState(
                    stamina = 18.0,
                    headDamage = 76.0,
                    bodyDamage = 62.0,
                    stability = 22.0,
                    defensiveFailureStreak = 2,
                ),
            )
            if (result.stoppage?.method == FightMethod.TKO) return Triple(result, red, blue)
        }
        error("Aucun TKO de test trouvé.")
    }

    private fun Double.roundPercent(): Int = kotlin.math.round(this).toInt().coerceIn(0, 100)
}

object Jalon6Step1AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val audit = Jalon6Step1Auditor.run(500)
        println("TITLE FIGHT — Jalon 6 étape 1 — Audit")
        println("Combats: ${audit.fights}")
        println("États écran: ${audit.screenStates}")
        println("États action: ${audit.actionStates}")
        println("États entre rounds: ${audit.betweenRoundStates}")
        println("États finaux: ${audit.completedStates}")
        println("Décisions / KO / TKO: ${audit.decisionFights} / ${audit.koFights} / ${audit.tkoFights}")
        println("Contrôles reproductibles: ${audit.reproducibilityChecks}")
        println("Erreurs reproductibilité: ${audit.reproducibilityErrors}")
        println("Erreurs frames: ${audit.frameErrors}")
        println("Erreurs phases: ${audit.phaseErrors}")
        println("Erreurs horloge: ${audit.clockErrors}")
        println("Erreurs fenêtre tactique: ${audit.tacticalWindowErrors}")
        println("Champs de fuite juges: ${audit.judgeLeakFields}")
        println("Empreintes historiques modifiées: ${audit.legacyFingerprintMismatches}")
        println("Empreinte: ${audit.digest}")
    }
}
