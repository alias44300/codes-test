plugins {
    alias(libs.plugins.android.library)
}

android {
    namespace = "titlefight.data.local"
    compileSdk = 37

    defaultConfig {
        minSdk = 26
        consumerProguardFiles("consumer-rules.pro")
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(project(":engine"))
    testImplementation(libs.junit4)
    testImplementation(libs.kotlin.test)
}
