package androidx.activity
import android.os.Bundle
open class ComponentActivity { open fun onCreate(savedInstanceState: Bundle?) {} }
