package titlefight.app

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import org.junit.Rule
import org.junit.Test

class MainActivityTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun demoLaunchesAndShowsTacticalPause() {
        composeRule.onNodeWithText("TITLE FIGHT").assertExists()
        composeRule
            .onNodeWithContentDescription("Valider le plan tactique pour le prochain round")
            .assertExists()
    }
}
