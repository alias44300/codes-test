# Jalon 3 — Étape 5 — Audit statistique final

## Objectif

Valider le système des trois juges sur plusieurs fenêtres indépendantes sans ajouter de mécanisme de combat ou de jugement.

## Méthode

- 10 fenêtres indépendantes ;
- 1 000 combats par fenêtre ;
- 10 000 combats au total ;
- 500 paires de graines par fenêtre ;
- chaque paire est simulée deux fois en inversant les coins ;
- mêmes profils et mêmes plans tactiques ;
- vérification de reproductibilité pour chaque combat ;
- contrôle de chaque carte, total et décision officielle.

## Bandes d’acceptation internes

- aucune carte invalide ;
- aucune décision contraire à la majorité ;
- aucune décision manquante à la distance ;
- aucune décision après KO ou TKO ;
- part du coin rouge parmi les décisions avec vainqueur entre 47 % et 53 % ;
- écart de taux de victoire d’un boxeur selon le coin inférieur ou égal à 4 points ;
- écart de points combinés moyens entre juges inférieur ou égal à 0,08 ;
- écart de marge absolue moyenne entre juges inférieur ou égal à 0,25 ;
- écart de fréquence des 10-10 inférieur ou égal à 3 points ;
- écart de cartes favorables à un coin ou à un boxeur inférieur ou égal à 3 points.

## Résultats

- 10 000 combats ;
- 9 976 combats à la distance ;
- 24 arrêts, dont 14 KO et 10 TKO ;
- 9 976 décisions officielles ;
- 8 273 décisions unanimes ;
- 76 décisions partagées ;
- 441 décisions majoritaires ;
- 851 nuls unanimes ;
- 257 nuls majoritaires ;
- 78 nuls partagés ;
- 4 350 victoires du coin rouge ;
- 4 440 victoires du coin bleu ;
- part rouge parmi les décisions avec vainqueur : 49,49 % ;
- écart Vega selon le coin : 0,56 point ;
- écart Kessler selon le coin : 1,24 point ;
- écart maximal de points combinés moyens entre juges : 0,0021 ;
- écart maximal de marge absolue moyenne : 0,0687 ;
- écart maximal de fréquence 10-10 : 0,21 point ;
- écart maximal de cartes rouges : 0,34 point ;
- écart maximal de cartes favorables à Vega : 1,52 point ;
- 0 carte invalide ;
- 0 décision contraire à la majorité ;
- 0 décision manquante ;
- 0 décision après arrêt ;
- 400 contrôles de reproductibilité ;
- 0 écart de reproductibilité.

## Décision

Toutes les bandes d’acceptation sont respectées. Aucun réglage des pondérations ou des règles de score n’est nécessaire.
