package titlefight

import java.util.Locale
import kotlin.math.abs

data class ThresholdWindowResult(
    val seedStart: Long,
    val vegaLeads: Int,
    val kesslerLeads: Int,
    val ties: Int,
    val meanVegaMinusKessler: Double,
    val redLeads: Int,
    val blueLeads: Int,
    val meanRedMinusBlue: Double,
    val vegaAverageStamina: Double,
    val kesslerAverageStamina: Double,
    val vegaAverageHeadDamage: Double,
    val kesslerAverageHeadDamage: Double,
    val vegaAverageBodyDamage: Double,
    val kesslerAverageBodyDamage: Double,
    val vegaAverageStability: Double,
    val kesslerAverageStability: Double,
) {
    init {
        require(vegaLeads + kesslerLeads + ties == 100)
        require(redLeads + blueLeads + ties == 100)
    }
}

data class ThresholdAuditResult(
    val windows: List<ThresholdWindowResult>,
) {
    val totalFights: Int get() = windows.size * 100
    val totalVegaLeads: Int get() = windows.sumOf { it.vegaLeads }
    val totalKesslerLeads: Int get() = windows.sumOf { it.kesslerLeads }
    val totalTies: Int get() = windows.sumOf { it.ties }
    val totalRedLeads: Int get() = windows.sumOf { it.redLeads }
    val totalBlueLeads: Int get() = windows.sumOf { it.blueLeads }
    val meanVegaMinusKessler: Double get() = windows.map { it.meanVegaMinusKessler }.average()
    val meanRedMinusBlue: Double get() = windows.map { it.meanRedMinusBlue }.average()

    init {
        require(windows.size == 10) { "L’audit final exige dix fenêtres indépendantes." }
        require(totalVegaLeads + totalKesslerLeads + totalTies == totalFights)
        require(totalRedLeads + totalBlueLeads + totalTies == totalFights)
    }
}

object ThresholdAuditor {
    private val DEFAULT_SEED_STARTS = listOf(
        2026072000L,
        2026082000L,
        2026092000L,
        2026102000L,
        2026112000L,
        2026122000L,
        2027012000L,
        2027022000L,
        2027032000L,
        2027042000L,
    )

    fun run(seedStarts: List<Long> = DEFAULT_SEED_STARTS): ThresholdAuditResult {
        require(seedStarts.size == 10)
        require(seedStarts.distinct().size == seedStarts.size)

        val windows = seedStarts.map { seedStart ->
            val result = BatchValidator.run(seedStart = seedStart)
            val vegaMinusKessler = result.records.map { it.vegaPerformance - it.kesslerPerformance }
            val redMinusBlue = result.records.map { record ->
                if (record.vegaInRedCorner) {
                    record.vegaPerformance - record.kesslerPerformance
                } else {
                    record.kesslerPerformance - record.vegaPerformance
                }
            }

            ThresholdWindowResult(
                seedStart = seedStart,
                vegaLeads = result.vega.performanceLeads,
                kesslerLeads = result.kessler.performanceLeads,
                ties = result.ties,
                meanVegaMinusKessler = vegaMinusKessler.average(),
                redLeads = redMinusBlue.count { it > 1e-9 },
                blueLeads = redMinusBlue.count { it < -1e-9 },
                meanRedMinusBlue = redMinusBlue.average(),
                vegaAverageStamina = result.vega.averageFinalStamina,
                kesslerAverageStamina = result.kessler.averageFinalStamina,
                vegaAverageHeadDamage = result.vega.averageHeadDamageReceived,
                kesslerAverageHeadDamage = result.kessler.averageHeadDamageReceived,
                vegaAverageBodyDamage = result.vega.averageBodyDamageReceived,
                kesslerAverageBodyDamage = result.kessler.averageBodyDamageReceived,
                vegaAverageStability = result.vega.averageFinalStability,
                kesslerAverageStability = result.kessler.averageFinalStability,
            )
        }
        return ThresholdAuditResult(windows)
    }

    fun assertAcceptable(result: ThresholdAuditResult) {
        result.windows.forEach { window ->
            check(window.vegaLeads in 35..65) {
                "Déséquilibre de performance dans la fenêtre ${window.seedStart}: ${window.vegaLeads}/100 pour Vega."
            }
            check(window.redLeads in 35..65) {
                "Biais de coin excessif dans la fenêtre ${window.seedStart}: ${window.redLeads}/100 pour le coin rouge."
            }
            check(abs(window.meanVegaMinusKessler) <= 5.0) {
                "Écart moyen excessif entre profils dans la fenêtre ${window.seedStart}."
            }
            check(abs(window.meanRedMinusBlue) <= 5.0) {
                "Écart moyen excessif entre coins dans la fenêtre ${window.seedStart}."
            }
            check(window.vegaAverageStamina in 45.0..90.0)
            check(window.kesslerAverageStamina in 35.0..80.0)
            check(window.vegaAverageStability in 35.0..80.0)
            check(window.kesslerAverageStability in 35.0..80.0)
            check(window.vegaAverageBodyDamage > window.kesslerAverageBodyDamage + 8.0)
            check(window.kesslerAverageStamina < window.vegaAverageStamina - 8.0)
        }

        check(result.totalVegaLeads in 450..550)
        check(result.totalKesslerLeads in 450..550)
        check(result.totalRedLeads in 450..550)
        check(result.totalBlueLeads in 450..550)
        check(abs(result.meanVegaMinusKessler) <= 2.0)
        check(abs(result.meanRedMinusBlue) <= 2.0)
    }
}

object ThresholdAuditFormatter {
    fun format(result: ThresholdAuditResult): String = buildString {
        appendLine("TITLE FIGHT — Jalon 1, audit final des seuils")
        appendLine("10 fenêtres indépendantes de 100 combats")
        appendLine("Total : ${result.totalFights} combats, ${result.totalFights * 3} rounds, ${result.totalFights * 36} séquences")
        appendLine()
        appendLine("FENÊTRES")
        result.windows.forEachIndexed { index, window ->
            appendLine(
                "${index + 1}. graines ${window.seedStart}–${window.seedStart + 99} | " +
                    "Vega ${window.vegaLeads}, Kessler ${window.kesslerLeads} | " +
                    "écart moyen ${decimal(window.meanVegaMinusKessler)} | " +
                    "coin rouge ${window.redLeads}, bleu ${window.blueLeads} | " +
                    "écart coin ${decimal(window.meanRedMinusBlue)}"
            )
        }
        appendLine()
        appendLine("AGRÉGAT")
        appendLine("Avantages internes : Vega ${result.totalVegaLeads}, Kessler ${result.totalKesslerLeads}, égalités ${result.totalTies}")
        appendLine("Coins : rouge ${result.totalRedLeads}, bleu ${result.totalBlueLeads}")
        appendLine("Écart moyen Vega − Kessler : ${decimal(result.meanVegaMinusKessler)}")
        appendLine("Écart moyen rouge − bleu : ${decimal(result.meanRedMinusBlue)}")
        appendLine()
        appendLine("DÉCISION")
        appendLine("Aucun micro-réglage du moteur n’est nécessaire au jalon 1.")
        appendLine("Les écarts restent dans les seuils d’acceptation sur les dix fenêtres.")
        appendLine("Le jalon 1 peut être validé sans ajouter de fonctionnalité.")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
}

object ThresholdAuditCsvFormatter {
    fun format(result: ThresholdAuditResult): String = buildString {
        appendLine("seed_start,vega_leads,kessler_leads,ties,mean_vega_minus_kessler,red_leads,blue_leads,mean_red_minus_blue,vega_stamina,kessler_stamina,vega_head_damage,kessler_head_damage,vega_body_damage,kessler_body_damage,vega_stability,kessler_stability")
        result.windows.forEach { window ->
            appendLine(
                listOf(
                    window.seedStart,
                    window.vegaLeads,
                    window.kesslerLeads,
                    window.ties,
                    decimal(window.meanVegaMinusKessler),
                    window.redLeads,
                    window.blueLeads,
                    decimal(window.meanRedMinusBlue),
                    decimal(window.vegaAverageStamina),
                    decimal(window.kesslerAverageStamina),
                    decimal(window.vegaAverageHeadDamage),
                    decimal(window.kesslerAverageHeadDamage),
                    decimal(window.vegaAverageBodyDamage),
                    decimal(window.kesslerAverageBodyDamage),
                    decimal(window.vegaAverageStability),
                    decimal(window.kesslerAverageStability),
                ).joinToString(",")
            )
        }
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.6f", value)
}

object ThresholdAuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = ThresholdAuditor.run()
        ThresholdAuditor.assertAcceptable(result)
        print(ThresholdAuditFormatter.format(result))
    }
}

object ThresholdAuditCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        print(ThresholdAuditCsvFormatter.format(ThresholdAuditor.run()))
    }
}
