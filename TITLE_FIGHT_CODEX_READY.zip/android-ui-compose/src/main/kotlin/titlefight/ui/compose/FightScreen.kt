package titlefight.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import titlefight.FightActionScreenState
import titlefight.FightResultScreenState
import titlefight.FightScreenPhase
import titlefight.FightScreenState
import titlefight.FighterCorner
import titlefight.FighterScreenState
import titlefight.TacticalPlanScreenState
import titlefight.TacticalDistance
import titlefight.TacticalPace
import titlefight.TacticalRisk
import titlefight.TacticalTarget

@Composable
fun TitleFightScreen(
    state: FightScreenState,
    tacticalSelection: TacticalSelectionUiState? = null,
    onTacticalAction: (TacticalSelectionAction) -> Unit = {},
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .semantics { contentDescription = FightScreenAccessibility.screenSummary(state) },
        contentAlignment = Alignment.TopCenter,
    ) {
        val tokens = remember(maxWidth) { FightScreenLayoutPolicy.forWidth(maxWidth.value) }
        val presentation = remember(state) { FightScreenPresentationMapper.from(state) }
        val scrollState = rememberScrollState()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = tokens.contentMaxWidthDp.dp)
                .padding(horizontal = tokens.horizontalPaddingDp.dp, vertical = tokens.sectionGapDp.dp)
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(tokens.sectionGapDp.dp),
        ) {
            FightScoreboard(state, presentation.screenTitle, tokens)
            FighterPair(state.red, state.blue, tokens)

            when (state.phase) {
                FightScreenPhase.PRE_FIGHT -> PreFightPanel(state, tokens)
                FightScreenPhase.ROUND_IN_PROGRESS -> CurrentActionPanel(state.currentAction, tokens)
                FightScreenPhase.BETWEEN_ROUNDS -> BetweenRoundsPanel(state, tacticalSelection, onTacticalAction, tokens)
                FightScreenPhase.COMPLETE -> ResultPanel(requireNotNull(state.result), tokens)
            }

            CommentaryPanel(state, tokens)
            RecentLogPanel(state.recentCommentary, tokens)

            if (state.phase != FightScreenPhase.BETWEEN_ROUNDS && state.phase != FightScreenPhase.COMPLETE) {
                TacticalSummaryPair(state, tokens)
            }

            PhaseFooter(state, tokens)
        }
    }
}

@Composable
private fun FightScoreboard(
    state: FightScreenState,
    screenTitle: String,
    tokens: FightScreenLayoutTokens,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .semantics { heading() },
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "TITLE FIGHT",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                )
                Text(
                    text = screenTitle,
                    fontSize = tokens.minimumBodySp.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "ROUND ${state.roundNumber}/${state.totalRounds}",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = state.clock.display,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                )
            }
        }
    }
}

@Composable
private fun FighterPair(
    red: FighterScreenState,
    blue: FighterScreenState,
    tokens: FightScreenLayoutTokens,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(tokens.fighterGapDp.dp),
    ) {
        FighterCard(red, tokens, Modifier.weight(1f))
        FighterCard(blue, tokens, Modifier.weight(1f))
    }
}

@Composable
private fun FighterCard(
    fighter: FighterScreenState,
    tokens: FightScreenLayoutTokens,
    modifier: Modifier = Modifier,
) {
    val cornerColor = if (fighter.corner == FighterCorner.RED) {
        MaterialTheme.colorScheme.tertiary
    } else {
        MaterialTheme.colorScheme.secondary
    }
    Surface(
        modifier = modifier
            .widthIn(min = tokens.fighterCardMinWidthDp.dp)
            .semantics(mergeDescendants = true) {
                contentDescription = FightScreenAccessibility.fighterSummary(fighter)
            },
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, cornerColor.copy(alpha = 0.75f)),
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Text(
                text = fighter.name,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = fighter.nickname,
                fontSize = tokens.minimumBodySp.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            MetricBar("ÉNERGIE", fighter.stamina, cornerColor, tokens)
            MetricBar("TÊTE", 100 - fighter.headDamage, cornerColor, tokens)
            MetricBar("CORPS", 100 - fighter.bodyDamage, cornerColor, tokens)
            MetricBar("STABILITÉ", fighter.stability, cornerColor, tokens)
            Text(
                text = "${fighter.landed}/${fighter.thrown} touches · KD ${fighter.knockdownsSuffered}",
                fontSize = tokens.minimumBodySp.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun MetricBar(
    label: String,
    value: Int,
    color: Color,
    tokens: FightScreenLayoutTokens,
) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = tokens.minimumBodySp.sp, fontWeight = FontWeight.Bold)
            Text("$value", fontSize = tokens.minimumBodySp.sp)
        }
        LinearProgressIndicator(
            progress = { value / 100f },
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .semantics {
                    contentDescription = "$label, $value pour cent"
                    progressBarRangeInfo = ProgressBarRangeInfo(value / 100f, 0f..1f)
                },
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
    }
}

@Composable
private fun CurrentActionPanel(
    action: FightActionScreenState?,
    tokens: FightScreenLayoutTokens,
) {
    val label = FightScreenAccessibility.actionSummary(action)
    SectionCard(
        title = "ACTION EN COURS",
        tokens = tokens,
        semanticLabel = label,
    ) {
        Text(
            text = label.replaceFirstChar { it.uppercase() },
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun PreFightPanel(state: FightScreenState, tokens: FightScreenLayoutTokens) {
    SectionCard("AVANT-COMBAT", tokens, state.commentary) {
        Text(state.commentary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun BetweenRoundsPanel(
    state: FightScreenState,
    selection: TacticalSelectionUiState?,
    onAction: (TacticalSelectionAction) -> Unit,
    tokens: FightScreenLayoutTokens,
) {
    SectionCard(
        title = "FENÊTRE TACTIQUE",
        tokens = tokens,
        semanticLabel = if (selection == null) {
            "Fenêtre tactique ouverte, contrôleur non connecté."
        } else {
            "Fenêtre tactique ouverte. ${selection.statusText}."
        },
    ) {
        if (selection == null) {
            Text(
                text = "Contrôleur tactique indisponible",
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
            TacticalReadOnlyGrid(state.red.tacticalPlan, tokens)
        } else {
            Text(
                text = selection.statusText,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
            )
            TacticalChoiceGroup(
                label = "Rythme",
                options = TacticalPace.entries,
                selected = selection.draft.pace,
                labelOf = TacticalSelectionLabels::pace,
                enabled = selection.enabled,
                tokens = tokens,
                onSelect = { onAction(TacticalSelectionAction.SelectPace(selection.windowId, it)) },
            )
            TacticalChoiceGroup(
                label = "Distance",
                options = TacticalDistance.entries,
                selected = selection.draft.distance,
                labelOf = TacticalSelectionLabels::distance,
                enabled = selection.enabled,
                tokens = tokens,
                onSelect = { onAction(TacticalSelectionAction.SelectDistance(selection.windowId, it)) },
            )
            TacticalChoiceGroup(
                label = "Cible",
                options = TacticalTarget.entries,
                selected = selection.draft.target,
                labelOf = TacticalSelectionLabels::target,
                enabled = selection.enabled,
                tokens = tokens,
                onSelect = { onAction(TacticalSelectionAction.SelectTarget(selection.windowId, it)) },
            )
            TacticalChoiceGroup(
                label = "Risque",
                options = TacticalRisk.entries,
                selected = selection.draft.risk,
                labelOf = TacticalSelectionLabels::risk,
                enabled = selection.enabled,
                tokens = tokens,
                onSelect = { onAction(TacticalSelectionAction.SelectRisk(selection.windowId, it)) },
            )
            TacticalConfirmButton(
                enabled = selection.confirmEnabled,
                tokens = tokens,
                onClick = { onAction(TacticalSelectionAction.Confirm(selection.windowId)) },
            )
        }
    }
}

@Composable
private fun <T> TacticalChoiceGroup(
    label: String,
    options: List<T>,
    selected: T,
    labelOf: (T) -> String,
    enabled: Boolean,
    tokens: FightScreenLayoutTokens,
    onSelect: (T) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label.uppercase(), fontSize = tokens.minimumBodySp.sp, fontWeight = FontWeight.Black)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            options.forEach { option ->
                TacticalChoiceChip(
                    axis = label,
                    value = labelOf(option),
                    selected = option == selected,
                    enabled = enabled,
                    tokens = tokens,
                    modifier = Modifier.weight(1f),
                    onClick = { onSelect(option) },
                )
            }
        }
    }
}

@Composable
private fun TacticalChoiceChip(
    axis: String,
    value: String,
    selected: Boolean,
    enabled: Boolean,
    tokens: FightScreenLayoutTokens,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .heightIn(min = tokens.minimumTapTargetDp.dp)
            .semantics {
                contentDescription = "$axis, $value, ${if (selected) "sélectionné" else "non sélectionné"}"
            },
        shape = RoundedCornerShape(10.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 7.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = value,
                fontSize = tokens.minimumBodySp.sp,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun TacticalConfirmButton(
    enabled: Boolean,
    tokens: FightScreenLayoutTokens,
    onClick: () -> Unit,
) {
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = tokens.minimumTapTargetDp.dp)
            .semantics { contentDescription = "Valider le plan tactique pour le prochain round" },
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.primary,
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = "VALIDER ET REPRENDRE",
                fontSize = tokens.minimumBodySp.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onPrimary,
            )
        }
    }
}

@Composable
private fun TacticalReadOnlyGrid(
    plan: TacticalPlanScreenState,
    tokens: FightScreenLayoutTokens,
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ReadOnlyTacticalChip("Rythme", plan.pace.name, tokens, Modifier.weight(1f))
            ReadOnlyTacticalChip("Distance", plan.distance.name, tokens, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ReadOnlyTacticalChip("Cible", plan.target.name, tokens, Modifier.weight(1f))
            ReadOnlyTacticalChip("Risque", plan.risk.name, tokens, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ReadOnlyTacticalChip(
    axis: String,
    value: String,
    tokens: FightScreenLayoutTokens,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .heightIn(min = tokens.minimumTapTargetDp.dp)
            .semantics { contentDescription = "$axis, $value, lecture seule" },
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(axis.uppercase(), fontSize = tokens.minimumBodySp.sp, fontWeight = FontWeight.Bold)
            Text(value.lowercase(), fontSize = tokens.minimumBodySp.sp)
        }
    }
}

@Composable
private fun ResultPanel(result: FightResultScreenState, tokens: FightScreenLayoutTokens) {
    SectionCard(
        title = "RÉSULTAT OFFICIEL",
        tokens = tokens,
        semanticLabel = FightScreenAccessibility.resultSummary(result),
        accent = MaterialTheme.colorScheme.primary,
    ) {
        Text(
            text = result.headline,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Text(
            text = result.detail,
            fontSize = tokens.minimumBodySp.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun CommentaryPanel(state: FightScreenState, tokens: FightScreenLayoutTokens) {
    SectionCard("COMMENTAIRE", tokens, state.commentary) {
        Text(
            text = state.commentary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun RecentLogPanel(entries: List<String>, tokens: FightScreenLayoutTokens) {
    SectionCard("JOURNAL RÉCENT", tokens, "Trois événements récents") {
        if (entries.isEmpty()) {
            Text("Aucun événement", fontSize = tokens.minimumBodySp.sp)
        } else {
            entries.takeLast(3).forEachIndexed { index, entry ->
                Text(
                    text = "${index + 1}. $entry",
                    fontSize = tokens.minimumBodySp.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun TacticalSummaryPair(state: FightScreenState, tokens: FightScreenLayoutTokens) {
    SectionCard("PLANS TACTIQUES", tokens, "Résumé des plans tactiques des deux coins") {
        Row(horizontalArrangement = Arrangement.spacedBy(tokens.fighterGapDp.dp)) {
            TacticalPlanSummary("ROUGE", state.red.tacticalPlan, tokens, Modifier.weight(1f))
            TacticalPlanSummary("BLEU", state.blue.tacticalPlan, tokens, Modifier.weight(1f))
        }
    }
}

@Composable
private fun TacticalPlanSummary(
    label: String,
    plan: TacticalPlanScreenState,
    tokens: FightScreenLayoutTokens,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, fontWeight = FontWeight.Black, fontSize = tokens.minimumBodySp.sp)
        Text(
            text = "${plan.pace.name.lowercase()} · ${plan.distance.name.lowercase()} · ${plan.target.name.lowercase()} · ${plan.risk.name.lowercase()}",
            fontSize = tokens.minimumBodySp.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun PhaseFooter(state: FightScreenState, tokens: FightScreenLayoutTokens) {
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    Text(
        text = when (state.phase) {
            FightScreenPhase.PRE_FIGHT -> "Préparation"
            FightScreenPhase.ROUND_IN_PROGRESS -> "Séquence ${state.sequenceNumber}/${state.sequencesPerRound}"
            FightScreenPhase.BETWEEN_ROUNDS -> "Pause réglementaire"
            FightScreenPhase.COMPLETE -> "Combat terminé"
        },
        modifier = Modifier.fillMaxWidth(),
        textAlign = TextAlign.Center,
        fontSize = tokens.minimumBodySp.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun SectionCard(
    title: String,
    tokens: FightScreenLayoutTokens,
    semanticLabel: String,
    accent: Color = MaterialTheme.colorScheme.secondary,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) { contentDescription = semanticLabel },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Text(
                text = title,
                fontSize = tokens.minimumBodySp.sp,
                fontWeight = FontWeight.Black,
                color = accent,
            )
            content()
        }
    }
}
