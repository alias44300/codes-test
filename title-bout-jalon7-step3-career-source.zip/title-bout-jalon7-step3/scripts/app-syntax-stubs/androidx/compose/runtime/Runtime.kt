package androidx.compose.runtime
@Target(AnnotationTarget.FUNCTION, AnnotationTarget.TYPE)
annotation class Composable
fun <T> remember(vararg keys: Any?, calculation: () -> T): T = calculation()
class MutableState<T>(var value: T)
fun <T> mutableStateOf(value: T): MutableState<T> = MutableState(value)
operator fun <T> MutableState<T>.getValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>): T = value
operator fun <T> MutableState<T>.setValue(thisRef: Any?, property: kotlin.reflect.KProperty<*>, newValue: T) { value = newValue }
