package titlefight

object OfficialDecisionStep4Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val engine = FightEngine()
        val redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
        val blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

        val fight = generateSequence(202607250000L) { it + 1L }
            .take(20_000)
            .map { seed ->
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = redTactics,
                    blueTactics = blueTactics,
                    seed = seed,
                )
            }
            .first { candidate ->
                candidate.stoppage == null && candidate.officialDecision?.type in setOf(
                    OfficialDecisionType.SPLIT_DECISION,
                    OfficialDecisionType.MAJORITY_DECISION,
                )
            }

        val decision = requireNotNull(fight.officialDecision)
        println("TITLE FIGHT — DÉMONSTRATION D'UNE DÉCISION OFFICIELLE")
        println("${TestProfiles.eliasVega.name} contre ${TestProfiles.brunoKessler.name}")
        println("Graine : ${fight.seed}")
        println()
        decision.scorecards.forEach { card ->
            val rounds = card.rounds.joinToString(" | ") { "R${it.roundNumber} ${it.redPoints}-${it.bluePoints}" }
            println("${card.judgeName} — ${card.judgeFocus} : ${card.redTotal}-${card.blueTotal} [$rounds]")
        }
        println()
        println("Type : ${decision.type.frenchLabel}")
        println("Cartes : rouge ${decision.redCards}, bleu ${decision.blueCards}, nulles ${decision.drawCards}")
        println(decision.explanation)
    }
}
