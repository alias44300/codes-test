package titlefight.ui.compose

import titlefight.FightScreenPhase
import titlefight.FightScreenState
import titlefight.FighterCorner
import titlefight.InteractiveFightAdvance
import titlefight.InteractiveFightPhase
import titlefight.InteractiveFightSession
import titlefight.InteractiveFightSessionState
import titlefight.PlayerTacticalDraft
import titlefight.TacticalAxis
import titlefight.TacticalDistance
import titlefight.TacticalPace
import titlefight.TacticalRisk
import titlefight.TacticalTarget

sealed interface TacticalSelectionAction {
    val windowId: Int

    data class SelectPace(override val windowId: Int, val value: TacticalPace) : TacticalSelectionAction
    data class SelectDistance(override val windowId: Int, val value: TacticalDistance) : TacticalSelectionAction
    data class SelectTarget(override val windowId: Int, val value: TacticalTarget) : TacticalSelectionAction
    data class SelectRisk(override val windowId: Int, val value: TacticalRisk) : TacticalSelectionAction
    data class Confirm(override val windowId: Int) : TacticalSelectionAction
}

data class TacticalSelectionUiState(
    val windowId: Int,
    val playerCorner: FighterCorner,
    val draft: PlayerTacticalDraft,
    val changedAxes: List<TacticalAxis>,
    val enabled: Boolean,
    val confirmEnabled: Boolean,
) {
    init {
        require(windowId >= 1)
        require(changedAxes.distinct().size == changedAxes.size)
        require(!confirmEnabled || enabled)
    }

    val statusText: String
        get() = if (changedAxes.isEmpty()) {
            "Plan conservé"
        } else {
            "${changedAxes.size} axe${if (changedAxes.size > 1) "s" else ""} modifié${if (changedAxes.size > 1) "s" else ""}"
        }

    companion object {
        fun from(session: InteractiveFightSessionState): TacticalSelectionUiState? {
            if (session.phase != InteractiveFightPhase.BETWEEN_ROUNDS) return null
            return TacticalSelectionUiState(
                windowId = requireNotNull(session.tacticalWindowId),
                playerCorner = session.playerCorner,
                draft = requireNotNull(session.pendingPlayerDraft),
                changedAxes = session.changedAxes,
                enabled = session.canEditTactics,
                confirmEnabled = session.canConfirmTactics,
            )
        }
    }
}

data class InteractiveFightViewState(
    val screenState: FightScreenState,
    val tacticalSelection: TacticalSelectionUiState?,
    val timelineSize: Int,
    val completedRounds: Int,
) {
    init {
        require(timelineSize >= 1)
        require(completedRounds in 1..3)
        require((screenState.phase == FightScreenPhase.BETWEEN_ROUNDS) == (tacticalSelection != null))
    }
}

/**
 * Coordinateur pur Kotlin entre la session de combat et l'écran Compose.
 *
 * Il n'exécute aucune logique sportive lui-même. Les actions de l'interface
 * sont traduites vers la session, puis le dernier `FightScreenState` validé est
 * renvoyé à l'écran.
 */
class InteractiveFightCoordinator(
    private val session: InteractiveFightSession,
) {
    fun start(): InteractiveFightViewState = view(session.start())

    fun dispatch(action: TacticalSelectionAction): InteractiveFightViewState = when (action) {
        is TacticalSelectionAction.SelectPace -> {
            session.selectPace(action.windowId, action.value)
            currentView()
        }
        is TacticalSelectionAction.SelectDistance -> {
            session.selectDistance(action.windowId, action.value)
            currentView()
        }
        is TacticalSelectionAction.SelectTarget -> {
            session.selectTarget(action.windowId, action.value)
            currentView()
        }
        is TacticalSelectionAction.SelectRisk -> {
            session.selectRisk(action.windowId, action.value)
            currentView()
        }
        is TacticalSelectionAction.Confirm -> view(session.confirmAndContinue(action.windowId))
    }

    fun currentView(): InteractiveFightViewState {
        val timeline = session.screenTimeline()
        require(timeline.isNotEmpty()) { "Le combat doit être démarré avant de demander l'écran." }
        return InteractiveFightViewState(
            screenState = timeline.last(),
            tacticalSelection = TacticalSelectionUiState.from(session.state()),
            timelineSize = timeline.size,
            completedRounds = session.state().completedRounds,
        )
    }

    private fun view(advance: InteractiveFightAdvance): InteractiveFightViewState = InteractiveFightViewState(
        screenState = advance.screenTimeline.last(),
        tacticalSelection = TacticalSelectionUiState.from(advance.state),
        timelineSize = advance.screenTimeline.size,
        completedRounds = advance.state.completedRounds,
    )
}

object TacticalSelectionLabels {
    fun pace(value: TacticalPace): String = when (value) {
        TacticalPace.CAUTIOUS -> "Prudent"
        TacticalPace.MEASURED -> "Mesuré"
        TacticalPace.SUSTAINED -> "Soutenu"
    }

    fun distance(value: TacticalDistance): String = when (value) {
        TacticalDistance.LONG -> "Longue"
        TacticalDistance.MEDIUM -> "Moyenne"
        TacticalDistance.CLOSE -> "Courte"
    }

    fun target(value: TacticalTarget): String = when (value) {
        TacticalTarget.HEAD -> "Tête"
        TacticalTarget.BODY -> "Corps"
        TacticalTarget.MIXED -> "Mixte"
    }

    fun risk(value: TacticalRisk): String = when (value) {
        TacticalRisk.SAFE -> "Sûr"
        TacticalRisk.BALANCED -> "Équilibré"
        TacticalRisk.AGGRESSIVE -> "Agressif"
    }
}
