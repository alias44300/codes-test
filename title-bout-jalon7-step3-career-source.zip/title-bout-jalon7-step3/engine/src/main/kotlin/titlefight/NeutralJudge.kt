package titlefight

import java.util.Locale
import kotlin.math.abs

/** Pondérations explicites d'un profil de juge. */
data class JudgeWeights(
    val strikingQuality: Double,
    val effectiveAggression: Double,
    val defense: Double,
    val ringControl: Double,
    val bodyWork: Double,
) {
    init {
        val values = listOf(strikingQuality, effectiveAggression, defense, ringControl, bodyWork)
        values.forEach { require(it in 0.0..1.0) }
        require(abs(values.sum() - 1.0) < 1e-9) { "Les pondérations d'un juge doivent totaliser 1,00." }
    }
}

data class JudgeProfile(
    val id: String,
    val name: String,
    val focus: String,
    val weights: JudgeWeights,
) {
    init {
        require(id.isNotBlank())
        require(name.isNotBlank())
        require(focus.isNotBlank())
    }
}

object JudgeProfiles {
    val GENERAL_BALANCE = JudgeProfile(
        id = "judge-a-balanced",
        name = "Juge A",
        focus = "équilibre général",
        weights = JudgeWeights(0.42, 0.18, 0.18, 0.14, 0.08),
    )
    val PRECISION_DEFENSE = JudgeProfile(
        id = "judge-b-precision-defense",
        name = "Juge B",
        focus = "précision et défense",
        weights = JudgeWeights(0.45, 0.14, 0.23, 0.11, 0.07),
    )
    val AGGRESSION_CONTROL = JudgeProfile(
        id = "judge-c-aggression-control",
        name = "Juge C",
        focus = "agressivité efficace et contrôle",
        weights = JudgeWeights(0.37, 0.24, 0.14, 0.18, 0.07),
    )

    val ALL: List<JudgeProfile> = listOf(GENERAL_BALANCE, PRECISION_DEFENSE, AGGRESSION_CONTROL)
}

/** Carte d'un juge identifié pour un round terminé. */
data class JudgeRoundScore(
    val judgeId: String,
    val judgeName: String,
    val judgeFocus: String,
    val roundNumber: Int,
    val redFighterId: String,
    val blueFighterId: String,
    val redPoints: Int,
    val bluePoints: Int,
    val winnerId: String?,
    val redMerit: Double,
    val blueMerit: Double,
    val meritMargin: Double,
    val knockdownDifference: Int,
    val decisiveFactors: List<String>,
    val explanation: String,
) {
    init {
        require(judgeId.isNotBlank())
        require(judgeName.isNotBlank())
        require(judgeFocus.isNotBlank())
        validateTenPointScore(
            roundNumber, redFighterId, blueFighterId, redPoints, bluePoints, winnerId,
            redMerit, blueMerit, meritMargin, decisiveFactors, explanation,
        )
    }

    fun toNeutralScore(): NeutralJudgeRoundScore = NeutralJudgeRoundScore(
        roundNumber = roundNumber,
        redFighterId = redFighterId,
        blueFighterId = blueFighterId,
        redPoints = redPoints,
        bluePoints = bluePoints,
        winnerId = winnerId,
        redMerit = redMerit,
        blueMerit = blueMerit,
        meritMargin = meritMargin,
        knockdownDifference = knockdownDifference,
        decisiveFactors = decisiveFactors,
        explanation = explanation.removePrefix("$judgeName ($judgeFocus), "),
    )
}

/**
 * Carte historique du juge neutre de l'étape 2.
 * Elle reste une vue compatible du Juge A, sans total de carte ni décision officielle.
 */
data class NeutralJudgeRoundScore(
    val roundNumber: Int,
    val redFighterId: String,
    val blueFighterId: String,
    val redPoints: Int,
    val bluePoints: Int,
    val winnerId: String?,
    val redMerit: Double,
    val blueMerit: Double,
    val meritMargin: Double,
    val knockdownDifference: Int,
    val decisiveFactors: List<String>,
    val explanation: String,
) {
    init {
        validateTenPointScore(
            roundNumber, redFighterId, blueFighterId, redPoints, bluePoints, winnerId,
            redMerit, blueMerit, meritMargin, decisiveFactors, explanation,
        )
    }
}

private fun validateTenPointScore(
    roundNumber: Int,
    redFighterId: String,
    blueFighterId: String,
    redPoints: Int,
    bluePoints: Int,
    winnerId: String?,
    redMerit: Double,
    blueMerit: Double,
    meritMargin: Double,
    decisiveFactors: List<String>,
    explanation: String,
) {
    require(roundNumber in 1..3)
    require(redFighterId.isNotBlank())
    require(blueFighterId.isNotBlank())
    require(redFighterId != blueFighterId)
    require(redPoints in 7..10)
    require(bluePoints in 7..10)
    require(redPoints == 10 || bluePoints == 10)
    require(abs(redPoints - bluePoints) <= 3)
    require(redMerit >= 0.0)
    require(blueMerit >= 0.0)
    require(meritMargin in -100.0..100.0)
    require(decisiveFactors.isNotEmpty())
    require(explanation.isNotBlank())

    when (winnerId) {
        null -> require(redPoints == 10 && bluePoints == 10)
        redFighterId -> require(redPoints == 10 && bluePoints in 7..9)
        blueFighterId -> require(bluePoints == 10 && redPoints in 7..9)
        else -> error("Le vainqueur du round doit appartenir au coin rouge ou bleu.")
    }
}

private data class ScoringAxis(
    val label: String,
    val redValue: Double,
    val blueValue: Double,
    val weight: Double,
) {
    val advantage: Double
        get() {
            val denominator = redValue + blueValue
            if (denominator <= 1e-9) return 0.0
            return ((redValue - blueValue) / denominator) * 100.0
        }
}

private object TenPointRoundScorer {
    private const val DRAW_MARGIN = 2.0

    fun score(profile: JudgeProfile, evidence: RoundJudgingEvidence): JudgeRoundScore {
        val axes = axes(profile.weights, evidence)
        val redMerit = axes.sumOf { it.redValue * it.weight }
        val blueMerit = axes.sumOf { it.blueValue * it.weight }
        val margin = axes.sumOf { it.advantage * it.weight }.coerceIn(-100.0, 100.0)
        val knockdownDifference = evidence.red.knockdownsScored - evidence.blue.knockdownsScored

        val winnerId: String?
        val redPoints: Int
        val bluePoints: Int

        when {
            knockdownDifference > 0 -> {
                winnerId = evidence.red.fighterId
                redPoints = 10
                bluePoints = if (knockdownDifference >= 2) 7 else 8
            }
            knockdownDifference < 0 -> {
                winnerId = evidence.blue.fighterId
                redPoints = if (knockdownDifference <= -2) 7 else 8
                bluePoints = 10
            }
            abs(margin) <= DRAW_MARGIN -> {
                winnerId = null
                redPoints = 10
                bluePoints = 10
            }
            margin > 0.0 -> {
                winnerId = evidence.red.fighterId
                redPoints = 10
                bluePoints = 9
            }
            else -> {
                winnerId = evidence.blue.fighterId
                redPoints = 9
                bluePoints = 10
            }
        }

        val factors = decisiveFactors(
            axes = axes,
            winnerId = winnerId,
            redFighterId = evidence.red.fighterId,
            knockdownDifference = knockdownDifference,
        )
        val explanation = explanation(
            profile = profile,
            redPoints = redPoints,
            bluePoints = bluePoints,
            winnerId = winnerId,
            redFighterId = evidence.red.fighterId,
            blueFighterId = evidence.blue.fighterId,
            margin = margin,
            knockdownDifference = knockdownDifference,
            factors = factors,
        )

        return JudgeRoundScore(
            judgeId = profile.id,
            judgeName = profile.name,
            judgeFocus = profile.focus,
            roundNumber = evidence.roundNumber,
            redFighterId = evidence.red.fighterId,
            blueFighterId = evidence.blue.fighterId,
            redPoints = redPoints,
            bluePoints = bluePoints,
            winnerId = winnerId,
            redMerit = redMerit,
            blueMerit = blueMerit,
            meritMargin = margin,
            knockdownDifference = knockdownDifference,
            decisiveFactors = factors,
            explanation = explanation,
        )
    }

    private fun axes(weights: JudgeWeights, evidence: RoundJudgingEvidence): List<ScoringAxis> {
        val red = evidence.red
        val blue = evidence.blue
        return listOf(
            ScoringAxis("coups nets et qualité des impacts", strikingQuality(red), strikingQuality(blue), weights.strikingQuality),
            ScoringAxis("agressivité efficace", effectiveAggression(red), effectiveAggression(blue), weights.effectiveAggression),
            ScoringAxis("défense", defense(red), defense(blue), weights.defense),
            ScoringAxis("contrôle de la distance et du rythme", ringControl(red), ringControl(blue), weights.ringControl),
            ScoringAxis("travail au corps", bodyWork(red), bodyWork(blue), weights.bodyWork),
        )
    }

    private fun strikingQuality(value: FighterRoundJudgingEvidence): Double =
        value.landedPunches * 1.0 + value.cleanHits * 2.2 + value.totalImpact * 0.28 + value.cleanImpact * 0.42

    private fun effectiveAggression(value: FighterRoundJudgingEvidence): Double =
        value.effectiveSequences * 1.2 + value.accuracy * 5.0 + value.totalImpact * 0.10

    private fun defense(value: FighterRoundJudgingEvidence): Double =
        value.defensiveSuccesses * 1.0 + value.defensiveSuccessRate * 6.0 +
            (value.punchesAllowed - value.cleanHitsAllowed).coerceAtLeast(0) * 0.35

    private fun ringControl(value: FighterRoundJudgingEvidence): Double =
        value.preferredRangeInitiatives * 1.0 + value.preferredRangeShare * 4.0 + value.initiatedSequences * 0.20

    private fun bodyWork(value: FighterRoundJudgingEvidence): Double =
        value.bodyShotsLanded * 1.2 + value.bodyImpact * 0.30

    private fun decisiveFactors(
        axes: List<ScoringAxis>,
        winnerId: String?,
        redFighterId: String,
        knockdownDifference: Int,
    ): List<String> {
        if (winnerId == null) return listOf("écart global inférieur au seuil d’un round réellement indiscernable")

        val winnerIsRed = winnerId == redFighterId
        val alignedAxes = axes
            .map { axis -> axis to if (winnerIsRed) axis.advantage else -axis.advantage }
            .filter { (_, advantage) -> advantage > 0.0 }
            .sortedByDescending { (_, advantage) -> advantage }
            .take(3)
            .map { (axis, _) -> axis.label }
            .toMutableList()

        if ((winnerIsRed && knockdownDifference > 0) || (!winnerIsRed && knockdownDifference < 0)) {
            alignedAxes.add(0, "avantage de knockdowns (${abs(knockdownDifference)})")
        }
        if (alignedAxes.isEmpty()) alignedAxes += "avantage global minimal mais mesurable"
        return alignedAxes.distinct().take(3)
    }

    private fun explanation(
        profile: JudgeProfile,
        redPoints: Int,
        bluePoints: Int,
        winnerId: String?,
        redFighterId: String,
        blueFighterId: String,
        margin: Double,
        knockdownDifference: Int,
        factors: List<String>,
    ): String {
        val formattedMargin = String.format(Locale.US, "%.2f", abs(margin))
        val prefix = "${profile.name} (${profile.focus})"
        return when (winnerId) {
            null -> "$prefix, 10-10 : round indiscernable, écart pondéré $formattedMargin. Facteur principal : ${factors.joinToString()}"
            redFighterId -> "$prefix, $redPoints-$bluePoints pour le coin rouge : ${factors.joinToString()}. Écart pondéré $formattedMargin${knockdownSuffix(knockdownDifference)}"
            blueFighterId -> "$prefix, $redPoints-$bluePoints pour le coin bleu : ${factors.joinToString()}. Écart pondéré $formattedMargin${knockdownSuffix(knockdownDifference)}"
            else -> error("Vainqueur de round invalide.")
        }
    }

    private fun knockdownSuffix(knockdownDifference: Int): String =
        if (knockdownDifference == 0) "." else ", différence de knockdowns ${abs(knockdownDifference)}."
}

object ThreeJudgePanel {
    fun score(evidence: RoundJudgingEvidence): List<JudgeRoundScore> =
        JudgeProfiles.ALL.map { profile -> TenPointRoundScorer.score(profile, evidence) }
}

object NeutralJudge {
    fun score(evidence: RoundJudgingEvidence): NeutralJudgeRoundScore =
        TenPointRoundScorer.score(JudgeProfiles.GENERAL_BALANCE, evidence).toNeutralScore()
}
