package titlefight.ui.compose

import titlefight.BoxerProfile
import titlefight.FightResult
import titlefight.FightScreenState
import titlefight.FightScreenStateMapper

/**
 * Frontière explicite entre moteur et interface.
 *
 * L'adaptateur délègue au mapper validé du moteur et retourne une liste
 * immuable. Aucun état du moteur n'est modifié et aucun tirage n'est consommé.
 */
object FightScreenTimelineAdapter {
    fun fromFightResult(
        result: FightResult,
        red: BoxerProfile,
        blue: BoxerProfile,
    ): List<FightScreenState> = FightScreenStateMapper.buildTimeline(result, red, blue)

    fun stateAt(
        timeline: List<FightScreenState>,
        index: Int,
    ): FightScreenState {
        require(timeline.isNotEmpty())
        return timeline[index.coerceIn(0, timeline.lastIndex)]
    }
}
