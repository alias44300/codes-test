package titlefight

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Point d'application unique des effets tactiques bornés.
 *
 * Toutes les fonctions sont pures. Elles ne consomment aucun tirage aléatoire et
 * retournent la valeur historique lorsque le plan est absent.
 */
object TacticalPlanApplication {
    private const val ACTIVITY_SCORE_SCALE = 5.0
    private const val RANGE_CONTROL_SCALE = 15.0
    private const val ACCURACY_DEFENSE_SCALE = 0.15
    private const val IMPACT_SCALE = 0.20
    private const val STAMINA_COST_SCALE = 0.20
    private const val MEDIUM_RANGE_ANCHOR = 6.0
    private const val MEDIUM_COUNTER_SUPPORT = 1.5
    private const val MAX_MEDIUM_RANGE_RESISTANCE = 8.5

    fun activityScoreDelta(plan: TacticalPlan?): Double =
        (plan?.modifiers?.activityDelta ?: 0.0) * ACTIVITY_SCORE_SCALE

    fun rangeControlBonus(plan: TacticalPlan?, range: FightRange): Double =
        if (plan?.distance?.toFightRange() == range) {
            plan.modifiers.preferredRangeControlDelta * RANGE_CONTROL_SCALE
        } else 0.0

    /**
     * Résistance bornée à l'aspiration vers les extrêmes pour un plan de distance moyenne.
     *
     * Elle reste nulle lorsque les effets tactiques sont désactivés (`plan == null`),
     * ce qui préserve strictement les empreintes historiques. La même formule est
     * appliquée aux deux coins, sans dépendre de l'identité du boxeur.
     */
    fun mediumRangeResistance(plan: TacticalPlan?, tactic: Tactic, stamina: Double): Double {
        if (plan?.distance != TacticalDistance.MEDIUM) return 0.0
        val fatigueFactor = (stamina / 100.0).coerceIn(0.0, 1.0)
        val counterSupport = if (tactic == Tactic.COUNTER) MEDIUM_COUNTER_SUPPORT else 0.0
        val planControl = rangeControlBonus(plan, FightRange.MID)
        return ((MEDIUM_RANGE_ANCHOR + counterSupport) * fatigueFactor + planControl)
            .coerceIn(0.0, MAX_MEDIUM_RANGE_RESISTANCE)
    }

    fun adjustedHitProbability(
        historicalProbability: Double,
        attackerPlan: TacticalPlan?,
        defenderPlan: TacticalPlan?,
        minimum: Double = 0.08,
        maximum: Double = 0.88,
    ): Double {
        val attackDelta = (attackerPlan?.modifiers?.accuracyDelta ?: 0.0) * ACCURACY_DEFENSE_SCALE
        val defenseDelta = (defenderPlan?.modifiers?.defenseDelta ?: 0.0) * ACCURACY_DEFENSE_SCALE
        return clamp(historicalProbability + attackDelta - defenseDelta, minimum, maximum)
    }

    fun adjustedImpact(historicalImpact: Double, plan: TacticalPlan?): Double =
        max(0.0, historicalImpact * (1.0 + (plan?.modifiers?.impactDelta ?: 0.0) * IMPACT_SCALE))

    fun adjustedStaminaCost(historicalCost: Double, plan: TacticalPlan?): Double =
        max(0.0, historicalCost * (1.0 + (plan?.modifiers?.staminaCostDelta ?: 0.0) * STAMINA_COST_SCALE))

    fun targetSlots(plan: TacticalPlan?, totalSlots: Int = 10): Pair<Int, Int> {
        require(totalSlots >= 2)
        if (plan == null) return totalSlots to 0
        val effectiveHeadShare = 0.50 + (plan.modifiers.headTargetShare - 0.50) * 0.50
        val head = (effectiveHeadShare * totalSlots).roundToInt().coerceIn(1, totalSlots - 1)
        return head to totalSlots - head
    }

    private fun TacticalDistance.toFightRange(): FightRange = when (this) {
        TacticalDistance.LONG -> FightRange.OUTSIDE
        TacticalDistance.MEDIUM -> FightRange.MID
        TacticalDistance.CLOSE -> FightRange.INSIDE
    }

    private fun clamp(value: Double, minimum: Double, maximum: Double): Double =
        min(maximum, max(minimum, value))
}
