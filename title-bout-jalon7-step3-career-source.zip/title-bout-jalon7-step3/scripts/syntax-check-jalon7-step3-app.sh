#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build-jalon7-step3"
ENGINE_JAR="$BUILD/title-bout-jalon7-step3.jar"
STUBS="$ROOT/scripts/app-syntax-stubs"
if [[ ! -f "$ENGINE_JAR" ]]; then
  "$ROOT/scripts/test-jalon7-step3.sh" >/dev/null
fi
rm -f "$BUILD/app-ui-syntax.jar" "$BUILD/main-activity-syntax.jar"
kotlinc -J-Xmx1024m -J-Dfile.encoding=UTF-8 \
  -classpath "$ENGINE_JAR" \
  $(find "$STUBS" -name '*.kt' ! -path '*/titlefight/app/*' ! -path '*/titlefight/data/local/*' ! -path '*/titlefight/ui/compose/*' ! -path '*/android/*' ! -path '*/androidx/activity/*' ! -path '*/androidx/compose/ui/platform/*' | sort) \
  "$ROOT/app/src/main/kotlin/titlefight/app/CareerScreen.kt" \
  "$ROOT/app/src/main/kotlin/titlefight/app/HomeScreen.kt" \
  -d "$BUILD/app-ui-syntax.jar"
kotlinc -J-Xmx1024m -J-Dfile.encoding=UTF-8 \
  -classpath "$ENGINE_JAR" \
  $(find "$STUBS" -name '*.kt' | sort) \
  "$ROOT/app/src/main/kotlin/titlefight/app/MainActivity.kt" \
  -d "$BUILD/main-activity-syntax.jar"
echo "Écrans carrière, accueil et navigation Android : syntaxe Kotlin validée."
echo "Contrôle effectué avec des stubs locaux ; il ne remplace pas assembleDebug."
