# Jalon 5 — Étape 3 — Matrice complète des affrontements

## Objectif

Simuler les 45 duels uniques du roster de dix boxeurs fictifs, avec inversion systématique des coins et plusieurs graines appariées par duel, afin de mesurer le comportement réel du prototype avant toute calibration.

## Protocole verrouillé

- 45 duels uniques ;
- 100 graines appariées par duel ;
- deux combats par graine, avec coins inversés ;
- 200 combats par duel ;
- 9 000 combats au total ;
- IA tactique adaptative activée ;
- script tactique déterministe dérivé uniquement du style ;
- trois rounds maximum ;
- aucune modification des profils ou du moteur pendant l’audit.

## Contrôles techniques

- couverture exacte des 45 paires ;
- 900 apparitions rouges et 900 apparitions bleues par boxeur ;
- validité des KO, TKO, décisions et cartes des juges ;
- plans tactiques attachés aux rounds et cohérents avec les décisions ;
- absence de décision tactique après arrêt ;
- répétition exacte de 180 combats ;
- conservation des empreintes historiques Vega/Kessler en mode compatible.

## Résultat technique

- 108 tests automatisés réussis ;
- 9 000 combats ;
- 4 213 victoires rouges, 4 170 victoires bleues et 617 nuls ;
- part rouge parmi les combats avec vainqueur : 50,26 % ;
- 16 KO, 60 TKO et 8 924 décisions ;
- 180 contrôles de reproductibilité, 0 écart ;
- 0 résultat invalide ;
- 0 plan manquant ou divergent ;
- 0 décision après arrêt ;
- 0 empreinte historique modifiée.

## Diagnostic d’équilibrage

La matrice est techniquement valide mais le roster n’est pas encore équilibré.

Profils au-dessus de la bande exploratoire de 75 % de victoires hors nuls :

- Darius Cole : 81,38 % ;
- Idris Kane : 78,86 %.

Profils sous la bande exploratoire de 25 % :

- Viktor Sokolov : 14,68 % ;
- Kenji Mori : 6,74 %.

Styles hors de la bande exploratoire de 35 à 65 % :

- pressure fighter : 71,02 % ;
- counterpuncher : 25,62 % ;
- swarmer : 81,38 % ;
- slugger : 14,68 % ;
- defensive specialist : 6,74 %.

## Décision

**Étape 3 validée techniquement. Calibration requise avant l’audit final.**

Les résultats sont gelés comme référence de départ de l’étape 4. Aucun équilibrage n’a été appliqué dans cette étape.
