# Jalon 2, étape 1 — Détection de chute

## Décision d’architecture

La détection utilise un flux pseudo-aléatoire distinct dérivé de la graine du round. L’ajout du système de chute ne modifie donc pas la succession des distances, initiatives, coups, réussites et impacts du moteur validé au jalon 1.

## Conditions

Une chute ne peut être évaluée qu’après une frappe réussie avec un impact positif. Le score utilise :

- l’impact du coup ;
- la stabilité restante après le coup ;
- la fatigue avant le coup ;
- les dégâts accumulés à la tête ou au corps ;
- le type de coup ;
- la qualité nette ou partielle ;
- le menton ou la résistance au corps.

Les jabs exigent un impact minimal de 5,8. Les autres coups exigent 5,2. Un score insuffisant donne une probabilité nulle.

## Événement enregistré

`KnockdownEvent` contient :

- identifiant de l’attaquant ;
- identifiant du défenseur ;
- round ;
- séquence ;
- coup ;
- impact ;
- score ;
- probabilité ;
- tirage déterministe.

## Audit technique

Audit standard : 1 000 combats, 3 000 rounds et 36 000 séquences.

- chutes détectées : 452 ;
- chutes sur attaque manquée : 0 ;
- chutes sous le seuil minimal d’impact : 0 ;
- coin rouge : 235 ;
- coin bleu : 217 ;
- Elias Vega : 57 chutes provoquées ;
- Bruno Kessler : 395 chutes provoquées ;
- impact moyen des chutes : 11,71 ;
- impact minimal : 6,87 ;
- impact maximal : 17,15.

Ces chiffres servent à vérifier le câblage du détecteur. Ils ne constituent pas encore l’équilibrage final des fréquences, prévu à l’étape 5 du jalon 2.

## Limite volontaire

Après une chute, le round continue immédiatement. Aucun compte, relèvement, KO ou TKO n’est encore calculé.
