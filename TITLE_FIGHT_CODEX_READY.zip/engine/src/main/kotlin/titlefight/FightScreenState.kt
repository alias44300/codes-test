package titlefight

import kotlin.math.roundToInt

enum class FightScreenPhase {
    PRE_FIGHT,
    ROUND_IN_PROGRESS,
    BETWEEN_ROUNDS,
    COMPLETE,
}

enum class FighterCorner { RED, BLUE }

enum class FighterCondition {
    FRESH,
    WORKING,
    TIRED,
    HURT,
    CRITICAL,
}

enum class FightResultKind {
    KO,
    TKO,
    DECISION,
    DRAW,
}

data class FightClockState(
    val remainingSeconds: Int,
) {
    init {
        require(remainingSeconds in 0..180)
    }

    val display: String
        get() = "%d:%02d".format(remainingSeconds / 60, remainingSeconds % 60)
}

data class TacticalPlanScreenState(
    val pace: TacticalPace,
    val distance: TacticalDistance,
    val target: TacticalTarget,
    val risk: TacticalRisk,
    val explanation: String,
) {
    init {
        require(explanation.isNotBlank())
    }
}

data class FighterScreenState(
    val id: String,
    val name: String,
    val nickname: String,
    val corner: FighterCorner,
    val stance: Stance,
    val style: BoxingStyle,
    val stamina: Int,
    val fatigue: Int,
    val headDamage: Int,
    val bodyDamage: Int,
    val stability: Int,
    val landed: Int,
    val thrown: Int,
    val knockdownsSuffered: Int,
    val vulnerabilitySequencesRemaining: Int,
    val pendingTenCount: Boolean,
    val condition: FighterCondition,
    val tacticalPlan: TacticalPlanScreenState,
) {
    init {
        require(id.isNotBlank())
        require(name.isNotBlank())
        require(nickname.isNotBlank())
        listOf(stamina, fatigue, headDamage, bodyDamage, stability).forEach { require(it in 0..100) }
        require(stamina + fatigue in 99..101)
        require(landed >= 0)
        require(thrown >= landed)
        require(knockdownsSuffered >= 0)
        require(vulnerabilitySequencesRemaining in 0..6)
    }
}

data class FightActionScreenState(
    val attackerId: String,
    val defenderId: String,
    val range: FightRange,
    val punch: Punch,
    val landed: Boolean,
    val clean: Boolean,
    val impact: Double,
    val knockdown: Boolean,
    val refereeCount: Int?,
) {
    init {
        require(attackerId != defenderId)
        require(impact >= 0.0)
        require(!clean || landed)
        require(!knockdown || landed)
        require(refereeCount == null || refereeCount in 1..10)
    }
}

data class FightResultScreenState(
    val kind: FightResultKind,
    val winnerId: String?,
    val loserId: String?,
    val headline: String,
    val detail: String,
) {
    init {
        require(headline.isNotBlank())
        require(detail.isNotBlank())
        if (kind == FightResultKind.DRAW) {
            require(winnerId == null && loserId == null)
        } else {
            require(winnerId != null && loserId != null && winnerId != loserId)
        }
    }
}

/**
 * Contrat immuable entre le moteur et le futur écran Android.
 *
 * Aucune carte détaillée de juge n'est présente ici. Pendant un combat, la vue
 * ne reçoit donc ni total de juge ni estimation officielle cachée.
 */
data class FightScreenState(
    val fightSeed: Long,
    val phase: FightScreenPhase,
    val roundNumber: Int,
    val totalRounds: Int,
    val sequenceNumber: Int,
    val sequencesPerRound: Int,
    val clock: FightClockState,
    val red: FighterScreenState,
    val blue: FighterScreenState,
    val currentAction: FightActionScreenState?,
    val commentary: String,
    val recentCommentary: List<String>,
    val tacticalWindowOpen: Boolean,
    val result: FightResultScreenState?,
) {
    init {
        require(roundNumber in 1..totalRounds)
        require(totalRounds == 3)
        require(sequenceNumber in 0..sequencesPerRound)
        require(sequencesPerRound >= 1)
        require(red.corner == FighterCorner.RED)
        require(blue.corner == FighterCorner.BLUE)
        require(red.id != blue.id)
        require(commentary.isNotBlank())
        require(recentCommentary.size <= 3)
        require(recentCommentary.none { it.isBlank() })
        require(tacticalWindowOpen == (phase == FightScreenPhase.BETWEEN_ROUNDS))
        require((result != null) == (phase == FightScreenPhase.COMPLETE))
        if (phase == FightScreenPhase.PRE_FIGHT) {
            require(sequenceNumber == 0)
            require(clock.remainingSeconds == 180)
            require(currentAction == null)
        }
        if (phase == FightScreenPhase.BETWEEN_ROUNDS) {
            require(clock.remainingSeconds == 0)
            require(currentAction == null)
            require(roundNumber < totalRounds)
        }
    }
}

object FightScreenStateMapper {
    const val ROUND_SECONDS: Int = 180
    const val DEFAULT_SEQUENCES_PER_ROUND: Int = 12

    fun buildTimeline(
        result: FightResult,
        red: BoxerProfile,
        blue: BoxerProfile,
        sequencesPerRound: Int = DEFAULT_SEQUENCES_PER_ROUND,
    ): List<FightScreenState> {
        require(result.redId == red.id)
        require(result.blueId == blue.id)
        require(sequencesPerRound >= 1)
        require(result.rounds.all { it.events.size <= sequencesPerRound })
        require(result.rounds.all { it.sequenceFrames.size == it.events.size }) {
            "Le moteur doit fournir un état observationnel après chaque séquence."
        }

        val timeline = mutableListOf<FightScreenState>()
        val comments = mutableListOf<String>()
        val firstSnapshot = result.tacticalSnapshots.first()
        val firstRedDecision = decision(result, red.id, 1)
        val firstBlueDecision = decision(result, blue.id, 1)

        timeline += FightScreenState(
            fightSeed = result.seed,
            phase = FightScreenPhase.PRE_FIGHT,
            roundNumber = 1,
            totalRounds = 3,
            sequenceNumber = 0,
            sequencesPerRound = sequencesPerRound,
            clock = FightClockState(ROUND_SECONDS),
            red = fighterFromSnapshot(red, FighterCorner.RED, firstSnapshot.red, firstRedDecision),
            blue = fighterFromSnapshot(blue, FighterCorner.BLUE, firstSnapshot.blue, firstBlueDecision),
            currentAction = null,
            commentary = "Les deux boxeurs sont prêts. Le combat va commencer.",
            recentCommentary = emptyList(),
            tacticalWindowOpen = false,
            result = null,
        )

        result.rounds.forEach { round ->
            val redDecision = decision(result, red.id, round.roundNumber)
            val blueDecision = decision(result, blue.id, round.roundNumber)

            round.sequenceFrames.forEach { frame ->
                val comment = FightCommentaryFormatter.short(frame.event, red, blue, frame.stoppage)
                comments += comment
                val isComplete = frame.stoppage != null
                timeline += FightScreenState(
                    fightSeed = result.seed,
                    phase = if (isComplete) FightScreenPhase.COMPLETE else FightScreenPhase.ROUND_IN_PROGRESS,
                    roundNumber = round.roundNumber,
                    totalRounds = 3,
                    sequenceNumber = frame.sequenceNumber,
                    sequencesPerRound = sequencesPerRound,
                    clock = FightClockState(remainingSeconds(frame.sequenceNumber, sequencesPerRound)),
                    red = fighterFromState(red, FighterCorner.RED, frame.redState, redDecision),
                    blue = fighterFromState(blue, FighterCorner.BLUE, frame.blueState, blueDecision),
                    currentAction = action(frame.event),
                    commentary = comment,
                    recentCommentary = comments.takeLast(3),
                    tacticalWindowOpen = false,
                    result = frame.stoppage?.let { stoppageResult(it, red, blue) },
                )
            }

            if (round.stoppage == null && round.roundNumber < 3) {
                timeline += FightScreenState(
                    fightSeed = result.seed,
                    phase = FightScreenPhase.BETWEEN_ROUNDS,
                    roundNumber = round.roundNumber,
                    totalRounds = 3,
                    sequenceNumber = sequencesPerRound,
                    sequencesPerRound = sequencesPerRound,
                    clock = FightClockState(0),
                    red = fighterFromState(red, FighterCorner.RED, round.redState, redDecision),
                    blue = fighterFromState(blue, FighterCorner.BLUE, round.blueState, blueDecision),
                    currentAction = null,
                    commentary = "Fin du round ${round.roundNumber}. La fenêtre tactique est ouverte.",
                    recentCommentary = comments.takeLast(3),
                    tacticalWindowOpen = true,
                    result = null,
                )
            }
        }

        if (result.stoppage == null) {
            val lastRound = result.rounds.last()
            val redDecision = decision(result, red.id, lastRound.roundNumber)
            val blueDecision = decision(result, blue.id, lastRound.roundNumber)
            val official = requireNotNull(result.officialDecision)
            timeline += FightScreenState(
                fightSeed = result.seed,
                phase = FightScreenPhase.COMPLETE,
                roundNumber = 3,
                totalRounds = 3,
                sequenceNumber = sequencesPerRound,
                sequencesPerRound = sequencesPerRound,
                clock = FightClockState(0),
                red = fighterFromState(red, FighterCorner.RED, result.finalRedState, redDecision),
                blue = fighterFromState(blue, FighterCorner.BLUE, result.finalBlueState, blueDecision),
                currentAction = null,
                commentary = decisionCommentary(official, red, blue),
                recentCommentary = comments.takeLast(3),
                tacticalWindowOpen = false,
                result = decisionResult(official, red, blue),
            )
        }

        require(timeline.count { it.phase == FightScreenPhase.COMPLETE } == 1)
        require(timeline.last().phase == FightScreenPhase.COMPLETE)
        return timeline.toList()
    }

    internal fun remainingSeconds(sequenceNumber: Int, sequencesPerRound: Int): Int {
        val elapsed = (ROUND_SECONDS.toDouble() * sequenceNumber / sequencesPerRound).roundToInt()
        return (ROUND_SECONDS - elapsed).coerceIn(0, ROUND_SECONDS)
    }

    private fun decision(result: FightResult, fighterId: String, beforeRound: Int): TacticalDecision =
        result.tacticalDecisions.single { it.fighterId == fighterId && it.beforeRound == beforeRound }

    internal fun fighterFromSnapshot(
        profile: BoxerProfile,
        corner: FighterCorner,
        state: FighterTacticalState,
        decision: TacticalDecision,
    ): FighterScreenState = fighter(
        profile = profile,
        corner = corner,
        stamina = state.stamina,
        headDamage = state.headDamage,
        bodyDamage = state.bodyDamage,
        stability = state.stability,
        landed = 0,
        thrown = 0,
        knockdownsSuffered = state.knockdownsSuffered,
        vulnerabilitySequencesRemaining = 0,
        pendingTenCount = false,
        decision = decision,
    )

    internal fun fighterFromState(
        profile: BoxerProfile,
        corner: FighterCorner,
        state: FighterState,
        decision: TacticalDecision,
    ): FighterScreenState = fighter(
        profile = profile,
        corner = corner,
        stamina = state.stamina,
        headDamage = state.headDamage,
        bodyDamage = state.bodyDamage,
        stability = state.stability,
        landed = state.landed,
        thrown = state.thrown,
        knockdownsSuffered = state.knockdownsSuffered,
        vulnerabilitySequencesRemaining = state.vulnerabilitySequencesRemaining,
        pendingTenCount = state.pendingTenCount,
        decision = decision,
    )

    private fun fighter(
        profile: BoxerProfile,
        corner: FighterCorner,
        stamina: Double,
        headDamage: Double,
        bodyDamage: Double,
        stability: Double,
        landed: Int,
        thrown: Int,
        knockdownsSuffered: Int,
        vulnerabilitySequencesRemaining: Int,
        pendingTenCount: Boolean,
        decision: TacticalDecision,
    ): FighterScreenState {
        val staminaInt = percent(stamina)
        val head = percent(headDamage)
        val body = percent(bodyDamage)
        val stabilityInt = percent(stability)
        return FighterScreenState(
            id = profile.id,
            name = profile.name,
            nickname = profile.nickname,
            corner = corner,
            stance = profile.stance,
            style = profile.style,
            stamina = staminaInt,
            fatigue = 100 - staminaInt,
            headDamage = head,
            bodyDamage = body,
            stability = stabilityInt,
            landed = landed,
            thrown = thrown,
            knockdownsSuffered = knockdownsSuffered,
            vulnerabilitySequencesRemaining = vulnerabilitySequencesRemaining,
            pendingTenCount = pendingTenCount,
            condition = condition(staminaInt, head, body, stabilityInt, pendingTenCount),
            tacticalPlan = TacticalPlanScreenState(
                pace = decision.selectedPlan.pace,
                distance = decision.selectedPlan.distance,
                target = decision.selectedPlan.target,
                risk = decision.selectedPlan.risk,
                explanation = decision.explanation,
            ),
        )
    }

    private fun condition(
        stamina: Int,
        headDamage: Int,
        bodyDamage: Int,
        stability: Int,
        pendingTenCount: Boolean,
    ): FighterCondition = when {
        pendingTenCount || stability <= 15 || headDamage >= 85 || bodyDamage >= 90 -> FighterCondition.CRITICAL
        stability <= 38 || headDamage >= 62 || bodyDamage >= 72 -> FighterCondition.HURT
        stamina <= 42 -> FighterCondition.TIRED
        stamina <= 72 || headDamage >= 25 || bodyDamage >= 30 -> FighterCondition.WORKING
        else -> FighterCondition.FRESH
    }

    internal fun action(event: SequenceEvent): FightActionScreenState = FightActionScreenState(
        attackerId = event.attackerId,
        defenderId = event.defenderId,
        range = event.range,
        punch = event.punch,
        landed = event.landed,
        clean = event.clean,
        impact = event.impact,
        knockdown = event.knockdown != null,
        refereeCount = event.knockdown?.refereeCount?.countReached,
    )

    internal fun stoppageResult(
        stoppage: FightStoppage,
        red: BoxerProfile,
        blue: BoxerProfile,
    ): FightResultScreenState {
        val winner = profile(stoppage.winnerId, red, blue)
        val loser = profile(stoppage.loserId, red, blue)
        val kind = if (stoppage.method == FightMethod.KO) FightResultKind.KO else FightResultKind.TKO
        return FightResultScreenState(
            kind = kind,
            winnerId = winner.id,
            loserId = loser.id,
            headline = "${winner.name} gagne par ${stoppage.method}",
            detail = "Round ${stoppage.roundNumber}, séquence ${stoppage.sequenceNumber}. ${stoppage.reason}.",
        )
    }

    internal fun decisionResult(
        decision: OfficialDecision,
        red: BoxerProfile,
        blue: BoxerProfile,
    ): FightResultScreenState {
        if (decision.winnerId == null) {
            return FightResultScreenState(
                kind = FightResultKind.DRAW,
                winnerId = null,
                loserId = null,
                headline = "Match nul",
                detail = decision.type.frenchLabel.replaceFirstChar { it.uppercase() } + ".",
            )
        }
        val winner = profile(requireNotNull(decision.winnerId), red, blue)
        val loser = profile(requireNotNull(decision.loserId), red, blue)
        return FightResultScreenState(
            kind = FightResultKind.DECISION,
            winnerId = winner.id,
            loserId = loser.id,
            headline = "${winner.name} gagne aux points",
            detail = decision.type.frenchLabel.replaceFirstChar { it.uppercase() } + ".",
        )
    }

    internal fun decisionCommentary(
        decision: OfficialDecision,
        red: BoxerProfile,
        blue: BoxerProfile,
    ): String = if (decision.winnerId == null) {
        "Le combat se termine par ${decision.type.frenchLabel}."
    } else {
        val winner = profile(requireNotNull(decision.winnerId), red, blue)
        "${winner.name} remporte le combat par ${decision.type.frenchLabel}."
    }

    private fun profile(id: String, red: BoxerProfile, blue: BoxerProfile): BoxerProfile = when (id) {
        red.id -> red
        blue.id -> blue
        else -> error("Boxeur inconnu dans le résultat : $id")
    }

    private fun percent(value: Double): Int = value.roundToInt().coerceIn(0, 100)
}

object FightCommentaryFormatter {
    fun short(
        event: SequenceEvent,
        red: BoxerProfile,
        blue: BoxerProfile,
        stoppage: FightStoppage?,
    ): String {
        val attacker = profile(event.attackerId, red, blue)
        val defender = profile(event.defenderId, red, blue)
        if (stoppage?.method == FightMethod.TKO) {
            return "L'arbitre protège ${defender.name}. ${attacker.name} gagne par TKO."
        }
        val count = event.knockdown?.refereeCount
        if (count != null) {
            return if (count.countReached == 10) {
                "${defender.name} ne se relève pas. ${attacker.name} gagne par KO."
            } else {
                "${attacker.name} envoie ${defender.name} au tapis. Compte ${count.countReached}."
            }
        }
        val punch = punchLabel(event.punch)
        return when {
            event.clean -> "${attacker.name} touche nettement avec $punch."
            event.landed -> "${attacker.name} touche avec $punch."
            else -> "${defender.name} évite $punch de ${attacker.name}."
        }
    }

    private fun profile(id: String, red: BoxerProfile, blue: BoxerProfile): BoxerProfile = when (id) {
        red.id -> red
        blue.id -> blue
        else -> error("Boxeur inconnu dans l'événement : $id")
    }

    private fun punchLabel(punch: Punch): String = when (punch) {
        Punch.JAB -> "un jab"
        Punch.CROSS -> "un direct"
        Punch.HOOK -> "un crochet"
        Punch.UPPERCUT -> "un uppercut"
        Punch.BODY_HOOK -> "un crochet au corps"
        Punch.COMBINATION -> "une combinaison"
    }
}
