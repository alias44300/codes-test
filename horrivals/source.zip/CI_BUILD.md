# HORRIVALS Android CI

The GitHub Actions workflow builds the Godot project with Godot 4.7.2 stable, exports a signed arm64 Android APK, verifies its signature and zip alignment, checks the Android package id and application label, and uploads the APK as a workflow artifact.

The CI signing certificate is generated per build. It is suitable for direct test installation, but not for long-term Play Store update continuity. A persistent release keystore must be configured before store publication.
