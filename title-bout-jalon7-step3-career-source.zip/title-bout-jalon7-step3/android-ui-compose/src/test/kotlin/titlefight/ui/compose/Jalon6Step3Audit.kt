package titlefight.ui.compose

import titlefight.BoxerCatalog
import titlefight.BoxingStyle
import titlefight.FightEngine
import titlefight.FightScreenPhase
import titlefight.FightScreenStateMapper
import titlefight.Tactic
import java.security.MessageDigest

data class Jalon6Step3AuditResult(
    val testedWidths: List<Int>,
    val fakeScenarios: Int,
    val mappedFights: Int,
    val mappedStates: Int,
    val replayChecks: Int,
    val replayErrors: Int,
    val layoutErrors: Int,
    val phaseErrors: Int,
    val accessibilityErrors: Int,
    val adapterErrors: Int,
    val judgeLeakErrors: Int,
    val digest: String,
)

object Jalon6Step3Auditor {
    fun run(mappedFights: Int = 120): Jalon6Step3AuditResult {
        require(mappedFights >= 20)
        val widths = listOf(320, 360, 412)
        var layoutErrors = 0
        var phaseErrors = 0
        var accessibilityErrors = 0
        var adapterErrors = 0
        var judgeLeakErrors = 0
        var mappedStates = 0
        var replayChecks = 0
        var replayErrors = 0
        val digestLines = mutableListOf<String>()

        widths.forEach { width ->
            val tokens = FightScreenLayoutPolicy.forWidth(width)
            if (tokens.minimumBodySp < 10.0) layoutErrors++
            if (tokens.minimumTapTargetDp < 44) layoutErrors++
            if (tokens.fighterCardMinWidthDp * 2 + tokens.fighterGapDp + tokens.horizontalPaddingDp * 2 > width + 8) {
                layoutErrors++
            }
            digestLines += "width|$width|$tokens"
        }

        val fakes = listOf(
            FightScreenPreviewFixtures.active(),
            FightScreenPreviewFixtures.betweenRounds(),
            FightScreenPreviewFixtures.complete(),
        )
        fakes.forEach { state ->
            val presentation = FightScreenPresentationMapper.from(state)
            if (presentation.tacticalControlsEnabled != (state.phase == FightScreenPhase.BETWEEN_ROUNDS)) phaseErrors++
            if (presentation.officialResultVisible != (state.phase == FightScreenPhase.COMPLETE)) phaseErrors++
            if (presentation.currentActionVisible != (state.phase == FightScreenPhase.ROUND_IN_PROGRESS)) phaseErrors++
            val screenSummary = FightScreenAccessibility.screenSummary(state)
            if (screenSummary.isBlank() || state.red.name !in screenSummary || state.blue.name !in screenSummary) {
                accessibilityErrors++
            }
            if (listOf("scorecard", "carte du juge", "total du juge").any { it in screenSummary.lowercase() }) {
                judgeLeakErrors++
            }
            digestLines += "fake|${state.phase}|${presentation.visibleRegions.sortedBy { it.name }}|$screenSummary"
        }

        val roster = BoxerCatalog.all
        repeat(mappedFights) { index ->
            val red = roster[index % roster.size]
            var blue = roster[(index * 7 + 3) % roster.size]
            if (blue.id == red.id) blue = roster[(roster.indexOf(blue) + 1) % roster.size]
            val seed = 6_300_000L + index
            val result = fight(red, blue, seed)
            val direct = FightScreenStateMapper.buildTimeline(result, red, blue)
            val adapted = FightScreenTimelineAdapter.fromFightResult(result, red, blue)
            mappedStates += adapted.size
            if (direct != adapted) adapterErrors++
            if (adapted.first().phase != FightScreenPhase.PRE_FIGHT || adapted.last().phase != FightScreenPhase.COMPLETE) {
                phaseErrors++
            }
            if (adapted.any { state ->
                    FightScreenAccessibility.screenSummary(state).isBlank() ||
                        FightScreenAccessibility.fighterSummary(state.red).isBlank() ||
                        FightScreenAccessibility.fighterSummary(state.blue).isBlank()
                }
            ) accessibilityErrors++
            if (index < 60) {
                replayChecks++
                val replay = FightScreenTimelineAdapter.fromFightResult(fight(red, blue, seed), red, blue)
                if (adapted != replay) replayErrors++
            }
            val sampled = listOf(0, adapted.lastIndex / 2, adapted.lastIndex)
                .map { FightScreenTimelineAdapter.stateAt(adapted, it) }
            digestLines += listOf(
                red.id,
                blue.id,
                seed,
                adapted.size,
                adapted.last().result?.headline,
                sampled.joinToString("/") { "${it.phase}:${it.roundNumber}:${it.sequenceNumber}" },
            ).joinToString("|")
        }

        return Jalon6Step3AuditResult(
            testedWidths = widths,
            fakeScenarios = fakes.size,
            mappedFights = mappedFights,
            mappedStates = mappedStates,
            replayChecks = replayChecks,
            replayErrors = replayErrors,
            layoutErrors = layoutErrors,
            phaseErrors = phaseErrors,
            accessibilityErrors = accessibilityErrors,
            adapterErrors = adapterErrors,
            judgeLeakErrors = judgeLeakErrors,
            digest = sha256(digestLines.joinToString("\n")),
        )
    }

    private fun fight(red: titlefight.BoxerProfile, blue: titlefight.BoxerProfile, seed: Long) =
        FightEngine(adaptiveTacticsEnabled = true).simulateThreeRoundFight(
            red = red,
            blue = blue,
            redTactics = List(3) { legacyTactic(red.style) },
            blueTactics = List(3) { legacyTactic(blue.style) },
            seed = seed,
        )

    private fun legacyTactic(style: BoxingStyle): Tactic = when (style) {
        BoxingStyle.OUT_BOXER -> Tactic.CONTROL
        BoxingStyle.PRESSURE_FIGHTER -> Tactic.PRESS
        BoxingStyle.COUNTERPUNCHER -> Tactic.COUNTER
        BoxingStyle.BOXER_PUNCHER -> Tactic.CONTROL
        BoxingStyle.SWARMER -> Tactic.PRESS
        BoxingStyle.SLUGGER -> Tactic.SEEK_KO
        BoxingStyle.DEFENSIVE_SPECIALIST -> Tactic.RECOVER
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray())
        .joinToString("") { "%02x".format(it) }
}

object Jalon6Step3Test {
    @JvmStatic
    fun main(args: Array<String>) {
        breakpointsMatchTheLockedMockup()
        layoutTokensGrowMonotonically()
        activePresentationShowsActionWithoutControls()
        betweenRoundsPresentationShowsControlsOnlyThere()
        completePresentationShowsOnlyOfficialResult()
        accessibilitySummariesDescribeBothCorners()
        progressValuesStayInAccessibleBounds()
        fakeStatesRespectFightScreenStateContract()
        timelineAdapterDelegatesExactlyToValidatedMapper()
        stateAtClampsSafely()
        auditIsClean()
        auditIsReproducible()
        println("12 tests Jalon 6 étape 3 réussis")
    }

    private fun breakpointsMatchTheLockedMockup() {
        val compact = FightScreenLayoutPolicy.forWidth(320)
        val standard = FightScreenLayoutPolicy.forWidth(360)
        val expanded = FightScreenLayoutPolicy.forWidth(412)
        check(compact.widthClass == FightScreenWidthClass.COMPACT)
        check(standard.widthClass == FightScreenWidthClass.STANDARD)
        check(expanded.widthClass == FightScreenWidthClass.EXPANDED)
        check(compact.minimumBodySp == 10.0 && compact.minimumTapTargetDp == 44)
        check(standard.minimumBodySp == 10.5 && standard.minimumTapTargetDp == 44)
        check(expanded.minimumBodySp == 11.0 && expanded.minimumTapTargetDp == 48)
    }

    private fun layoutTokensGrowMonotonically() {
        val all = listOf(320, 360, 412).map(FightScreenLayoutPolicy::forWidth)
        check(all.zipWithNext().all { (a, b) -> a.horizontalPaddingDp <= b.horizontalPaddingDp })
        check(all.zipWithNext().all { (a, b) -> a.minimumBodySp <= b.minimumBodySp })
        check(all.zipWithNext().all { (a, b) -> a.fighterCardMinWidthDp <= b.fighterCardMinWidthDp })
    }

    private fun activePresentationShowsActionWithoutControls() {
        val presentation = FightScreenPresentationMapper.from(FightScreenPreviewFixtures.active())
        check(presentation.currentActionVisible)
        check(!presentation.tacticalControlsEnabled)
        check(!presentation.officialResultVisible)
        check(FightScreenRegion.CURRENT_ACTION in presentation.visibleRegions)
    }

    private fun betweenRoundsPresentationShowsControlsOnlyThere() {
        val presentation = FightScreenPresentationMapper.from(FightScreenPreviewFixtures.betweenRounds())
        check(presentation.tacticalControlsEnabled)
        check(!presentation.currentActionVisible)
        check(!presentation.officialResultVisible)
        check(FightScreenRegion.BETWEEN_ROUNDS_TACTICS in presentation.visibleRegions)
    }

    private fun completePresentationShowsOnlyOfficialResult() {
        val presentation = FightScreenPresentationMapper.from(FightScreenPreviewFixtures.complete())
        check(presentation.officialResultVisible)
        check(!presentation.currentActionVisible)
        check(!presentation.tacticalControlsEnabled)
        check(FightScreenRegion.RESULT in presentation.visibleRegions)
    }

    private fun accessibilitySummariesDescribeBothCorners() {
        listOf(
            FightScreenPreviewFixtures.active(),
            FightScreenPreviewFixtures.betweenRounds(),
            FightScreenPreviewFixtures.complete(),
        ).forEach { state ->
            val text = FightScreenAccessibility.screenSummary(state)
            check(state.red.name in text)
            check(state.blue.name in text)
            check(state.commentary in text)
            check("scorecard" !in text.lowercase())
        }
    }

    private fun progressValuesStayInAccessibleBounds() {
        val state = FightScreenPreviewFixtures.active()
        listOf(state.red, state.blue).forEach { fighter ->
            check(fighter.stamina in 0..100)
            check((100 - fighter.headDamage) in 0..100)
            check((100 - fighter.bodyDamage) in 0..100)
            check(fighter.stability in 0..100)
        }
    }

    private fun fakeStatesRespectFightScreenStateContract() {
        check(FightScreenPreviewFixtures.active().phase == FightScreenPhase.ROUND_IN_PROGRESS)
        check(FightScreenPreviewFixtures.betweenRounds().tacticalWindowOpen)
        check(FightScreenPreviewFixtures.complete().result != null)
    }

    private fun timelineAdapterDelegatesExactlyToValidatedMapper() {
        val red = BoxerCatalog.all[0]
        val blue = BoxerCatalog.all[1]
        val result = FightEngine(adaptiveTacticsEnabled = true).simulateThreeRoundFight(
            red = red,
            blue = blue,
            redTactics = List(3) { Tactic.CONTROL },
            blueTactics = List(3) { Tactic.PRESS },
            seed = 20260721L,
        )
        check(
            FightScreenTimelineAdapter.fromFightResult(result, red, blue) ==
                FightScreenStateMapper.buildTimeline(result, red, blue),
        )
    }

    private fun stateAtClampsSafely() {
        val timeline = listOf(
            FightScreenPreviewFixtures.active(),
            FightScreenPreviewFixtures.betweenRounds(),
            FightScreenPreviewFixtures.complete(),
        )
        check(FightScreenTimelineAdapter.stateAt(timeline, -100) == timeline.first())
        check(FightScreenTimelineAdapter.stateAt(timeline, 100) == timeline.last())
    }

    private fun auditIsClean() {
        val audit = Jalon6Step3Auditor.run(60)
        check(audit.replayErrors == 0)
        check(audit.layoutErrors == 0)
        check(audit.phaseErrors == 0)
        check(audit.accessibilityErrors == 0)
        check(audit.adapterErrors == 0)
        check(audit.judgeLeakErrors == 0)
    }

    private fun auditIsReproducible() {
        check(Jalon6Step3Auditor.run(40) == Jalon6Step3Auditor.run(40))
    }
}

object Jalon6Step3AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val audit = Jalon6Step3Auditor.run()
        println("JALON 6 ETAPE 3 - AUDIT COMPOSE")
        println("largeurs=${audit.testedWidths.joinToString(",")}")
        println("scenarios_factices=${audit.fakeScenarios}")
        println("combats_mappes=${audit.mappedFights}")
        println("etats_mappes=${audit.mappedStates}")
        println("relectures=${audit.replayChecks}")
        println("erreurs_relecture=${audit.replayErrors}")
        println("erreurs_layout=${audit.layoutErrors}")
        println("erreurs_phase=${audit.phaseErrors}")
        println("erreurs_accessibilite=${audit.accessibilityErrors}")
        println("erreurs_adaptateur=${audit.adapterErrors}")
        println("fuites_juges=${audit.judgeLeakErrors}")
        println("empreinte=${audit.digest}")
    }
}
