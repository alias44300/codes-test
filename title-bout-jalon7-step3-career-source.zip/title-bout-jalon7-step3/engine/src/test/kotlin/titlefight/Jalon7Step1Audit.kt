package titlefight

object Jalon7Step1Test {
    @JvmStatic
    fun main(args: Array<String>) {
        val entries = PlayableBoxerDatabase.allEntries
        check(entries.size == 20)
        check(entries.map { it.versionId }.distinct().size == 20)
        check(entries.map { it.boxerId }.distinct().size == 20)
        check(entries.map { it.style }.toSet() == BoxingStyle.entries.toSet())
        check(entries.map { it.stance }.toSet().containsAll(Stance.entries))
        check(entries.all { it.ratings.values().all { value -> value in 1..100 } })
        check(entries.all { it.profile.primaryStats.all { value -> value in 1..100 } })
        check(PlayableBoxerDatabase.search("muhammad").single().name == "Muhammad Ali")
        check(PlayableBoxerDatabase.search(style = BoxingStyle.COUNTERPUNCHER).isNotEmpty())
        check(PlayableBoxerDatabase.search(stance = Stance.SOUTHPAW).single().name == "Oleksandr Usyk")

        val engine = FightEngine(adaptiveTacticsEnabled = true)
        var fights = 0
        var events = 0
        var narrativeLines = 0
        val uniqueNarrativeLines = linkedSetOf<String>()
        var invalid = 0
        var deterministicErrors = 0

        entries.indices.forEach { left ->
            for (right in left + 1 until entries.size) {
                val red = entries[left].profile
                val blue = entries[right].profile
                val redTactics = tactics(red.style)
                val blueTactics = tactics(blue.style)
                val seed = 7_000_000L + left * 100L + right
                val first = engine.simulateThreeRoundFight(red, blue, redTactics, blueTactics, seed)
                val replay = engine.simulateThreeRoundFight(red, blue, redTactics, blueTactics, seed)
                fights += 1
                if (first != replay) deterministicErrors += 1
                if (first.rounds.isEmpty() || first.rounds.size > 3) invalid += 1
                first.rounds.forEach { round ->
                    var previous: SequenceEvent? = null
                    round.sequenceFrames.forEach { frame ->
                        val narrative = NarrativeCommentaryEngine.describe(
                            event = frame.event,
                            red = red,
                            blue = blue,
                            roundNumber = round.roundNumber,
                            redState = frame.redState,
                            blueState = frame.blueState,
                            stoppage = frame.stoppage,
                            previousEvent = previous,
                        )
                        val replayNarrative = NarrativeCommentaryEngine.describe(
                            event = frame.event,
                            red = red,
                            blue = blue,
                            roundNumber = round.roundNumber,
                            redState = frame.redState,
                            blueState = frame.blueState,
                            stoppage = frame.stoppage,
                            previousEvent = previous,
                        )
                        check(narrative == replayNarrative)
                        check(narrative.lines.size in 2..5)
                        narrative.lines.forEach {
                            check(it.isNotBlank())
                            uniqueNarrativeLines += it
                        }
                        events += 1
                        narrativeLines += narrative.lines.size
                        previous = frame.event
                    }
                }
            }
        }

        check(fights == 190)
        check(invalid == 0)
        check(deterministicErrors == 0)
        check(events > 5_000)
        check(narrativeLines > 10_000)
        check(uniqueNarrativeLines.size >= 250) {
            "La narration manque de variété : ${uniqueNarrativeLines.size} lignes uniques."
        }

        println("20 profils historiques validés")
        println("190 affrontements jouables")
        println("$events événements sportifs audités")
        println("$narrativeLines lignes narratives générées")
        println("${uniqueNarrativeLines.size} lignes narratives uniques")
        println("0 divergence déterministe")
        println("12 contrôles Jalon 7 étape 1 réussis")
    }

    private fun tactics(style: BoxingStyle): List<Tactic> = when (style) {
        BoxingStyle.OUT_BOXER -> listOf(Tactic.CONTROL, Tactic.COUNTER, Tactic.RECOVER)
        BoxingStyle.PRESSURE_FIGHTER -> listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)
        BoxingStyle.COUNTERPUNCHER -> listOf(Tactic.COUNTER, Tactic.CONTROL, Tactic.COUNTER)
        BoxingStyle.BOXER_PUNCHER -> listOf(Tactic.CONTROL, Tactic.PRESS, Tactic.SEEK_KO)
        BoxingStyle.SWARMER -> listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.SEEK_KO)
        BoxingStyle.SLUGGER -> listOf(Tactic.CONTROL, Tactic.PRESS, Tactic.SEEK_KO)
        BoxingStyle.DEFENSIVE_SPECIALIST -> listOf(Tactic.COUNTER, Tactic.CONTROL, Tactic.RECOVER)
    }
}
