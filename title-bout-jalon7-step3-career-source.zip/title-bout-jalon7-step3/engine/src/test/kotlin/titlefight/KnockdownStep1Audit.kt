package titlefight

import java.util.Locale

private val STEP1_VEGA_TACTICS = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
private val STEP1_KESSLER_TACTICS = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

data class KnockdownStep1AuditResult(
    val fightCount: Int,
    val totalSequences: Int,
    val knockdowns: Int,
    val knockdownsOnMisses: Int,
    val knockdownsBelowMinimumImpact: Int,
    val redCornerKnockdownsScored: Int,
    val blueCornerKnockdownsScored: Int,
    val vegaKnockdownsScored: Int,
    val kesslerKnockdownsScored: Int,
    val averageImpact: Double,
    val minimumImpact: Double,
    val maximumImpact: Double,
) {
    init {
        require(fightCount > 0)
        require(totalSequences == fightCount * 36)
        require(knockdownsOnMisses == 0)
        require(knockdownsBelowMinimumImpact == 0)
        require(redCornerKnockdownsScored + blueCornerKnockdownsScored == knockdowns)
        require(vegaKnockdownsScored + kesslerKnockdownsScored == knockdowns)
    }
}

object KnockdownStep1Auditor {
    fun run(fightCount: Int = 1000, seedStart: Long = 2026073000L): KnockdownStep1AuditResult {
        require(fightCount == 1000) { "L’audit de l’étape 1 utilise exactement 1 000 combats." }
        val engine = FightEngine(stopOnTenCount = false, stopOnTko = false)
        var knockdowns = 0
        var knockdownsOnMisses = 0
        var knockdownsBelowMinimumImpact = 0
        var redCornerKnockdownsScored = 0
        var blueCornerKnockdownsScored = 0
        var vegaKnockdownsScored = 0
        var kesslerKnockdownsScored = 0
        val impacts = mutableListOf<Double>()

        repeat(fightCount) { index ->
            val vegaInRedCorner = index % 2 == 0
            val fight = if (vegaInRedCorner) {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = STEP1_VEGA_TACTICS,
                    blueTactics = STEP1_KESSLER_TACTICS,
                    seed = seedStart + index,
                )
            } else {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.brunoKessler,
                    blue = TestProfiles.eliasVega,
                    redTactics = STEP1_KESSLER_TACTICS,
                    blueTactics = STEP1_VEGA_TACTICS,
                    seed = seedStart + index,
                )
            }

            fight.rounds.flatMap { it.events }.forEach { event ->
                val knockdown = event.knockdown ?: return@forEach
                knockdowns++
                if (!event.landed) knockdownsOnMisses++
                val minimumImpact = if (event.punch == Punch.JAB) 5.8 else 5.2
                if (event.impact < minimumImpact) knockdownsBelowMinimumImpact++
                if (event.attackerId == fight.redId) redCornerKnockdownsScored++ else blueCornerKnockdownsScored++
                if (event.attackerId == TestProfiles.eliasVega.id) vegaKnockdownsScored++ else kesslerKnockdownsScored++
                impacts += knockdown.impact
            }
        }

        return KnockdownStep1AuditResult(
            fightCount = fightCount,
            totalSequences = fightCount * 36,
            knockdowns = knockdowns,
            knockdownsOnMisses = knockdownsOnMisses,
            knockdownsBelowMinimumImpact = knockdownsBelowMinimumImpact,
            redCornerKnockdownsScored = redCornerKnockdownsScored,
            blueCornerKnockdownsScored = blueCornerKnockdownsScored,
            vegaKnockdownsScored = vegaKnockdownsScored,
            kesslerKnockdownsScored = kesslerKnockdownsScored,
            averageImpact = impacts.ifEmpty { listOf(0.0) }.average(),
            minimumImpact = impacts.minOrNull() ?: 0.0,
            maximumImpact = impacts.maxOrNull() ?: 0.0,
        )
    }
}

object KnockdownStep1AuditFormatter {
    fun format(result: KnockdownStep1AuditResult): String = buildString {
        appendLine("TITLE FIGHT — Jalon 2, étape 1")
        appendLine("Audit de la détection de chute, sans compte ni arrêt")
        appendLine()
        appendLine("Combats : ${result.fightCount}")
        appendLine("Séquences : ${result.totalSequences}")
        appendLine("Chutes détectées : ${result.knockdowns}")
        appendLine("Chutes sur attaque manquée : ${result.knockdownsOnMisses}")
        appendLine("Chutes sous le seuil minimal d’impact : ${result.knockdownsBelowMinimumImpact}")
        appendLine("Coin rouge / bleu : ${result.redCornerKnockdownsScored} / ${result.blueCornerKnockdownsScored}")
        appendLine("Elias Vega / Bruno Kessler : ${result.vegaKnockdownsScored} / ${result.kesslerKnockdownsScored}")
        appendLine("Impact des chutes : moyenne ${decimal(result.averageImpact)}, minimum ${decimal(result.minimumImpact)}, maximum ${decimal(result.maximumImpact)}")
        appendLine()
        appendLine("Le combat continue après chaque chute. Aucun compte, KO ou TKO n’est calculé à cette étape.")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
}

object KnockdownStep1AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        print(KnockdownStep1AuditFormatter.format(KnockdownStep1Auditor.run()))
    }
}
