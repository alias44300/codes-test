package titlefight

import java.util.Locale
import kotlin.math.abs


data class JudgeProfileAuditStats(
    val judgeId: String,
    val judgeName: String,
    val redRoundWins: Int,
    val blueRoundWins: Int,
    val tiedRounds: Int,
    val tenNineRounds: Int,
    val tenEightRounds: Int,
    val tenSevenRounds: Int,
    val tenTenRounds: Int,
) {
    val scoredRounds: Int get() = redRoundWins + blueRoundWins + tiedRounds
}

data class ThreeJudgeStep3AuditResult(
    val fightCount: Int,
    val simulatedRounds: Int,
    val scoredRounds: Int,
    val stoppedRoundsSkipped: Int,
    val totalJudgeScores: Int,
    val unanimousScorelineRounds: Int,
    val disagreementRounds: Int,
    val threeOutcomeRounds: Int,
    val knockdownRounds: Int,
    val knockdownUnanimityViolations: Int,
    val scoreMismatchCount: Int,
    val invalidScoreCount: Int,
    val blankExplanationCount: Int,
    val stoppedRoundScoreCount: Int,
    val maximumMarginSpread: Double,
    val judgeStats: List<JudgeProfileAuditStats>,
) {
    init {
        require(fightCount == 1000)
        require(scoredRounds + stoppedRoundsSkipped == simulatedRounds)
        require(totalJudgeScores == scoredRounds * 3)
        require(unanimousScorelineRounds + disagreementRounds == scoredRounds)
        require(judgeStats.size == 3)
        judgeStats.forEach { require(it.scoredRounds == scoredRounds) }
    }

    val disagreementShare: Double get() = if (scoredRounds == 0) 0.0 else disagreementRounds.toDouble() / scoredRounds
}

object ThreeJudgeStep3Auditor {
    private val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
    private val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

    private data class MutableJudgeStats(
        val profile: JudgeProfile,
        var redWins: Int = 0,
        var blueWins: Int = 0,
        var ties: Int = 0,
        var tenNine: Int = 0,
        var tenEight: Int = 0,
        var tenSeven: Int = 0,
        var tenTen: Int = 0,
    )

    fun run(seedStart: Long = 202607240000L): ThreeJudgeStep3AuditResult {
        val engine = FightEngine()
        val stats = JudgeProfiles.ALL.associate { it.id to MutableJudgeStats(it) }.toMutableMap()
        var simulatedRounds = 0
        var scoredRounds = 0
        var stoppedRoundsSkipped = 0
        var totalJudgeScores = 0
        var unanimousScorelineRounds = 0
        var disagreementRounds = 0
        var threeOutcomeRounds = 0
        var knockdownRounds = 0
        var knockdownUnanimityViolations = 0
        var scoreMismatchCount = 0
        var invalidScoreCount = 0
        var blankExplanationCount = 0
        var stoppedRoundScoreCount = 0
        var maximumMarginSpread = 0.0

        repeat(1000) { index ->
            val vegaInRed = index % 2 == 0
            val fight = if (vegaInRed) {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = vegaTactics,
                    blueTactics = kesslerTactics,
                    seed = seedStart + index,
                )
            } else {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.brunoKessler,
                    blue = TestProfiles.eliasVega,
                    redTactics = kesslerTactics,
                    blueTactics = vegaTactics,
                    seed = seedStart + index,
                )
            }

            fight.rounds.forEach { round ->
                simulatedRounds++
                if (round.stoppage != null) {
                    stoppedRoundsSkipped++
                    stoppedRoundScoreCount += round.judgeScores.size
                    return@forEach
                }

                scoredRounds++
                val scores = round.judgeScores
                totalJudgeScores += scores.size
                if (scores != ThreeJudgePanel.score(round.judgingEvidence)) scoreMismatchCount++
                if (scores.size != 3 || scores.map { it.judgeId } != JudgeProfiles.ALL.map { it.id }) {
                    invalidScoreCount++
                    return@forEach
                }

                val scorelineKeys = scores.map { Triple(it.redPoints, it.bluePoints, it.winnerId) }.toSet()
                if (scorelineKeys.size == 1) unanimousScorelineRounds++ else disagreementRounds++
                if (scores.map { it.winnerId }.toSet().size == 3) threeOutcomeRounds++

                val margins = scores.map { it.meritMargin }
                maximumMarginSpread = maxOf(maximumMarginSpread, margins.max() - margins.min())

                val kdDifference = round.judgingEvidence.red.knockdownsScored - round.judgingEvidence.blue.knockdownsScored
                if (kdDifference != 0) {
                    knockdownRounds++
                    val expectedWinner = if (kdDifference > 0) round.judgingEvidence.red.fighterId else round.judgingEvidence.blue.fighterId
                    val expectedLoserPoints = if (abs(kdDifference) >= 2) 7 else 8
                    if (scores.any { score ->
                            score.winnerId != expectedWinner ||
                                (if (kdDifference > 0) score.bluePoints else score.redPoints) != expectedLoserPoints
                        }
                    ) {
                        knockdownUnanimityViolations++
                    }
                }

                scores.forEach { score ->
                    val stat = stats.getValue(score.judgeId)
                    if (score.explanation.isBlank() || score.decisiveFactors.isEmpty()) blankExplanationCount++
                    when (score.redPoints to score.bluePoints) {
                        10 to 9, 9 to 10 -> stat.tenNine++
                        10 to 8, 8 to 10 -> stat.tenEight++
                        10 to 7, 7 to 10 -> stat.tenSeven++
                        10 to 10 -> stat.tenTen++
                        else -> invalidScoreCount++
                    }
                    when (score.winnerId) {
                        score.redFighterId -> stat.redWins++
                        score.blueFighterId -> stat.blueWins++
                        null -> stat.ties++
                        else -> invalidScoreCount++
                    }
                }
            }
        }

        return ThreeJudgeStep3AuditResult(
            fightCount = 1000,
            simulatedRounds = simulatedRounds,
            scoredRounds = scoredRounds,
            stoppedRoundsSkipped = stoppedRoundsSkipped,
            totalJudgeScores = totalJudgeScores,
            unanimousScorelineRounds = unanimousScorelineRounds,
            disagreementRounds = disagreementRounds,
            threeOutcomeRounds = threeOutcomeRounds,
            knockdownRounds = knockdownRounds,
            knockdownUnanimityViolations = knockdownUnanimityViolations,
            scoreMismatchCount = scoreMismatchCount,
            invalidScoreCount = invalidScoreCount,
            blankExplanationCount = blankExplanationCount,
            stoppedRoundScoreCount = stoppedRoundScoreCount,
            maximumMarginSpread = maximumMarginSpread,
            judgeStats = JudgeProfiles.ALL.map { profile ->
                val stat = stats.getValue(profile.id)
                JudgeProfileAuditStats(
                    judgeId = profile.id,
                    judgeName = profile.name,
                    redRoundWins = stat.redWins,
                    blueRoundWins = stat.blueWins,
                    tiedRounds = stat.ties,
                    tenNineRounds = stat.tenNine,
                    tenEightRounds = stat.tenEight,
                    tenSevenRounds = stat.tenSeven,
                    tenTenRounds = stat.tenTen,
                )
            },
        )
    }
}

object ThreeJudgeStep3AuditFormatter {
    fun format(result: ThreeJudgeStep3AuditResult): String = buildString {
        appendLine("TITLE FIGHT — JALON 3 — ÉTAPE 3")
        appendLine("AUDIT DES TROIS PROFILS DE JUGE")
        appendLine()
        appendLine("Combats : ${result.fightCount}")
        appendLine("Rounds simulés : ${result.simulatedRounds}")
        appendLine("Rounds jugés : ${result.scoredRounds}")
        appendLine("Rounds interrompus et non jugés : ${result.stoppedRoundsSkipped}")
        appendLine("Notes individuelles : ${result.totalJudgeScores}")
        appendLine()
        appendLine("Rounds avec score identique des trois juges : ${result.unanimousScorelineRounds}")
        appendLine("Rounds avec désaccord : ${result.disagreementRounds} (${percent(result.disagreementShare)})")
        appendLine("Rounds rouge / bleu / nul simultanément : ${result.threeOutcomeRounds}")
        appendLine("Écart maximal de marge pondérée entre juges : ${decimal(result.maximumMarginSpread)}")
        appendLine()
        appendLine("Rounds avec knockdown : ${result.knockdownRounds}")
        appendLine("Violations d'unanimité sur knockdown : ${result.knockdownUnanimityViolations}")
        appendLine("Écarts de reproductibilité : ${result.scoreMismatchCount}")
        appendLine("Scores invalides : ${result.invalidScoreCount}")
        appendLine("Justifications vides : ${result.blankExplanationCount}")
        appendLine("Notes attachées à un round interrompu : ${result.stoppedRoundScoreCount}")
        appendLine()
        result.judgeStats.forEach { stat ->
            appendLine("${stat.judgeName} : rouge ${stat.redRoundWins}, bleu ${stat.blueRoundWins}, nuls ${stat.tiedRounds}; 10-9 ${stat.tenNineRounds}, 10-8 ${stat.tenEightRounds}, 10-7 ${stat.tenSevenRounds}, 10-10 ${stat.tenTenRounds}")
        }
        appendLine()
        appendLine("Aucun total de carte et aucune décision officielle ne sont produits à cette étape.")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
    private fun percent(value: Double): String = String.format(Locale.US, "%.2f %%", value * 100.0)
}

object ThreeJudgeStep3AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        Locale.setDefault(Locale.FRANCE)
        print(ThreeJudgeStep3AuditFormatter.format(ThreeJudgeStep3Auditor.run()))
    }
}
