#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build-step4"
cd "$ROOT"
rm -rf "$BUILD"
mkdir -p "$BUILD"
kotlinc -J-Xmx2048m -J-Dfile.encoding=UTF-8 \
  engine/src/main/kotlin/titlefight/*.kt \
  engine/src/test/kotlin/titlefight/*.kt \
  -d "$BUILD/title-fight-jalon5-step4.jar"
kotlin -J-Xmx2g -J-Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-jalon5-step4.jar" titlefight.FightEngineTest
kotlin -J-Xmx2g -J-Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-jalon5-step4.jar" titlefight.Jalon5Step4AuditDemo
