package titlefight

enum class NarrativeTag {
    SETUP,
    FOOTWORK,
    OFFENSE,
    DEFENSE,
    BODY_ATTACK,
    CLEAN_HIT,
    HEAVY_HIT,
    KNOCKDOWN,
    COUNT,
    STOPPAGE,
    FATIGUE,
    ROPES,
    TACTICAL,
}

data class NarrativeCommentary(
    val primary: String,
    val lines: List<String>,
    val tags: Set<NarrativeTag>,
) {
    init {
        require(primary.isNotBlank())
        require(lines.size in 1..5)
        require(lines.none { it.isBlank() })
        require(primary == lines.joinToString("\n"))
    }
}

/**
 * Couche narrative strictement observationnelle.
 *
 * Elle n'utilise aucun générateur aléatoire du moteur. Les variantes sont
 * choisies par un hachage stable de l'événement, du round et de la séquence.
 * Le même combat conserve donc exactement le même texte et les mêmes résultats.
 */
object NarrativeCommentaryEngine {
    fun describe(
        event: SequenceEvent,
        red: BoxerProfile,
        blue: BoxerProfile,
        roundNumber: Int,
        redState: FighterState,
        blueState: FighterState,
        stoppage: FightStoppage? = null,
        previousEvent: SequenceEvent? = null,
    ): NarrativeCommentary {
        val attacker = profile(event.attackerId, red, blue)
        val defender = profile(event.defenderId, red, blue)
        val attackerState = if (attacker.id == red.id) redState else blueState
        val defenderState = if (defender.id == red.id) redState else blueState
        val key = stableKey(event, roundNumber, attacker, defender)
        val lines = mutableListOf<String>()
        val tags = linkedSetOf<NarrativeTag>()

        lines += setupLine(event, attacker, defender, previousEvent, key)
        tags += NarrativeTag.SETUP
        if (event.range == FightRange.OUTSIDE) tags += NarrativeTag.FOOTWORK
        if (event.range == FightRange.INSIDE) tags += NarrativeTag.ROPES

        val count = event.knockdown?.refereeCount
        when {
            stoppage?.method == FightMethod.TKO -> {
                lines += impactLine(event, attacker, defender, key + 11)
                lines += "${defender.name} ne répond plus correctement. L'arbitre s'interpose et protège le boxeur."
                lines += "${attacker.name} remporte le combat par TKO."
                tags += setOf(NarrativeTag.OFFENSE, NarrativeTag.HEAVY_HIT, NarrativeTag.STOPPAGE)
            }
            count?.countReached == 10 -> {
                lines += impactLine(event, attacker, defender, key + 13)
                lines += "${defender.name} reste au sol pendant que le compte atteint dix."
                lines += "KO. ${attacker.name} gagne immédiatement."
                tags += setOf(NarrativeTag.OFFENSE, NarrativeTag.KNOCKDOWN, NarrativeTag.COUNT, NarrativeTag.STOPPAGE)
            }
            count != null -> {
                lines += impactLine(event, attacker, defender, key + 17)
                lines += pick(
                    listOf(
                        "${defender.name} tombe près des cordes. L'arbitre écarte ${attacker.name} et commence le compte.",
                        "Les jambes de ${defender.name} cèdent. L'arbitre lance le compte sans hésiter.",
                        "${defender.name} touche le tapis. ${attacker.name} rejoint le coin neutre.",
                        "La chute est nette. L'arbitre surveille les yeux de ${defender.name} pendant le compte.",
                    ),
                    key + 19,
                )
                lines += if (count.recovered) {
                    "${defender.name} se relève au compte de ${count.countReached}, encore vulnérable."
                } else {
                    "Le compte atteint ${count.countReached}. ${defender.name} ne peut pas reprendre."
                }
                tags += setOf(NarrativeTag.OFFENSE, NarrativeTag.KNOCKDOWN, NarrativeTag.COUNT)
            }
            event.clean -> {
                lines += attackLine(event, attacker, defender, key + 23)
                lines += impactLine(event, attacker, defender, key + 29)
                consequenceLine(defender, defenderState, event, key + 31)?.let { lines += it }
                tags += setOf(NarrativeTag.OFFENSE, NarrativeTag.CLEAN_HIT)
                if (event.impact >= 8.5) tags += NarrativeTag.HEAVY_HIT
            }
            event.landed -> {
                lines += attackLine(event, attacker, defender, key + 37)
                lines += guardedImpactLine(event, attacker, defender, key + 41)
                if (event.punch == Punch.BODY_HOOK) tags += NarrativeTag.BODY_ATTACK
                tags += NarrativeTag.OFFENSE
            }
            else -> {
                lines += attackLine(event, attacker, defender, key + 43)
                lines += defenseLine(event, defender, key + 47)
                tags += NarrativeTag.DEFENSE
            }
        }

        if (stoppage == null && attackerState.stamina <= 36.0 && lines.size < 5) {
            lines += "${attacker.name} termine l'action en respirant lourdement. Son rythme devient plus coûteux."
            tags += NarrativeTag.FATIGUE
        } else if (stoppage == null && defenderState.stamina <= 32.0 && lines.size < 5) {
            lines += "${defender.name} économise ses déplacements et cherche quelques secondes de répit."
            tags += NarrativeTag.FATIGUE
        }

        val trimmed = lines.take(5)
        return NarrativeCommentary(
            primary = trimmed.joinToString("\n"),
            lines = trimmed,
            tags = tags,
        )
    }

    private fun setupLine(
        event: SequenceEvent,
        attacker: BoxerProfile,
        defender: BoxerProfile,
        previousEvent: SequenceEvent?,
        key: Int,
    ): String {
        if (previousEvent?.attackerId == attacker.id && previousEvent.landed) {
            return pick(
                listOf(
                    "${attacker.name} conserve l'initiative et refuse de laisser ${defender.name} se réorganiser.",
                    "Après sa réussite précédente, ${attacker.name} remet immédiatement la pression.",
                    "${defender.name} n'a pas encore repris sa position que ${attacker.name} repart à l'attaque.",
                ),
                key,
            )
        }
        return when (event.range) {
            FightRange.OUTSIDE -> pick(
                listOf(
                    "${attacker.name} travaille à longue distance et fait réagir la garde de ${defender.name}.",
                    "${attacker.name} prend le centre, mesure l'allonge et garde ${defender.name} au bout des gants.",
                    "Un pas latéral ouvre la ligne. ${attacker.name} prépare l'attaque depuis l'extérieur.",
                    "${attacker.name} change légèrement d'angle avant d'engager à longue portée.",
                    "${defender.name} cherche l'entrée, mais ${attacker.name} contrôle encore l'espace.",
                ),
                key,
            )
            FightRange.MID -> pick(
                listOf(
                    "Les deux boxeurs se retrouvent à mi-distance. ${attacker.name} déclenche le premier.",
                    "${attacker.name} feinte du buste et force ${defender.name} à figer sa garde.",
                    "Le combat se resserre au centre. ${attacker.name} aperçoit une ouverture.",
                    "${attacker.name} avance derrière une feinte et entre dans la zone d'échange.",
                    "${defender.name} hésite une fraction de seconde. ${attacker.name} exploite ce temps mort.",
                ),
                key,
            )
            FightRange.INSIDE -> pick(
                listOf(
                    "Épaule contre épaule, ${attacker.name} libère une main à courte distance.",
                    "${attacker.name} enferme ${defender.name} dans un échange compact.",
                    "Le front presque contre le front, ${attacker.name} cherche de l'espace pour frapper.",
                    "${attacker.name} travaille dans la poche pendant que ${defender.name} tente de nouer le clinch.",
                    "La distance disparaît. ${attacker.name} garde les coudes serrés et prépare un coup court.",
                ),
                key,
            )
        }
    }

    private fun attackLine(event: SequenceEvent, attacker: BoxerProfile, defender: BoxerProfile, key: Int): String = when (event.punch) {
        Punch.JAB -> pick(
            listOf(
                "${attacker.name} lance un jab sec vers le visage.",
                "Le bras avant de ${attacker.name} part sans appel.",
                "${attacker.name} double presque son jab pour casser le rythme de ${defender.name}.",
                "Un jab de mesure devient soudain une attaque franche.",
                "${attacker.name} pique la garde avec son bras avant.",
            ), key,
        )
        Punch.CROSS -> pick(
            listOf(
                "${attacker.name} transfère le poids et lâche la main arrière.",
                "Le direct de ${attacker.name} traverse la ligne centrale.",
                "${attacker.name} arme une droite rectiligne derrière l'épaule.",
                "Après la feinte, la main arrière de ${attacker.name} fuse vers la cible.",
                "${attacker.name} plante ses appuis et déclenche le direct.",
            ), key,
        )
        Punch.HOOK -> pick(
            listOf(
                "${attacker.name} referme un crochet autour de la garde.",
                "Le coude monte et ${attacker.name} déclenche un crochet compact.",
                "${attacker.name} pivote sur l'appui avant pour fouetter le crochet.",
                "Un crochet large de ${attacker.name} contourne la défense.",
                "${attacker.name} raccourcit le bras et vise la tempe.",
            ), key,
        )
        Punch.UPPERCUT -> pick(
            listOf(
                "${attacker.name} trouve l'axe intérieur et remonte un uppercut.",
                "L'uppercut de ${attacker.name} part entre les deux gants.",
                "${attacker.name} fléchit les jambes puis remonte le poing sous la garde.",
                "À courte portée, ${attacker.name} déclenche un uppercut vif.",
                "${attacker.name} crée une brèche avec l'épaule et frappe de bas en haut.",
            ), key,
        )
        Punch.BODY_HOOK -> pick(
            listOf(
                "${attacker.name} descend son niveau et cherche les côtes.",
                "Un crochet au corps de ${attacker.name} part sous le coude.",
                "${attacker.name} fixe la tête puis tourne vers le flanc.",
                "Le poing de ${attacker.name} plonge vers le foie.",
                "${attacker.name} compacte sa garde et frappe au corps.",
            ), key,
        )
        Punch.COMBINATION -> pick(
            listOf(
                "${attacker.name} enchaîne plusieurs coups sans rendre l'initiative.",
                "Une combinaison tête-corps de ${attacker.name} oblige ${defender.name} à choisir sa défense.",
                "${attacker.name} accélère avec une rafale courte.",
                "Les deux mains de ${attacker.name} travaillent en alternance.",
                "${attacker.name} varie les niveaux au milieu d'une combinaison rapide.",
            ), key,
        )
    }

    private fun impactLine(event: SequenceEvent, attacker: BoxerProfile, defender: BoxerProfile, key: Int): String {
        val location = if (event.punch == Punch.BODY_HOOK) "au corps" else "à la tête"
        return if (event.impact >= 9.5) {
            pick(
                listOf(
                    "L'impact explose $location. ${defender.name} perd immédiatement son équilibre.",
                    "Le coup arrive avec une puissance brutale. ${defender.name} vacille nettement.",
                    "${defender.name} est secoué jusque dans les jambes par la frappe de ${attacker.name}.",
                    "La frappe traverse la défense et déplace tout le buste de ${defender.name}.",
                ), key,
            )
        } else {
            pick(
                listOf(
                    "Le coup arrive proprement $location et interrompt l'action de ${defender.name}.",
                    "${defender.name} est touché net avant de pouvoir répondre.",
                    "La précision de ${attacker.name} fait la différence sur cet échange.",
                    "Le gant atteint la cible sans être dévié. ${defender.name} doit se replacer.",
                    "${attacker.name} trouve une ouverture franche dans la défense.",
                ), key,
            )
        }
    }

    private fun guardedImpactLine(event: SequenceEvent, attacker: BoxerProfile, defender: BoxerProfile, key: Int): String =
        if (event.punch == Punch.BODY_HOOK) {
            pick(
                listOf(
                    "${defender.name} serre le coude, mais une partie du coup atteint les côtes.",
                    "Le crochet est partiellement bloqué. Le corps de ${defender.name} absorbe malgré tout l'impact.",
                    "${attacker.name} marque au corps sans obtenir une ouverture complète.",
                    "Le gant se glisse sous la garde et ralentit légèrement ${defender.name}.",
                ), key,
            )
        } else {
            pick(
                listOf(
                    "${defender.name} amortit sur les gants, mais le coup compte.",
                    "La frappe traverse partiellement la garde et fait reculer ${defender.name}.",
                    "${attacker.name} touche sans trouver l'impact parfait.",
                    "Le coup effleure puis accroche la cible pendant le retrait de ${defender.name}.",
                    "${defender.name} roule avec la frappe, limitant les dégâts.",
                ), key,
            )
        }

    private fun defenseLine(event: SequenceEvent, defender: BoxerProfile, key: Int): String = when (event.range) {
        FightRange.OUTSIDE -> pick(
            listOf(
                "${defender.name} retire la tête et laisse le coup mourir devant le visage.",
                "Un pas arrière suffit à ${defender.name} pour sortir de portée.",
                "${defender.name} dévie la frappe avec la main avant puis reprend l'angle.",
                "Le coup passe court. ${defender.name} conserve la bonne distance.",
                "${defender.name} pivote hors de la ligne avant l'arrivée du gant.",
            ), key,
        )
        FightRange.MID -> pick(
            listOf(
                "${defender.name} glisse le buste et fait passer la frappe au-dessus de l'épaule.",
                "Une parade courte de ${defender.name} ferme l'ouverture.",
                "${defender.name} lit le départ du coup et répond par un déplacement de tête.",
                "Le blocage de ${defender.name} absorbe la tentative.",
                "${defender.name} casse l'angle juste avant l'impact.",
            ), key,
        )
        FightRange.INSIDE -> pick(
            listOf(
                "${defender.name} colle l'épaule et étouffe la frappe avant son extension.",
                "Le clinch de ${defender.name} neutralise l'attaque à courte distance.",
                "${defender.name} ferme les coudes et ne laisse aucune trajectoire propre.",
                "La frappe se perd dans les avant-bras de ${defender.name}.",
                "${defender.name} tourne dans la poche et fait manquer le coup de quelques centimètres.",
            ), key,
        )
    }

    private fun consequenceLine(
        defender: BoxerProfile,
        state: FighterState,
        event: SequenceEvent,
        key: Int,
    ): String? = when {
        state.stability <= 25.0 -> pick(
            listOf(
                "${defender.name} cherche immédiatement un appui sûr et garde les mains très hautes.",
                "Les jambes de ${defender.name} répondent mal. Le danger devient évident.",
                "${defender.name} dérive vers les cordes pour éviter un nouvel échange.",
            ), key,
        )
        state.headDamage >= 62.0 -> pick(
            listOf(
                "${defender.name} cligne des yeux et tarde à retrouver la ligne de mire.",
                "La défense de ${defender.name} se resserre autour d'une tête déjà marquée.",
                "${defender.name} secoue la tête, mais l'accumulation commence à peser.",
            ), key,
        )
        state.bodyDamage >= 64.0 || event.punch == Punch.BODY_HOOK && event.impact >= 7.0 -> pick(
            listOf(
                "${defender.name} replie le coude et respire plus court après le coup au corps.",
                "Le travail au corps ralentit la sortie de ${defender.name}.",
                "${defender.name} protège désormais davantage le flanc, ouvrant la ligne haute.",
            ), key,
        )
        event.impact >= 8.5 -> pick(
            listOf(
                "${defender.name} recule de deux pas et abandonne momentanément le centre.",
                "L'action force ${defender.name} à interrompre toute tentative de réponse.",
                "${attackerPressurePhrase(defender)}",
            ), key,
        )
        else -> null
    }

    private fun attackerPressurePhrase(defender: BoxerProfile): String =
        "${defender.name} doit maintenant choisir entre accrocher ou céder encore du terrain."

    private fun stableKey(event: SequenceEvent, roundNumber: Int, attacker: BoxerProfile, defender: BoxerProfile): Int =
        listOf(
            roundNumber,
            event.sequenceNumber,
            event.attackerId,
            event.defenderId,
            event.range.name,
            event.punch.name,
            event.landed,
            event.clean,
            (event.impact * 100.0).toInt(),
            attacker.style.name,
            defender.style.name,
        ).joinToString("|").hashCode()

    private fun <T> pick(values: List<T>, key: Int): T = values[Math.floorMod(key, values.size)]

    private fun profile(id: String, red: BoxerProfile, blue: BoxerProfile): BoxerProfile = when (id) {
        red.id -> red
        blue.id -> blue
        else -> error("Boxeur inconnu dans l'événement narratif : $id")
    }
}
