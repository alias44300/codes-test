#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build-jalon6-step3"
ENGINE_JAR="$BUILD/title-fight-jalon6-step3.jar"
if [[ ! -f "$ENGINE_JAR" ]]; then
  python3 "$ROOT/scripts/test-jalon6-step3.py" >/dev/null
fi
rm -f "$BUILD/compose-syntax-check.jar"
mkdir -p "$BUILD"
kotlinc -J-Xmx1024m -J-Dfile.encoding=UTF-8 \
  -classpath "$ENGINE_JAR" \
  $(find "$ROOT/scripts/compose-syntax-stubs" -name '*.kt' | sort) \
  "$ROOT/android-ui-compose/src/main/kotlin/titlefight/ui/compose/FightScreen.kt" \
  "$ROOT/android-ui-compose/src/main/kotlin/titlefight/ui/compose/FightScreenPreviews.kt" \
  "$ROOT/android-ui-compose/src/main/kotlin/titlefight/ui/compose/TitleFightTheme.kt" \
  -d "$BUILD/compose-syntax-check.jar"
echo "Syntaxe Kotlin des composants Compose validée avec les stubs locaux."
echo "Ce contrôle ne remplace pas une compilation Android avec le SDK et le plugin Compose."
