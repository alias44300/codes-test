package titlefight

/**
 * Phases contrôlables d'un combat interactif.
 *
 * Un round est simulé de façon atomique et déterministe. La session s'arrête
 * ensuite uniquement entre deux rounds ou à la fin du combat.
 */
enum class InteractiveFightPhase {
    READY,
    BETWEEN_ROUNDS,
    COMPLETE,
}

data class PlayerTacticalDraft(
    val anchorStyle: BoxingStyle,
    val pace: TacticalPace,
    val distance: TacticalDistance,
    val target: TacticalTarget,
    val risk: TacticalRisk,
) {
    fun toPlan(): TacticalPlan = TacticalPlan(
        anchorStyle = anchorStyle,
        pace = pace,
        distance = distance,
        target = target,
        risk = risk,
    )

    fun withPace(value: TacticalPace): PlayerTacticalDraft = copy(pace = value)
    fun withDistance(value: TacticalDistance): PlayerTacticalDraft = copy(distance = value)
    fun withTarget(value: TacticalTarget): PlayerTacticalDraft = copy(target = value)
    fun withRisk(value: TacticalRisk): PlayerTacticalDraft = copy(risk = value)

    companion object {
        fun from(plan: TacticalPlan): PlayerTacticalDraft = PlayerTacticalDraft(
            anchorStyle = plan.anchorStyle,
            pace = plan.pace,
            distance = plan.distance,
            target = plan.target,
            risk = plan.risk,
        )
    }
}

data class InteractiveFightSessionState(
    val fightSeed: Long,
    val playerCorner: FighterCorner,
    val phase: InteractiveFightPhase,
    val completedRounds: Int,
    val nextRoundNumber: Int?,
    val tacticalWindowId: Int?,
    val committedPlayerPlan: TacticalPlan,
    val pendingPlayerDraft: PlayerTacticalDraft?,
    val opponentPlan: TacticalPlan,
    val result: FightResult?,
) {
    init {
        require(completedRounds in 0..3)
        require((phase == InteractiveFightPhase.COMPLETE) == (result != null))
        require((phase == InteractiveFightPhase.BETWEEN_ROUNDS) == (tacticalWindowId != null))
        require((phase == InteractiveFightPhase.BETWEEN_ROUNDS) == (pendingPlayerDraft != null))
        require(pendingPlayerDraft == null || pendingPlayerDraft.anchorStyle == committedPlayerPlan.anchorStyle)
        when (phase) {
            InteractiveFightPhase.READY -> {
                require(completedRounds == 0)
                require(nextRoundNumber == 1)
            }
            InteractiveFightPhase.BETWEEN_ROUNDS -> {
                require(completedRounds in 1..2)
                require(nextRoundNumber == completedRounds + 1)
            }
            InteractiveFightPhase.COMPLETE -> {
                require(completedRounds in 1..3)
                require(nextRoundNumber == null)
            }
        }
    }

    val canEditTactics: Boolean
        get() = phase == InteractiveFightPhase.BETWEEN_ROUNDS

    val canConfirmTactics: Boolean
        get() = canEditTactics && pendingPlayerDraft != null

    val pendingPlayerPlan: TacticalPlan?
        get() = pendingPlayerDraft?.toPlan()

    val changedAxes: List<TacticalAxis>
        get() = pendingPlayerPlan?.let { TacticalDecision.changedAxes(committedPlayerPlan, it) }.orEmpty()
}

data class InteractiveFightAdvance(
    val state: InteractiveFightSessionState,
    val simulatedRound: RoundResult?,
    val screenTimeline: List<FightScreenState>,
)

/**
 * Session de combat pilotable par un joueur, sans réseau et sans tirage lors
 * des sélections tactiques.
 *
 * Les graines de round sont consommées uniquement au moment où un round est
 * effectivement simulé. Modifier plusieurs fois un brouillon puis revenir au
 * même plan produit donc exactement le même combat.
 */
class InteractiveFightSession(
    val red: BoxerProfile,
    val blue: BoxerProfile,
    private val redTactics: List<Tactic>,
    private val blueTactics: List<Tactic>,
    val seed: Long,
    val playerCorner: FighterCorner = FighterCorner.RED,
    sequencesPerRound: Int = FightScreenStateMapper.DEFAULT_SEQUENCES_PER_ROUND,
    stopOnTenCount: Boolean = true,
    stopOnTko: Boolean = true,
) {
    init {
        require(red.id != blue.id)
        require(redTactics.size == 3)
        require(blueTactics.size == 3)
    }

    private val engine = FightEngine(
        sequencesPerRound = sequencesPerRound,
        stopOnTenCount = stopOnTenCount,
        stopOnTko = stopOnTko,
        adaptiveTacticsEnabled = true,
    )
    private val seedStream = DeterministicRandom(seed)
    private val sequencesPerRound = sequencesPerRound
    private var redState = FighterState()
    private var blueState = FighterState()
    private val rounds = mutableListOf<RoundResult>()
    private val snapshots = mutableListOf<TacticalStateSnapshot>()
    private val decisions = mutableListOf<TacticalDecision>()
    private val redHistory = mutableListOf<TacticalDecision>()
    private val blueHistory = mutableListOf<TacticalDecision>()
    private var phase = InteractiveFightPhase.READY
    private var windowCounter = 0
    private var openWindowId: Int? = null
    private var pendingDraft: PlayerTacticalDraft? = null
    private var finalResult: FightResult? = null

    fun state(): InteractiveFightSessionState {
        val playerHistory = playerHistory()
        val opponentHistory = opponentHistory()
        return InteractiveFightSessionState(
            fightSeed = seed,
            playerCorner = playerCorner,
            phase = phase,
            completedRounds = rounds.size,
            nextRoundNumber = if (phase == InteractiveFightPhase.COMPLETE) null else rounds.size + 1,
            tacticalWindowId = openWindowId,
            committedPlayerPlan = playerHistory.lastOrNull()?.selectedPlan ?: TacticalPlanCatalog.naturalFor(playerProfile()),
            pendingPlayerDraft = pendingDraft,
            opponentPlan = opponentHistory.lastOrNull()?.selectedPlan ?: TacticalPlanCatalog.naturalFor(opponentProfile()),
            result = finalResult,
        )
    }

    fun start(): InteractiveFightAdvance {
        check(phase == InteractiveFightPhase.READY) { "Le combat a déjà commencé." }
        val round = simulateNextRound(playerPlanOverride = null)
        return advance(round)
    }

    fun selectPace(windowId: Int, value: TacticalPace): InteractiveFightSessionState =
        updateDraft(windowId) { it.withPace(value) }

    fun selectDistance(windowId: Int, value: TacticalDistance): InteractiveFightSessionState =
        updateDraft(windowId) { it.withDistance(value) }

    fun selectTarget(windowId: Int, value: TacticalTarget): InteractiveFightSessionState =
        updateDraft(windowId) { it.withTarget(value) }

    fun selectRisk(windowId: Int, value: TacticalRisk): InteractiveFightSessionState =
        updateDraft(windowId) { it.withRisk(value) }

    fun replaceDraft(windowId: Int, draft: PlayerTacticalDraft): InteractiveFightSessionState {
        require(draft.anchorStyle == playerProfile().style) {
            "Le style d'ancrage du joueur ne peut pas être remplacé par l'interface."
        }
        return updateDraft(windowId) { draft }
    }

    fun confirmAndContinue(windowId: Int): InteractiveFightAdvance {
        requireOpenWindow(windowId)
        val plan = requireNotNull(pendingDraft).toPlan()
        // Fermer avant la simulation protège contre une double confirmation du même jeton.
        openWindowId = null
        pendingDraft = null
        val round = simulateNextRound(playerPlanOverride = plan)
        return advance(round)
    }

    fun screenTimeline(): List<FightScreenState> = InteractiveFightScreenStateMapper.buildTimeline(this)

    internal fun roundsView(): List<RoundResult> = rounds.toList()
    internal fun snapshotsView(): List<TacticalStateSnapshot> = snapshots.toList()
    internal fun decisionsView(): List<TacticalDecision> = decisions.toList()
    internal fun resultView(): FightResult? = finalResult
    internal fun sequencesPerRound(): Int = sequencesPerRound

    private fun updateDraft(
        windowId: Int,
        transform: (PlayerTacticalDraft) -> PlayerTacticalDraft,
    ): InteractiveFightSessionState {
        requireOpenWindow(windowId)
        val current = requireNotNull(pendingDraft)
        val updated = transform(current)
        require(updated.anchorStyle == playerProfile().style)
        pendingDraft = updated
        return state()
    }

    private fun requireOpenWindow(windowId: Int) {
        check(phase == InteractiveFightPhase.BETWEEN_ROUNDS) {
            "Les tactiques ne sont modifiables qu'entre les rounds."
        }
        check(openWindowId == windowId) {
            "Fenêtre tactique expirée ou déjà validée."
        }
    }

    private fun simulateNextRound(playerPlanOverride: TacticalPlan?): RoundResult {
        val roundNumber = rounds.size + 1
        require(roundNumber in 1..3)
        val snapshot = TacticalStateSnapshotExtractor.extract(
            red = red,
            blue = blue,
            redState = redState,
            blueState = blueState,
            completedRounds = rounds.map(TacticalRoundFacts::fromCompletedRound),
            nextRoundNumber = roundNumber,
            sequencesPerRound = sequencesPerRound,
        )
        snapshots += snapshot

        val redDecision: TacticalDecision
        val blueDecision: TacticalDecision
        if (roundNumber == 1) {
            redDecision = TacticalDecisionEngine.decide(red, snapshot, redHistory)
            blueDecision = TacticalDecisionEngine.decide(blue, snapshot, blueHistory)
        } else if (playerCorner == FighterCorner.RED) {
            redDecision = playerDecision(red, roundNumber, requireNotNull(playerPlanOverride), redHistory.last().selectedPlan)
            blueDecision = TacticalDecisionEngine.decide(blue, snapshot, blueHistory)
        } else {
            redDecision = TacticalDecisionEngine.decide(red, snapshot, redHistory)
            blueDecision = playerDecision(blue, roundNumber, requireNotNull(playerPlanOverride), blueHistory.last().selectedPlan)
        }
        redHistory += redDecision
        blueHistory += blueDecision
        decisions += redDecision
        decisions += blueDecision

        val round = engine.simulateRound(
            roundNumber = roundNumber,
            red = red,
            blue = blue,
            redStart = redState,
            blueStart = blueState,
            redTactic = redTactics[roundNumber - 1],
            blueTactic = blueTactics[roundNumber - 1],
            seed = seedStream.nextLong(),
            redPlan = redDecision.selectedPlan,
            bluePlan = blueDecision.selectedPlan,
        )
        rounds += round
        redState = round.redState
        blueState = round.blueState

        if (round.stoppage != null || roundNumber == 3) {
            finalResult = buildResult()
            phase = InteractiveFightPhase.COMPLETE
            openWindowId = null
            pendingDraft = null
        } else {
            phase = InteractiveFightPhase.BETWEEN_ROUNDS
            windowCounter += 1
            openWindowId = windowCounter
            pendingDraft = PlayerTacticalDraft.from(playerDecisionFor(roundNumber).selectedPlan)
        }
        return round
    }

    private fun playerDecision(
        profile: BoxerProfile,
        beforeRound: Int,
        selectedPlan: TacticalPlan,
        previousPlan: TacticalPlan,
    ): TacticalDecision {
        require(selectedPlan.anchorStyle == profile.style)
        return TacticalDecision(
            fighterId = profile.id,
            beforeRound = beforeRound,
            phase = TacticalDecisionPhase.BETWEEN_ROUNDS,
            previousPlan = previousPlan,
            selectedPlan = selectedPlan,
            changedAxes = TacticalDecision.changedAxes(previousPlan, selectedPlan),
            triggers = listOf(TacticalDecisionTrigger.PLAYER_SELECTION),
            explanation = if (selectedPlan == previousPlan) {
                "Le joueur conserve son plan pour le round $beforeRound."
            } else {
                "Le joueur valide un nouveau plan pour le round $beforeRound."
            },
        )
    }

    private fun buildResult(): FightResult {
        val stoppage = rounds.last().stoppage
        val official = if (stoppage == null) OfficialDecisionResolver.resolve(red.id, blue.id, rounds) else null
        return FightResult(
            redId = red.id,
            blueId = blue.id,
            seed = seed,
            rounds = rounds.toList(),
            finalRedState = redState,
            finalBlueState = blueState,
            redPerformanceTotal = rounds.sumOf { it.redRoundScore },
            bluePerformanceTotal = rounds.sumOf { it.blueRoundScore },
            tacticalSnapshots = snapshots.toList(),
            tacticalDecisions = decisions.toList(),
            adaptiveTacticsEnabled = true,
            stoppage = stoppage,
            officialDecision = official,
        )
    }

    private fun playerProfile(): BoxerProfile = if (playerCorner == FighterCorner.RED) red else blue
    private fun opponentProfile(): BoxerProfile = if (playerCorner == FighterCorner.RED) blue else red
    private fun playerHistory(): List<TacticalDecision> = if (playerCorner == FighterCorner.RED) redHistory else blueHistory
    private fun opponentHistory(): List<TacticalDecision> = if (playerCorner == FighterCorner.RED) blueHistory else redHistory
    private fun playerDecisionFor(roundNumber: Int): TacticalDecision =
        decisions.single { it.fighterId == playerProfile().id && it.beforeRound == roundNumber }

    private fun advance(round: RoundResult): InteractiveFightAdvance = InteractiveFightAdvance(
        state = state(),
        simulatedRound = round,
        screenTimeline = screenTimeline(),
    )
}

/**
 * Mapper progressif vers le même contrat d'écran que le combat complet.
 */
object InteractiveFightScreenStateMapper {
    fun buildTimeline(session: InteractiveFightSession): List<FightScreenState> {
        val rounds = session.roundsView()
        if (rounds.isEmpty()) return emptyList()
        val snapshots = session.snapshotsView()
        val decisions = session.decisionsView()
        val result = session.resultView()
        val red = session.red
        val blue = session.blue
        val sequencesPerRound = session.sequencesPerRound()
        val comments = mutableListOf<String>()
        val timeline = mutableListOf<FightScreenState>()

        val firstSnapshot = snapshots.first()
        val firstRedDecision = decision(decisions, red.id, 1)
        val firstBlueDecision = decision(decisions, blue.id, 1)
        timeline += FightScreenState(
            fightSeed = session.seed,
            phase = FightScreenPhase.PRE_FIGHT,
            roundNumber = 1,
            totalRounds = 3,
            sequenceNumber = 0,
            sequencesPerRound = sequencesPerRound,
            clock = FightClockState(FightScreenStateMapper.ROUND_SECONDS),
            red = FightScreenStateMapper.fighterFromSnapshot(red, FighterCorner.RED, firstSnapshot.red, firstRedDecision),
            blue = FightScreenStateMapper.fighterFromSnapshot(blue, FighterCorner.BLUE, firstSnapshot.blue, firstBlueDecision),
            currentAction = null,
            commentary = "Les deux boxeurs sont prêts. Le combat va commencer.",
            recentCommentary = emptyList(),
            tacticalWindowOpen = false,
            result = null,
        )

        rounds.forEach { round ->
            val redDecision = decision(decisions, red.id, round.roundNumber)
            val blueDecision = decision(decisions, blue.id, round.roundNumber)
            round.sequenceFrames.forEach { frame ->
                val comment = FightCommentaryFormatter.short(frame.event, red, blue, frame.stoppage)
                comments += comment
                timeline += FightScreenState(
                    fightSeed = session.seed,
                    phase = if (frame.stoppage == null) FightScreenPhase.ROUND_IN_PROGRESS else FightScreenPhase.COMPLETE,
                    roundNumber = round.roundNumber,
                    totalRounds = 3,
                    sequenceNumber = frame.sequenceNumber,
                    sequencesPerRound = sequencesPerRound,
                    clock = FightClockState(FightScreenStateMapper.remainingSeconds(frame.sequenceNumber, sequencesPerRound)),
                    red = FightScreenStateMapper.fighterFromState(red, FighterCorner.RED, frame.redState, redDecision),
                    blue = FightScreenStateMapper.fighterFromState(blue, FighterCorner.BLUE, frame.blueState, blueDecision),
                    currentAction = FightScreenStateMapper.action(frame.event),
                    commentary = comment,
                    recentCommentary = comments.takeLast(3),
                    tacticalWindowOpen = false,
                    result = frame.stoppage?.let { FightScreenStateMapper.stoppageResult(it, red, blue) },
                )
            }
            if (round.stoppage == null && round.roundNumber < 3) {
                timeline += FightScreenState(
                    fightSeed = session.seed,
                    phase = FightScreenPhase.BETWEEN_ROUNDS,
                    roundNumber = round.roundNumber,
                    totalRounds = 3,
                    sequenceNumber = sequencesPerRound,
                    sequencesPerRound = sequencesPerRound,
                    clock = FightClockState(0),
                    red = FightScreenStateMapper.fighterFromState(red, FighterCorner.RED, round.redState, redDecision),
                    blue = FightScreenStateMapper.fighterFromState(blue, FighterCorner.BLUE, round.blueState, blueDecision),
                    currentAction = null,
                    commentary = "Fin du round ${round.roundNumber}. La fenêtre tactique est ouverte.",
                    recentCommentary = comments.takeLast(3),
                    tacticalWindowOpen = true,
                    result = null,
                )
            }
        }

        when {
            result == null -> Unit
            result.stoppage == null -> {
                val lastRound = rounds.last()
                val redDecision = decision(decisions, red.id, 3)
                val blueDecision = decision(decisions, blue.id, 3)
                val official = requireNotNull(result.officialDecision)
                timeline += FightScreenState(
                    fightSeed = session.seed,
                    phase = FightScreenPhase.COMPLETE,
                    roundNumber = 3,
                    totalRounds = 3,
                    sequenceNumber = sequencesPerRound,
                    sequencesPerRound = sequencesPerRound,
                    clock = FightClockState(0),
                    red = FightScreenStateMapper.fighterFromState(red, FighterCorner.RED, lastRound.redState, redDecision),
                    blue = FightScreenStateMapper.fighterFromState(blue, FighterCorner.BLUE, lastRound.blueState, blueDecision),
                    currentAction = null,
                    commentary = FightScreenStateMapper.decisionCommentary(official, red, blue),
                    recentCommentary = comments.takeLast(3),
                    tacticalWindowOpen = false,
                    result = FightScreenStateMapper.decisionResult(official, red, blue),
                )
            }
        }
        return timeline.toList()
    }

    private fun decision(decisions: List<TacticalDecision>, fighterId: String, round: Int): TacticalDecision =
        decisions.single { it.fighterId == fighterId && it.beforeRound == round }
}
