# Jalon 3 — Étape 3 — Trois profils de juge

## Périmètre

Cette étape ajoute exactement trois profils de juge déterministes :

- Juge A : équilibre général ;
- Juge B : précision et défense ;
- Juge C : agressivité efficace et contrôle.

Aucun total de carte, aucune décision officielle, aucun écran Android et aucun APK ne sont ajoutés.

## Pondérations

| Axe | Juge A | Juge B | Juge C |
|---|---:|---:|---:|
| Coups nets et qualité des impacts | 42 % | 45 % | 37 % |
| Agressivité efficace | 18 % | 14 % | 24 % |
| Défense | 18 % | 23 % | 14 % |
| Contrôle de la distance et du rythme | 14 % | 11 % | 18 % |
| Travail au corps | 8 % | 7 % | 7 % |

Les trois profils utilisent les mêmes preuves de round. Aucun tirage aléatoire n'intervient dans le jugement.

## Règles communes

- système simplifié des dix points obligatoires ;
- 10-9 sans différence de knockdowns ;
- 10-8 pour un avantage d'un knockdown ;
- 10-7 pour un avantage d'au moins deux knockdowns ;
- 10-10 lorsque la marge pondérée absolue ne dépasse pas 2 points ;
- aucun round interrompu par KO ou TKO n'est jugé ;
- les knockdowns ont priorité sur les préférences de profil.

## Audit reproductible

- 1 000 combats ;
- 3 000 rounds simulés ;
- 2 997 rounds jugés ;
- 3 rounds interrompus et non jugés ;
- 8 991 notes individuelles ;
- 2 838 rounds avec score identique des trois juges ;
- 159 rounds avec désaccord, soit 5,31 % ;
- 399 rounds avec knockdown ;
- 0 violation d'unanimité sur knockdown ;
- 0 score invalide ;
- 0 justification vide ;
- 0 note attachée à un round interrompu ;
- 0 écart de reproductibilité.

## Statut

Étape 3 validée. La prochaine étape est limitée à la totalisation des trois cartes et à la décision officielle des combats allant à la distance.
