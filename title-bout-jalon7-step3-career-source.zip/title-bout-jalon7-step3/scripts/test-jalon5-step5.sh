#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build-step5-final"
cd "$ROOT"
rm -rf "$BUILD"
mkdir -p "$BUILD"

mapfile -t BASE_TEST_SOURCES < <(find engine/src/test/kotlin/titlefight -maxdepth 1 -name '*.kt' ! -name 'Jalon5Step5Audit.kt' -print | sort)

kotlinc -J-Xmx1536m -J-Dfile.encoding=UTF-8 \
  engine/src/main/kotlin/titlefight/*.kt \
  "${BASE_TEST_SOURCES[@]}" \
  -d "$BUILD/title-fight-base.jar"

sleep 5
bash -lc "kotlinc -J-Xmx1536m -J-Dfile.encoding=UTF-8 -cp '$BUILD/title-fight-base.jar' '$ROOT/engine/src/test/kotlin/titlefight/Jalon5Step5Audit.kt' -d '$BUILD/title-fight-jalon5-step5.jar'"

CP="$BUILD/title-fight-base.jar:$BUILD/title-fight-jalon5-step5.jar"
export LC_ALL=C.UTF-8

kotlin -J-Xmx2g -J-Dfile.encoding=UTF-8 \
  -cp "$BUILD/title-fight-base.jar" \
  titlefight.FightEngineTest

kotlin -J-Xmx2g -J-Dfile.encoding=UTF-8 \
  -Djava.util.concurrent.ForkJoinPool.common.parallelism=10 \
  -cp "$CP" \
  titlefight.Jalon5Step5Test

kotlin -J-Xmx2g -J-Dfile.encoding=UTF-8 \
  -Djava.util.concurrent.ForkJoinPool.common.parallelism=10 \
  -cp "$CP" \
  titlefight.Jalon5Step5AuditDemo

echo "122 tests réussis au total"
