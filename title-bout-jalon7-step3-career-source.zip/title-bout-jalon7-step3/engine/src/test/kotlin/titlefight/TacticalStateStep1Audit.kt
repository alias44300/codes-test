package titlefight

import java.security.MessageDigest
import kotlin.math.abs

data class TacticalStateStep1AuditResult(
    val fightCount: Int,
    val totalRounds: Int,
    val totalSnapshots: Int,
    val preFightSnapshots: Int,
    val betweenRoundSnapshots: Int,
    val stoppedFights: Int,
    val snapshotsAfterStoppage: Int,
    val timelineMismatches: Int,
    val stateMismatches: Int,
    val sequenceSourceMismatches: Int,
    val knockdownMismatches: Int,
    val extractionMismatches: Int,
    val reproducibilityMismatches: Int,
    val legacyBehaviorFingerprintMismatches: Int,
    val redEstimatedLeads: Int,
    val blueEstimatedLeads: Int,
    val evenEstimatedPositions: Int,
    val redMomentumLeads: Int,
    val blueMomentumLeads: Int,
    val evenMomentumPositions: Int,
)

object TacticalStateStep1Auditor {
    fun run(fightCount: Int = 1_000, seedStart: Long = 202607210600L): TacticalStateStep1AuditResult {
        require(fightCount >= 1)

        var totalRounds = 0
        var totalSnapshots = 0
        var preFightSnapshots = 0
        var betweenRoundSnapshots = 0
        var stoppedFights = 0
        var snapshotsAfterStoppage = 0
        var timelineMismatches = 0
        var stateMismatches = 0
        var sequenceSourceMismatches = 0
        var knockdownMismatches = 0
        var extractionMismatches = 0
        var reproducibilityMismatches = 0
        var redEstimatedLeads = 0
        var blueEstimatedLeads = 0
        var evenEstimatedPositions = 0
        var redMomentumLeads = 0
        var blueMomentumLeads = 0
        var evenMomentumPositions = 0

        repeat(fightCount) { index ->
            val seed = seedStart + index
            val setup = setup(index, seed)
            val fight = setup.fight
            totalRounds += fight.rounds.size
            totalSnapshots += fight.tacticalSnapshots.size
            if (fight.stoppage != null) stoppedFights++

            if (index < 200) {
                val repeated = setup(index, seed).fight
                if (fight != repeated) reproducibilityMismatches++
            }

            fight.tacticalSnapshots.forEachIndexed { snapshotIndex, snapshot ->
                if (snapshotIndex == 0) preFightSnapshots++ else betweenRoundSnapshots++

                if (snapshot.completedRounds != snapshotIndex || snapshot.nextRoundNumber != snapshotIndex + 1) {
                    timelineMismatches++
                }
                val priorRounds = fight.rounds.take(snapshotIndex)
                val expectedSequences = priorRounds.sumOf { it.events.size }
                if (snapshot.completedSequenceCount != expectedSequences) sequenceSourceMismatches++

                if (snapshotIndex > 0) {
                    val prior = fight.rounds[snapshotIndex - 1]
                    if (!matches(snapshot.red, prior.redState) || !matches(snapshot.blue, prior.blueState)) {
                        stateMismatches++
                    }
                }

                val expectedRedKds = priorRounds.sumOf { round ->
                    round.events.count { it.attackerId == fight.redId && it.knockdown != null }
                }
                val expectedBlueKds = priorRounds.sumOf { round ->
                    round.events.count { it.attackerId == fight.blueId && it.knockdown != null }
                }
                if (snapshot.red.knockdownsScored != expectedRedKds || snapshot.blue.knockdownsScored != expectedBlueKds) {
                    knockdownMismatches++
                }

                val expected = TacticalStateSnapshotExtractor.extract(
                    red = setup.red,
                    blue = setup.blue,
                    redState = if (snapshotIndex == 0) setup.redStart else priorRounds.last().redState,
                    blueState = if (snapshotIndex == 0) setup.blueStart else priorRounds.last().blueState,
                    completedRounds = priorRounds.map(TacticalRoundFacts::fromCompletedRound),
                    nextRoundNumber = snapshotIndex + 1,
                    sequencesPerRound = 12,
                )
                if (snapshot != expected) extractionMismatches++

                when (snapshot.estimatedLeaderId) {
                    fight.redId -> redEstimatedLeads++
                    fight.blueId -> blueEstimatedLeads++
                    null -> evenEstimatedPositions++
                    else -> timelineMismatches++
                }
                when (snapshot.recentMomentumLeaderId) {
                    fight.redId -> redMomentumLeads++
                    fight.blueId -> blueMomentumLeads++
                    null -> evenMomentumPositions++
                    else -> timelineMismatches++
                }
            }

            fight.stoppage?.let { stoppage ->
                snapshotsAfterStoppage += fight.tacticalSnapshots.count { it.nextRoundNumber > stoppage.roundNumber }
            }
        }

        return TacticalStateStep1AuditResult(
            fightCount = fightCount,
            totalRounds = totalRounds,
            totalSnapshots = totalSnapshots,
            preFightSnapshots = preFightSnapshots,
            betweenRoundSnapshots = betweenRoundSnapshots,
            stoppedFights = stoppedFights,
            snapshotsAfterStoppage = snapshotsAfterStoppage,
            timelineMismatches = timelineMismatches,
            stateMismatches = stateMismatches,
            sequenceSourceMismatches = sequenceSourceMismatches,
            knockdownMismatches = knockdownMismatches,
            extractionMismatches = extractionMismatches,
            reproducibilityMismatches = reproducibilityMismatches,
            legacyBehaviorFingerprintMismatches = LegacyBehaviorFingerprint.verify(),
            redEstimatedLeads = redEstimatedLeads,
            blueEstimatedLeads = blueEstimatedLeads,
            evenEstimatedPositions = evenEstimatedPositions,
            redMomentumLeads = redMomentumLeads,
            blueMomentumLeads = blueMomentumLeads,
            evenMomentumPositions = evenMomentumPositions,
        )
    }

    fun assertValid(result: TacticalStateStep1AuditResult) {
        check(result.totalSnapshots == result.totalRounds)
        check(result.preFightSnapshots == result.fightCount)
        check(result.preFightSnapshots + result.betweenRoundSnapshots == result.totalSnapshots)
        check(result.snapshotsAfterStoppage == 0)
        check(result.timelineMismatches == 0)
        check(result.stateMismatches == 0)
        check(result.sequenceSourceMismatches == 0)
        check(result.knockdownMismatches == 0)
        check(result.extractionMismatches == 0)
        check(result.reproducibilityMismatches == 0)
        check(result.legacyBehaviorFingerprintMismatches == 0)
        check(result.redEstimatedLeads + result.blueEstimatedLeads + result.evenEstimatedPositions == result.totalSnapshots)
        check(result.redMomentumLeads + result.blueMomentumLeads + result.evenMomentumPositions == result.totalSnapshots)
    }

    data class Setup(
        val red: BoxerProfile,
        val blue: BoxerProfile,
        val redStart: FighterState,
        val blueStart: FighterState,
        val fight: FightResult,
    )

    private fun setup(index: Int, seed: Long): Setup {
        val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
        val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)
        val redIsVega = index % 2 == 0
        val red = if (redIsVega) TestProfiles.eliasVega else TestProfiles.brunoKessler
        val blue = if (redIsVega) TestProfiles.brunoKessler else TestProfiles.eliasVega
        val redTactics = if (redIsVega) vegaTactics else kesslerTactics
        val blueTactics = if (redIsVega) kesslerTactics else vegaTactics
        val redStart = FighterState()
        val blueStart = FighterState()
        val fight = FightEngine().simulateThreeRoundFight(
            red = red,
            blue = blue,
            redTactics = redTactics,
            blueTactics = blueTactics,
            seed = seed,
            redStart = redStart,
            blueStart = blueStart,
        )
        return Setup(red, blue, redStart, blueStart, fight)
    }

    private fun matches(snapshot: FighterTacticalState, state: FighterState): Boolean =
        abs(snapshot.stamina - state.stamina) <= 1e-9 &&
            abs(snapshot.headDamage - state.headDamage) <= 1e-9 &&
            abs(snapshot.bodyDamage - state.bodyDamage) <= 1e-9 &&
            abs(snapshot.stability - state.stability) <= 1e-9 &&
            snapshot.knockdownsSuffered == state.knockdownsSuffered
}

object TacticalStateStep1AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = TacticalStateStep1Auditor.run()
        TacticalStateStep1Auditor.assertValid(result)
        println("AUDIT JALON 4 — ÉTAPE 1")
        println("Combats : ${result.fightCount}")
        println("Rounds / instantanés : ${result.totalRounds} / ${result.totalSnapshots}")
        println("Avant combat / entre rounds : ${result.preFightSnapshots} / ${result.betweenRoundSnapshots}")
        println("Combats arrêtés : ${result.stoppedFights}")
        println("Instantanés après arrêt : ${result.snapshotsAfterStoppage}")
        println("Erreurs chronologiques : ${result.timelineMismatches}")
        println("Erreurs d'état : ${result.stateMismatches}")
        println("Erreurs de source séquentielle : ${result.sequenceSourceMismatches}")
        println("Erreurs knockdowns : ${result.knockdownMismatches}")
        println("Écarts de réextraction : ${result.extractionMismatches}")
        println("Écarts de reproductibilité : ${result.reproducibilityMismatches}")
        println("Empreintes historiques modifiées : ${result.legacyBehaviorFingerprintMismatches}")
        println("Positions estimées rouge / bleu / neutre : ${result.redEstimatedLeads} / ${result.blueEstimatedLeads} / ${result.evenEstimatedPositions}")
        println("Dynamiques rouge / bleu / neutre : ${result.redMomentumLeads} / ${result.blueMomentumLeads} / ${result.evenMomentumPositions}")
    }
}

object TacticalStateStep1Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val fight = FightEngine().simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = 202607210601L,
        )
        println("DÉMONSTRATION TACTICAL STATE SNAPSHOT")
        fight.tacticalSnapshots.forEach { snapshot ->
            println("Avant le round ${snapshot.nextRoundNumber}")
            println("  rounds terminés=${snapshot.completedRounds}, séquences historiques=${snapshot.completedSequenceCount}, séquences maximales restantes=${snapshot.remainingSequencesMaximum}")
            println("  estimation=${snapshot.estimatedLeaderId ?: "équilibre"}, marge rounds=${snapshot.estimatedRoundMargin}, marge performance=${"%.2f".format(snapshot.estimatedPerformanceMargin)}")
            println("  dynamique=${snapshot.recentMomentumLeaderId ?: "neutre"}, marge=${"%.2f".format(snapshot.recentMomentumMargin)}")
            println("  Vega énergie=${"%.2f".format(snapshot.red.stamina)}, fatigue=${"%.2f".format(snapshot.red.fatigue)}, dégâts tête/corps=${"%.2f".format(snapshot.red.headDamage)}/${"%.2f".format(snapshot.red.bodyDamage)}, stabilité=${"%.2f".format(snapshot.red.stability)}, KD=${snapshot.red.knockdownsScored}/${snapshot.red.knockdownsSuffered}")
            println("  Kessler énergie=${"%.2f".format(snapshot.blue.stamina)}, fatigue=${"%.2f".format(snapshot.blue.fatigue)}, dégâts tête/corps=${"%.2f".format(snapshot.blue.headDamage)}/${"%.2f".format(snapshot.blue.bodyDamage)}, stabilité=${"%.2f".format(snapshot.blue.stability)}, KD=${snapshot.blue.knockdownsScored}/${snapshot.blue.knockdownsSuffered}")
        }
    }
}

object LegacyBehaviorFingerprint {
    private val expected = mapOf(
        1L to "5e0dac367189c13856a78537660bad7edad12e30040961406e86350db022def4",
        20260720L to "fc3c6380916855f11798432a3f61e6a8ddea2de2164c9754a82878825e5a2461",
        999999L to "98539b55b5b4dfc5cf00cc12bba192bebf7abd82ab0553c1fb1ad0d74b4e6788",
    )

    fun verify(): Int = expected.count { (seed, hash) -> fingerprint(seed) != hash }

    private fun fingerprint(seed: Long): String {
        val fight = FightEngine().simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = seed,
        )
        val canonical = buildString {
            append(fight.redId).append('|').append(fight.blueId).append('|').append(fight.seed).append('\n')
            fight.rounds.forEach { round ->
                append(round.roundNumber).append('|').append(round.seed).append('|')
                append(round.redState).append('|').append(round.blueState).append('|')
                append(round.redRoundScore).append('|').append(round.blueRoundScore).append('|')
                append(round.stoppage).append('\n')
                round.events.forEach { event ->
                    append(event.sequenceNumber).append('|').append(event.attackerId).append('|').append(event.defenderId).append('|')
                    append(event.range).append('|').append(event.punch).append('|').append(event.landed).append('|').append(event.clean).append('|')
                    append(event.impact).append('|').append(event.knockdown).append('\n')
                }
            }
            append(fight.finalRedState).append('|').append(fight.finalBlueState).append('|')
            append(fight.redPerformanceTotal).append('|').append(fight.bluePerformanceTotal).append('|')
            append(fight.stoppage).append('|').append(fight.officialDecision)
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}
