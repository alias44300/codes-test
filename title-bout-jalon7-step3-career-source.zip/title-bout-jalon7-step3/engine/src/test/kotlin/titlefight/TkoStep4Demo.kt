package titlefight

object TkoStep4Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val found = (1L..50000L).firstNotNullOfOrNull { seed ->
            val fight = TkoStep4Scenario.fight(seed, attackerInRed = true)
            if (fight.stoppage?.method == FightMethod.TKO) seed to fight else null
        } ?: error("Aucun TKO de démonstration trouvé.")

        val (seed, fight) = found
        print(FightReportFormatter.format(fight, TestProfiles.brunoKessler, TkoStep4Scenario.protectedProfile))
        println()
        println("Graine de démonstration TKO : $seed")
        println("L’arrêt est déterministe et repose uniquement sur les seuils de sécurité explicites.")
    }
}
