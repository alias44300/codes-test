package androidx.compose.ui.tooling.preview
@Target(AnnotationTarget.FUNCTION)
annotation class Preview(val name: String = "", val widthDp: Int = 0, val heightDp: Int = 0, val showBackground: Boolean = false)
