package titlefight.data.local
import android.content.Context
import titlefight.BoxerProfile
import titlefight.OfficialRoster
class AndroidBoxerRepository(context: Context) {
    fun allProfiles(): List<BoxerProfile> = OfficialRoster.profiles
    fun contentVersion(): String = OfficialRoster.CONTENT_VERSION
}
