package titlefight

import java.util.Locale

object KnockdownStep1Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val engine = FightEngine(stopOnTenCount = false, stopOnTko = false)
        val vulnerableStart = FighterState(
            stamina = 12.0,
            headDamage = 82.0,
            bodyDamage = 58.0,
            stability = 12.0,
        )

        val pair = (1L..5000L).asSequence().map { seed ->
            seed to engine.simulateRound(
                roundNumber = 1,
                red = TestProfiles.brunoKessler,
                blue = TestProfiles.eliasVega,
                redStart = FighterState(),
                blueStart = vulnerableStart,
                redTactic = Tactic.SEEK_KO,
                blueTactic = Tactic.RECOVER,
                seed = seed,
            )
        }.first { (_, round) -> round.events.any { it.knockdown != null } }

        val seed = pair.first
        val round = pair.second
        println("TITLE FIGHT — Démonstration contrôlée de chute")
        println("Graine : $seed")
        println("État initial vulnérable d’Elias Vega : énergie 12, tête 82, corps 58, stabilité 12")
        println()
        round.events.forEach { event ->
            println("${event.sequenceNumber}. ${event.text}")
            event.knockdown?.let { kd ->
                println(
                    "   Événement Knockdown : auteur=${kd.attackerId}, victime=${kd.defenderId}, " +
                        "coup=${kd.punch}, impact=${decimal(kd.impact)}, score=${decimal(kd.score)}, " +
                        "probabilité=${percent(kd.probability)}, tirage=${decimal(kd.roll)}",
                )
            }
        }
        println()
        println("Séquences jouées : ${round.events.size}/12")
        println("Chutes subies par Elias : ${round.blueState.knockdownsSuffered}")
        println("Le round continue après la chute. Aucun compte, KO ou TKO n’est calculé.")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
    private fun percent(value: Double): String = String.format(Locale.US, "%.1f %%", value * 100.0)
}
