package titlefight

import kotlin.math.abs

data class TacticalIntegrationStep4AuditResult(
    val fightCount: Int,
    val totalRounds: Int,
    val totalSequences: Int,
    val totalDecisions: Int,
    val appliedPlans: Int,
    val stoppedFights: Int,
    val decisionsAfterStoppage: Int,
    val missingPlanAttachments: Int,
    val planDecisionMismatches: Int,
    val reproducibilityMismatches: Int,
    val changedFromDisabledFights: Int,
    val comparedWithDisabledFights: Int,
    val legacyBehaviorFingerprintMismatches: Int,
    val reportModeErrors: Int,
    val targetEventCounts: Map<TacticalTarget, Int>,
    val targetBodyPunchCounts: Map<TacticalTarget, Int>,
    val distanceEventCounts: Map<TacticalDistance, Int>,
    val desiredRangeCounts: Map<TacticalDistance, Int>,
    val paceRoundCounts: Map<TacticalPace, Int>,
    val paceAttackCounts: Map<TacticalPace, Int>,
    val riskLandedCounts: Map<TacticalRisk, Int>,
    val riskImpactTotals: Map<TacticalRisk, Double>,
) {
    fun bodyPunchShare(target: TacticalTarget): Double = ratio(targetBodyPunchCounts[target] ?: 0, targetEventCounts[target] ?: 0)
    fun desiredRangeShare(distance: TacticalDistance): Double = ratio(desiredRangeCounts[distance] ?: 0, distanceEventCounts[distance] ?: 0)
    fun averageAttacks(pace: TacticalPace): Double = ratio(paceAttackCounts[pace] ?: 0, paceRoundCounts[pace] ?: 0)
    fun averageImpact(risk: TacticalRisk): Double = if ((riskLandedCounts[risk] ?: 0) == 0) 0.0 else
        (riskImpactTotals[risk] ?: 0.0) / (riskLandedCounts[risk] ?: 1)

    private fun ratio(value: Int, total: Int): Double = if (total == 0) 0.0 else value.toDouble() / total
}

object TacticalIntegrationStep4Auditor {
    private const val DEFAULT_FIGHT_COUNT = 1_000
    private const val COMPARISON_COUNT = 200

    fun run(fightCount: Int = DEFAULT_FIGHT_COUNT, seedStart: Long = 202607211000L): TacticalIntegrationStep4AuditResult {
        val adaptiveEngine = FightEngine(adaptiveTacticsEnabled = true)
        val disabledEngine = FightEngine(adaptiveTacticsEnabled = false)
        var totalRounds = 0
        var totalSequences = 0
        var totalDecisions = 0
        var appliedPlans = 0
        var stoppedFights = 0
        var decisionsAfterStoppage = 0
        var missingPlanAttachments = 0
        var planDecisionMismatches = 0
        var reproducibilityMismatches = 0
        var changedFromDisabledFights = 0
        var reportModeErrors = 0

        val targetEventCounts = TacticalTarget.entries.associateWith { 0 }.toMutableMap()
        val targetBodyPunchCounts = TacticalTarget.entries.associateWith { 0 }.toMutableMap()
        val distanceEventCounts = TacticalDistance.entries.associateWith { 0 }.toMutableMap()
        val desiredRangeCounts = TacticalDistance.entries.associateWith { 0 }.toMutableMap()
        val paceRoundCounts = TacticalPace.entries.associateWith { 0 }.toMutableMap()
        val paceAttackCounts = TacticalPace.entries.associateWith { 0 }.toMutableMap()
        val riskLandedCounts = TacticalRisk.entries.associateWith { 0 }.toMutableMap()
        val riskImpactTotals = TacticalRisk.entries.associateWith { 0.0 }.toMutableMap()

        repeat(fightCount) { index ->
            val seed = seedStart + index
            val setup = setup(index)
            val fight = adaptiveEngine.simulateThreeRoundFight(
                red = setup.red,
                blue = setup.blue,
                redTactics = setup.redTactics,
                blueTactics = setup.blueTactics,
                seed = seed,
            )
            totalRounds += fight.rounds.size
            totalSequences += fight.rounds.sumOf { it.events.size }
            totalDecisions += fight.tacticalDecisions.size
            if (fight.stoppage != null) stoppedFights++

            if (index < COMPARISON_COUNT) {
                val repeated = adaptiveEngine.simulateThreeRoundFight(
                    red = setup.red,
                    blue = setup.blue,
                    redTactics = setup.redTactics,
                    blueTactics = setup.blueTactics,
                    seed = seed,
                )
                if (repeated != fight) reproducibilityMismatches++

                val disabled = disabledEngine.simulateThreeRoundFight(
                    red = setup.red,
                    blue = setup.blue,
                    redTactics = setup.redTactics,
                    blueTactics = setup.blueTactics,
                    seed = seed,
                )
                if (behaviorSignature(disabled) != behaviorSignature(fight)) changedFromDisabledFights++

                if (index < 20) {
                    val report = FightReportFormatter.format(fight, setup.red, setup.blue)
                    if ("effets actifs" !in report || "observation seulement" in report) reportModeErrors++
                }
            }

            fight.stoppage?.let { stoppage ->
                decisionsAfterStoppage += fight.tacticalDecisions.count { it.beforeRound > stoppage.roundNumber }
            }

            fight.rounds.forEach { round ->
                val decisions = fight.tacticalDecisions.filter { it.beforeRound == round.roundNumber }
                val redDecision = decisions.first { it.fighterId == fight.redId }
                val blueDecision = decisions.first { it.fighterId == fight.blueId }
                val redPlan = round.redAppliedTacticalPlan
                val bluePlan = round.blueAppliedTacticalPlan
                if (!round.tacticalEffectsEnabled || redPlan == null || bluePlan == null) {
                    missingPlanAttachments++
                    return@forEach
                }
                appliedPlans += 2
                if (redPlan != redDecision.selectedPlan || bluePlan != blueDecision.selectedPlan) planDecisionMismatches++

                val plans = mapOf(fight.redId to redPlan, fight.blueId to bluePlan)
                plans.values.forEach { plan ->
                    paceRoundCounts[plan.pace] = paceRoundCounts.getValue(plan.pace) + 1
                }
                round.events.forEach { event ->
                    val plan = plans.getValue(event.attackerId)
                    targetEventCounts[plan.target] = targetEventCounts.getValue(plan.target) + 1
                    if (event.punch == Punch.BODY_HOOK) {
                        targetBodyPunchCounts[plan.target] = targetBodyPunchCounts.getValue(plan.target) + 1
                    }
                    distanceEventCounts[plan.distance] = distanceEventCounts.getValue(plan.distance) + 1
                    if (event.range == desiredRange(plan.distance)) {
                        desiredRangeCounts[plan.distance] = desiredRangeCounts.getValue(plan.distance) + 1
                    }
                    paceAttackCounts[plan.pace] = paceAttackCounts.getValue(plan.pace) + 1
                    if (event.landed) {
                        riskLandedCounts[plan.risk] = riskLandedCounts.getValue(plan.risk) + 1
                        riskImpactTotals[plan.risk] = riskImpactTotals.getValue(plan.risk) + event.impact
                    }
                }
            }
        }

        return TacticalIntegrationStep4AuditResult(
            fightCount = fightCount,
            totalRounds = totalRounds,
            totalSequences = totalSequences,
            totalDecisions = totalDecisions,
            appliedPlans = appliedPlans,
            stoppedFights = stoppedFights,
            decisionsAfterStoppage = decisionsAfterStoppage,
            missingPlanAttachments = missingPlanAttachments,
            planDecisionMismatches = planDecisionMismatches,
            reproducibilityMismatches = reproducibilityMismatches,
            changedFromDisabledFights = changedFromDisabledFights,
            comparedWithDisabledFights = minOf(fightCount, COMPARISON_COUNT),
            legacyBehaviorFingerprintMismatches = LegacyBehaviorFingerprint.verify(),
            reportModeErrors = reportModeErrors,
            targetEventCounts = targetEventCounts,
            targetBodyPunchCounts = targetBodyPunchCounts,
            distanceEventCounts = distanceEventCounts,
            desiredRangeCounts = desiredRangeCounts,
            paceRoundCounts = paceRoundCounts,
            paceAttackCounts = paceAttackCounts,
            riskLandedCounts = riskLandedCounts,
            riskImpactTotals = riskImpactTotals,
        )
    }

    fun assertValid(result: TacticalIntegrationStep4AuditResult) {
        check(result.totalDecisions == result.totalRounds * 2)
        check(result.appliedPlans == result.totalRounds * 2)
        check(result.decisionsAfterStoppage == 0)
        check(result.missingPlanAttachments == 0)
        check(result.planDecisionMismatches == 0)
        check(result.reproducibilityMismatches == 0)
        check(result.legacyBehaviorFingerprintMismatches == 0)
        check(result.reportModeErrors == 0)
        check(result.changedFromDisabledFights >= (result.comparedWithDisabledFights * 0.80).toInt())

        val mixedCount = result.targetEventCounts.getValue(TacticalTarget.MIXED)
        val bodyCount = result.targetEventCounts.getValue(TacticalTarget.BODY)
        check(mixedCount > 0 && bodyCount > 0)
        check(result.bodyPunchShare(TacticalTarget.BODY) >= result.bodyPunchShare(TacticalTarget.MIXED) + 0.12)

        check(result.distanceEventCounts.getValue(TacticalDistance.LONG) > 0)
        check(result.distanceEventCounts.getValue(TacticalDistance.MEDIUM) > 0)
        check(result.distanceEventCounts.getValue(TacticalDistance.CLOSE) > 0)
        check(result.desiredRangeShare(TacticalDistance.LONG) >= 0.60)
        check(result.desiredRangeShare(TacticalDistance.MEDIUM) >= 0.08)
        check(result.desiredRangeShare(TacticalDistance.CLOSE) >= 0.30)

        check(result.paceRoundCounts.getValue(TacticalPace.MEASURED) > 0)
        check(result.paceRoundCounts.getValue(TacticalPace.SUSTAINED) > 0)
        check(result.averageAttacks(TacticalPace.SUSTAINED) > result.averageAttacks(TacticalPace.MEASURED) + 0.50)

        check(result.riskLandedCounts.getValue(TacticalRisk.SAFE) > 0)
        check(result.riskLandedCounts.getValue(TacticalRisk.AGGRESSIVE) > 0)
        check(result.averageImpact(TacticalRisk.AGGRESSIVE) > result.averageImpact(TacticalRisk.SAFE) + 0.30)
    }

    private data class Setup(
        val red: BoxerProfile,
        val blue: BoxerProfile,
        val redTactics: List<Tactic>,
        val blueTactics: List<Tactic>,
    )

    private fun setup(index: Int): Setup {
        val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
        val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)
        val redIsVega = index % 2 == 0
        return Setup(
            red = if (redIsVega) TestProfiles.eliasVega else TestProfiles.brunoKessler,
            blue = if (redIsVega) TestProfiles.brunoKessler else TestProfiles.eliasVega,
            redTactics = if (redIsVega) vegaTactics else kesslerTactics,
            blueTactics = if (redIsVega) kesslerTactics else vegaTactics,
        )
    }

    private fun desiredRange(distance: TacticalDistance): FightRange = when (distance) {
        TacticalDistance.LONG -> FightRange.OUTSIDE
        TacticalDistance.MEDIUM -> FightRange.MID
        TacticalDistance.CLOSE -> FightRange.INSIDE
    }

    private fun behaviorSignature(fight: FightResult): String = buildString {
        fight.rounds.forEach { round ->
            append(round.redState).append('|').append(round.blueState).append('|').append(round.stoppage).append('\n')
            round.events.forEach { event ->
                append(event.attackerId).append('|').append(event.range).append('|').append(event.punch).append('|')
                    .append(event.landed).append('|').append(event.clean).append('|').append(event.impact).append('|')
                    .append(event.knockdown).append('\n')
            }
        }
        append(fight.stoppage).append('|').append(fight.officialDecision)
    }
}

object TacticalIntegrationStep4AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = TacticalIntegrationStep4Auditor.run()
        TacticalIntegrationStep4Auditor.assertValid(result)
        println("AUDIT JALON 4 — ÉTAPE 4")
        println("Combats / rounds / séquences : ${result.fightCount} / ${result.totalRounds} / ${result.totalSequences}")
        println("Décisions / plans appliqués : ${result.totalDecisions} / ${result.appliedPlans}")
        println("Combats arrêtés / décisions après arrêt : ${result.stoppedFights} / ${result.decisionsAfterStoppage}")
        println("Plans manquants / divergents : ${result.missingPlanAttachments} / ${result.planDecisionMismatches}")
        println("Écarts de reproductibilité : ${result.reproducibilityMismatches}")
        println("Combats modifiés face au mode désactivé : ${result.changedFromDisabledFights}/${result.comparedWithDisabledFights}")
        println("Empreintes historiques modifiées : ${result.legacyBehaviorFingerprintMismatches}")
        println("Part de coups au corps, cible MIXED/BODY : ${"%.2f".format(result.bodyPunchShare(TacticalTarget.MIXED) * 100)} % / ${"%.2f".format(result.bodyPunchShare(TacticalTarget.BODY) * 100)} %")
        println("Distance recherchée LONG/MEDIUM/CLOSE : ${"%.2f".format(result.desiredRangeShare(TacticalDistance.LONG) * 100)} % / ${"%.2f".format(result.desiredRangeShare(TacticalDistance.MEDIUM) * 100)} % / ${"%.2f".format(result.desiredRangeShare(TacticalDistance.CLOSE) * 100)} %")
        println("Initiatives moyennes MEASURED/SUSTAINED : ${"%.2f".format(result.averageAttacks(TacticalPace.MEASURED))} / ${"%.2f".format(result.averageAttacks(TacticalPace.SUSTAINED))}")
        println("Impact moyen SAFE/AGGRESSIVE : ${"%.2f".format(result.averageImpact(TacticalRisk.SAFE))} / ${"%.2f".format(result.averageImpact(TacticalRisk.AGGRESSIVE))}")
    }
}

object TacticalIntegrationStep4Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val fight = FightEngine(adaptiveTacticsEnabled = true).simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = 202607211004L,
        )
        println(FightReportFormatter.format(fight, TestProfiles.eliasVega, TestProfiles.brunoKessler))
    }
}
