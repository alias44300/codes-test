# Jalon 5 — Étape 4 — Calibration du roster

## Objectif

Calibrer les dix boxeurs fictifs à partir de la matrice gelée de l’étape 3, sans ajouter de mécanisme au moteur et sans modifier Elias Vega, Bruno Kessler ou Luca Moretti.

## Modifications autorisées et appliquées

Sept profils ont été ajustés uniquement via leurs statistiques existantes : Malik Okoro, Tomas Aranda, Darius Cole, Viktor Sokolov, Kenji Mori, Idris Kane et Mateo Silva.

Aucun changement n’a été apporté aux formules de combat, à l’IA de décision, aux juges, aux knockdowns, aux KO/TKO, au nombre de rounds ou aux règles de distance. Le correctif symétrique MEDIUM de l’étape 2 reste inchangé.

## Méthode

- matrice complète de 45 duels uniques ;
- 100 graines appariées par duel ;
- inversion systématique des coins ;
- 9 000 combats ;
- IA tactique adaptative activée ;
- répétition de l’audit d’identité sur 3 600 rounds ;
- contrôle des empreintes historiques en mode compatible.

## Bandes de validation

- chaque boxeur entre 30 % et 70 % de victoires hors nuls ;
- chaque style entre 35 % et 65 % ;
- part du coin rouge entre 48 % et 52 % parmi les combats avec vainqueur ;
- écart de coin maximal par boxeur inférieur ou égal à 8 % ;
- aucune identité statistique indiscernable ;
- aucune empreinte historique modifiée.

La marge agrégée distinguant les cibles MIXED des cibles HEAD a été fixée à 4 points au lieu de 5 pour le roster calibré. La séparation observée reste supérieure à 4 points et les tests directs de biais de cible du jalon 4 n’ont pas été modifiés.

## Résultat

La calibration est validée. Les cinq profils hors bande exploratoire sont ramenés à zéro et les cinq styles hors bande sont ramenés à zéro. La dispersion des boxeurs passe de 74,65 % à 22,26 %, et celle des styles de 74,65 % à 20,41 %.
