package titlefight

object Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val fight = FightEngine().simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = 20260720L,
        )
        print(FightReportFormatter.format(fight, TestProfiles.eliasVega, TestProfiles.brunoKessler))
    }
}
