# Jalon 3 — Décision finale

## Statut

**VALIDÉ**

## Périmètre livré

- preuves objectives de round ;
- système simplifié des dix points obligatoires ;
- trois profils de juge déterministes ;
- scores 10-9, 10-8, 10-7 et 10-10 ;
- priorité des knockdowns ;
- trois cartes complètes ;
- décision unanime, partagée ou majoritaire ;
- match nul unanime, majoritaire ou partagé ;
- priorité absolue des KO et TKO ;
- audit final de 10 000 combats.

## Validation

- 55 tests automatisés réussis ;
- archive finale réextraite puis retestée ;
- aucun biais persistant du coin ;
- aucune sévérité anormale d’un juge ;
- aucune faveur systématique pour un boxeur ou un style ;
- aucune carte ou décision invalide.

## Hors périmètre conservé

- aucune interface Android ;
- aucun APK ;
- aucun score en direct visible au joueur ;
- aucune faute ou déduction de point ;
- aucune disqualification ;
- aucun nouveau boxeur.
