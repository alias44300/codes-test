package titlefight

object ThreeJudgeStep3Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val engine = FightEngine()
        val redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
        val blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

        val fight = generateSequence(202607240000L) { it + 1L }
            .take(20_000)
            .map { seed ->
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = redTactics,
                    blueTactics = blueTactics,
                    seed = seed,
                )
            }
            .first { candidate ->
                candidate.rounds.any { round ->
                    round.stoppage == null && round.judgeScores.map { it.winnerId }.toSet().size > 1
                }
            }

        println("TITLE FIGHT — DÉMONSTRATION DES TROIS JUGES")
        println("${TestProfiles.eliasVega.name} contre ${TestProfiles.brunoKessler.name}")
        println("Graine : ${fight.seed}")
        println()
        fight.rounds.forEach { round ->
            if (round.stoppage != null) {
                println("Round ${round.roundNumber} : non jugé (${round.stoppage.method}).")
            } else {
                println("Round ${round.roundNumber}")
                round.judgeScores.forEach { score ->
                    println("  ${score.judgeName} — ${score.judgeFocus} : ${score.redPoints}-${score.bluePoints}")
                    println("    ${score.explanation}")
                }
            }
        }
        println()
        println("Aucun total de carte et aucune décision officielle ne sont calculés.")
    }
}
