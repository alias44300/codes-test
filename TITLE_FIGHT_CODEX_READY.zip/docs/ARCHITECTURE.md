# Architecture V0.1.7

## Noyau local

Le moteur Kotlin est indépendant d’Android, de Supabase et d’OpenAI. Un combat contient jusqu’à trois `RoundResult`.

## Reproductibilité

`FightEngine.simulateThreeRoundFight` reçoit une graine globale. Un flux pseudo-aléatoire déterministe dérive une graine différente pour chaque round. Les frappes, les chutes et les comptes disposent de flux séparés. Les mêmes profils, tactiques, états initiaux et graine globale produisent le même `FightResult` bit pour bit.

## Continuité du combat

Sans arrêt, le `FighterState` final de chaque round devient l’état initial du round suivant. Les compteurs de coups, l’énergie, les dégâts, la stabilité, les chutes et la vulnérabilité sont cumulatifs.

## Arrêt par KO

Un `RefereeCount` égal à 10 produit un `FightStoppage` de méthode `KO`. L’arrêt mémorise le vainqueur, le perdant, le round et la séquence. La séquence ayant provoqué le KO est la dernière du round, et le round est le dernier du combat. Aucune récupération de fin de round n’est appliquée après l’arrêt.

## Performance de round

La performance d’un round est calculée uniquement à partir des événements et des dégâts produits pendant ce round. Elle reste un indicateur interne et ne remplace pas le futur système de juges.

## Preuves objectives de jugement

Chaque `RoundResult` contient un `RoundJudgingEvidence` construit uniquement depuis les `SequenceEvent` du round. Les preuves couvrent l’activité efficace, les coups nets, les impacts, la défense, le contrôle de la distance, le travail au corps et les knockdowns. Cette couche ne contient aucun point, aucun vainqueur de round et aucune préférence de juge.

Un round interrompu par KO ou TKO contient uniquement les preuves des séquences réellement simulées.

## Rapport

`FightReportFormatter` fournit les sections réellement calculées. En cas de KO, il annonce le résultat officiel du moteur et confirme qu’aucun événement n’a été calculé après l’arrêt. En l’absence de KO, il affiche le bilan après trois rounds sans décision aux points.

## Compatibilité des audits historiques

Le paramètre `stopOnTenCount` est activé par défaut. Les validateurs historiques des jalons 1, 2 étape 1 et 2 étape 2 le désactivent explicitement afin de conserver leurs jeux de données de référence.


## Décision tactique observationnelle

`TacticalDecisionEngine` reçoit uniquement un `TacticalStateSnapshot`, le profil du boxeur et ses décisions précédentes. Il ne consomme aucun tirage aléatoire et ne lit aucune carte exacte de juge.

Deux décisions sont produites avant chaque round réellement simulé, dans l’ordre coin rouge puis coin bleu. Le premier choix est le plan naturel du style. Les choix suivants peuvent réagir au score estimé, à la fatigue, aux dégâts, à la stabilité, à la vulnérabilité adverse et au temps restant.

Les changements sont bornés à un niveau par axe et restent au plus à un niveau du plan naturel pour le rythme, la distance et le risque. Une inversion immédiate sans cause forte est bloquée.

À l’étape 3, ces décisions sont stockées dans `FightResult.tacticalDecisions` mais ne sont pas utilisées par `simulateRound`. Les empreintes des séquences, états, KO, TKO et décisions officielles restent donc identiques au jalon 3.


## Catalogue des boxeurs fictifs

`BoxerCatalog` devient la source unique des dix profils du prototype. `TestProfiles` conserve uniquement deux alias historiques vers Elias Vega et Bruno Kessler afin de ne pas casser les audits des jalons précédents.

`BoxerProfile` comprend désormais :

- un identifiant slug, un nom et un surnom ;
- une garde, un style et une distance préférée ;
- une taille entre 150 et 220 cm ;
- une allonge entre 150 et 230 cm ;
- un écart taille/allonge borné à 25 cm ;
- six statistiques principales ;
- six attributs secondaires.

Le catalogue vérifie à son initialisation l’unicité des identifiants, noms et surnoms, la couverture des sept styles, la couverture des trois gardes et la cohérence entre style et distance préférée. Aucun profil supplémentaire ne change le comportement historique de Vega contre Kessler.

## Couche de maquette statique — Jalon 6 étape 2

`ui-mockups/` est une couche de spécification visuelle sans dépendance Android. Elle contient le contrat de dimensions, un rendu PNG reproductible et une maquette HTML de référence. Elle ne dépend pas du moteur d’exécution et ne modifie aucun état de combat. La future couche Compose devra reproduire cette hiérarchie en consommant uniquement `FightScreenState`.


## Couche Jetpack Compose — Jalon 6 étape 3

`android-ui-compose/` consomme uniquement `FightScreenState`. `FightScreenLayoutPolicy` et `FightScreenPresentationMapper` restent en Kotlin pur afin de tester le redimensionnement et les règles de phase sans runtime Android. `TitleFightScreen` sélectionne ses composants via la phase de l’état et n’appelle jamais `FightEngine`.

`FightScreenTimelineAdapter` délègue intégralement à `FightScreenStateMapper`, ce qui conserve la timeline validée et interdit toute seconde interprétation des données moteur. Les futures interactions tactiques sont absentes : les axes sont actuellement des surfaces en lecture seule avec cibles minimales de 44 ou 48 dp.
