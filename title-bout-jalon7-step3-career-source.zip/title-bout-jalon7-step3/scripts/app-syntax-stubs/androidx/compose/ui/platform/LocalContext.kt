package androidx.compose.ui.platform
import android.content.Context
object LocalContext { val current: Context = Context() }
