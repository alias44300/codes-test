package titlefight

import java.io.File

object Jalon7DatabaseExport {
    @JvmStatic
    fun main(args: Array<String>) {
        require(args.size == 1) { "Un dossier de sortie est requis." }
        val out = File(args[0]).apply { mkdirs() }
        val entries = PlayableBoxerDatabase.allEntries
        File(out, "boxers-heavyweight-v1.json").writeText(buildJson(entries))
        File(out, "database-manifest.json").writeText(
            """
            {
              "schemaVersion": ${PlayableBoxerDatabase.SCHEMA_VERSION},
              "contentVersion": "${PlayableBoxerDatabase.CONTENT_VERSION}",
              "boxerVersions": ${entries.size},
              "weightClasses": ["HEAVYWEIGHT"],
              "ratingFields": 28,
              "tendencyFields": 9,
              "offline": true
            }
            """.trimIndent() + "\n",
        )
        println("${entries.size} profils exportés dans ${out.absolutePath}")
    }

    private fun buildJson(entries: List<BoxerDatabaseEntry>): String = buildString {
        append("{\n")
        append("  \"schemaVersion\": ${PlayableBoxerDatabase.SCHEMA_VERSION},\n")
        append("  \"contentVersion\": \"${escape(PlayableBoxerDatabase.CONTENT_VERSION)}\",\n")
        append("  \"boxers\": [\n")
        entries.forEachIndexed { index, entry ->
            val r = entry.ratings
            val t = entry.tendencies
            append("    {\n")
            append("      \"databaseId\": ${entry.databaseId},\n")
            append("      \"boxerId\": \"${escape(entry.boxerId)}\",\n")
            append("      \"versionId\": \"${escape(entry.versionId)}\",\n")
            append("      \"name\": \"${escape(entry.name)}\",\n")
            append("      \"nickname\": \"${escape(entry.nickname)}\",\n")
            append("      \"countryCode\": \"${entry.countryCode}\",\n")
            append("      \"countryName\": \"${escape(entry.countryName)}\",\n")
            append("      \"era\": \"${entry.era}\",\n")
            append("      \"prime\": {\"start\": ${entry.primeStartYear}, \"end\": ${entry.primeEndYear}},\n")
            append("      \"weightClass\": \"${entry.weightClass}\",\n")
            append("      \"stance\": \"${entry.stance}\",\n")
            append("      \"style\": \"${entry.style}\",\n")
            append("      \"secondaryStyle\": ${entry.secondaryStyle?.let { "\"$it\"" } ?: "null"},\n")
            append("      \"preferredRange\": \"${entry.preferredRange}\",\n")
            append("      \"heightCm\": ${entry.heightCm},\n")
            append("      \"reachCm\": ${entry.reachCm},\n")
            append("      \"ratings\": {\n")
            val ratingPairs = listOf(
                "jabPower" to r.jabPower, "rearHandPower" to r.rearHandPower,
                "hookPower" to r.hookPower, "bodyPower" to r.bodyPower,
                "handSpeed" to r.handSpeed, "footSpeed" to r.footSpeed,
                "accuracy" to r.accuracy, "timing" to r.timing,
                "headDefense" to r.headDefense, "bodyDefense" to r.bodyDefense,
                "blocking" to r.blocking, "evasiveness" to r.evasiveness,
                "countering" to r.countering, "pressure" to r.pressure,
                "rangeControl" to r.rangeControl, "insideFighting" to r.insideFighting,
                "endurance" to r.endurance, "recovery" to r.recovery,
                "chin" to r.chin, "bodyResistance" to r.bodyResistance,
                "balance" to r.balance, "cutResistance" to r.cutResistance,
                "ringIq" to r.ringIq, "adaptability" to r.adaptability,
                "discipline" to r.discipline, "aggression" to r.aggression,
                "finishing" to r.finishing, "composure" to r.composure,
            )
            ratingPairs.forEachIndexed { pairIndex, pair ->
                append("        \"${pair.first}\": ${pair.second}${if (pairIndex == ratingPairs.lastIndex) "" else ","}\n")
            }
            append("      },\n")
            append("      \"tendencies\": {\n")
            val tendencyPairs = listOf(
                "jabFrequency" to t.jabFrequency,
                "bodyAttackFrequency" to t.bodyAttackFrequency,
                "combinationFrequency" to t.combinationFrequency,
                "counterFrequency" to t.counterFrequency,
                "clinchFrequency" to t.clinchFrequency,
                "pressureFrequency" to t.pressureFrequency,
                "riskTolerance" to t.riskTolerance,
                "fastStart" to t.fastStart,
                "lateSurge" to t.lateSurge,
            )
            tendencyPairs.forEachIndexed { pairIndex, pair ->
                append("        \"${pair.first}\": ${pair.second}${if (pairIndex == tendencyPairs.lastIndex) "" else ","}\n")
            }
            append("      },\n")
            append("      \"signatureActions\": ${stringArray(entry.signatureActions)},\n")
            append("      \"traits\": ${stringArray(entry.traits)}\n")
            append("    }${if (index == entries.lastIndex) "" else ","}\n")
        }
        append("  ]\n")
        append("}\n")
    }

    private fun stringArray(values: List<String>): String =
        values.joinToString(prefix = "[", postfix = "]") { "\"${escape(it)}\"" }

    private fun escape(value: String): String = value
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
}
