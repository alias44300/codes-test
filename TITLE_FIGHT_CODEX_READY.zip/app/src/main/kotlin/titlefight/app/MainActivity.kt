package titlefight.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import titlefight.BoxerCatalog
import titlefight.FighterCorner
import titlefight.InteractiveFightSession
import titlefight.Tactic
import titlefight.ui.compose.InteractiveFightCoordinator
import titlefight.ui.compose.TitleFightScreen
import titlefight.ui.compose.TitleFightTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TitleFightTheme(darkTheme = true) {
                TitleFightDemoApp()
            }
        }
    }
}

object DemoFightFactory {
    fun coordinator(seed: Long = 6_202_607_21L): InteractiveFightCoordinator =
        InteractiveFightCoordinator(
            InteractiveFightSession(
                red = BoxerCatalog.eliasVega,
                blue = BoxerCatalog.brunoKessler,
                redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
                blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
                seed = seed,
                playerCorner = FighterCorner.RED,
            ),
        )
}

@Composable
fun TitleFightDemoApp() {
    val coordinator = remember { DemoFightFactory.coordinator() }
    var viewState by remember { mutableStateOf(coordinator.start()) }

    TitleFightScreen(
        state = viewState.screenState,
        tacticalSelection = viewState.tacticalSelection,
        onTacticalAction = { action ->
            viewState = coordinator.dispatch(action)
        },
    )
}
