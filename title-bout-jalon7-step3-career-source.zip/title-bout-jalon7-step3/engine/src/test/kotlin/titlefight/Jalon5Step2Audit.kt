package titlefight

import kotlin.math.abs

/**
 * Mesure contrôlée de l'identité statistique des dix profils.
 *
 * Chaque boxeur affronte le même partenaire d'étalonnage, avec les six tactiques
 * historiques réparties à parts égales et les coins alternés. Le plan naturel du
 * style est fixé pour tout le round afin de mesurer son expression sans adaptation
 * inter-rounds et sans lancer la matrice des 45 affrontements.
 */
data class BoxerIdentityMetrics(
    val fighterId: String,
    val fighterName: String,
    val style: BoxingStyle,
    val naturalPlanId: String,
    val rounds: Int,
    val attacks: Int,
    val landed: Int,
    val cleanHits: Int,
    val outsideAttacks: Int,
    val midAttacks: Int,
    val insideAttacks: Int,
    val bodyAttempts: Int,
    val defensiveSuccesses: Int,
    val punchesAllowed: Int,
    val totalImpact: Double,
    val totalStaminaSpent: Double,
    val knockdownsScored: Int,
) {
    val attacksPerRound: Double get() = attacks.toDouble() / rounds
    val accuracy: Double get() = ratio(landed, attacks)
    val cleanHitShare: Double get() = ratio(cleanHits, landed)
    val outsideShare: Double get() = ratio(outsideAttacks, attacks)
    val midShare: Double get() = ratio(midAttacks, attacks)
    val insideShare: Double get() = ratio(insideAttacks, attacks)
    val bodyAttemptShare: Double get() = ratio(bodyAttempts, attacks)
    val defensiveSuccessRate: Double get() = ratio(defensiveSuccesses, defensiveSuccesses + punchesAllowed)
    val averageImpact: Double get() = if (landed == 0) 0.0 else totalImpact / landed
    val staminaSpentPerRound: Double get() = totalStaminaSpent / rounds
    val knockdownsPerHundredRounds: Double get() = knockdownsScored.toDouble() * 100.0 / rounds
    val preferredRangeShare: Double get() = when (style) {
        BoxingStyle.OUT_BOXER, BoxingStyle.DEFENSIVE_SPECIALIST -> outsideShare
        BoxingStyle.PRESSURE_FIGHTER, BoxingStyle.SWARMER -> insideShare
        BoxingStyle.COUNTERPUNCHER, BoxingStyle.BOXER_PUNCHER, BoxingStyle.SLUGGER -> midShare
    }

    val dominantRange: FightRange get() = listOf(
        FightRange.OUTSIDE to outsideShare,
        FightRange.MID to midShare,
        FightRange.INSIDE to insideShare,
    ).maxBy { it.second }.first

    private fun ratio(value: Int, total: Int): Double = if (total == 0) 0.0 else value.toDouble() / total
}

data class Jalon5Step2AuditResult(
    val roundsPerProfile: Int,
    val profiles: List<BoxerIdentityMetrics>,
    val reproducibilityChecks: Int,
    val reproducibilityMismatches: Int,
    val missingNaturalPlans: Int,
    val wrongAppliedPlans: Int,
    val invalidMetricCount: Int,
    val indistinguishablePairs: List<Pair<String, String>>,
    val dominantRangeMismatches: List<String>,
    val acceptanceIssues: List<String>,
    val legacyBehaviorFingerprintMismatches: Int,
) {
    val identityAccepted: Boolean get() = acceptanceIssues.isEmpty()
    fun profile(id: String): BoxerIdentityMetrics = profiles.first { it.fighterId == id }
    fun byStyle(style: BoxingStyle): List<BoxerIdentityMetrics> = profiles.filter { it.style == style }
    fun averageAttacks(pace: TacticalPace): Double = averageFor(pace) { it.attacksPerRound }
    fun averageBodyShare(target: TacticalTarget): Double = averageFor(target) { it.bodyAttemptShare }
    fun averagePreferredRangeShare(distance: TacticalDistance): Double = averageFor(distance) { it.preferredRangeShare }
    fun averageImpact(risk: TacticalRisk): Double = averageFor(risk) { it.averageImpact }
    fun averageDefense(style: BoxingStyle): Double = byStyle(style).map { it.defensiveSuccessRate }.average()

    private fun averageFor(pace: TacticalPace, selector: (BoxerIdentityMetrics) -> Double): Double =
        profiles.filter { TacticalPlanCatalog.naturalFor(it.style).pace == pace }.map(selector).average()

    private fun averageFor(target: TacticalTarget, selector: (BoxerIdentityMetrics) -> Double): Double =
        profiles.filter { TacticalPlanCatalog.naturalFor(it.style).target == target }.map(selector).average()

    private fun averageFor(distance: TacticalDistance, selector: (BoxerIdentityMetrics) -> Double): Double =
        profiles.filter { TacticalPlanCatalog.naturalFor(it.style).distance == distance }.map(selector).average()

    private fun averageFor(risk: TacticalRisk, selector: (BoxerIdentityMetrics) -> Double): Double =
        profiles.filter { TacticalPlanCatalog.naturalFor(it.style).risk == risk }.map(selector).average()
}

object Jalon5Step2Auditor {
    private const val DEFAULT_ROUNDS_PER_PROFILE = 360
    private const val DEFAULT_SEED_START = 202607212000L

    private val calibrationPartner = BoxerProfile(
        id = "identity-calibration-partner",
        name = "Identity Calibration Partner",
        nickname = "The Measure",
        stance = Stance.ORTHODOX,
        style = BoxingStyle.BOXER_PUNCHER,
        preferredRange = FightRange.MID,
        heightCm = 180,
        reachCm = 184,
        power = 82,
        speed = 82,
        technique = 84,
        defense = 83,
        endurance = 84,
        mental = 84,
        chin = 84,
        recovery = 84,
        accuracy = 84,
        mobility = 83,
        bodyResistance = 84,
        aggression = 82,
    )

    fun run(
        roundsPerProfile: Int = DEFAULT_ROUNDS_PER_PROFILE,
        seedStart: Long = DEFAULT_SEED_START,
    ): Jalon5Step2AuditResult {
        require(roundsPerProfile > 0 && roundsPerProfile % Tactic.entries.size == 0)
        val engine = FightEngine(
            sequencesPerRound = 12,
            stopOnTenCount = false,
            stopOnTko = false,
            adaptiveTacticsEnabled = true,
        )
        var reproducibilityChecks = 0
        var reproducibilityMismatches = 0
        var missingNaturalPlans = 0
        var wrongAppliedPlans = 0
        val profiles = BoxerCatalog.all.mapIndexed { profileIndex, profile ->
            val naturalPlan = TacticalPlanCatalog.naturalFor(profile)
            val calibrationPlan = TacticalPlanCatalog.naturalFor(calibrationPartner)
            var attacks = 0
            var landed = 0
            var cleanHits = 0
            var outsideAttacks = 0
            var midAttacks = 0
            var insideAttacks = 0
            var bodyAttempts = 0
            var defensiveSuccesses = 0
            var punchesAllowed = 0
            var totalImpact = 0.0
            var totalStaminaSpent = 0.0
            var knockdownsScored = 0

            repeat(roundsPerProfile) { roundIndex ->
                val tactic = Tactic.entries[roundIndex % Tactic.entries.size]
                val seed = seedStart + profileIndex * 1_000_000L + roundIndex
                val profileIsRed = roundIndex % 2 == 0
                val round = if (profileIsRed) {
                    engine.simulateRound(
                        roundNumber = 1,
                        red = profile,
                        blue = calibrationPartner,
                        redStart = FighterState(),
                        blueStart = FighterState(),
                        redTactic = tactic,
                        blueTactic = tactic,
                        seed = seed,
                        redPlan = naturalPlan,
                        bluePlan = calibrationPlan,
                    )
                } else {
                    engine.simulateRound(
                        roundNumber = 1,
                        red = calibrationPartner,
                        blue = profile,
                        redStart = FighterState(),
                        blueStart = FighterState(),
                        redTactic = tactic,
                        blueTactic = tactic,
                        seed = seed,
                        redPlan = calibrationPlan,
                        bluePlan = naturalPlan,
                    )
                }

                if (roundIndex < 12) {
                    reproducibilityChecks++
                    val repeated = if (profileIsRed) {
                        engine.simulateRound(1, profile, calibrationPartner, FighterState(), FighterState(), tactic, tactic, seed, naturalPlan, calibrationPlan)
                    } else {
                        engine.simulateRound(1, calibrationPartner, profile, FighterState(), FighterState(), tactic, tactic, seed, calibrationPlan, naturalPlan)
                    }
                    if (repeated != round) reproducibilityMismatches++
                }

                val appliedPlan = if (profileIsRed) round.redAppliedTacticalPlan else round.blueAppliedTacticalPlan
                if (appliedPlan == null) missingNaturalPlans++
                if (appliedPlan != naturalPlan) wrongAppliedPlans++

                val evidence = if (profileIsRed) round.judgingEvidence.red else round.judgingEvidence.blue
                val finalState = if (profileIsRed) round.redState else round.blueState
                val ownEvents = round.events.filter { it.attackerId == profile.id }

                attacks += evidence.initiatedSequences
                landed += evidence.landedPunches
                cleanHits += evidence.cleanHits
                outsideAttacks += evidence.outsideInitiatives
                midAttacks += evidence.midInitiatives
                insideAttacks += evidence.insideInitiatives
                bodyAttempts += ownEvents.count { it.punch == Punch.BODY_HOOK }
                defensiveSuccesses += evidence.defensiveSuccesses
                punchesAllowed += evidence.punchesAllowed
                totalImpact += evidence.totalImpact
                totalStaminaSpent += 100.0 - finalState.stamina
                knockdownsScored += evidence.knockdownsScored
            }

            BoxerIdentityMetrics(
                fighterId = profile.id,
                fighterName = profile.name,
                style = profile.style,
                naturalPlanId = naturalPlan.id,
                rounds = roundsPerProfile,
                attacks = attacks,
                landed = landed,
                cleanHits = cleanHits,
                outsideAttacks = outsideAttacks,
                midAttacks = midAttacks,
                insideAttacks = insideAttacks,
                bodyAttempts = bodyAttempts,
                defensiveSuccesses = defensiveSuccesses,
                punchesAllowed = punchesAllowed,
                totalImpact = totalImpact,
                totalStaminaSpent = totalStaminaSpent,
                knockdownsScored = knockdownsScored,
            )
        }

        val dominantRangeMismatches = profiles
            .filter { it.dominantRange != expectedRange(it.style) }
            .map { it.fighterId }
        val provisional = Jalon5Step2AuditResult(
            roundsPerProfile = roundsPerProfile,
            profiles = profiles,
            reproducibilityChecks = reproducibilityChecks,
            reproducibilityMismatches = reproducibilityMismatches,
            missingNaturalPlans = missingNaturalPlans,
            wrongAppliedPlans = wrongAppliedPlans,
            invalidMetricCount = profiles.count(::hasInvalidMetric),
            indistinguishablePairs = indistinguishablePairs(profiles),
            dominantRangeMismatches = dominantRangeMismatches,
            acceptanceIssues = emptyList(),
            legacyBehaviorFingerprintMismatches = LegacyBehaviorFingerprint.verify(),
        )
        return provisional.copy(acceptanceIssues = acceptanceIssues(provisional))
    }

    fun assertIntegrity(result: Jalon5Step2AuditResult) {
        check(result.profiles.size == 10)
        check(result.profiles.map { it.fighterId }.toSet() == BoxerCatalog.all.map { it.id }.toSet())
        check(result.reproducibilityChecks == 120)
        check(result.reproducibilityMismatches == 0)
        check(result.missingNaturalPlans == 0)
        check(result.wrongAppliedPlans == 0)
        check(result.invalidMetricCount == 0)
        check(result.indistinguishablePairs.isEmpty())
        check(result.legacyBehaviorFingerprintMismatches == 0)

        result.profiles.forEach { profile ->
            check(profile.rounds == result.roundsPerProfile)
            check(profile.attacks > 0)
            check(profile.landed > 0)
            check(profile.naturalPlanId == TacticalPlanCatalog.naturalFor(profile.style).id)
            check(profile.outsideAttacks + profile.midAttacks + profile.insideAttacks == profile.attacks)
        }

        check(result.averageAttacks(TacticalPace.SUSTAINED) > result.averageAttacks(TacticalPace.MEASURED))
        check(result.averageAttacks(TacticalPace.MEASURED) > result.averageAttacks(TacticalPace.CAUTIOUS))

        val bodyTarget = result.byStyle(BoxingStyle.PRESSURE_FIGHTER).map { it.bodyAttemptShare }.average()
        val closeMixed = result.byStyle(BoxingStyle.SWARMER).single().bodyAttemptShare
        check(bodyTarget > closeMixed + 0.12)

        val mediumHead = (result.byStyle(BoxingStyle.COUNTERPUNCHER) + result.byStyle(BoxingStyle.SLUGGER))
            .map { it.bodyAttemptShare }.average()
        val mediumMixed = result.byStyle(BoxingStyle.BOXER_PUNCHER).map { it.bodyAttemptShare }.average()
        check(mediumMixed > mediumHead + 0.04)

        val defensive = result.profile(BoxerCatalog.kenjiMori.id)
        val slugger = result.profile(BoxerCatalog.viktorSokolov.id)
        val swarmer = result.profile(BoxerCatalog.dariusCole.id)
        check(defensive.defensiveSuccessRate >= result.profiles.map { it.defensiveSuccessRate }.average())
        check(slugger.averageImpact >= result.profiles.map { it.averageImpact }.average())
        check(swarmer.attacksPerRound >= result.profiles.map { it.attacksPerRound }.average())
    }

    fun csv(result: Jalon5Step2AuditResult): String = buildString {
        appendLine("fighter_id,fighter_name,style,natural_plan,rounds,attacks_per_round,accuracy,clean_hit_share,outside_share,mid_share,inside_share,preferred_range_share,body_attempt_share,defensive_success_rate,average_impact,stamina_spent_per_round,knockdowns_per_100_rounds")
        result.profiles.forEach { p ->
            appendLine(listOf(
                p.fighterId,
                p.fighterName,
                p.style,
                p.naturalPlanId,
                p.rounds,
                f(p.attacksPerRound),
                f(p.accuracy),
                f(p.cleanHitShare),
                f(p.outsideShare),
                f(p.midShare),
                f(p.insideShare),
                f(p.preferredRangeShare),
                f(p.bodyAttemptShare),
                f(p.defensiveSuccessRate),
                f(p.averageImpact),
                f(p.staminaSpentPerRound),
                f(p.knockdownsPerHundredRounds),
            ).joinToString(","))
        }
    }

    private fun acceptanceIssues(result: Jalon5Step2AuditResult): List<String> = buildList {
        if (result.dominantRangeMismatches.isNotEmpty()) {
            add("La distance dominante ne correspond pas au style naturel pour : ${result.dominantRangeMismatches.joinToString()}.")
        }
        val mediumShare = result.averagePreferredRangeShare(TacticalDistance.MEDIUM)
        if (mediumShare < 0.30) {
            add("La part moyenne à distance moyenne est de ${"%.2f".format(java.util.Locale.ROOT, mediumShare * 100.0)} %, sous le seuil de 30 %.")
        }
        val longShare = result.averagePreferredRangeShare(TacticalDistance.LONG)
        if (longShare < 0.60) add("La longue distance naturelle est insuffisamment visible.")
        val closeShare = result.averagePreferredRangeShare(TacticalDistance.CLOSE)
        if (closeShare < 0.55) add("La courte distance naturelle est insuffisamment visible.")
    }

    private fun expectedRange(style: BoxingStyle): FightRange = when (style) {
        BoxingStyle.OUT_BOXER, BoxingStyle.DEFENSIVE_SPECIALIST -> FightRange.OUTSIDE
        BoxingStyle.PRESSURE_FIGHTER, BoxingStyle.SWARMER -> FightRange.INSIDE
        BoxingStyle.COUNTERPUNCHER, BoxingStyle.BOXER_PUNCHER, BoxingStyle.SLUGGER -> FightRange.MID
    }

    private fun hasInvalidMetric(profile: BoxerIdentityMetrics): Boolean =
        profile.attacksPerRound !in 0.0..12.0 ||
            profile.accuracy !in 0.0..1.0 ||
            profile.cleanHitShare !in 0.0..1.0 ||
            profile.outsideShare !in 0.0..1.0 ||
            profile.midShare !in 0.0..1.0 ||
            profile.insideShare !in 0.0..1.0 ||
            abs(profile.outsideShare + profile.midShare + profile.insideShare - 1.0) > 1e-9 ||
            profile.bodyAttemptShare !in 0.0..1.0 ||
            profile.defensiveSuccessRate !in 0.0..1.0 ||
            profile.averageImpact < 0.0 ||
            profile.staminaSpentPerRound !in 0.0..100.0 ||
            profile.knockdownsPerHundredRounds < 0.0

    private fun indistinguishablePairs(profiles: List<BoxerIdentityMetrics>): List<Pair<String, String>> = buildList {
        profiles.forEachIndexed { index, first ->
            profiles.drop(index + 1).forEach { second ->
                val indistinguishable =
                    abs(first.outsideShare - second.outsideShare) < 0.025 &&
                        abs(first.midShare - second.midShare) < 0.025 &&
                        abs(first.insideShare - second.insideShare) < 0.025 &&
                        abs(first.attacksPerRound - second.attacksPerRound) < 0.10 &&
                        abs(first.bodyAttemptShare - second.bodyAttemptShare) < 0.025 &&
                        abs(first.defensiveSuccessRate - second.defensiveSuccessRate) < 0.0125 &&
                        abs(first.averageImpact - second.averageImpact) < 0.12 &&
                        abs(first.staminaSpentPerRound - second.staminaSpentPerRound) < 0.12
                if (indistinguishable) add(first.fighterId to second.fighterId)
            }
        }
    }

    private fun f(value: Double): String = "%.6f".format(java.util.Locale.ROOT, value)
}

object Jalon5Step2AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step2Auditor.run()
        Jalon5Step2Auditor.assertIntegrity(result)
        println("AUDIT JALON 5 — ÉTAPE 2")
        println("Profils : ${result.profiles.size}")
        println("Rounds contrôlés : ${result.profiles.sumOf { it.rounds }}")
        println("Contrôles de reproductibilité : ${result.reproducibilityChecks}")
        println("Écarts de reproductibilité : ${result.reproducibilityMismatches}")
        println("Plans naturels manquants / incorrects : ${result.missingNaturalPlans} / ${result.wrongAppliedPlans}")
        println("Métriques invalides : ${result.invalidMetricCount}")
        println("Paires statistiquement indiscernables : ${result.indistinguishablePairs.size} ${result.indistinguishablePairs}")
        println("Empreintes historiques modifiées : ${result.legacyBehaviorFingerprintMismatches}")
        println("Distances dominantes incohérentes : ${result.dominantRangeMismatches.size} ${result.dominantRangeMismatches}")
        println("Statut d’acceptation : ${if (result.identityAccepted) "VALIDÉ" else "CORRECTION REQUISE"}")
        result.acceptanceIssues.forEach { println("- $it") }
        println()
        result.profiles.forEach { p ->
            println(
                "${p.fighterName} | ${p.style} | portée ${p.dominantRange} (${pct(p.preferredRangeShare)}) | " +
                    "activité ${n(p.attacksPerRound)} | corps ${pct(p.bodyAttemptShare)} | défense ${pct(p.defensiveSuccessRate)} | " +
                    "impact ${n(p.averageImpact)} | fatigue ${n(p.staminaSpentPerRound)}",
            )
        }
        println()
        println("Activité CAUTIOUS / MEASURED / SUSTAINED : ${n(result.averageAttacks(TacticalPace.CAUTIOUS))} / ${n(result.averageAttacks(TacticalPace.MEASURED))} / ${n(result.averageAttacks(TacticalPace.SUSTAINED))}")
        println("Cible HEAD / MIXED / BODY : ${pct(result.averageBodyShare(TacticalTarget.HEAD))} / ${pct(result.averageBodyShare(TacticalTarget.MIXED))} / ${pct(result.averageBodyShare(TacticalTarget.BODY))}")
        println("Portée LONG / MEDIUM / CLOSE : ${pct(result.averagePreferredRangeShare(TacticalDistance.LONG))} / ${pct(result.averagePreferredRangeShare(TacticalDistance.MEDIUM))} / ${pct(result.averagePreferredRangeShare(TacticalDistance.CLOSE))}")
    }

    private fun pct(value: Double): String = "%.2f%%".format(java.util.Locale.ROOT, value * 100.0)
    private fun n(value: Double): String = "%.2f".format(java.util.Locale.ROOT, value)
}

object Jalon5Step2CsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step2Auditor.run()
        Jalon5Step2Auditor.assertIntegrity(result)
        print(Jalon5Step2Auditor.csv(result))
    }
}
