# Jalon 3 — Étape 1 — Preuves objectives de round

## Statut

VALIDÉE

## Objectif

Créer une structure de faits vérifiables pour alimenter ultérieurement les trois juges, sans calculer de points, de carte ou de décision officielle.

## Structures ajoutées

- `FighterRoundJudgingEvidence`
- `RoundJudgingEvidence`
- `RoundJudgingEvidenceExtractor`

Chaque `RoundResult` contient désormais ses propres preuves objectives.

## Données agrégées

Pour chaque boxeur et pour chaque round :

- séquences initiées ;
- séquences efficaces ;
- coups touchés et coups nets ;
- impact total et impact net ;
- réussites défensives ;
- coups nets et impact concédés ;
- répartition des initiatives par distance ;
- part des initiatives à la distance préférée ;
- travail au corps ;
- knockdowns provoqués et subis.

## Garde-fous

- les preuves sont construites uniquement depuis `SequenceEvent` ;
- les correspondances attaque/défense sont validées entre les deux boxeurs ;
- aucun événement fictif n’est ajouté après un KO ou TKO ;
- aucune note 10-9, aucun vainqueur de round, aucune carte et aucune décision n’existent à cette étape.

## Validation

- 35 tests automatisés réussis ;
- archive réextraite puis retestée : 35 tests réussis ;
- audit reproductible de 1 000 combats ;
- 3 000 rounds réellement simulés ;
- 35 990 séquences réellement simulées ;
- 2 rounds interrompus par KO/TKO ;
- 0 preuve vide ;
- 0 écart entre la preuve attachée et sa réextraction depuis les événements bruts.
