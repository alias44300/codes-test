package titlefight

import kotlin.math.abs

data class Jalon5Step4AuditResult(
    val matrix: Jalon5Step3AuditResult,
    val identity: Jalon5Step2AuditResult,
    val boxerOutliersBefore: Int,
    val boxerOutliersAfter: Int,
    val styleOutliersBefore: Int,
    val styleOutliersAfter: Int,
    val boxerSpreadBefore: Double,
    val boxerSpreadAfter: Double,
    val styleSpreadBefore: Double,
    val styleSpreadAfter: Double,
    val historicalProfilesUnchanged: Boolean,
    val approvedCalibratedProfileIds: Set<String>,
) {
    val maxBoxerCornerGap: Double get() = matrix.boxers.maxOf { it.cornerGap }
    val allBoxersCompetitive: Boolean get() = matrix.boxers.all { it.nonDrawWinShare in 0.30..0.70 }
    val allStylesCompetitive: Boolean get() = matrix.styles.all { it.nonDrawWinShare in 0.35..0.65 }
    val cornerNeutral: Boolean get() = matrix.redWinnerShare in 0.48..0.52 && maxBoxerCornerGap <= 0.08
    val identityPreserved: Boolean get() = identity.identityAccepted && identity.indistinguishablePairs.isEmpty()
    val calibrationAccepted: Boolean
        get() = matrix.technicalIntegrityAccepted &&
            allBoxersCompetitive &&
            allStylesCompetitive &&
            cornerNeutral &&
            identityPreserved &&
            matrix.calibrationFlags.isEmpty() &&
            matrix.legacyBehaviorFingerprintMismatches == 0 &&
            historicalProfilesUnchanged &&
            boxerSpreadAfter < boxerSpreadBefore &&
            styleSpreadAfter < styleSpreadBefore
}

object Jalon5Step4Auditor {
    private val baselineBoxerNonDrawShares = mapOf(
        "elias-vega" to 0.538133,
        "bruno-kessler" to 0.630006,
        "malik-okoro" to 0.256213,
        "tomas-aranda" to 0.564458,
        "darius-cole" to 0.813842,
        "viktor-sokolov" to 0.146832,
        "kenji-mori" to 0.067390,
        "luca-moretti" to 0.584767,
        "idris-kane" to 0.788551,
        "mateo-silva" to 0.634102,
    )

    private val baselineStyleNonDrawShares = mapOf(
        BoxingStyle.OUT_BOXER to 0.561371,
        BoxingStyle.PRESSURE_FIGHTER to 0.710192,
        BoxingStyle.COUNTERPUNCHER to 0.256213,
        BoxingStyle.BOXER_PUNCHER to 0.599154,
        BoxingStyle.SWARMER to 0.813842,
        BoxingStyle.SLUGGER to 0.146832,
        BoxingStyle.DEFENSIVE_SPECIALIST to 0.067390,
    )

    val approvedCalibratedProfileIds: Set<String> = setOf(
        BoxerCatalog.malikOkoro.id,
        BoxerCatalog.tomasAranda.id,
        BoxerCatalog.dariusCole.id,
        BoxerCatalog.viktorSokolov.id,
        BoxerCatalog.kenjiMori.id,
        BoxerCatalog.idrisKane.id,
        BoxerCatalog.mateoSilva.id,
    )

    fun run(): Jalon5Step4AuditResult = evaluate(
        matrix = Jalon5Step3Auditor.run(),
        identity = Jalon5Step2Auditor.run(),
    )

    fun evaluate(
        matrix: Jalon5Step3AuditResult,
        identity: Jalon5Step2AuditResult,
    ): Jalon5Step4AuditResult {
        Jalon5Step3Auditor.assertTechnicalIntegrity(matrix)
        Jalon5Step2Auditor.assertIntegrity(identity)

        val boxerAfter = matrix.boxers.associate { it.fighterId to it.nonDrawWinShare }
        val styleAfter = matrix.styles.associate { it.style to it.nonDrawWinShare }
        return Jalon5Step4AuditResult(
            matrix = matrix,
            identity = identity,
            boxerOutliersBefore = baselineBoxerNonDrawShares.values.count { it !in 0.30..0.70 },
            boxerOutliersAfter = boxerAfter.values.count { it !in 0.30..0.70 },
            styleOutliersBefore = baselineStyleNonDrawShares.values.count { it !in 0.35..0.65 },
            styleOutliersAfter = styleAfter.values.count { it !in 0.35..0.65 },
            boxerSpreadBefore = spread(baselineBoxerNonDrawShares.values),
            boxerSpreadAfter = spread(boxerAfter.values),
            styleSpreadBefore = spread(baselineStyleNonDrawShares.values),
            styleSpreadAfter = spread(styleAfter.values),
            historicalProfilesUnchanged = historicalProfilesUnchanged(),
            approvedCalibratedProfileIds = approvedCalibratedProfileIds,
        )
    }

    fun assertAccepted(result: Jalon5Step4AuditResult) {
        check(result.calibrationAccepted)
        check(result.boxerOutliersBefore == 5)
        check(result.boxerOutliersAfter == 0)
        check(result.styleOutliersBefore == 5)
        check(result.styleOutliersAfter == 0)
        check(result.matrix.boxers.all { it.wins > 0 && it.losses > 0 })
        check(result.matrix.styles.all { it.wins > 0 && it.losses > 0 })
        check(result.maxBoxerCornerGap <= 0.08)
        check(abs(result.matrix.redWinnerShare - 0.50) <= 0.02)
        check(result.approvedCalibratedProfileIds.size == 7)
    }

    fun report(result: Jalon5Step4AuditResult): String = buildString {
        appendLine("AUDIT JALON 5 — ÉTAPE 4")
        appendLine("Combats de matrice : ${result.matrix.totalFights}")
        appendLine("Profils hors bande avant / après : ${result.boxerOutliersBefore} / ${result.boxerOutliersAfter}")
        appendLine("Styles hors bande avant / après : ${result.styleOutliersBefore} / ${result.styleOutliersAfter}")
        appendLine("Dispersion boxeurs avant / après : ${pct(result.boxerSpreadBefore)} / ${pct(result.boxerSpreadAfter)}")
        appendLine("Dispersion styles avant / après : ${pct(result.styleSpreadBefore)} / ${pct(result.styleSpreadAfter)}")
        appendLine("Victoires rouge / bleu / nuls : ${result.matrix.redWins} / ${result.matrix.blueWins} / ${result.matrix.draws}")
        appendLine("Part rouge parmi les vainqueurs : ${pct(result.matrix.redWinnerShare)}")
        appendLine("Écart de coin maximal par boxeur : ${pct(result.maxBoxerCornerGap)}")
        appendLine("KO / TKO / décisions : ${result.matrix.ko} / ${result.matrix.tko} / ${result.matrix.decisions}")
        appendLine("Identité statistique préservée : ${result.identityPreserved}")
        appendLine("Profils historiques inchangés : ${result.historicalProfilesUnchanged}")
        appendLine("Empreintes historiques modifiées : ${result.matrix.legacyBehaviorFingerprintMismatches}")
        appendLine("Calibration : ${if (result.calibrationAccepted) "VALIDÉE" else "ÉCHEC"}")
        appendLine()
        result.matrix.boxers.sortedByDescending { it.nonDrawWinShare }.forEach {
            appendLine("${it.fighterName} | ${it.style} | ${it.wins}-${it.losses}-${it.draws} | hors nuls ${pct(it.nonDrawWinShare)} | coin ${pct(it.cornerGap)}")
        }
    }

    private fun historicalProfilesUnchanged(): Boolean =
        BoxerCatalog.eliasVega == BoxerProfile(
            id = "elias-vega", name = "Elias Vega", nickname = "The Comet",
            stance = Stance.ORTHODOX, style = BoxingStyle.OUT_BOXER, preferredRange = FightRange.OUTSIDE,
            heightCm = 182, reachCm = 188,
            power = 74, speed = 92, technique = 89, defense = 88, endurance = 84, mental = 86,
            chin = 78, recovery = 84, accuracy = 90, mobility = 94, bodyResistance = 77, aggression = 62,
        ) && BoxerCatalog.brunoKessler == BoxerProfile(
            id = "bruno-kessler", name = "Bruno Kessler", nickname = "The Anvil",
            stance = Stance.ORTHODOX, style = BoxingStyle.PRESSURE_FIGHTER, preferredRange = FightRange.INSIDE,
            heightCm = 180, reachCm = 183,
            power = 92, speed = 73, technique = 80, defense = 76, endurance = 91, mental = 90,
            chin = 94, recovery = 92, accuracy = 82, mobility = 70, bodyResistance = 93, aggression = 95,
        ) && BoxerCatalog.lucaMoretti == BoxerProfile(
            id = "luca-moretti", name = "Luca Moretti", nickname = "The Maestro",
            stance = Stance.SWITCH, style = BoxingStyle.OUT_BOXER, preferredRange = FightRange.OUTSIDE,
            heightCm = 181, reachCm = 187,
            power = 76, speed = 89, technique = 94, defense = 86, endurance = 83, mental = 90,
            chin = 77, recovery = 83, accuracy = 92, mobility = 91, bodyResistance = 79, aggression = 64,
        )

    private fun spread(values: Collection<Double>): Double = values.maxOrNull()!! - values.minOrNull()!!
    private fun pct(value: Double): String = "%.2f%%".format(java.util.Locale.ROOT, value * 100.0)
}

object Jalon5Step4AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step4Auditor.run()
        Jalon5Step4Auditor.assertAccepted(result)
        print(Jalon5Step4Auditor.report(result))
    }
}

object Jalon5Step4MatchupsCsvDemo {
    @JvmStatic fun main(args: Array<String>) {
        val result = Jalon5Step4Auditor.run()
        Jalon5Step4Auditor.assertAccepted(result)
        print(Jalon5Step3Auditor.matchupsCsv(result.matrix))
    }
}

object Jalon5Step4BoxersCsvDemo {
    @JvmStatic fun main(args: Array<String>) {
        val result = Jalon5Step4Auditor.run()
        Jalon5Step4Auditor.assertAccepted(result)
        print(Jalon5Step3Auditor.boxerCsv(result.matrix))
    }
}

object Jalon5Step4StylesCsvDemo {
    @JvmStatic fun main(args: Array<String>) {
        val result = Jalon5Step4Auditor.run()
        Jalon5Step4Auditor.assertAccepted(result)
        print(Jalon5Step3Auditor.stylesCsv(result.matrix))
    }
}
