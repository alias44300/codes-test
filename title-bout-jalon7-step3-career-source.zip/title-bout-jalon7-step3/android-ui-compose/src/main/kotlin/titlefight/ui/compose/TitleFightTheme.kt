package titlefight.ui.compose

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFC44D),
    onPrimary = Color(0xFF251800),
    secondary = Color(0xFF4FA3FF),
    tertiary = Color(0xFFFF5B61),
    background = Color(0xFF080D18),
    surface = Color(0xFF111A2A),
    surfaceVariant = Color(0xFF18243A),
    onBackground = Color(0xFFF4F7FF),
    onSurface = Color(0xFFF4F7FF),
    onSurfaceVariant = Color(0xFFC3CEE2),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF805600),
    secondary = Color(0xFF005FAF),
    tertiary = Color(0xFFB3262E),
    background = Color(0xFFF5F7FC),
    surface = Color.White,
    surfaceVariant = Color(0xFFE8EEF8),
    onBackground = Color(0xFF111827),
    onSurface = Color(0xFF111827),
    onSurfaceVariant = Color(0xFF42516A),
)

@Composable
fun TitleFightTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
