# Jalon 2 — Étape 4 : TKO de sécurité

## Fonction livrée

Le moteur peut arrêter un combat par TKO lorsqu’un boxeur ne se défend plus intelligemment.

## Règle finale après l’audit de l’étape 5

Le TKO est déclenché uniquement lorsque toutes les conditions suivantes sont réunies :

1. la dernière attaque est réussie et menaçante ;
2. aucune chute n’est attachée à cette même séquence ;
3. le boxeur a subi au moins trois impacts lourds consécutifs sans réponse ;
4. sa stabilité est inférieure ou égale à 42 ;
5. son énergie est inférieure ou égale à 55 ;
6. ses dégâts à la tête atteignent 50, ou ses dégâts au corps atteignent 60.

Les seuils initiaux de l’étape 4 étaient 24, 32, 72 et 82. L’audit sur des combats démarrant à 100 % a montré que le TKO était pratiquement dormant. L’étape 5 a donc assoupli uniquement ces quatre seuils, sans modifier le mécanisme ni l’exigence de trois impacts lourds sans réponse.

## Priorité des arrêts

- un compte à 10 produit toujours un KO ;
- le TKO n’est évalué qu’en l’absence de KO sur la séquence ;
- aucun tirage aléatoire n’est utilisé pour le TKO.

## Données enregistrées

- méthode : `TKO` ;
- identifiant du vainqueur ;
- identifiant du perdant ;
- round de l’arrêt ;
- séquence de l’arrêt ;
- motif détaillé avec état physique et série d’échecs défensifs.

## Invariants

1. Aucun TKO sur une attaque manquée.
2. Aucun TKO sur la même séquence qu’une chute.
3. Aucun TKO si un seul seuil manque.
4. Aucun événement n’est calculé après le TKO.
5. Le résultat est strictement reproductible avec la même graine.
6. Les juges et l’interface restent hors périmètre.

## Audit technique de câblage

L’audit de l’étape 4 utilise 1 000 scénarios volontairement compromis pour exercer les deux mécanismes d’arrêt. Il vérifie le câblage, tandis que les fréquences normales sont contrôlées par l’audit final de l’étape 5.
