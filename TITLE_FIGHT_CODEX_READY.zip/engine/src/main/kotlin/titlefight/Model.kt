package titlefight

enum class Stance { ORTHODOX, SOUTHPAW, SWITCH }
enum class BoxingStyle { OUT_BOXER, PRESSURE_FIGHTER, COUNTERPUNCHER, BOXER_PUNCHER, SWARMER, SLUGGER, DEFENSIVE_SPECIALIST }
enum class FightRange { OUTSIDE, MID, INSIDE }
enum class Tactic { CONTROL, PRESS, COUNTER, BODY_WORK, RECOVER, SEEK_KO }
enum class Punch { JAB, CROSS, HOOK, UPPERCUT, BODY_HOOK, COMBINATION }
enum class FightMethod { KO, TKO }

data class BoxerProfile(
    val id: String,
    val name: String,
    val nickname: String,
    val stance: Stance,
    val style: BoxingStyle,
    val preferredRange: FightRange,
    val heightCm: Int,
    val reachCm: Int,
    val power: Int,
    val speed: Int,
    val technique: Int,
    val defense: Int,
    val endurance: Int,
    val mental: Int,
    val chin: Int,
    val recovery: Int,
    val accuracy: Int,
    val mobility: Int,
    val bodyResistance: Int,
    val aggression: Int,
) {
    init {
        require(id.matches(Regex("[a-z0-9]+(?:-[a-z0-9]+)*"))) {
            "L’identifiant d’un boxeur doit être un slug ASCII non vide."
        }
        require(name.isNotBlank()) { "Le nom du boxeur est obligatoire." }
        require(nickname.isNotBlank()) { "Le surnom du boxeur est obligatoire." }
        require(heightCm in 150..220) { "La taille doit être comprise entre 150 et 220 cm." }
        require(reachCm in 150..230) { "L’allonge doit être comprise entre 150 et 230 cm." }
        require(kotlin.math.abs(reachCm - heightCm) <= 25) {
            "L’écart taille/allonge doit rester plausible pour le prototype."
        }
        listOf(power, speed, technique, defense, endurance, mental, chin, recovery, accuracy, mobility, bodyResistance, aggression)
            .forEach { require(it in 1..100) { "Toutes les statistiques doivent être comprises entre 1 et 100." } }
    }

    val primaryStats: List<Int>
        get() = listOf(power, speed, technique, defense, endurance, mental)

    val secondaryStats: List<Int>
        get() = listOf(chin, recovery, accuracy, mobility, bodyResistance, aggression)
}


data class FighterState(
    val stamina: Double = 100.0,
    val headDamage: Double = 0.0,
    val bodyDamage: Double = 0.0,
    val stability: Double = 100.0,
    val landed: Int = 0,
    val thrown: Int = 0,
    val cleanHits: Int = 0,
    val knockdownsSuffered: Int = 0,
    val vulnerabilitySequencesRemaining: Int = 0,
    val pendingTenCount: Boolean = false,
    val defensiveFailureStreak: Int = 0,
) {
    init {
        require(stamina in 0.0..100.0)
        require(headDamage in 0.0..100.0)
        require(bodyDamage in 0.0..100.0)
        require(stability in 0.0..100.0)
        require(landed >= 0)
        require(thrown >= 0)
        require(cleanHits >= 0)
        require(knockdownsSuffered >= 0)
        require(vulnerabilitySequencesRemaining in 0..6)
        require(defensiveFailureStreak in 0..12)
    }
}

data class RefereeCount(
    val countReached: Int,
    val recovered: Boolean,
    val recoveryScore: Double,
    val requiredScore: Double,
    val roll: Double,
    val vulnerabilitySequences: Int,
) {
    init {
        require(countReached in 1..10)
        require(recoveryScore >= 0.0)
        require(requiredScore >= 0.0)
        require(roll in 0.0..1.0)
        require(recovered == (countReached < 10))
        require(vulnerabilitySequences in 0..4)
        require(recovered || vulnerabilitySequences == 0)
        require(!recovered || vulnerabilitySequences >= 1)
    }
}

data class KnockdownEvent(
    val attackerId: String,
    val defenderId: String,
    val roundNumber: Int,
    val sequenceNumber: Int,
    val punch: Punch,
    val impact: Double,
    val score: Double,
    val probability: Double,
    val roll: Double,
    val refereeCount: RefereeCount? = null,
) {
    init {
        require(attackerId != defenderId)
        require(roundNumber >= 1)
        require(sequenceNumber >= 1)
        require(impact > 0.0)
        require(score > 0.0)
        require(probability in 0.0..1.0)
        require(roll in 0.0..1.0)
        require(roll < probability) { "Un événement de chute ne peut être créé que si le tirage est inférieur à sa probabilité." }
    }
}

data class SequenceEvent(
    val sequenceNumber: Int,
    val attackerId: String,
    val defenderId: String,
    val range: FightRange,
    val punch: Punch,
    val landed: Boolean,
    val clean: Boolean,
    val impact: Double,
    val knockdown: KnockdownEvent? = null,
    val text: String,
) {
    init {
        require(sequenceNumber >= 1)
        require(attackerId != defenderId)
        require(impact >= 0.0)
        require(!clean || landed)
        require(knockdown == null || landed) { "Une chute ne peut jamais provenir d’une attaque manquée." }
        require(knockdown == null || knockdown.attackerId == attackerId)
        require(knockdown == null || knockdown.defenderId == defenderId)
        require(knockdown == null || knockdown.punch == punch)
        require(knockdown == null || knockdown.sequenceNumber == sequenceNumber)
    }
}

data class FightStoppage(
    val winnerId: String,
    val loserId: String,
    val roundNumber: Int,
    val sequenceNumber: Int,
    val method: FightMethod,
    val reason: String,
) {
    init {
        require(winnerId != loserId)
        require(roundNumber in 1..3)
        require(sequenceNumber >= 1)
        require(reason.isNotBlank())
    }
}



/**
 * État physique strictement observationnel enregistré après une séquence.
 *
 * Cette structure ne consomme aucun tirage aléatoire et n'influence jamais
 * la simulation. Elle existe uniquement pour permettre une lecture mobile
 * exacte de la progression du combat.
 */
data class SequenceStateFrame(
    val roundNumber: Int,
    val sequenceNumber: Int,
    val event: SequenceEvent,
    val redState: FighterState,
    val blueState: FighterState,
    val stoppage: FightStoppage? = null,
) {
    init {
        require(roundNumber in 1..3)
        require(sequenceNumber >= 1)
        require(event.sequenceNumber == sequenceNumber)
        stoppage?.let {
            require(it.roundNumber == roundNumber)
            require(it.sequenceNumber == sequenceNumber)
        }
    }
}

data class RoundResult(
    val roundNumber: Int,
    val seed: Long,
    val redState: FighterState,
    val blueState: FighterState,
    val events: List<SequenceEvent>,
    val redRoundScore: Double,
    val blueRoundScore: Double,
    val judgingEvidence: RoundJudgingEvidence,
    val neutralJudgeScore: NeutralJudgeRoundScore?,
    val judgeScores: List<JudgeRoundScore>,
    val redAppliedTacticalPlan: TacticalPlan? = null,
    val blueAppliedTacticalPlan: TacticalPlan? = null,
    val tacticalEffectsEnabled: Boolean = false,
    val sequenceFrames: List<SequenceStateFrame> = emptyList(),
    val stoppage: FightStoppage? = null,
) {
    init {
        require(roundNumber in 1..3)
        require(events.map { it.sequenceNumber } == (1..events.size).toList())
        if (sequenceFrames.isNotEmpty()) {
            require(sequenceFrames.size == events.size)
            require(sequenceFrames.map { it.roundNumber }.all { it == roundNumber })
            require(sequenceFrames.map { it.sequenceNumber } == (1..events.size).toList())
            require(sequenceFrames.map { it.event } == events)
            require(sequenceFrames.dropLast(1).none { it.stoppage != null })
            require(sequenceFrames.last().stoppage == stoppage)
        }
        require(judgingEvidence.roundNumber == roundNumber)
        require(judgingEvidence.sequenceCount == events.size)
        if (tacticalEffectsEnabled) {
            require(redAppliedTacticalPlan != null && blueAppliedTacticalPlan != null) {
                "Deux plans tactiques doivent être attachés à un round lorsque leurs effets sont actifs."
            }
        } else {
            require(redAppliedTacticalPlan == null && blueAppliedTacticalPlan == null) {
                "Aucun plan ne doit être marqué comme appliqué lorsque les effets tactiques sont désactivés."
            }
        }
        if (stoppage == null) {
            require(neutralJudgeScore != null) { "Un round terminé doit recevoir la note du juge neutre historique." }
            require(neutralJudgeScore.roundNumber == roundNumber)
            require(neutralJudgeScore.redFighterId == judgingEvidence.red.fighterId)
            require(neutralJudgeScore.blueFighterId == judgingEvidence.blue.fighterId)
            require(judgeScores.size == 3) { "Un round terminé doit recevoir exactement trois notes de juges." }
            require(judgeScores.map { it.judgeId } == JudgeProfiles.ALL.map { it.id })
            judgeScores.forEach { score ->
                require(score.roundNumber == roundNumber)
                require(score.redFighterId == judgingEvidence.red.fighterId)
                require(score.blueFighterId == judgingEvidence.blue.fighterId)
            }
            require(neutralJudgeScore == judgeScores.first().toNeutralScore())
        } else {
            require(neutralJudgeScore == null) { "Un round interrompu par KO ou TKO ne doit pas être jugé." }
            require(judgeScores.isEmpty()) { "Un round interrompu ne doit contenir aucune note de juge." }
        }
        stoppage?.let {
            require(it.roundNumber == roundNumber)
            require(events.isNotEmpty())
            require(it.sequenceNumber == events.last().sequenceNumber)
        }
    }
}

data class FightResult(
    val redId: String,
    val blueId: String,
    val seed: Long,
    val rounds: List<RoundResult>,
    val finalRedState: FighterState,
    val finalBlueState: FighterState,
    val redPerformanceTotal: Double,
    val bluePerformanceTotal: Double,
    val tacticalSnapshots: List<TacticalStateSnapshot>,
    val tacticalDecisions: List<TacticalDecision>,
    val adaptiveTacticsEnabled: Boolean = false,
    val stoppage: FightStoppage? = null,
    val officialDecision: OfficialDecision? = null,
) {
    init {
        require(redId != blueId)
        require(rounds.size in 1..3) { "Un combat contient entre un et trois rounds selon un éventuel KO." }
        require(rounds.map { it.roundNumber } == (1..rounds.size).toList())
        require(finalRedState == rounds.last().redState)
        require(finalBlueState == rounds.last().blueState)
        require(tacticalSnapshots.size == rounds.size) {
            "Un instantané tactique doit exister au début de chaque round réellement simulé."
        }
        require(tacticalDecisions.size == rounds.size * 2) {
            "Deux décisions tactiques doivent exister avant chaque round réellement simulé."
        }
        tacticalSnapshots.forEachIndexed { index, snapshot ->
            require(snapshot.completedRounds == index)
            require(snapshot.nextRoundNumber == index + 1)
            require(snapshot.red.fighterId == redId)
            require(snapshot.blue.fighterId == blueId)
            val decisions = tacticalDecisions.filter { it.beforeRound == index + 1 }
            require(decisions.size == 2)
            require(decisions.map { it.fighterId } == listOf(redId, blueId))
            decisions.forEach { decision ->
                require(decision.selectedPlan.anchorStyle == if (decision.fighterId == redId) {
                    tacticalDecisions.first { it.fighterId == redId }.selectedPlan.anchorStyle
                } else {
                    tacticalDecisions.first { it.fighterId == blueId }.selectedPlan.anchorStyle
                })
            }
            require(rounds[index].tacticalEffectsEnabled == adaptiveTacticsEnabled)
            if (adaptiveTacticsEnabled) {
                require(rounds[index].redAppliedTacticalPlan == decisions[0].selectedPlan)
                require(rounds[index].blueAppliedTacticalPlan == decisions[1].selectedPlan)
            }
            if (index > 0) {
                val previousRound = rounds[index - 1]
                require(previousRound.stoppage == null) {
                    "Aucun instantané tactique ne peut être créé après un KO ou un TKO."
                }
                require(kotlin.math.abs(snapshot.red.stamina - previousRound.redState.stamina) <= 1e-9)
                require(kotlin.math.abs(snapshot.blue.stamina - previousRound.blueState.stamina) <= 1e-9)
                require(kotlin.math.abs(snapshot.red.headDamage - previousRound.redState.headDamage) <= 1e-9)
                require(kotlin.math.abs(snapshot.blue.headDamage - previousRound.blueState.headDamage) <= 1e-9)
                require(kotlin.math.abs(snapshot.red.bodyDamage - previousRound.redState.bodyDamage) <= 1e-9)
                require(kotlin.math.abs(snapshot.blue.bodyDamage - previousRound.blueState.bodyDamage) <= 1e-9)
                require(kotlin.math.abs(snapshot.red.stability - previousRound.redState.stability) <= 1e-9)
                require(kotlin.math.abs(snapshot.blue.stability - previousRound.blueState.stability) <= 1e-9)
            }
        }

        val roundStoppages = rounds.mapNotNull { it.stoppage }
        if (stoppage == null) {
            require(rounds.size == 3) { "Sans arrêt, les trois rounds doivent être calculés." }
            require(roundStoppages.isEmpty())
            require(officialDecision != null) { "Un combat arrivé à la distance doit recevoir une décision officielle." }
            require(officialDecision.redFighterId == redId)
            require(officialDecision.blueFighterId == blueId)
            require(officialDecision == OfficialDecisionResolver.resolve(redId, blueId, rounds))
        } else {
            require(roundStoppages == listOf(stoppage))
            require(rounds.last().stoppage == stoppage)
            require(stoppage.winnerId in setOf(redId, blueId))
            require(stoppage.loserId in setOf(redId, blueId))
            require(stoppage.winnerId != stoppage.loserId)
            require(officialDecision == null) { "Un KO ou un TKO garde la priorité et interdit toute décision aux points." }
        }
    }
}
