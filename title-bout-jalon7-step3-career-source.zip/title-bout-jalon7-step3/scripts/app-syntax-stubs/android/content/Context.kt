package android.content
open class Context { val applicationContext: Context get() = this }
