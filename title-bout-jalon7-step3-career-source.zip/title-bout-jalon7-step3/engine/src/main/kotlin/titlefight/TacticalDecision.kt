package titlefight

import kotlin.math.abs

enum class TacticalDecisionPhase { PRE_FIGHT, BETWEEN_ROUNDS }
enum class TacticalAxis { PACE, DISTANCE, TARGET, RISK }
enum class TacticalDecisionTrigger {
    NATURAL_STYLE,
    SCORE_DEFICIT,
    FINAL_ROUND_DEFICIT,
    LEAD_PROTECTION,
    HIGH_FATIGUE,
    MODERATE_FATIGUE,
    PHYSICAL_DANGER,
    OPPONENT_HEAD_VULNERABLE,
    OPPONENT_BODY_VULNERABLE,
    OPPONENT_GENERAL_VULNERABILITY,
    MOMENTUM_LOSS,
    CONFLICT_MANAGEMENT,
    ANTI_OSCILLATION,
    PLAN_MAINTAINED,
    PLAYER_SELECTION,
}

/**
 * Décision tactique explicite prise avant un round.
 *
 * À l'étape 3, le plan sélectionné est uniquement enregistré. Il n'est pas
 * transmis aux calculs de distance, d'initiative, de précision ou d'impact.
 */
data class TacticalDecision(
    val fighterId: String,
    val beforeRound: Int,
    val phase: TacticalDecisionPhase,
    val previousPlan: TacticalPlan?,
    val selectedPlan: TacticalPlan,
    val changedAxes: List<TacticalAxis>,
    val triggers: List<TacticalDecisionTrigger>,
    val explanation: String,
) {
    init {
        require(fighterId.isNotBlank())
        require(beforeRound in 1..3)
        require(explanation.isNotBlank())
        require(triggers.isNotEmpty())
        require(changedAxes.distinct().size == changedAxes.size)
        require(triggers.distinct().size == triggers.size)
        require(selectedPlan.anchorStyle == previousPlan?.anchorStyle ?: selectedPlan.anchorStyle)
        if (beforeRound == 1) {
            require(phase == TacticalDecisionPhase.PRE_FIGHT)
            require(previousPlan == null)
            require(changedAxes.isEmpty())
            require(triggers == listOf(TacticalDecisionTrigger.NATURAL_STYLE))
        } else {
            require(phase == TacticalDecisionPhase.BETWEEN_ROUNDS)
            require(previousPlan != null)
            require(changedAxes == changedAxes(previousPlan, selectedPlan))
        }
    }

    val changed: Boolean
        get() = changedAxes.isNotEmpty()

    companion object {
        fun changedAxes(previous: TacticalPlan, selected: TacticalPlan): List<TacticalAxis> = buildList {
            if (previous.pace != selected.pace) add(TacticalAxis.PACE)
            if (previous.distance != selected.distance) add(TacticalAxis.DISTANCE)
            if (previous.target != selected.target) add(TacticalAxis.TARGET)
            if (previous.risk != selected.risk) add(TacticalAxis.RISK)
        }
    }
}

/**
 * Sélecteur déterministe, sans RNG et sans accès aux cartes des juges.
 *
 * Les seules entrées dynamiques sont l'instantané pris avant le round et
 * l'historique des décisions déjà prises pour ce boxeur.
 */
object TacticalDecisionEngine {
    const val PERFORMANCE_MARGIN_TRIGGER = 5.0
    const val MOMENTUM_MARGIN_TRIGGER = 8.0
    const val MODERATE_FATIGUE_STAMINA = 55.0
    const val HIGH_FATIGUE_STAMINA = 42.0
    const val HEAD_DANGER = 58.0
    const val BODY_DANGER = 68.0
    const val STABILITY_DANGER = 42.0
    const val TARGET_DAMAGE_MINIMUM = 48.0
    const val TARGET_DAMAGE_GAP = 10.0

    fun decide(
        profile: BoxerProfile,
        snapshot: TacticalStateSnapshot,
        history: List<TacticalDecision>,
    ): TacticalDecision {
        require(profile.id in setOf(snapshot.red.fighterId, snapshot.blue.fighterId))
        require(history.all { it.fighterId == profile.id })
        require(history.map { it.beforeRound } == (1..history.size).toList())
        require(history.size == snapshot.completedRounds)

        val natural = TacticalPlanCatalog.naturalFor(profile)
        if (snapshot.nextRoundNumber == 1) {
            require(history.isEmpty())
            return TacticalDecision(
                fighterId = profile.id,
                beforeRound = 1,
                phase = TacticalDecisionPhase.PRE_FIGHT,
                previousPlan = null,
                selectedPlan = natural,
                changedAxes = emptyList(),
                triggers = listOf(TacticalDecisionTrigger.NATURAL_STYLE),
                explanation = "Plan naturel ${profile.style.name.lowercase()} retenu avant le combat.",
            )
        }

        val previous = history.last().selectedPlan
        require(previous.anchorStyle == profile.style)
        val own = fighterState(snapshot, profile.id)
        val opponent = opponentState(snapshot, profile.id)
        val signedPerformanceMargin = if (profile.id == snapshot.red.fighterId) {
            snapshot.estimatedPerformanceMargin
        } else {
            -snapshot.estimatedPerformanceMargin
        }
        val signedMomentumMargin = if (profile.id == snapshot.red.fighterId) {
            snapshot.recentMomentumMargin
        } else {
            -snapshot.recentMomentumMargin
        }

        val trailing = own.estimatedRoundBalance < 0 ||
            (own.estimatedRoundBalance == 0 && signedPerformanceMargin <= -PERFORMANCE_MARGIN_TRIGGER)
        val leading = own.estimatedRoundBalance > 0 ||
            (own.estimatedRoundBalance == 0 && signedPerformanceMargin >= PERFORMANCE_MARGIN_TRIGGER)
        val finalRound = snapshot.nextRoundNumber == 3
        val highFatigue = own.stamina <= HIGH_FATIGUE_STAMINA
        val moderateFatigue = own.stamina <= MODERATE_FATIGUE_STAMINA
        val physicalDanger = own.headDamage >= HEAD_DANGER || own.bodyDamage >= BODY_DANGER ||
            own.stability <= STABILITY_DANGER ||
            (own.knockdownsSuffered > own.knockdownsScored && own.stability <= 55.0)

        var pace = previous.pace
        var distance = previous.distance
        var target = previous.target
        var risk = previous.risk
        val triggers = mutableListOf<TacticalDecisionTrigger>()

        val targetTrigger = vulnerableTarget(opponent)
        if (targetTrigger != null) {
            target = if (targetTrigger == TacticalDecisionTrigger.OPPONENT_HEAD_VULNERABLE) {
                TacticalTarget.HEAD
            } else {
                TacticalTarget.BODY
            }
            triggers += targetTrigger
        }

        when {
            physicalDanger -> {
                pace = stepDown(pace)
                distance = stepAway(distance)
                risk = TacticalRisk.SAFE
                triggers += TacticalDecisionTrigger.PHYSICAL_DANGER
                if (finalRound && trailing) {
                    risk = TacticalRisk.BALANCED
                    triggers += TacticalDecisionTrigger.FINAL_ROUND_DEFICIT
                    triggers += TacticalDecisionTrigger.CONFLICT_MANAGEMENT
                }
            }
            highFatigue -> {
                pace = stepDown(pace)
                risk = TacticalRisk.SAFE
                triggers += TacticalDecisionTrigger.HIGH_FATIGUE
                if (finalRound && trailing) {
                    risk = TacticalRisk.BALANCED
                    triggers += TacticalDecisionTrigger.FINAL_ROUND_DEFICIT
                    triggers += TacticalDecisionTrigger.CONFLICT_MANAGEMENT
                }
            }
            finalRound && trailing -> {
                pace = stepUp(pace)
                distance = stepCloser(distance)
                risk = stepUp(risk)
                triggers += TacticalDecisionTrigger.FINAL_ROUND_DEFICIT
            }
            finalRound && leading -> {
                pace = stepDown(pace)
                distance = stepAway(distance)
                risk = stepDown(risk)
                triggers += TacticalDecisionTrigger.LEAD_PROTECTION
            }
            trailing -> {
                pace = stepUp(pace)
                risk = stepUp(risk)
                triggers += TacticalDecisionTrigger.SCORE_DEFICIT
            }
            moderateFatigue -> {
                pace = stepDown(pace)
                triggers += TacticalDecisionTrigger.MODERATE_FATIGUE
            }
            signedMomentumMargin <= -MOMENTUM_MARGIN_TRIGGER -> {
                pace = stepUp(pace)
                triggers += TacticalDecisionTrigger.MOMENTUM_LOSS
            }
        }

        val opponentGenerallyVulnerable = opponent.stability <= 48.0 ||
            opponent.headDamage >= 55.0 || opponent.bodyDamage >= 62.0 ||
            opponent.knockdownsSuffered > 0
        if (opponentGenerallyVulnerable && !physicalDanger && !highFatigue && !leading) {
            risk = stepUp(risk)
            triggers += TacticalDecisionTrigger.OPPONENT_GENERAL_VULNERABILITY
        }

        var candidate = TacticalPlan(
            anchorStyle = profile.style,
            pace = boundAroundNatural(stepToward(previous.pace, pace), natural.pace),
            distance = boundAroundNatural(stepToward(previous.distance, distance), natural.distance),
            target = target,
            risk = boundAroundNatural(stepToward(previous.risk, risk), natural.risk),
        )

        val urgent = physicalDanger || highFatigue || (finalRound && (trailing || leading))
        val stabilized = stabilizeAgainstUnexplainedReversal(
            history = history,
            previous = previous,
            candidate = candidate,
            urgent = urgent,
            targetChangeStronglySupported = targetTrigger != null && targetDamageGap(opponent) >= TARGET_DAMAGE_GAP + 8.0,
        )
        candidate = stabilized.plan
        if (stabilized.suppressedReversal) triggers += TacticalDecisionTrigger.ANTI_OSCILLATION

        val axes = TacticalDecision.changedAxes(previous, candidate)
        if (triggers.isEmpty() || axes.isEmpty() && TacticalDecisionTrigger.ANTI_OSCILLATION !in triggers) {
            triggers += TacticalDecisionTrigger.PLAN_MAINTAINED
        }
        val distinctTriggers = triggers.distinct()

        return TacticalDecision(
            fighterId = profile.id,
            beforeRound = snapshot.nextRoundNumber,
            phase = TacticalDecisionPhase.BETWEEN_ROUNDS,
            previousPlan = previous,
            selectedPlan = candidate,
            changedAxes = axes,
            triggers = distinctTriggers,
            explanation = explanation(profile, snapshot.nextRoundNumber, previous, candidate, distinctTriggers),
        )
    }

    private fun fighterState(snapshot: TacticalStateSnapshot, fighterId: String): FighterTacticalState =
        if (snapshot.red.fighterId == fighterId) snapshot.red else snapshot.blue

    private fun opponentState(snapshot: TacticalStateSnapshot, fighterId: String): FighterTacticalState =
        if (snapshot.red.fighterId == fighterId) snapshot.blue else snapshot.red

    private fun vulnerableTarget(opponent: FighterTacticalState): TacticalDecisionTrigger? = when {
        opponent.headDamage >= TARGET_DAMAGE_MINIMUM && opponent.headDamage - opponent.bodyDamage >= TARGET_DAMAGE_GAP ->
            TacticalDecisionTrigger.OPPONENT_HEAD_VULNERABLE
        opponent.bodyDamage >= TARGET_DAMAGE_MINIMUM && opponent.bodyDamage - opponent.headDamage >= TARGET_DAMAGE_GAP ->
            TacticalDecisionTrigger.OPPONENT_BODY_VULNERABLE
        else -> null
    }

    private fun targetDamageGap(opponent: FighterTacticalState): Double = abs(opponent.headDamage - opponent.bodyDamage)

    private fun stepUp(value: TacticalPace): TacticalPace = TacticalPace.entries[(value.ordinal + 1).coerceAtMost(TacticalPace.entries.lastIndex)]
    private fun stepDown(value: TacticalPace): TacticalPace = TacticalPace.entries[(value.ordinal - 1).coerceAtLeast(0)]
    private fun stepCloser(value: TacticalDistance): TacticalDistance = TacticalDistance.entries[(value.ordinal + 1).coerceAtMost(TacticalDistance.entries.lastIndex)]
    private fun stepAway(value: TacticalDistance): TacticalDistance = TacticalDistance.entries[(value.ordinal - 1).coerceAtLeast(0)]
    private fun stepUp(value: TacticalRisk): TacticalRisk = TacticalRisk.entries[(value.ordinal + 1).coerceAtMost(TacticalRisk.entries.lastIndex)]
    private fun stepDown(value: TacticalRisk): TacticalRisk = TacticalRisk.entries[(value.ordinal - 1).coerceAtLeast(0)]

    private fun <T : Enum<T>> stepToward(current: T, desired: T): T {
        val entries = current.declaringJavaClass.enumConstants
        val nextOrdinal = when {
            desired.ordinal > current.ordinal -> current.ordinal + 1
            desired.ordinal < current.ordinal -> current.ordinal - 1
            else -> current.ordinal
        }
        return entries[nextOrdinal]
    }

    private fun <T : Enum<T>> boundAroundNatural(value: T, natural: T): T {
        val entries = value.declaringJavaClass.enumConstants
        val minimum = (natural.ordinal - 1).coerceAtLeast(0)
        val maximum = (natural.ordinal + 1).coerceAtMost(entries.lastIndex)
        return entries[value.ordinal.coerceIn(minimum, maximum)]
    }

    private data class StabilizedPlan(val plan: TacticalPlan, val suppressedReversal: Boolean)

    private fun stabilizeAgainstUnexplainedReversal(
        history: List<TacticalDecision>,
        previous: TacticalPlan,
        candidate: TacticalPlan,
        urgent: Boolean,
        targetChangeStronglySupported: Boolean,
    ): StabilizedPlan {
        if (history.size < 2 || urgent) return StabilizedPlan(candidate, false)
        val older = history[history.lastIndex - 1].selectedPlan
        var suppressed = false

        fun stabilizedOrdinal(olderValue: Int, previousValue: Int, candidateValue: Int): Int {
            val lastDirection = previousValue.compareTo(olderValue)
            val newDirection = candidateValue.compareTo(previousValue)
            return if (lastDirection != 0 && newDirection != 0 && lastDirection == -newDirection) {
                suppressed = true
                previousValue
            } else candidateValue
        }

        val paceOrdinal = stabilizedOrdinal(older.pace.ordinal, previous.pace.ordinal, candidate.pace.ordinal)
        val distanceOrdinal = stabilizedOrdinal(older.distance.ordinal, previous.distance.ordinal, candidate.distance.ordinal)
        val riskOrdinal = stabilizedOrdinal(older.risk.ordinal, previous.risk.ordinal, candidate.risk.ordinal)
        val target = if (older.target != previous.target && candidate.target == older.target && !targetChangeStronglySupported) {
            suppressed = true
            previous.target
        } else candidate.target

        return StabilizedPlan(
            TacticalPlan(
                anchorStyle = candidate.anchorStyle,
                pace = TacticalPace.entries[paceOrdinal],
                distance = TacticalDistance.entries[distanceOrdinal],
                target = target,
                risk = TacticalRisk.entries[riskOrdinal],
            ),
            suppressed,
        )
    }

    private fun explanation(
        profile: BoxerProfile,
        round: Int,
        previous: TacticalPlan,
        selected: TacticalPlan,
        triggers: List<TacticalDecisionTrigger>,
    ): String {
        val action = if (previous == selected) "maintient" else "ajuste"
        val causes = triggers.joinToString(", ") { triggerLabel(it) }
        return "Avant le round $round, ${profile.name} $action son plan : $causes. " +
            "Rythme ${selected.pace.name.lowercase()}, distance ${selected.distance.name.lowercase()}, " +
            "cible ${selected.target.name.lowercase()}, risque ${selected.risk.name.lowercase()}."
    }

    private fun triggerLabel(trigger: TacticalDecisionTrigger): String = when (trigger) {
        TacticalDecisionTrigger.NATURAL_STYLE -> "style naturel"
        TacticalDecisionTrigger.SCORE_DEFICIT -> "retard estimé"
        TacticalDecisionTrigger.FINAL_ROUND_DEFICIT -> "retard avant le dernier round"
        TacticalDecisionTrigger.LEAD_PROTECTION -> "avance à protéger"
        TacticalDecisionTrigger.HIGH_FATIGUE -> "fatigue élevée"
        TacticalDecisionTrigger.MODERATE_FATIGUE -> "fatigue à gérer"
        TacticalDecisionTrigger.PHYSICAL_DANGER -> "état physique dangereux"
        TacticalDecisionTrigger.OPPONENT_HEAD_VULNERABLE -> "tête adverse vulnérable"
        TacticalDecisionTrigger.OPPONENT_BODY_VULNERABLE -> "corps adverse vulnérable"
        TacticalDecisionTrigger.OPPONENT_GENERAL_VULNERABILITY -> "adversaire fragilisé"
        TacticalDecisionTrigger.MOMENTUM_LOSS -> "dynamique récente défavorable"
        TacticalDecisionTrigger.CONFLICT_MANAGEMENT -> "urgence offensive limitée par la sécurité"
        TacticalDecisionTrigger.ANTI_OSCILLATION -> "retour de plan non justifié bloqué"
        TacticalDecisionTrigger.PLAN_MAINTAINED -> "aucun signal assez fort pour changer"
        TacticalDecisionTrigger.PLAYER_SELECTION -> "choix validé par le joueur"
    }
}
