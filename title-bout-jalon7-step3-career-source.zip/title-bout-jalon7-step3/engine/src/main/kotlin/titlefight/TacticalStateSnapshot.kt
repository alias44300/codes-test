package titlefight

import kotlin.math.abs

/**
 * Projection strictement observationnelle d'un round terminé.
 *
 * Les cartes exactes des juges ne font volontairement pas partie de cette
 * structure. L'IA tactique future ne peut donc travailler qu'avec les faits
 * déjà produits par le moteur.
 */
data class TacticalRoundFacts(
    val roundNumber: Int,
    val redPerformance: Double,
    val bluePerformance: Double,
    val events: List<SequenceEvent>,
) {
    init {
        require(roundNumber in 1..3)
        require(redPerformance >= 0.0)
        require(bluePerformance >= 0.0)
        require(events.isNotEmpty())
        require(events.map { it.sequenceNumber } == (1..events.size).toList())
    }

    companion object {
        fun fromCompletedRound(round: RoundResult): TacticalRoundFacts {
            require(round.stoppage == null) {
                "Un round interrompu ne peut pas alimenter un instantané entre les rounds."
            }
            return TacticalRoundFacts(
                roundNumber = round.roundNumber,
                redPerformance = round.redRoundScore,
                bluePerformance = round.blueRoundScore,
                events = round.events,
            )
        }
    }
}

data class FighterTacticalState(
    val fighterId: String,
    val stamina: Double,
    val fatigue: Double,
    val headDamage: Double,
    val bodyDamage: Double,
    val stability: Double,
    val knockdownsScored: Int,
    val knockdownsSuffered: Int,
    val estimatedRoundsWon: Int,
    val estimatedRoundsLost: Int,
    val estimatedEvenRounds: Int,
    val recentMomentumScore: Double,
) {
    init {
        require(fighterId.isNotBlank())
        listOf(stamina, fatigue, headDamage, bodyDamage, stability).forEach {
            require(it in 0.0..100.0)
        }
        require(abs((stamina + fatigue) - 100.0) <= EPSILON)
        require(knockdownsScored >= 0)
        require(knockdownsSuffered >= 0)
        require(estimatedRoundsWon >= 0)
        require(estimatedRoundsLost >= 0)
        require(estimatedEvenRounds >= 0)
        require(recentMomentumScore >= 0.0)
    }

    val estimatedRoundBalance: Int
        get() = estimatedRoundsWon - estimatedRoundsLost

    companion object {
        private const val EPSILON = 1e-8
    }
}

/**
 * Photo tactique prise au début d'un round réellement simulé.
 *
 * Un combat de trois rounds à la distance possède donc trois instantanés :
 * avant le round 1, avant le round 2 et avant le round 3. Aucun instantané
 * n'est créé après un KO ou un TKO.
 */
data class TacticalStateSnapshot(
    val completedRounds: Int,
    val nextRoundNumber: Int,
    val remainingRoundsIncludingNext: Int,
    val remainingSequencesMaximum: Int,
    val completedSequenceCount: Int,
    val red: FighterTacticalState,
    val blue: FighterTacticalState,
    val estimatedLeaderId: String?,
    val estimatedRoundMargin: Int,
    val estimatedPerformanceMargin: Double,
    val recentMomentumLeaderId: String?,
    val recentMomentumMargin: Double,
) {
    init {
        require(completedRounds in 0..2)
        require(nextRoundNumber in 1..3)
        require(completedRounds == nextRoundNumber - 1)
        require(remainingRoundsIncludingNext == 4 - nextRoundNumber)
        require(remainingRoundsIncludingNext in 1..3)
        require(remainingSequencesMaximum >= remainingRoundsIncludingNext)
        require(completedSequenceCount >= 0)
        require(red.fighterId != blue.fighterId)
        require(red.estimatedRoundsWon + red.estimatedRoundsLost + red.estimatedEvenRounds == completedRounds)
        require(blue.estimatedRoundsWon + blue.estimatedRoundsLost + blue.estimatedEvenRounds == completedRounds)
        require(red.estimatedRoundsWon == blue.estimatedRoundsLost)
        require(red.estimatedRoundsLost == blue.estimatedRoundsWon)
        require(red.estimatedEvenRounds == blue.estimatedEvenRounds)
        require(estimatedRoundMargin == red.estimatedRoundBalance)
        require(estimatedRoundMargin == -blue.estimatedRoundBalance)
        require(estimatedLeaderId == leaderFromSignedMargin(estimatedRoundMargin.toDouble(), red.fighterId, blue.fighterId, 0.0))
        require(recentMomentumLeaderId == leaderFromSignedMargin(
            recentMomentumMargin,
            red.fighterId,
            blue.fighterId,
            TacticalStateSnapshotExtractor.MOMENTUM_TIE_MARGIN,
        ))
    }

    companion object {
        internal fun leaderFromSignedMargin(
            signedMargin: Double,
            redId: String,
            blueId: String,
            tieMargin: Double,
        ): String? = when {
            signedMargin > tieMargin -> redId
            signedMargin < -tieMargin -> blueId
            else -> null
        }
    }
}

object TacticalStateSnapshotExtractor {
    const val ROUND_ESTIMATE_TIE_MARGIN: Double = 1.0
    const val MOMENTUM_TIE_MARGIN: Double = 1.0
    const val RECENT_SEQUENCE_WINDOW: Int = 4

    fun extract(
        red: BoxerProfile,
        blue: BoxerProfile,
        redState: FighterState,
        blueState: FighterState,
        completedRounds: List<TacticalRoundFacts>,
        nextRoundNumber: Int,
        sequencesPerRound: Int,
    ): TacticalStateSnapshot {
        require(red.id != blue.id)
        require(nextRoundNumber in 1..3)
        require(sequencesPerRound >= 1)
        require(completedRounds.size == nextRoundNumber - 1)
        require(completedRounds.map { it.roundNumber } == (1..completedRounds.size).toList())

        val roundOutcomes = completedRounds.map { roundOutcome(it) }
        val redWins = roundOutcomes.count { it > 0 }
        val blueWins = roundOutcomes.count { it < 0 }
        val evenRounds = roundOutcomes.count { it == 0 }
        val redKnockdownsScored = completedRounds.sumOf { facts ->
            facts.events.count { it.attackerId == red.id && it.knockdown != null }
        }
        val blueKnockdownsScored = completedRounds.sumOf { facts ->
            facts.events.count { it.attackerId == blue.id && it.knockdown != null }
        }
        require(redKnockdownsScored == blueState.knockdownsSuffered)
        require(blueKnockdownsScored == redState.knockdownsSuffered)

        val recentEvents = completedRounds.lastOrNull()?.events?.takeLast(RECENT_SEQUENCE_WINDOW).orEmpty()
        val redMomentum = momentumScore(red.id, recentEvents)
        val blueMomentum = momentumScore(blue.id, recentEvents)
        val estimatedRoundMargin = redWins - blueWins
        val estimatedPerformanceMargin = completedRounds.sumOf { it.redPerformance - it.bluePerformance }
        val recentMomentumMargin = redMomentum - blueMomentum
        val remainingRounds = 4 - nextRoundNumber

        return TacticalStateSnapshot(
            completedRounds = completedRounds.size,
            nextRoundNumber = nextRoundNumber,
            remainingRoundsIncludingNext = remainingRounds,
            remainingSequencesMaximum = remainingRounds * sequencesPerRound,
            completedSequenceCount = completedRounds.sumOf { it.events.size },
            red = fighterState(
                profile = red,
                state = redState,
                knockdownsScored = redKnockdownsScored,
                estimatedRoundsWon = redWins,
                estimatedRoundsLost = blueWins,
                estimatedEvenRounds = evenRounds,
                recentMomentumScore = redMomentum,
            ),
            blue = fighterState(
                profile = blue,
                state = blueState,
                knockdownsScored = blueKnockdownsScored,
                estimatedRoundsWon = blueWins,
                estimatedRoundsLost = redWins,
                estimatedEvenRounds = evenRounds,
                recentMomentumScore = blueMomentum,
            ),
            estimatedLeaderId = TacticalStateSnapshot.leaderFromSignedMargin(
                estimatedRoundMargin.toDouble(),
                red.id,
                blue.id,
                0.0,
            ),
            estimatedRoundMargin = estimatedRoundMargin,
            estimatedPerformanceMargin = estimatedPerformanceMargin,
            recentMomentumLeaderId = TacticalStateSnapshot.leaderFromSignedMargin(
                recentMomentumMargin,
                red.id,
                blue.id,
                MOMENTUM_TIE_MARGIN,
            ),
            recentMomentumMargin = recentMomentumMargin,
        )
    }

    private fun roundOutcome(facts: TacticalRoundFacts): Int {
        val margin = facts.redPerformance - facts.bluePerformance
        return when {
            margin > ROUND_ESTIMATE_TIE_MARGIN -> 1
            margin < -ROUND_ESTIMATE_TIE_MARGIN -> -1
            else -> 0
        }
    }

    private fun fighterState(
        profile: BoxerProfile,
        state: FighterState,
        knockdownsScored: Int,
        estimatedRoundsWon: Int,
        estimatedRoundsLost: Int,
        estimatedEvenRounds: Int,
        recentMomentumScore: Double,
    ): FighterTacticalState = FighterTacticalState(
        fighterId = profile.id,
        stamina = state.stamina,
        fatigue = 100.0 - state.stamina,
        headDamage = state.headDamage,
        bodyDamage = state.bodyDamage,
        stability = state.stability,
        knockdownsScored = knockdownsScored,
        knockdownsSuffered = state.knockdownsSuffered,
        estimatedRoundsWon = estimatedRoundsWon,
        estimatedRoundsLost = estimatedRoundsLost,
        estimatedEvenRounds = estimatedEvenRounds,
        recentMomentumScore = recentMomentumScore,
    )

    private fun momentumScore(fighterId: String, events: List<SequenceEvent>): Double =
        events.filter { it.attackerId == fighterId }.sumOf { event ->
            0.25 +
                (if (event.landed) 1.0 + event.impact else 0.0) +
                (if (event.clean) 1.5 else 0.0) +
                (if (event.knockdown != null) 8.0 else 0.0)
        }
}
