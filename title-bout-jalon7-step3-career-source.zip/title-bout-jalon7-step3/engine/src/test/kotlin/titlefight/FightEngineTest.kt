package titlefight

object FightEngineTest {
    private val finalJalon2Audit: Jalon2FinalAuditResult by lazy { Jalon2FinalAuditor.run() }
    private val step3JudgeAudit: ThreeJudgeStep3AuditResult by lazy { ThreeJudgeStep3Auditor.run() }
    private val step4DecisionAudit: OfficialDecisionStep4AuditResult by lazy { OfficialDecisionStep4Auditor.run() }
    private val finalJalon3Audit: Jalon3FinalAuditResult by lazy { Jalon3FinalAuditor.run() }
    private val tacticalIntegrationStep4Audit: TacticalIntegrationStep4AuditResult by lazy {
        TacticalIntegrationStep4Auditor.run()
    }
    private val finalJalon4Audit: Jalon4FinalAuditResult by lazy {
        Jalon4FinalAuditor.run()
    }
    private val jalon5Step2Audit: Jalon5Step2AuditResult by lazy {
        Jalon5Step2Auditor.run()
    }
    private val jalon5Step3Audit: Jalon5Step3AuditResult by lazy {
        Jalon5Step3Auditor.run()
    }
    private val jalon5Step4Audit: Jalon5Step4AuditResult by lazy {
        Jalon5Step4Auditor.evaluate(jalon5Step3Audit, jalon5Step2Audit)
    }

    @JvmStatic
    fun main(args: Array<String>) {
        deterministicRoundIsReproducible()
        differentSeedsChangeTheRound()
        statesRemainWithinBounds()
        tacticalProfilesRemainDistinct()
        threeRoundFightIsReproducible()
        threeRoundFightCarriesStateAndProducesCompleteReport()
        batchOfOneHundredFightsCompletesAndIsReproducible()
        batchShowsDistinctAndBalancedTacticalPatterns()
        thresholdsRemainAcceptableAcrossTenWindows()
        knockdownDetectorRejectsMissesAndWeakImpacts()
        integratedKnockdownIsReproducibleAndWellAttached()
        fightContinuesAfterRecoveredKnockdown()
        standardKnockdownAuditRespectsStepOneGuards()
        refereeCountsAreDeterministicAndBounded()
        strongerRecoveryProducesBetterCounts()
        vulnerabilityIsAppliedAndTemporary()
        tenCountEndsRoundByKo()
        koStopsThreeRoundFightImmediately()
        koResultIsReproducibleAndReported()
        standardStepTwoAuditIsConsistent()
        standardStepThreeAuditIsConsistent()
        tkoDetectorRequiresAllSafetyThresholds()
        integratedTkoStopsFightImmediately()
        tkoResultIsReproducibleAndReported()
        koKeepsPriorityOverTkoOnTenCount()
        standardStepFourAuditIsConsistent()
        finalJalonTwoAuditIsReproducibleAndComplete()
        finalJalonTwoAuditRespectsGuardrails()
        finalJalonTwoRatesAreAcceptable()
        finalJalonTwoAuditHasNoPersistentCornerBias()
        judgingEvidenceIsReproducibleAndAttached()
        judgingEvidenceMatchesEveryRawEvent()
        judgingEvidenceCapturesDefenseRangeBodyWorkAndKnockdowns()
        stoppedRoundsContainNoPhantomEvidence()
        judgingEvidenceAuditIsReproducibleAndExact()
        neutralJudgeIsDeterministicAndAttachedOnlyToCompletedRounds()
        neutralJudgeUsesValidTenPointScores()
        knockdownPriorityProducesTenEight()
        twoKnockdownsProduceTenSeven()
        neutralJudgeCanProduceRareTenTen()
        threeJudgePanelIsDeterministicAndAttached()
        judgeProfilesHaveExplicitModestWeights()
        threeJudgesRespectKnockdownPriority()
        judgeProfilesDisagreeSometimesButRemainClose()
        stoppedRoundsHaveNoPanelScores()
        officialDecisionIsDeterministicAndAttachedAtDistance()
        scorecardsTotalExactlyThreeCompletedRounds()
        allOfficialDecisionTypesAreClassifiedCorrectly()
        koAndTkoKeepPriorityOverOfficialDecision()
        officialDecisionAuditIsReproducibleAndValid()
        finalJalonThreeAuditIsCompleteAndReproducible()
        finalJalonThreeAuditHasNoInvalidCardsOrDecisions()
        finalJalonThreeAuditHasNoPersistentCornerBias()
        finalJalonThreeJudgesHaveComparableSeverity()
        finalJalonThreeJudgesDoNotSystematicallyFavorAStyle()
        tacticalSnapshotsAreDeterministicAndAttachedAtRoundStarts()
        preFightSnapshotContainsNoPastInformation()
        tacticalSnapshotsIgnoreFutureRoundsAndFutureTactics()
        tacticalSnapshotCapturesPhysicalStateKnockdownsAndMomentum()
        noTacticalSnapshotExistsAfterStoppage()
        tacticalSnapshotAuditIsExactAndLegacyBehaviorIsUnchanged()
        tacticalPlanCatalogCoversEveryStyle()
        naturalPlansPreserveStyleIdentity()
        tacticalPlanModifiersAreBoundedForEveryCombination()
        paceAndRiskModifiersRemainMonotonic()
        targetBiasMatchesPriority()
        tacticalPlanConstructionIsDeterministicAndPure()
        tacticalPlanStepTwoAuditIsExactAndLegacyBehaviorUnchanged()
        tacticalDecisionsAreDeterministicAndAttached()
        preFightDecisionsUseNaturalPlans()
        trailingFighterBecomesMoreEnterprising()
        highlyFatiguedFighterReducesPace()
        physicallyEndangeredFighterProtectsItself()
        unexplainedTargetReversalIsBlocked()
        tacticalDecisionAuditIsExactAndLegacyBehaviorUnchanged()
        adaptiveTacticalApplicationIsDeterministicAndAttached()
        disabledTacticalModePreservesLegacyBehavior()
        tacticalApplicationMathIsBoundedAndMonotonic()
        targetPlanBiasesPunchSelection()
        distancePlanBiasesResolvedRange()
        fightReportShowsActiveTactics()
        tacticalIntegrationAuditIsReproducibleAndValid()
        finalJalonFourAuditIsCompleteAndReproducible()
        finalJalonFourAuditHasNoStructuralErrors()
        finalJalonFourAuditHasNoPersistentCornerBias()
        finalJalonFourAdaptiveResponsesRemainCoherent()
        finalJalonFourHasNoUniversalDominantPlan()
        finalJalonFourDiffersMeaningfullyFromFixedNaturalPlans()
        boxerCatalogContainsExactlyTenUniqueProfiles()
        boxerCatalogCoversEveryStyleAndStance()
        everyProfileHasValidPhysicalDimensions()
        primaryAndSecondaryStatsRemainCompleteAndBounded()
        preferredRangesMatchStyleAnchors()
        catalogLookupIsStableAndRejectsUnknownIds()
        legacyTwoFighterBehaviorRemainsUnchangedAfterRosterExpansion()
        rosterIdentityAuditIsCompleteAndReproducible()
        naturalPlansAreAppliedWithoutDriftDuringIdentityAudit()
        allTenProfilesHaveDistinctStatisticalSignatures()
        paceTargetAndCoreTraitsRemainVisible()
        mediumRangeIdentityIsRestoredBeforeMatchupMatrix()
        identityAuditPreservesHistoricalTwoFighterBehavior()
        matchupMatrixCoversAllFortyFiveUniqueDuels()
        matchupMatrixAlternatesCornersExactly()
        matchupMatrixIsDeterministicAcrossPairedReplays()
        matchupMatrixContainsOnlyValidOfficialOutcomes()
        matchupMatrixKeepsTacticalPlansAttachedAndStopsFinal()
        matchupMatrixProducesCompleteBoxerAndStyleSummaries()
        matchupMatrixPreservesHistoricalTwoFighterBehavior()
        calibratedRosterKeepsTechnicalIntegrity()
        calibrationBringsEveryBoxerIntoCompetitiveBand()
        calibrationBringsEveryStyleIntoCompetitiveBand()
        calibrationReducesRosterAndStyleDispersion()
        calibratedRosterPreservesStatisticalIdentity()
        calibratedRosterHasNoPersistentCornerBias()
        calibrationPreservesHistoricalProfilesAndBehavior()
        println("115 tests réussis")
    }

    private fun deterministicRoundIsReproducible() {
        val engine = FightEngine()
        val first = engine.simulateRound(
            1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
            FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS, 20260720L,
        )
        val second = engine.simulateRound(
            1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
            FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS, 20260720L,
        )
        check(first == second) { "Le même scénario doit produire exactement le même round." }
    }

    private fun differentSeedsChangeTheRound() {
        val engine = FightEngine()
        val first = engine.simulateRound(1, TestProfiles.eliasVega, TestProfiles.brunoKessler, FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS, 1L)
        val second = engine.simulateRound(1, TestProfiles.eliasVega, TestProfiles.brunoKessler, FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS, 2L)
        check(first.events != second.events) { "Deux graines différentes ne doivent pas systématiquement produire la même séquence." }
    }

    private fun statesRemainWithinBounds() {
        val engine = FightEngine(sequencesPerRound = 40)
        val result = engine.simulateRound(1, TestProfiles.eliasVega, TestProfiles.brunoKessler, FighterState(), FighterState(), Tactic.SEEK_KO, Tactic.SEEK_KO, 99L)
        listOf(result.redState, result.blueState).forEach { state ->
            check(state.stamina in 0.0..100.0)
            check(state.headDamage in 0.0..100.0)
            check(state.bodyDamage in 0.0..100.0)
            check(state.stability in 0.0..100.0)
        }
    }

    private fun tacticalProfilesRemainDistinct() {
        val engine = FightEngine()
        var vegaOutsideActions = 0
        var kesslerInsideActions = 0
        repeat(200) { index ->
            val result = engine.simulateRound(
                1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
                FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS, index.toLong() + 1000,
            )
            vegaOutsideActions += result.events.count { it.attackerId == TestProfiles.eliasVega.id && it.range == FightRange.OUTSIDE }
            kesslerInsideActions += result.events.count { it.attackerId == TestProfiles.brunoKessler.id && it.range == FightRange.INSIDE }
        }
        check(vegaOutsideActions > 0)
        check(kesslerInsideActions > 0)
    }

    private fun threeRoundFightIsReproducible() {
        val engine = FightEngine()
        val first = createThreeRoundFight(engine, 20260720L)
        val second = createThreeRoundFight(engine, 20260720L)
        check(first == second) { "Le même combat complet doit être strictement reproductible." }
        check(first.rounds.map { it.seed }.distinct().size == 3) { "Chaque round doit recevoir une graine dérivée distincte." }
    }

    private fun threeRoundFightCarriesStateAndProducesCompleteReport() {
        val fight = createThreeRoundFight(FightEngine(), 20260721L)
        check(fight.rounds.size == 3)
        check(fight.rounds.map { it.roundNumber } == listOf(1, 2, 3))
        check(fight.rounds.all { it.events.size == 12 })

        fight.rounds.zipWithNext().forEach { (previous, next) ->
            check(next.redState.thrown >= previous.redState.thrown)
            check(next.blueState.thrown >= previous.blueState.thrown)
            check(next.redState.headDamage >= previous.redState.headDamage)
            check(next.blueState.headDamage >= previous.blueState.headDamage)
        }
        check(fight.finalRedState == fight.rounds.last().redState)
        check(fight.finalBlueState == fight.rounds.last().blueState)
        check(fight.redPerformanceTotal == fight.rounds.sumOf { it.redRoundScore })
        check(fight.bluePerformanceTotal == fight.rounds.sumOf { it.blueRoundScore })

        val report = FightReportFormatter.format(fight, TestProfiles.eliasVega, TestProfiles.brunoKessler)
        check("ROUND 1" in report)
        check("ROUND 2" in report)
        check("ROUND 3" in report)
        check("BILAN MOTEUR APRÈS 3 ROUNDS" in report)
        check("CARTES OFFICIELLES" in report)
        check("RÉSULTAT OFFICIEL DU MOTEUR" in report)
        check(fight.officialDecision != null)
        check(fight.officialDecision.type.frenchLabel in report)
    }

    private fun batchOfOneHundredFightsCompletesAndIsReproducible() {
        val first = BatchValidator.run(seedStart = 2026072000L)
        val second = BatchValidator.run(seedStart = 2026072000L)
        check(first == second) { "Le lot de 100 combats doit être strictement reproductible." }
        check(first.fightCount == 100)
        check(first.totalRounds == 300)
        check(first.totalSequences == 3600)
        check(first.redCornerAppearancesByFighter[TestProfiles.eliasVega.id] == 50)
        check(first.redCornerAppearancesByFighter[TestProfiles.brunoKessler.id] == 50)
        check(first.records.size == 100)
        check(BatchCsvFormatter.format(first).trimEnd().lineSequence().count() == 101)
        check(first.vega.performanceLeads + first.kessler.performanceLeads + first.ties == 100)
    }

    private fun batchShowsDistinctAndBalancedTacticalPatterns() {
        val result = BatchValidator.run(seedStart = 2026072000L)
        check(result.vega.outsideActionShare > 0.75) { "Vega doit imposer majoritairement la longue distance lors de ses initiatives." }
        check(result.kessler.insideActionShare > 0.25) { "Kessler doit produire une part significative d’actions à courte distance." }
        check(result.kessler.insideActionShare > result.vega.insideActionShare * 5.0)
        check(result.vega.averageBodyDamageReceived > result.kessler.averageBodyDamageReceived + 8.0) { "Le travail au corps de Kessler doit être visible dans l’échantillon." }
        check(result.kessler.averageFinalStamina < result.vega.averageFinalStamina - 8.0) { "La pression de Kessler doit coûter davantage d’énergie." }
        check(result.vega.performanceLeads in 35..65)
        check(result.kessler.performanceLeads in 35..65)
        check(kotlin.math.abs(result.vega.averagePerformance - result.kessler.averagePerformance) <= 5.0)
    }

    private fun thresholdsRemainAcceptableAcrossTenWindows() {
        val audit = ThresholdAuditor.run()
        ThresholdAuditor.assertAcceptable(audit)
        check(audit.totalFights == 1000)
        check(audit.totalTies == 0)
    }


    private fun knockdownDetectorRejectsMissesAndWeakImpacts() {
        val defender = TestProfiles.eliasVega
        val before = FighterState(stamina = 15.0, headDamage = 80.0, bodyDamage = 70.0, stability = 10.0)
        val after = before.copy(headDamage = 82.0, stability = 8.0)

        val miss = KnockdownDetector.evaluate(
            defender = defender,
            defenderBefore = before,
            defenderAfter = after,
            punch = Punch.HOOK,
            landed = false,
            clean = false,
            impact = 20.0,
        )
        check(!miss.eligible)
        check(miss.probability == 0.0)

        val weakHit = KnockdownDetector.evaluate(
            defender = defender,
            defenderBefore = before,
            defenderAfter = after,
            punch = Punch.JAB,
            landed = true,
            clean = true,
            impact = 3.0,
        )
        check(!weakHit.eligible)
        check(weakHit.probability == 0.0)
    }

    private fun integratedKnockdownIsReproducibleAndWellAttached() {
        val (seed, first) = findVulnerableRoundWithKnockdown()
        val second = vulnerableRound(seed)
        check(first == second) { "La même graine doit produire exactement les mêmes chutes." }

        val knockdownEvents = first.events.filter { it.knockdown != null }
        check(knockdownEvents.isNotEmpty())
        knockdownEvents.forEach { event ->
            val knockdown = requireNotNull(event.knockdown)
            check(event.landed)
            check(event.impact > 0.0)
            check(knockdown.attackerId == event.attackerId)
            check(knockdown.defenderId == event.defenderId)
            check(knockdown.punch == event.punch)
            check(knockdown.sequenceNumber == event.sequenceNumber)
            check(knockdown.roundNumber == first.roundNumber)
            check(knockdown.roll < knockdown.probability)
        }
    }

    private fun fightContinuesAfterRecoveredKnockdown() {
        val (_, round) = findRecoveredRound(requireBeforeLastSequence = true)
        val firstKnockdownIndex = round.events.indexOfFirst { it.knockdown?.refereeCount?.recovered == true }
        check(firstKnockdownIndex >= 0)
        check(firstKnockdownIndex < round.events.lastIndex) { "Le scénario de test exige un relèvement avant la dernière séquence." }
        check(round.events.size == 12) { "Le round doit continuer après un relèvement avant 10." }
        check(round.stoppage == null)

        val redKnockdowns = round.events.count { it.knockdown?.defenderId == TestProfiles.brunoKessler.id }
        val blueKnockdowns = round.events.count { it.knockdown?.defenderId == TestProfiles.eliasVega.id }
        check(round.redState.knockdownsSuffered == redKnockdowns)
        check(round.blueState.knockdownsSuffered == blueKnockdowns)
    }

    private fun standardKnockdownAuditRespectsStepOneGuards() {
        val first = KnockdownStep1Auditor.run()
        val second = KnockdownStep1Auditor.run()
        check(first == second) { "L’audit de chutes doit être reproductible." }
        check(first.fightCount == 1000)
        check(first.totalSequences == 36000)
        check(first.knockdowns > 0) { "Le détecteur doit produire au moins une chute sur l’échantillon standard." }
        check(first.knockdownsOnMisses == 0)
        check(first.knockdownsBelowMinimumImpact == 0)
    }


    private fun refereeCountsAreDeterministicAndBounded() {
        val (seed, first) = findRecoveredRound()
        val second = vulnerableRound(seed)
        check(first == second)
        val counts = first.events.mapNotNull { it.knockdown?.refereeCount }
        check(counts.isNotEmpty())
        counts.forEach { count ->
            check(count.countReached in 1..10)
            check(count.recovered == (count.countReached < 10))
            check(count.roll in 0.0..1.0)
        }
    }

    private fun strongerRecoveryProducesBetterCounts() {
        val resilient = TestProfiles.brunoKessler.copy(id = "resilient-test")
        val fragile = TestProfiles.eliasVega.copy(
            id = "fragile-test",
            recovery = 45,
            mental = 48,
            chin = 44,
            bodyResistance = 46,
        )
        val before = FighterState(stamina = 38.0, headDamage = 62.0, bodyDamage = 35.0, stability = 34.0)
        val after = before.copy(headDamage = 74.0, stability = 20.0, knockdownsSuffered = 1)

        fun counts(profile: BoxerProfile): List<Int> {
            val knockdown = KnockdownEvent(
                attackerId = "attacker", defenderId = profile.id, roundNumber = 1, sequenceNumber = 1,
                punch = Punch.HOOK, impact = 13.5, score = 34.0, probability = 0.8, roll = 0.2,
            )
            return (0 until 1000).map { index ->
                RefereeCountResolver.evaluate(
                    defender = profile,
                    defenderBefore = before,
                    defenderAfterKnockdown = after,
                    knockdown = knockdown,
                    roll = (index + 0.5) / 1000.0,
                ).countReached
            }
        }

        val resilientCounts = counts(resilient)
        val fragileCounts = counts(fragile)
        check(resilientCounts.average() + 1.0 < fragileCounts.average())
        check(resilientCounts.count { it < 10 } > fragileCounts.count { it < 10 })
    }

    private fun vulnerabilityIsAppliedAndTemporary() {
        val (_, round) = findRecoveredRound(requireBeforeLastSequence = true, requireSingleKnockdown = true)
        val index = round.events.indexOfFirst { it.knockdown?.refereeCount?.recovered == true }
        val event = round.events[index]
        val count = requireNotNull(event.knockdown?.refereeCount)
        check(count.vulnerabilitySequences >= 1)

        val victimState = when (event.defenderId) {
            TestProfiles.eliasVega.id -> round.blueState
            TestProfiles.brunoKessler.id -> round.redState
            else -> error("Victime inconnue")
        }
        check(victimState.vulnerabilitySequencesRemaining in 0..count.vulnerabilitySequences)
        if (index < round.events.lastIndex) {
            check(victimState.vulnerabilitySequencesRemaining < count.vulnerabilitySequences)
        }
    }

    private fun tenCountEndsRoundByKo() {
        val (_, round) = findRoundWithKo()
        val stoppage = requireNotNull(round.stoppage)
        val lastEvent = round.events.last()
        val count = requireNotNull(lastEvent.knockdown?.refereeCount)

        check(count.countReached == 10)
        check(!count.recovered)
        check(stoppage.method == FightMethod.KO)
        check(stoppage.winnerId == lastEvent.attackerId)
        check(stoppage.loserId == lastEvent.defenderId)
        check(stoppage.roundNumber == round.roundNumber)
        check(stoppage.sequenceNumber == lastEvent.sequenceNumber)
        check(round.events.size == stoppage.sequenceNumber)
        check(round.blueState.pendingTenCount || round.redState.pendingTenCount)
    }

    private fun koStopsThreeRoundFightImmediately() {
        val (_, fight) = findFightWithKo()
        val stoppage = requireNotNull(fight.stoppage)
        check(fight.rounds.size == stoppage.roundNumber)
        check(fight.rounds.last().stoppage == stoppage)
        check(fight.rounds.dropLast(1).none { it.stoppage != null })
        check(fight.rounds.last().events.size == stoppage.sequenceNumber)
        check(fight.rounds.none { round -> round.events.any { it.sequenceNumber > (round.stoppage?.sequenceNumber ?: Int.MAX_VALUE) } })
    }

    private fun koResultIsReproducibleAndReported() {
        val (seed, first) = findFightWithKo()
        val second = extremeThreeRoundFight(seed)
        check(first == second)
        val report = FightReportFormatter.format(first, TestProfiles.brunoKessler, TestProfiles.eliasVega)
        check("RÉSULTAT OFFICIEL DU MOTEUR" in report)
        check("par KO" in report)
        check("Aucun round ni aucune séquence n’est calculé après l’arrêt" in report)
        check("Le round interrompu n’est pas jugé" in report)
        check("aucune décision aux points n’est produite" in report)
    }


    private fun tkoDetectorRequiresAllSafetyThresholds() {
        val threateningEvent = SequenceEvent(
            sequenceNumber = 3,
            attackerId = TestProfiles.brunoKessler.id,
            defenderId = TestProfiles.eliasVega.id,
            range = FightRange.INSIDE,
            punch = Punch.HOOK,
            landed = true,
            clean = true,
            impact = 8.5,
            text = "impact de test",
        )
        val eligibleState = FighterState(
            stamina = 20.0,
            headDamage = 76.0,
            bodyDamage = 50.0,
            stability = 20.0,
            defensiveFailureStreak = 3,
        )
        val eligible = TkoSafetyDetector.evaluate(eligibleState, threateningEvent)
        check(eligible.eligible)
        check(eligible.latestThreat)
        check(eligible.sustainedDefensiveFailure)
        check(eligible.severeDamage)
        check(eligible.criticalStability)
        check(eligible.exhaustion)

        check(!TkoSafetyDetector.evaluate(eligibleState.copy(defensiveFailureStreak = TkoSafetyDetector.MIN_FAILURE_STREAK - 1), threateningEvent).eligible)
        check(!TkoSafetyDetector.evaluate(eligibleState.copy(stability = TkoSafetyDetector.MAX_STABILITY + 1.0), threateningEvent).eligible)
        check(!TkoSafetyDetector.evaluate(eligibleState.copy(stamina = TkoSafetyDetector.MAX_STAMINA + 1.0), threateningEvent).eligible)
        check(!TkoSafetyDetector.evaluate(eligibleState.copy(
            headDamage = TkoSafetyDetector.MIN_HEAD_DAMAGE - 1.0,
            bodyDamage = TkoSafetyDetector.MIN_BODY_DAMAGE - 1.0,
        ), threateningEvent).eligible)

        val knockdown = KnockdownEvent(
            attackerId = threateningEvent.attackerId,
            defenderId = threateningEvent.defenderId,
            roundNumber = 1,
            sequenceNumber = threateningEvent.sequenceNumber,
            punch = threateningEvent.punch,
            impact = threateningEvent.impact,
            score = 20.0,
            probability = 0.8,
            roll = 0.2,
        )
        check(!TkoSafetyDetector.evaluate(eligibleState, threateningEvent.copy(knockdown = knockdown)).eligible) {
            "Le TKO ne doit pas être prononcé sur la même séquence qu’une chute : le compte garde la priorité."
        }
    }

    private fun integratedTkoStopsFightImmediately() {
        val (_, fight) = findFightWithTko()
        val stoppage = requireNotNull(fight.stoppage)
        val round = fight.rounds.last()
        val lastEvent = round.events.last()
        val loserState = if (stoppage.loserId == fight.redId) round.redState else round.blueState
        val safety = TkoSafetyDetector.evaluate(loserState, lastEvent)

        check(stoppage.method == FightMethod.TKO)
        check(stoppage.winnerId == lastEvent.attackerId)
        check(stoppage.loserId == lastEvent.defenderId)
        check(stoppage.roundNumber == round.roundNumber)
        check(stoppage.sequenceNumber == lastEvent.sequenceNumber)
        check(stoppage.reason == safety.reason)
        check(safety.eligible)
        check(lastEvent.knockdown == null)
        check(round.events.size == stoppage.sequenceNumber)
        check(fight.rounds.size == stoppage.roundNumber)
        check("TKO" in lastEvent.text)
    }

    private fun tkoResultIsReproducibleAndReported() {
        val (seed, first) = findFightWithTko()
        val second = TkoStep4Scenario.fight(seed, attackerInRed = true)
        check(first == second)
        val report = FightReportFormatter.format(first, TestProfiles.brunoKessler, TkoStep4Scenario.protectedProfile)
        check("RÉSULTAT OFFICIEL DU MOTEUR" in report)
        check("par TKO" in report)
        check("absence de défense intelligente" in report)
        check("Aucun round ni aucune séquence n’est calculé après l’arrêt" in report)
        check("Le round interrompu n’est pas jugé" in report)
        check("aucune décision aux points n’est produite" in report)
    }

    private fun koKeepsPriorityOverTkoOnTenCount() {
        for (seed in 1L..20000L) {
            val fight = FightEngine().simulateThreeRoundFight(
                red = TestProfiles.brunoKessler,
                blue = TestProfiles.eliasVega,
                redTactics = List(3) { Tactic.SEEK_KO },
                blueTactics = List(3) { Tactic.RECOVER },
                seed = seed,
                redStart = FighterState(),
                blueStart = FighterState(stamina = 3.0, headDamage = 94.0, bodyDamage = 80.0, stability = 3.0),
            )
            val stoppage = fight.stoppage ?: continue
            if (stoppage.method == FightMethod.KO) {
                val event = fight.rounds.last().events.last()
                check(event.knockdown?.refereeCount?.countReached == 10)
                return
            }
        }
        error("Aucun KO avec TKO activé n’a été trouvé pour vérifier la priorité du compte à 10.")
    }

    private fun standardStepFourAuditIsConsistent() {
        val first = TkoStep4Auditor.run()
        val second = TkoStep4Auditor.run()
        check(first == second)
        check(first.fightCount == 1000)
        check(first.tkoCount > 0)
        check(first.invalidTkoStoppages == 0)
        check(first.fightsContinuingAfterStoppage == 0)
        check(first.eventsAfterStoppage == 0)
        check(first.redCornerTkos + first.blueCornerTkos == first.tkoCount)
        check(first.minimumFailureStreakAtTko >= TkoSafetyDetector.MIN_FAILURE_STREAK)
    }

    private fun finalJalonTwoAuditIsReproducibleAndComplete() {
        val second = Jalon2FinalAuditor.run()
        check(finalJalon2Audit == second) { "L'audit final du jalon 2 doit être strictement reproductible." }
        check(finalJalon2Audit.totalFights == 10_000)
        check(finalJalon2Audit.windows.size == 10)
        check(finalJalon2Audit.windows.all { it.fightCount == 1000 })
        check(Jalon2FinalAuditFormatter.csv(finalJalon2Audit).trimEnd().lineSequence().count() == 11)
    }

    private fun finalJalonTwoAuditRespectsGuardrails() {
        check(finalJalon2Audit.knockdownsOnMisses == 0)
        check(finalJalon2Audit.knockdownsWithoutCount == 0)
        check(finalJalon2Audit.countsOutsideBounds == 0)
        check(finalJalon2Audit.invalidKoStoppages == 0)
        check(finalJalon2Audit.invalidTkoStoppages == 0)
        check(finalJalon2Audit.fightsContinuingAfterStoppage == 0)
        check(finalJalon2Audit.eventsAfterStoppage == 0)
        check(finalJalon2Audit.koCount == finalJalon2Audit.tenCounts)
    }

    private fun finalJalonTwoRatesAreAcceptable() {
        Jalon2FinalAuditor.assertAcceptable(finalJalon2Audit)
        check(finalJalon2Audit.koCount > 0)
        check(finalJalon2Audit.tkoCount > 0)
        check(finalJalon2Audit.weakImpactShare <= 0.01)
    }

    private fun finalJalonTwoAuditHasNoPersistentCornerBias() {
        check(kotlin.math.abs(finalJalon2Audit.redStoppageShare - 0.5) <= 0.15)
        check(finalJalon2Audit.vegaDistanceLeadShare in 0.35..0.65)
        check(finalJalon2Audit.redCornerStoppages + finalJalon2Audit.blueCornerStoppages == finalJalon2Audit.stoppageCount)
    }

    private fun standardStepTwoAuditIsConsistent() {
        val first = KnockdownStep2Auditor.run()
        val second = KnockdownStep2Auditor.run()
        check(first == second)
        check(first.fightCount == 1000)
        check(first.totalCounts > 0)
        check(first.countsOutsideBounds == 0)
        check(first.countsWithoutKnockdown == 0)
        check(first.minimumCount in 1..10)
        check(first.maximumCount in 1..10)
        check(first.vulnerabilityApplied == first.recoveredCounts)
    }


    private fun standardStepThreeAuditIsConsistent() {
        val first = KnockoutStep3Auditor.run()
        val second = KnockoutStep3Auditor.run()
        check(first == second)
        check(first.fightCount == 1000)
        check(first.koCount > 0)
        check(first.fightsContinuingAfterKo == 0)
        check(first.eventsAfterKo == 0)
        check(first.invalidStoppages == 0)
        check(first.redCornerKOs + first.blueCornerKOs == first.koCount)
    }



    private fun judgingEvidenceIsReproducibleAndAttached() {
        val engine = FightEngine(stopOnTenCount = false, stopOnTko = false)
        val first = engine.simulateRound(
            1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
            FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS, 2026072101L,
        )
        val second = engine.simulateRound(
            1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
            FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS, 2026072101L,
        )
        check(first.judgingEvidence == second.judgingEvidence)
        check(first.judgingEvidence.roundNumber == first.roundNumber)
        check(first.judgingEvidence.sequenceCount == first.events.size)
        check(first.judgingEvidence.red.fighterId == TestProfiles.eliasVega.id)
        check(first.judgingEvidence.blue.fighterId == TestProfiles.brunoKessler.id)
    }

    private fun judgingEvidenceMatchesEveryRawEvent() {
        val round = FightEngine(stopOnTenCount = false, stopOnTko = false).simulateRound(
            1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
            FighterState(), FighterState(), Tactic.CONTROL, Tactic.BODY_WORK, 2026072102L,
        )
        val evidence = round.judgingEvidence
        val redAttacks = round.events.filter { it.attackerId == TestProfiles.eliasVega.id }
        val blueAttacks = round.events.filter { it.attackerId == TestProfiles.brunoKessler.id }

        check(evidence.red.initiatedSequences == redAttacks.size)
        check(evidence.blue.initiatedSequences == blueAttacks.size)
        check(evidence.red.landedPunches == redAttacks.count { it.landed })
        check(evidence.blue.landedPunches == blueAttacks.count { it.landed })
        check(evidence.red.cleanHits == redAttacks.count { it.clean })
        check(evidence.blue.cleanHits == blueAttacks.count { it.clean })
        check(kotlin.math.abs(evidence.red.totalImpact - redAttacks.sumOf { it.impact }) < 1e-9)
        check(kotlin.math.abs(evidence.blue.totalImpact - blueAttacks.sumOf { it.impact }) < 1e-9)
        check(evidence.red.initiatedSequences + evidence.blue.initiatedSequences == round.events.size)
    }

    private fun judgingEvidenceCapturesDefenseRangeBodyWorkAndKnockdowns() {
        val (_, round) = findVulnerableRoundWithKnockdown()
        val evidence = round.judgingEvidence
        val redAttacks = round.events.filter { it.attackerId == TestProfiles.brunoKessler.id }
        val blueAttacks = round.events.filter { it.attackerId == TestProfiles.eliasVega.id }

        check(evidence.red.defensiveSuccesses == blueAttacks.count { !it.landed })
        check(evidence.blue.defensiveSuccesses == redAttacks.count { !it.landed })
        check(evidence.red.preferredRangeInitiatives == redAttacks.count { it.range == TestProfiles.brunoKessler.preferredRange })
        check(evidence.blue.preferredRangeInitiatives == blueAttacks.count { it.range == TestProfiles.eliasVega.preferredRange })
        check(evidence.red.bodyShotsLanded == redAttacks.count { it.landed && it.punch == Punch.BODY_HOOK })
        check(evidence.blue.bodyShotsLanded == blueAttacks.count { it.landed && it.punch == Punch.BODY_HOOK })
        check(evidence.red.knockdownsScored + evidence.blue.knockdownsScored == round.events.count { it.knockdown != null })
        check(evidence.red.knockdownsSuffered == evidence.blue.knockdownsScored)
        check(evidence.blue.knockdownsSuffered == evidence.red.knockdownsScored)
    }

    private fun stoppedRoundsContainNoPhantomEvidence() {
        val (_, koFight) = findFightWithKo()
        val koRound = koFight.rounds.last()
        check(koRound.judgingEvidence.sequenceCount == koRound.stoppage?.sequenceNumber)
        check(koRound.judgingEvidence.red.initiatedSequences + koRound.judgingEvidence.blue.initiatedSequences == koRound.events.size)

        val (_, tkoFight) = findFightWithTko()
        val tkoRound = tkoFight.rounds.last()
        check(tkoRound.judgingEvidence.sequenceCount == tkoRound.stoppage?.sequenceNumber)
        check(tkoRound.judgingEvidence.red.initiatedSequences + tkoRound.judgingEvidence.blue.initiatedSequences == tkoRound.events.size)
    }

    private fun judgingEvidenceAuditIsReproducibleAndExact() {
        val first = JudgingEvidenceStep1Auditor.run()
        val second = JudgingEvidenceStep1Auditor.run()
        check(first == second)
        check(first.fightCount == 1000)
        check(first.evidenceMismatchCount == 0)
        check(first.emptyEvidenceCount == 0)
        check(first.sequenceCount == first.vegaInitiatives + first.kesslerInitiatives)
    }


    private fun neutralJudgeIsDeterministicAndAttachedOnlyToCompletedRounds() {
        val engine = FightEngine()
        val first = createThreeRoundFight(engine, 2026072301L)
        val second = createThreeRoundFight(engine, 2026072301L)
        check(first.rounds.map { it.neutralJudgeScore } == second.rounds.map { it.neutralJudgeScore })
        first.rounds.forEach { round ->
            if (round.stoppage == null) {
                check(round.neutralJudgeScore != null)
                check(round.neutralJudgeScore == NeutralJudge.score(round.judgingEvidence))
            } else {
                check(round.neutralJudgeScore == null)
            }
        }

        val (_, stoppedFight) = findFightWithKo()
        check(stoppedFight.rounds.last().stoppage != null)
        check(stoppedFight.rounds.last().neutralJudgeScore == null)
    }

    private fun neutralJudgeUsesValidTenPointScores() {
        val first = NeutralJudgeStep2Auditor.run()
        val second = NeutralJudgeStep2Auditor.run()
        check(first == second)
        check(first.fightCount == 1000)
        check(first.scoreMismatchCount == 0)
        check(first.invalidScoreCount == 0)
        check(first.knockdownPriorityViolationCount == 0)
        check(first.blankExplanationCount == 0)
        check(first.tenTenRounds * 20 < first.scoredRounds) { "Les rounds 10-10 doivent rester rares." }
    }

    private fun knockdownPriorityProducesTenEight() {
        val evidence = syntheticEvidence(
            redLanded = 1,
            redClean = 1,
            redImpact = 6.0,
            redBodyShots = 0,
            redBodyImpact = 0.0,
            redKnockdowns = 1,
            blueLanded = 6,
            blueClean = 5,
            blueImpact = 60.0,
            blueBodyShots = 2,
            blueBodyImpact = 18.0,
            blueKnockdowns = 0,
        )
        val score = NeutralJudge.score(evidence)
        check(score.winnerId == evidence.red.fighterId)
        check(score.redPoints == 10 && score.bluePoints == 8)
        check(score.knockdownDifference == 1)
        check(score.decisiveFactors.first().startsWith("avantage de knockdowns"))
    }

    private fun twoKnockdownsProduceTenSeven() {
        val evidence = syntheticEvidence(
            redLanded = 2,
            redClean = 2,
            redImpact = 12.0,
            redBodyShots = 0,
            redBodyImpact = 0.0,
            redKnockdowns = 2,
            blueLanded = 6,
            blueClean = 5,
            blueImpact = 58.0,
            blueBodyShots = 2,
            blueBodyImpact = 16.0,
            blueKnockdowns = 0,
        )
        val score = NeutralJudge.score(evidence)
        check(score.winnerId == evidence.red.fighterId)
        check(score.redPoints == 10 && score.bluePoints == 7)
        check(score.knockdownDifference == 2)
    }

    private fun neutralJudgeCanProduceRareTenTen() {
        val evidence = syntheticEvidence(
            redLanded = 3,
            redClean = 1,
            redImpact = 22.0,
            redBodyShots = 1,
            redBodyImpact = 6.0,
            redKnockdowns = 0,
            blueLanded = 3,
            blueClean = 1,
            blueImpact = 22.0,
            blueBodyShots = 1,
            blueBodyImpact = 6.0,
            blueKnockdowns = 0,
        )
        val score = NeutralJudge.score(evidence)
        check(score.winnerId == null)
        check(score.redPoints == 10 && score.bluePoints == 10)
        check(score.explanation.startsWith("10-10"))
    }


    private fun threeJudgePanelIsDeterministicAndAttached() {
        val engine = FightEngine()
        val first = createThreeRoundFight(engine, 2026072401L)
        val second = createThreeRoundFight(engine, 2026072401L)
        check(first.rounds.map { it.judgeScores } == second.rounds.map { it.judgeScores })
        first.rounds.forEach { round ->
            if (round.stoppage == null) {
                check(round.judgeScores.size == 3)
                check(round.judgeScores == ThreeJudgePanel.score(round.judgingEvidence))
                check(round.judgeScores.map { it.judgeId } == JudgeProfiles.ALL.map { it.id })
                check(round.neutralJudgeScore == round.judgeScores.first().toNeutralScore())
            } else {
                check(round.judgeScores.isEmpty())
            }
        }
    }

    private fun judgeProfilesHaveExplicitModestWeights() {
        check(JudgeProfiles.ALL.size == 3)
        check(JudgeProfiles.ALL.map { it.id }.distinct().size == 3)
        val allWeights = JudgeProfiles.ALL.map { profile ->
            with(profile.weights) { listOf(strikingQuality, effectiveAggression, defense, ringControl, bodyWork) }
        }
        allWeights.forEach { weights -> check(kotlin.math.abs(weights.sum() - 1.0) < 1e-9) }
        for (axis in 0 until 5) {
            val values = allWeights.map { it[axis] }
            check(values.max() - values.min() <= 0.10) { "Les préférences des juges doivent rester légères." }
        }
        check(allWeights.distinct().size == 3)
    }

    private fun threeJudgesRespectKnockdownPriority() {
        val evidence = syntheticEvidence(
            redLanded = 1, redClean = 1, redImpact = 5.0, redBodyShots = 0, redBodyImpact = 0.0, redKnockdowns = 1,
            blueLanded = 6, blueClean = 5, blueImpact = 65.0, blueBodyShots = 3, blueBodyImpact = 22.0, blueKnockdowns = 0,
        )
        val scores = ThreeJudgePanel.score(evidence)
        check(scores.size == 3)
        check(scores.all { it.winnerId == evidence.red.fighterId && it.redPoints == 10 && it.bluePoints == 8 })
    }

    private fun judgeProfilesDisagreeSometimesButRemainClose() {
        val first = step3JudgeAudit
        val second = ThreeJudgeStep3Auditor.run()
        check(first == second)
        check(first.scoreMismatchCount == 0)
        check(first.invalidScoreCount == 0)
        check(first.blankExplanationCount == 0)
        check(first.knockdownUnanimityViolations == 0)
        check(first.stoppedRoundScoreCount == 0)
        check(first.disagreementRounds > 0) { "Les profils distincts doivent produire quelques désaccords réels." }
        check(first.disagreementShare < 0.20) { "Les préférences légères ne doivent pas rendre les cartes arbitraires." }
        check(first.maximumMarginSpread <= 20.0)
    }

    private fun stoppedRoundsHaveNoPanelScores() {
        val (_, koFight) = findFightWithKo()
        val stoppedRound = koFight.rounds.last()
        check(stoppedRound.stoppage != null)
        check(stoppedRound.judgeScores.isEmpty())
        check(stoppedRound.neutralJudgeScore == null)
    }

    private fun officialDecisionIsDeterministicAndAttachedAtDistance() {
        val first = createThreeRoundFight(FightEngine(), 2026072501L)
        val second = createThreeRoundFight(FightEngine(), 2026072501L)
        check(first.stoppage == null)
        check(first.officialDecision != null)
        check(first.officialDecision == second.officialDecision)
        check(first.officialDecision == OfficialDecisionResolver.resolve(first.redId, first.blueId, first.rounds))
        val report = FightReportFormatter.format(first, TestProfiles.eliasVega, TestProfiles.brunoKessler)
        check("CARTES OFFICIELLES" in report)
        check(first.officialDecision.type.frenchLabel in report)
    }

    private fun scorecardsTotalExactlyThreeCompletedRounds() {
        val fight = createThreeRoundFight(FightEngine(), 2026072502L)
        val decision = requireNotNull(fight.officialDecision)
        check(decision.scorecards.size == 3)
        decision.scorecards.forEach { card ->
            check(card.rounds.size == 3)
            check(card.rounds.map { it.roundNumber } == listOf(1, 2, 3))
            check(card.redTotal == card.rounds.sumOf { it.redPoints })
            check(card.blueTotal == card.rounds.sumOf { it.bluePoints })
            when (card.verdict) {
                ScorecardVerdict.RED -> check(card.redTotal > card.blueTotal && card.winnerId == fight.redId)
                ScorecardVerdict.BLUE -> check(card.blueTotal > card.redTotal && card.winnerId == fight.blueId)
                ScorecardVerdict.DRAW -> check(card.redTotal == card.blueTotal && card.winnerId == null)
            }
        }
    }

    private fun allOfficialDecisionTypesAreClassifiedCorrectly() {
        check(OfficialDecisionResolver.classify(3, 0, 0) == OfficialDecisionType.UNANIMOUS_DECISION)
        check(OfficialDecisionResolver.classify(0, 3, 0) == OfficialDecisionType.UNANIMOUS_DECISION)
        check(OfficialDecisionResolver.classify(2, 1, 0) == OfficialDecisionType.SPLIT_DECISION)
        check(OfficialDecisionResolver.classify(1, 2, 0) == OfficialDecisionType.SPLIT_DECISION)
        check(OfficialDecisionResolver.classify(2, 0, 1) == OfficialDecisionType.MAJORITY_DECISION)
        check(OfficialDecisionResolver.classify(0, 2, 1) == OfficialDecisionType.MAJORITY_DECISION)
        check(OfficialDecisionResolver.classify(0, 0, 3) == OfficialDecisionType.UNANIMOUS_DRAW)
        check(OfficialDecisionResolver.classify(1, 0, 2) == OfficialDecisionType.MAJORITY_DRAW)
        check(OfficialDecisionResolver.classify(0, 1, 2) == OfficialDecisionType.MAJORITY_DRAW)
        check(OfficialDecisionResolver.classify(1, 1, 1) == OfficialDecisionType.SPLIT_DRAW)
    }

    private fun koAndTkoKeepPriorityOverOfficialDecision() {
        val (_, koFight) = findFightWithKo()
        check(koFight.stoppage?.method == FightMethod.KO)
        check(koFight.officialDecision == null)

        val (_, tkoFight) = findFightWithTko()
        check(tkoFight.stoppage?.method == FightMethod.TKO)
        check(tkoFight.officialDecision == null)

        val koReport = FightReportFormatter.format(koFight, TestProfiles.brunoKessler, TestProfiles.eliasVega)
        check("par KO" in koReport)
        check("CARTES OFFICIELLES" !in koReport)
    }

    private fun officialDecisionAuditIsReproducibleAndValid() {
        val first = step4DecisionAudit
        val second = OfficialDecisionStep4Auditor.run()
        check(first == second)
        check(first.fightCount == 1000)
        check(first.officialDecisionCount == first.distanceFights)
        check(first.scorecardCount == first.distanceFights * 3)
        check(first.decisionMismatchCount == 0)
        check(first.invalidScorecardCount == 0)
        check(first.majorityMismatchCount == 0)
        check(first.missingDecisionCount == 0)
        check(first.decisionAfterStoppageCount == 0)
        check(first.blankExplanationCount == 0)
    }

    private fun syntheticEvidence(
        redLanded: Int,
        redClean: Int,
        redImpact: Double,
        redBodyShots: Int,
        redBodyImpact: Double,
        redKnockdowns: Int,
        blueLanded: Int,
        blueClean: Int,
        blueImpact: Double,
        blueBodyShots: Int,
        blueBodyImpact: Double,
        blueKnockdowns: Int,
    ): RoundJudgingEvidence {
        val initiatives = 6
        val red = FighterRoundJudgingEvidence(
            fighterId = TestProfiles.eliasVega.id,
            initiatedSequences = initiatives,
            effectiveSequences = redLanded,
            landedPunches = redLanded,
            cleanHits = redClean,
            totalImpact = redImpact,
            cleanImpact = redImpact * if (redLanded == 0) 0.0 else redClean.toDouble() / redLanded,
            defensiveSuccesses = initiatives - blueLanded,
            punchesAllowed = blueLanded,
            cleanHitsAllowed = blueClean,
            impactAbsorbed = blueImpact,
            preferredRangeInitiatives = 3,
            outsideInitiatives = 2,
            midInitiatives = 2,
            insideInitiatives = 2,
            bodyShotsLanded = redBodyShots,
            bodyImpact = redBodyImpact,
            knockdownsScored = redKnockdowns,
            knockdownsSuffered = blueKnockdowns,
        )
        val blue = FighterRoundJudgingEvidence(
            fighterId = TestProfiles.brunoKessler.id,
            initiatedSequences = initiatives,
            effectiveSequences = blueLanded,
            landedPunches = blueLanded,
            cleanHits = blueClean,
            totalImpact = blueImpact,
            cleanImpact = blueImpact * if (blueLanded == 0) 0.0 else blueClean.toDouble() / blueLanded,
            defensiveSuccesses = initiatives - redLanded,
            punchesAllowed = redLanded,
            cleanHitsAllowed = redClean,
            impactAbsorbed = redImpact,
            preferredRangeInitiatives = 3,
            outsideInitiatives = 2,
            midInitiatives = 2,
            insideInitiatives = 2,
            bodyShotsLanded = blueBodyShots,
            bodyImpact = blueBodyImpact,
            knockdownsScored = blueKnockdowns,
            knockdownsSuffered = redKnockdowns,
        )
        return RoundJudgingEvidence(
            roundNumber = 1,
            sequenceCount = initiatives * 2,
            red = red,
            blue = blue,
        )
    }

    private fun findFightWithTko(): Pair<Long, FightResult> {
        for (seed in 1L..50000L) {
            val fight = TkoStep4Scenario.fight(seed, attackerInRed = true)
            if (fight.stoppage?.method == FightMethod.TKO) return seed to fight
        }
        error("Aucun combat terminé par TKO trouvé dans la plage de graines autorisée.")
    }

    private fun findRecoveredRound(
        requireBeforeLastSequence: Boolean = false,
        requireSingleKnockdown: Boolean = false,
    ): Pair<Long, RoundResult> {
        for (seed in 1L..10000L) {
            val round = vulnerableRound(seed)
            val recoveredIndices = round.events.mapIndexedNotNull { index, event ->
                if (event.knockdown?.refereeCount?.recovered == true) index else null
            }
            val acceptable = recoveredIndices.any { !requireBeforeLastSequence || it < round.events.lastIndex }
            val singleOk = !requireSingleKnockdown || round.events.count { it.knockdown != null } == 1
            if (acceptable && singleOk) return seed to round
        }
        error("Aucun relèvement de validation trouvé dans la plage de graines autorisée.")
    }

    private fun findVulnerableRoundWithKnockdown(requireBeforeLastSequence: Boolean = false): Pair<Long, RoundResult> {
        for (seed in 1L..5000L) {
            val round = vulnerableRound(seed)
            val index = round.events.indexOfFirst { it.knockdown != null }
            if (index >= 0 && (!requireBeforeLastSequence || index < round.events.lastIndex)) return seed to round
        }
        error("Aucune chute de validation trouvée dans la plage de graines autorisée.")
    }


    private fun findRoundWithKo(): Pair<Long, RoundResult> {
        for (seed in 1L..20000L) {
            val round = extremeRound(seed)
            if (round.stoppage?.method == FightMethod.KO) return seed to round
        }
        error("Aucun KO de validation trouvé dans la plage de graines autorisée.")
    }

    private fun findFightWithKo(): Pair<Long, FightResult> {
        for (seed in 1L..20000L) {
            val fight = extremeThreeRoundFight(seed)
            if (fight.stoppage?.method == FightMethod.KO) return seed to fight
        }
        error("Aucun combat terminé par KO trouvé dans la plage de graines autorisée.")
    }

    private fun extremeRound(seed: Long): RoundResult = FightEngine(stopOnTko = false).simulateRound(
        roundNumber = 1,
        red = TestProfiles.brunoKessler,
        blue = TestProfiles.eliasVega,
        redStart = FighterState(),
        blueStart = FighterState(stamina = 3.0, headDamage = 94.0, bodyDamage = 80.0, stability = 3.0),
        redTactic = Tactic.SEEK_KO,
        blueTactic = Tactic.RECOVER,
        seed = seed,
    )

    private fun extremeThreeRoundFight(seed: Long): FightResult = FightEngine(stopOnTko = false).simulateThreeRoundFight(
        red = TestProfiles.brunoKessler,
        blue = TestProfiles.eliasVega,
        redTactics = listOf(Tactic.SEEK_KO, Tactic.SEEK_KO, Tactic.SEEK_KO),
        blueTactics = listOf(Tactic.RECOVER, Tactic.RECOVER, Tactic.RECOVER),
        seed = seed,
        redStart = FighterState(),
        blueStart = FighterState(stamina = 3.0, headDamage = 94.0, bodyDamage = 80.0, stability = 3.0),
    )

    private fun vulnerableRound(seed: Long): RoundResult = FightEngine(stopOnTko = false).simulateRound(
        roundNumber = 1,
        red = TestProfiles.brunoKessler,
        blue = TestProfiles.eliasVega,
        redStart = FighterState(),
        blueStart = FighterState(stamina = 12.0, headDamage = 82.0, bodyDamage = 58.0, stability = 12.0),
        redTactic = Tactic.SEEK_KO,
        blueTactic = Tactic.RECOVER,
        seed = seed,
    )

    private fun createThreeRoundFight(engine: FightEngine, seed: Long): FightResult =
        engine.simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = seed,
        )
    private fun finalJalonThreeAuditIsCompleteAndReproducible() {
        check(finalJalon3Audit.totalFights == 10_000)
        check(finalJalon3Audit.windows.size == 10)
        check(finalJalon3Audit.windows.all { it.fights == 1_000 })
        check(finalJalon3Audit.reproducibilityMismatches == 0)
        check(finalJalon3Audit.totalOfficialDecisions == finalJalon3Audit.totalDistanceFights)
    }

    private fun finalJalonThreeAuditHasNoInvalidCardsOrDecisions() {
        check(finalJalon3Audit.invalidScorecards == 0)
        check(finalJalon3Audit.majorityMismatches == 0)
        check(finalJalon3Audit.missingDecisions == 0)
        check(finalJalon3Audit.decisionsAfterStoppage == 0)
    }

    private fun finalJalonThreeAuditHasNoPersistentCornerBias() {
        check(finalJalon3Audit.redWinShareAmongDecisions in 0.47..0.53)
        check(finalJalon3Audit.vegaRedBlueWinRateGap <= 0.04)
        check(finalJalon3Audit.kesslerRedBlueWinRateGap <= 0.04)
        check(finalJalon3Audit.windows.all { it.redWinShareAmongDecisions in 0.42..0.58 })
    }

    private fun finalJalonThreeJudgesHaveComparableSeverity() {
        check(finalJalon3Audit.judgeCombinedPointSpread <= 0.08)
        check(finalJalon3Audit.judgeAbsoluteMarginSpread <= 0.25)
        check(finalJalon3Audit.judgeTenTenShareSpread <= 0.03)
    }

    private fun finalJalonThreeJudgesDoNotSystematicallyFavorAStyle() {
        check(finalJalon3Audit.judgeRedCardShareSpread <= 0.03)
        check(finalJalon3Audit.judgeVegaCardShareSpread <= 0.03)
        Jalon3FinalAuditor.assertAcceptable(finalJalon3Audit)
    }

    private fun tacticalSnapshotsAreDeterministicAndAttachedAtRoundStarts() {
        val first = createThreeRoundFight(FightEngine(), 202607210610L)
        val second = createThreeRoundFight(FightEngine(), 202607210610L)
        check(first.tacticalSnapshots == second.tacticalSnapshots)
        check(first.tacticalSnapshots.size == first.rounds.size)
        check(first.tacticalSnapshots.map { it.nextRoundNumber } == (1..first.rounds.size).toList())
        check(first.tacticalSnapshots.map { it.completedRounds } == (0 until first.rounds.size).toList())
        first.tacticalSnapshots.drop(1).forEachIndexed { index, snapshot ->
            val prior = first.rounds[index]
            check(kotlin.math.abs(snapshot.red.stamina - prior.redState.stamina) <= 1e-9)
            check(kotlin.math.abs(snapshot.blue.stamina - prior.blueState.stamina) <= 1e-9)
            check(kotlin.math.abs(snapshot.red.headDamage - prior.redState.headDamage) <= 1e-9)
            check(kotlin.math.abs(snapshot.blue.bodyDamage - prior.blueState.bodyDamage) <= 1e-9)
        }
    }

    private fun preFightSnapshotContainsNoPastInformation() {
        val snapshot = createThreeRoundFight(FightEngine(), 202607210611L).tacticalSnapshots.first()
        check(snapshot.completedRounds == 0)
        check(snapshot.nextRoundNumber == 1)
        check(snapshot.remainingRoundsIncludingNext == 3)
        check(snapshot.remainingSequencesMaximum == 36)
        check(snapshot.completedSequenceCount == 0)
        check(snapshot.estimatedLeaderId == null)
        check(snapshot.estimatedRoundMargin == 0)
        check(snapshot.estimatedPerformanceMargin == 0.0)
        check(snapshot.recentMomentumLeaderId == null)
        check(snapshot.recentMomentumMargin == 0.0)
        check(snapshot.red.knockdownsScored == 0 && snapshot.red.knockdownsSuffered == 0)
        check(snapshot.blue.knockdownsScored == 0 && snapshot.blue.knockdownsSuffered == 0)
        check(snapshot.red.estimatedRoundsWon == 0 && snapshot.blue.estimatedRoundsWon == 0)
    }

    private fun tacticalSnapshotsIgnoreFutureRoundsAndFutureTactics() {
        val engine = FightEngine()
        val seed = 202607210612L
        val first = engine.simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = seed,
        )
        val second = engine.simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.SEEK_KO, Tactic.SEEK_KO),
            blueTactics = listOf(Tactic.PRESS, Tactic.RECOVER, Tactic.RECOVER),
            seed = seed,
        )
        check(first.rounds.first() == second.rounds.first())
        check(first.tacticalSnapshots[0] == second.tacticalSnapshots[0])
        check(first.tacticalSnapshots[1] == second.tacticalSnapshots[1]) {
            "L'instantané avant le round 2 ne doit dépendre ni des tactiques ni des séquences futures."
        }
        val rebuilt = TacticalStateSnapshotExtractor.extract(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redState = first.rounds.first().redState,
            blueState = first.rounds.first().blueState,
            completedRounds = listOf(TacticalRoundFacts.fromCompletedRound(first.rounds.first())),
            nextRoundNumber = 2,
            sequencesPerRound = 12,
        )
        check(rebuilt == first.tacticalSnapshots[1])
    }

    private fun tacticalSnapshotCapturesPhysicalStateKnockdownsAndMomentum() {
        var selected: FightResult? = null
        for (seed in 1L..20_000L) {
            val fight = FightEngine(stopOnTko = false).simulateThreeRoundFight(
                red = TestProfiles.brunoKessler,
                blue = TestProfiles.eliasVega,
                redTactics = listOf(Tactic.SEEK_KO, Tactic.PRESS, Tactic.PRESS),
                blueTactics = listOf(Tactic.RECOVER, Tactic.RECOVER, Tactic.CONTROL),
                seed = seed,
                blueStart = FighterState(stamina = 18.0, headDamage = 72.0, bodyDamage = 48.0, stability = 18.0),
            )
            if (fight.rounds.size >= 2 && fight.rounds.first().events.any { it.knockdown?.refereeCount?.recovered == true }) {
                selected = fight
                break
            }
        }
        val fight = requireNotNull(selected)
        val snapshot = fight.tacticalSnapshots[1]
        val firstRound = fight.rounds.first()
        check(snapshot.completedRounds == 1)
        check(snapshot.completedSequenceCount == firstRound.events.size)
        check(snapshot.red.fatigue == 100.0 - snapshot.red.stamina)
        check(snapshot.blue.fatigue == 100.0 - snapshot.blue.stamina)
        check(snapshot.red.headDamage == firstRound.redState.headDamage)
        check(snapshot.blue.bodyDamage == firstRound.blueState.bodyDamage)
        check(snapshot.red.knockdownsScored + snapshot.blue.knockdownsScored > 0)
        check(snapshot.red.knockdownsSuffered + snapshot.blue.knockdownsSuffered > 0)
        check(snapshot.red.recentMomentumScore + snapshot.blue.recentMomentumScore > 0.0)
    }

    private fun noTacticalSnapshotExistsAfterStoppage() {
        val (_, koFight) = findFightWithKo()
        val ko = requireNotNull(koFight.stoppage)
        check(koFight.tacticalSnapshots.size == koFight.rounds.size)
        check(koFight.tacticalSnapshots.none { it.nextRoundNumber > ko.roundNumber })

        val (_, tkoFight) = findFightWithTko()
        val tko = requireNotNull(tkoFight.stoppage)
        check(tkoFight.tacticalSnapshots.size == tkoFight.rounds.size)
        check(tkoFight.tacticalSnapshots.none { it.nextRoundNumber > tko.roundNumber })
    }

    private fun tacticalSnapshotAuditIsExactAndLegacyBehaviorIsUnchanged() {
        val first = TacticalStateStep1Auditor.run()
        val second = TacticalStateStep1Auditor.run()
        check(first == second)
        TacticalStateStep1Auditor.assertValid(first)
        check(first.fightCount == 1_000)
        check(first.totalSnapshots == first.totalRounds)
        check(LegacyBehaviorFingerprint.verify() == 0) {
            "L'ajout observationnel ne doit modifier ni les séquences, ni les états, ni les arrêts, ni les décisions historiques."
        }
    }

    private fun tacticalPlanCatalogCoversEveryStyle() {
        val plans = TacticalPlanCatalog.allNaturalPlans()
        check(plans.size == BoxingStyle.entries.size)
        check(plans.map { it.anchorStyle }.toSet() == BoxingStyle.entries.toSet())
        check(plans.map { it.id }.distinct().size == plans.size)
    }

    private fun naturalPlansPreserveStyleIdentity() {
        val vega = TacticalPlanCatalog.naturalFor(TestProfiles.eliasVega)
        check(vega.anchorStyle == BoxingStyle.OUT_BOXER)
        check(vega.distance == TacticalDistance.LONG)
        check(vega.pace == TacticalPace.MEASURED)
        check(vega.risk == TacticalRisk.SAFE)

        val kessler = TacticalPlanCatalog.naturalFor(TestProfiles.brunoKessler)
        check(kessler.anchorStyle == BoxingStyle.PRESSURE_FIGHTER)
        check(kessler.distance == TacticalDistance.CLOSE)
        check(kessler.pace == TacticalPace.SUSTAINED)
        check(kessler.target == TacticalTarget.BODY)
    }

    private fun tacticalPlanModifiersAreBoundedForEveryCombination() {
        TacticalPace.entries.forEach { pace ->
            TacticalDistance.entries.forEach { distance ->
                TacticalTarget.entries.forEach { target ->
                    TacticalRisk.entries.forEach { risk ->
                        val m = TacticalPlanModifierFactory.derive(pace, distance, target, risk)
                        check(m.activityDelta in TacticalPlanModifiers.MIN_ACTIVITY_DELTA..TacticalPlanModifiers.MAX_ACTIVITY_DELTA)
                        check(m.accuracyDelta in TacticalPlanModifiers.MIN_ACCURACY_DELTA..TacticalPlanModifiers.MAX_ACCURACY_DELTA)
                        check(m.defenseDelta in TacticalPlanModifiers.MIN_DEFENSE_DELTA..TacticalPlanModifiers.MAX_DEFENSE_DELTA)
                        check(m.impactDelta in TacticalPlanModifiers.MIN_IMPACT_DELTA..TacticalPlanModifiers.MAX_IMPACT_DELTA)
                        check(m.staminaCostDelta in TacticalPlanModifiers.MIN_STAMINA_COST_DELTA..TacticalPlanModifiers.MAX_STAMINA_COST_DELTA)
                        check(m.preferredRangeControlDelta in TacticalPlanModifiers.MIN_RANGE_CONTROL_DELTA..TacticalPlanModifiers.MAX_RANGE_CONTROL_DELTA)
                    }
                }
            }
        }
    }

    private fun paceAndRiskModifiersRemainMonotonic() {
        val cautious = TacticalPlanModifierFactory.derive(TacticalPace.CAUTIOUS, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        val measured = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        val sustained = TacticalPlanModifierFactory.derive(TacticalPace.SUSTAINED, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        check(cautious.activityDelta < measured.activityDelta && measured.activityDelta < sustained.activityDelta)
        check(cautious.staminaCostDelta < measured.staminaCostDelta && measured.staminaCostDelta < sustained.staminaCostDelta)

        val safe = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.SAFE)
        val balanced = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        val aggressive = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.AGGRESSIVE)
        check(safe.defenseDelta > balanced.defenseDelta && balanced.defenseDelta > aggressive.defenseDelta)
        check(safe.impactDelta < balanced.impactDelta && balanced.impactDelta < aggressive.impactDelta)
    }

    private fun targetBiasMatchesPriority() {
        val head = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.HEAD, TacticalRisk.BALANCED)
        val body = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.BODY, TacticalRisk.BALANCED)
        val mixed = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        check(head.headTargetShare > head.bodyTargetShare)
        check(body.bodyTargetShare > body.headTargetShare)
        check(mixed.headTargetShare == mixed.bodyTargetShare)
        listOf(head, body, mixed).forEach { check(kotlin.math.abs(it.headTargetShare + it.bodyTargetShare - 1.0) <= 1e-9) }
    }

    private fun tacticalPlanConstructionIsDeterministicAndPure() {
        val first = TacticalPlanCatalog.naturalFor(BoxingStyle.BOXER_PUNCHER)
        val second = TacticalPlanCatalog.naturalFor(BoxingStyle.BOXER_PUNCHER)
        check(first == second)
        check(first.modifiers == TacticalPlanModifierFactory.derive(first.pace, first.distance, first.target, first.risk))
        check(LegacyBehaviorFingerprint.verify() == 0)
    }

    private fun tacticalPlanStepTwoAuditIsExactAndLegacyBehaviorUnchanged() {
        val first = TacticalPlanStep2Auditor.run()
        val second = TacticalPlanStep2Auditor.run()
        check(first == second)
        TacticalPlanStep2Auditor.assertValid(first)
        check(first.combinationCount == 81)
        check(first.naturalPlanCount == 7)
        check(first.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun tacticalDecisionsAreDeterministicAndAttached() {
        val first = createThreeRoundFight(FightEngine(), 202607210701L)
        val second = createThreeRoundFight(FightEngine(), 202607210701L)
        check(first.tacticalDecisions == second.tacticalDecisions)
        check(first.tacticalDecisions.size == first.rounds.size * 2)
        first.rounds.indices.forEach { index ->
            val decisions = first.tacticalDecisions.filter { it.beforeRound == index + 1 }
            check(decisions.map { it.fighterId } == listOf(first.redId, first.blueId))
            check(decisions.all { it.explanation.isNotBlank() })
        }
    }

    private fun preFightDecisionsUseNaturalPlans() {
        val fight = createThreeRoundFight(FightEngine(), 202607210702L)
        val decisions = fight.tacticalDecisions.filter { it.beforeRound == 1 }
        check(decisions.size == 2)
        check(decisions[0].selectedPlan == TacticalPlanCatalog.naturalFor(TestProfiles.eliasVega))
        check(decisions[1].selectedPlan == TacticalPlanCatalog.naturalFor(TestProfiles.brunoKessler))
        check(decisions.all { it.phase == TacticalDecisionPhase.PRE_FIGHT && !it.changed })
    }

    private fun trailingFighterBecomesMoreEnterprising() {
        val profile = TestProfiles.eliasVega
        val natural = TacticalPlanCatalog.naturalFor(profile)
        val initial = initialDecision(profile)
        val roundTwo = maintainedDecision(profile, 2, natural)
        val snapshot = syntheticTacticalSnapshot(
            nextRound = 3,
            redStamina = 78.0,
            redHeadDamage = 18.0,
            redBodyDamage = 22.0,
            redStability = 74.0,
            redWins = 0,
            blueWins = 1,
            evenRounds = 1,
            performanceMargin = -12.0,
        )
        val decision = TacticalDecisionEngine.decide(profile, snapshot, listOf(initial, roundTwo))
        check(TacticalDecisionTrigger.FINAL_ROUND_DEFICIT in decision.triggers)
        check(decision.selectedPlan.pace.ordinal > natural.pace.ordinal)
        check(decision.selectedPlan.risk.ordinal > natural.risk.ordinal)
        check(decision.selectedPlan.distance.ordinal > natural.distance.ordinal)
        check(decision.selectedPlan.anchorStyle == profile.style)
    }

    private fun highlyFatiguedFighterReducesPace() {
        val profile = TestProfiles.brunoKessler
        val natural = TacticalPlanCatalog.naturalFor(profile)
        val snapshot = syntheticTacticalSnapshot(
            nextRound = 2,
            redId = profile.id,
            blueId = TestProfiles.eliasVega.id,
            redStamina = 35.0,
            redHeadDamage = 20.0,
            redBodyDamage = 25.0,
            redStability = 70.0,
            redWins = 0,
            blueWins = 0,
            evenRounds = 1,
        )
        val decision = TacticalDecisionEngine.decide(profile, snapshot, listOf(initialDecision(profile)))
        check(TacticalDecisionTrigger.HIGH_FATIGUE in decision.triggers)
        check(decision.selectedPlan.pace.ordinal < natural.pace.ordinal)
        check(decision.selectedPlan.risk == TacticalRisk.SAFE)
    }

    private fun physicallyEndangeredFighterProtectsItself() {
        val profile = TestProfiles.brunoKessler
        val natural = TacticalPlanCatalog.naturalFor(profile)
        val snapshot = syntheticTacticalSnapshot(
            nextRound = 2,
            redId = profile.id,
            blueId = TestProfiles.eliasVega.id,
            redStamina = 66.0,
            redHeadDamage = 62.0,
            redBodyDamage = 40.0,
            redStability = 38.0,
            redWins = 0,
            blueWins = 0,
            evenRounds = 1,
        )
        val decision = TacticalDecisionEngine.decide(profile, snapshot, listOf(initialDecision(profile)))
        check(TacticalDecisionTrigger.PHYSICAL_DANGER in decision.triggers)
        check(decision.selectedPlan.pace.ordinal < natural.pace.ordinal)
        check(decision.selectedPlan.distance.ordinal < natural.distance.ordinal)
        check(decision.selectedPlan.risk == TacticalRisk.SAFE)
    }

    private fun unexplainedTargetReversalIsBlocked() {
        val profile = TestProfiles.brunoKessler
        val natural = TacticalPlanCatalog.naturalFor(profile)
        val initial = initialDecision(profile)
        val headPlan = TacticalPlan(profile.style, natural.pace, natural.distance, TacticalTarget.HEAD, natural.risk)
        val roundTwo = TacticalDecision(
            fighterId = profile.id,
            beforeRound = 2,
            phase = TacticalDecisionPhase.BETWEEN_ROUNDS,
            previousPlan = natural,
            selectedPlan = headPlan,
            changedAxes = TacticalDecision.changedAxes(natural, headPlan),
            triggers = listOf(TacticalDecisionTrigger.OPPONENT_HEAD_VULNERABLE),
            explanation = "Adaptation de test vers la tête.",
        )
        val snapshot = syntheticTacticalSnapshot(
            nextRound = 3,
            redId = profile.id,
            blueId = TestProfiles.eliasVega.id,
            redStamina = 75.0,
            redHeadDamage = 20.0,
            redBodyDamage = 20.0,
            redStability = 75.0,
            blueHeadDamage = 48.0,
            blueBodyDamage = 60.0,
            blueStability = 70.0,
            redWins = 0,
            blueWins = 0,
            evenRounds = 2,
            performanceMargin = 0.0,
        )
        val decision = TacticalDecisionEngine.decide(profile, snapshot, listOf(initial, roundTwo))
        check(TacticalDecisionTrigger.ANTI_OSCILLATION in decision.triggers)
        check(decision.selectedPlan.target == TacticalTarget.HEAD)
    }

    private fun tacticalDecisionAuditIsExactAndLegacyBehaviorUnchanged() {
        val first = TacticalDecisionStep3Auditor.run()
        val second = TacticalDecisionStep3Auditor.run()
        check(first == second)
        TacticalDecisionStep3Auditor.assertValid(first)
        check(first.fightCount == 1_000)
        check(first.totalDecisions == first.totalRounds * 2)
        check(first.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun adaptiveTacticalApplicationIsDeterministicAndAttached() {
        val engine = FightEngine(adaptiveTacticsEnabled = true)
        val first = createThreeRoundFight(engine, 202607211001L)
        val second = createThreeRoundFight(engine, 202607211001L)
        check(first == second)
        check(first.adaptiveTacticsEnabled)
        first.rounds.forEach { round ->
            check(round.tacticalEffectsEnabled)
            val decisions = first.tacticalDecisions.filter { it.beforeRound == round.roundNumber }
            check(round.redAppliedTacticalPlan == decisions.first { it.fighterId == first.redId }.selectedPlan)
            check(round.blueAppliedTacticalPlan == decisions.first { it.fighterId == first.blueId }.selectedPlan)
        }
    }

    private fun disabledTacticalModePreservesLegacyBehavior() {
        val fight = createThreeRoundFight(FightEngine(), 202607211002L)
        check(!fight.adaptiveTacticsEnabled)
        check(fight.rounds.all { !it.tacticalEffectsEnabled })
        check(fight.rounds.all { it.redAppliedTacticalPlan == null && it.blueAppliedTacticalPlan == null })
        check(LegacyBehaviorFingerprint.verify() == 0)
    }

    private fun tacticalApplicationMathIsBoundedAndMonotonic() {
        val safe = TacticalPlan(
            anchorStyle = BoxingStyle.BOXER_PUNCHER,
            pace = TacticalPace.CAUTIOUS,
            distance = TacticalDistance.MEDIUM,
            target = TacticalTarget.MIXED,
            risk = TacticalRisk.SAFE,
        )
        val aggressive = TacticalPlan(
            anchorStyle = BoxingStyle.BOXER_PUNCHER,
            pace = TacticalPace.SUSTAINED,
            distance = TacticalDistance.MEDIUM,
            target = TacticalTarget.MIXED,
            risk = TacticalRisk.AGGRESSIVE,
        )
        check(TacticalPlanApplication.activityScoreDelta(aggressive) > TacticalPlanApplication.activityScoreDelta(safe))
        check(TacticalPlanApplication.adjustedImpact(10.0, aggressive) > TacticalPlanApplication.adjustedImpact(10.0, safe))
        check(TacticalPlanApplication.adjustedStaminaCost(2.0, aggressive) > TacticalPlanApplication.adjustedStaminaCost(2.0, safe))
        check(TacticalPlanApplication.adjustedHitProbability(0.95, aggressive, safe) in 0.08..0.88)
        check(TacticalPlanApplication.adjustedHitProbability(0.01, safe, aggressive) in 0.08..0.88)
        check(TacticalPlanApplication.adjustedImpact(10.0, null) == 10.0)
        check(TacticalPlanApplication.adjustedStaminaCost(2.0, null) == 2.0)

        val mediumControl = TacticalPlanApplication.mediumRangeResistance(safe, Tactic.CONTROL, 100.0)
        val mediumCounter = TacticalPlanApplication.mediumRangeResistance(safe, Tactic.COUNTER, 100.0)
        val fatiguedMedium = TacticalPlanApplication.mediumRangeResistance(safe, Tactic.CONTROL, 40.0)
        val longPlan = TacticalPlan(
            anchorStyle = safe.anchorStyle,
            pace = safe.pace,
            distance = TacticalDistance.LONG,
            target = safe.target,
            risk = safe.risk,
        )
        check(mediumControl in 0.0..8.5)
        check(mediumCounter in 0.0..8.5)
        check(mediumCounter > mediumControl)
        check(fatiguedMedium < mediumControl)
        check(TacticalPlanApplication.mediumRangeResistance(longPlan, Tactic.COUNTER, 100.0) == 0.0)
        check(TacticalPlanApplication.mediumRangeResistance(null, Tactic.COUNTER, 100.0) == 0.0)
    }

    private fun targetPlanBiasesPunchSelection() {
        val engine = FightEngine(adaptiveTacticsEnabled = true)
        val headPlan = TacticalPlan(BoxingStyle.OUT_BOXER, TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.HEAD, TacticalRisk.BALANCED)
        val bodyPlan = TacticalPlan(BoxingStyle.OUT_BOXER, TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.BODY, TacticalRisk.BALANCED)
        val bluePlan = TacticalPlanCatalog.naturalFor(TestProfiles.brunoKessler)
        var headPlanAttacks = 0
        var headPlanBodyShots = 0
        var bodyPlanAttacks = 0
        var bodyPlanBodyShots = 0
        repeat(250) { index ->
            val headRound = engine.simulateRound(
                1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
                FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS,
                202607211100L + index, headPlan, bluePlan,
            )
            val bodyRound = engine.simulateRound(
                1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
                FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS,
                202607211100L + index, bodyPlan, bluePlan,
            )
            headRound.events.filter { it.attackerId == TestProfiles.eliasVega.id }.forEach {
                headPlanAttacks++
                if (it.punch == Punch.BODY_HOOK) headPlanBodyShots++
            }
            bodyRound.events.filter { it.attackerId == TestProfiles.eliasVega.id }.forEach {
                bodyPlanAttacks++
                if (it.punch == Punch.BODY_HOOK) bodyPlanBodyShots++
            }
        }
        val headShare = headPlanBodyShots.toDouble() / headPlanAttacks
        val bodyShare = bodyPlanBodyShots.toDouble() / bodyPlanAttacks
        check(bodyShare > headShare + 0.30)
    }

    private fun distancePlanBiasesResolvedRange() {
        val engine = FightEngine(adaptiveTacticsEnabled = true)
        val longRed = TacticalPlan(BoxingStyle.OUT_BOXER, TacticalPace.MEASURED, TacticalDistance.LONG, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        val longBlue = TacticalPlan(BoxingStyle.PRESSURE_FIGHTER, TacticalPace.MEASURED, TacticalDistance.LONG, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        val closeRed = TacticalPlan(BoxingStyle.OUT_BOXER, TacticalPace.MEASURED, TacticalDistance.CLOSE, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        val closeBlue = TacticalPlan(BoxingStyle.PRESSURE_FIGHTER, TacticalPace.MEASURED, TacticalDistance.CLOSE, TacticalTarget.MIXED, TacticalRisk.BALANCED)
        var longOutside = 0
        var longInside = 0
        var closeOutside = 0
        var closeInside = 0
        repeat(200) { index ->
            val longRound = engine.simulateRound(
                1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
                FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS,
                202607211400L + index, longRed, longBlue,
            )
            val closeRound = engine.simulateRound(
                1, TestProfiles.eliasVega, TestProfiles.brunoKessler,
                FighterState(), FighterState(), Tactic.CONTROL, Tactic.PRESS,
                202607211400L + index, closeRed, closeBlue,
            )
            longOutside += longRound.events.count { it.range == FightRange.OUTSIDE }
            longInside += longRound.events.count { it.range == FightRange.INSIDE }
            closeOutside += closeRound.events.count { it.range == FightRange.OUTSIDE }
            closeInside += closeRound.events.count { it.range == FightRange.INSIDE }
        }
        check(longOutside > closeOutside)
        check(closeInside > longInside)
    }

    private fun fightReportShowsActiveTactics() {
        val fight = createThreeRoundFight(FightEngine(adaptiveTacticsEnabled = true), 202607211003L)
        val report = FightReportFormatter.format(fight, TestProfiles.eliasVega, TestProfiles.brunoKessler)
        check("effets actifs" in report)
        check("Tactique ${TestProfiles.eliasVega.name}" in report)
        check("Tactique ${TestProfiles.brunoKessler.name}" in report)
        check("observation seulement" !in report)
    }

    private fun tacticalIntegrationAuditIsReproducibleAndValid() {
        val result = tacticalIntegrationStep4Audit
        TacticalIntegrationStep4Auditor.assertValid(result)
        check(result.fightCount == 1_000)
        check(result.totalDecisions == result.totalRounds * 2)
        check(result.changedFromDisabledFights == result.comparedWithDisabledFights)
        check(result.reproducibilityMismatches == 0)
        check(result.legacyBehaviorFingerprintMismatches == 0)
    }


    private fun finalJalonFourAuditIsCompleteAndReproducible() {
        check(finalJalon4Audit.windows.size == 10)
        check(finalJalon4Audit.adaptiveFights == 10_000)
        check(finalJalon4Audit.fixedNaturalFights == 2_000)
        check(finalJalon4Audit.reproducibilityChecks == 400)
        check(finalJalon4Audit.reproducibilityMismatches == 0)
    }

    private fun finalJalonFourAuditHasNoStructuralErrors() {
        check(finalJalon4Audit.invalidAdaptiveResults == 0)
        check(finalJalon4Audit.decisionsAfterStoppage == 0)
        check(finalJalon4Audit.missingAppliedPlans == 0)
        check(finalJalon4Audit.planDecisionMismatches == 0)
        check(finalJalon4Audit.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun finalJalonFourAuditHasNoPersistentCornerBias() {
        check(finalJalon4Audit.adaptiveRedWinnerShare in 0.47..0.53)
        check(kotlin.math.abs(
            finalJalon4Audit.profileCornerWinShare(TestProfiles.eliasVega.id, "RED") -
                finalJalon4Audit.profileCornerWinShare(TestProfiles.eliasVega.id, "BLUE"),
        ) <= 0.03)
        check(kotlin.math.abs(
            finalJalon4Audit.profileCornerWinShare(TestProfiles.brunoKessler.id, "RED") -
                finalJalon4Audit.profileCornerWinShare(TestProfiles.brunoKessler.id, "BLUE"),
        ) <= 0.03)
    }

    private fun finalJalonFourAdaptiveResponsesRemainCoherent() {
        check(finalJalon4Audit.trailingOpportunities > 0)
        check(finalJalon4Audit.trailingResponseRate >= 0.85)
        check(finalJalon4Audit.fatigueOpportunities == 0 || finalJalon4Audit.fatigueResponseRate >= 0.80)
        check(finalJalon4Audit.dangerOpportunities == 0 || finalJalon4Audit.dangerResponseRate >= 0.80)
        check(finalJalon4Audit.tacticalChangeShare in 0.15..0.75)
    }

    private fun finalJalonFourHasNoUniversalDominantPlan() {
        check(finalJalon4Audit.distinctBetweenRoundPlans(TestProfiles.eliasVega.id) >= 3)
        check(finalJalon4Audit.distinctBetweenRoundPlans(TestProfiles.brunoKessler.id) >= 3)
        check(finalJalon4Audit.topBetweenRoundPlanShare(TestProfiles.eliasVega.id) <= 0.80)
        check(finalJalon4Audit.topBetweenRoundPlanShare(TestProfiles.brunoKessler.id) <= 0.80)
        check(finalJalon4Audit.bestBenchmark(TestProfiles.eliasVega.id).presetId !=
            finalJalon4Audit.bestBenchmark(TestProfiles.brunoKessler.id).presetId)
    }

    private fun finalJalonFourDiffersMeaningfullyFromFixedNaturalPlans() {
        Jalon4FinalAuditor.assertAcceptable(finalJalon4Audit)
        check(finalJalon4Audit.pairedOutcomeChangeShare >= 0.10)
        check(kotlin.math.abs(finalJalon4Audit.adaptiveVegaWinShare - finalJalon4Audit.fixedVegaWinShare) <= 0.06)
    }

    private fun initialDecision(profile: BoxerProfile): TacticalDecision {
        val snapshot = syntheticTacticalSnapshot(
            nextRound = 1,
            redId = profile.id,
            blueId = if (profile.id == TestProfiles.eliasVega.id) TestProfiles.brunoKessler.id else TestProfiles.eliasVega.id,
            redWins = 0,
            blueWins = 0,
            evenRounds = 0,
        )
        return TacticalDecisionEngine.decide(profile, snapshot, emptyList())
    }

    private fun maintainedDecision(profile: BoxerProfile, beforeRound: Int, plan: TacticalPlan): TacticalDecision = TacticalDecision(
        fighterId = profile.id,
        beforeRound = beforeRound,
        phase = TacticalDecisionPhase.BETWEEN_ROUNDS,
        previousPlan = plan,
        selectedPlan = plan,
        changedAxes = emptyList(),
        triggers = listOf(TacticalDecisionTrigger.PLAN_MAINTAINED),
        explanation = "Plan maintenu pour le test.",
    )

    private fun syntheticTacticalSnapshot(
        nextRound: Int,
        redId: String = TestProfiles.eliasVega.id,
        blueId: String = TestProfiles.brunoKessler.id,
        redStamina: Double = 80.0,
        blueStamina: Double = 80.0,
        redHeadDamage: Double = 20.0,
        blueHeadDamage: Double = 20.0,
        redBodyDamage: Double = 20.0,
        blueBodyDamage: Double = 20.0,
        redStability: Double = 80.0,
        blueStability: Double = 80.0,
        redWins: Int,
        blueWins: Int,
        evenRounds: Int,
        performanceMargin: Double = 0.0,
        momentumMargin: Double = 0.0,
    ): TacticalStateSnapshot {
        val completed = nextRound - 1
        check(redWins + blueWins + evenRounds == completed)
        val red = FighterTacticalState(
            fighterId = redId,
            stamina = redStamina,
            fatigue = 100.0 - redStamina,
            headDamage = redHeadDamage,
            bodyDamage = redBodyDamage,
            stability = redStability,
            knockdownsScored = 0,
            knockdownsSuffered = 0,
            estimatedRoundsWon = redWins,
            estimatedRoundsLost = blueWins,
            estimatedEvenRounds = evenRounds,
            recentMomentumScore = if (momentumMargin >= 0) momentumMargin else 0.0,
        )
        val blue = FighterTacticalState(
            fighterId = blueId,
            stamina = blueStamina,
            fatigue = 100.0 - blueStamina,
            headDamage = blueHeadDamage,
            bodyDamage = blueBodyDamage,
            stability = blueStability,
            knockdownsScored = 0,
            knockdownsSuffered = 0,
            estimatedRoundsWon = blueWins,
            estimatedRoundsLost = redWins,
            estimatedEvenRounds = evenRounds,
            recentMomentumScore = if (momentumMargin < 0) -momentumMargin else 0.0,
        )
        val roundMargin = redWins - blueWins
        return TacticalStateSnapshot(
            completedRounds = completed,
            nextRoundNumber = nextRound,
            remainingRoundsIncludingNext = 4 - nextRound,
            remainingSequencesMaximum = (4 - nextRound) * 12,
            completedSequenceCount = completed * 12,
            red = red,
            blue = blue,
            estimatedLeaderId = when {
                roundMargin > 0 -> redId
                roundMargin < 0 -> blueId
                else -> null
            },
            estimatedRoundMargin = roundMargin,
            estimatedPerformanceMargin = performanceMargin,
            recentMomentumLeaderId = when {
                momentumMargin > TacticalStateSnapshotExtractor.MOMENTUM_TIE_MARGIN -> redId
                momentumMargin < -TacticalStateSnapshotExtractor.MOMENTUM_TIE_MARGIN -> blueId
                else -> null
            },
            recentMomentumMargin = momentumMargin,
        )
    }

    private fun boxerCatalogContainsExactlyTenUniqueProfiles() {
        val profiles = BoxerCatalog.all
        check(profiles.size == 10)
        check(profiles.map { it.id }.distinct().size == 10)
        check(profiles.map { it.name }.distinct().size == 10)
        check(profiles.map { it.nickname }.distinct().size == 10)
        check(TestProfiles.eliasVega === BoxerCatalog.eliasVega)
        check(TestProfiles.brunoKessler === BoxerCatalog.brunoKessler)
    }

    private fun boxerCatalogCoversEveryStyleAndStance() {
        check(BoxerCatalog.all.map { it.style }.toSet() == BoxingStyle.entries.toSet())
        check(BoxerCatalog.all.map { it.stance }.toSet() == Stance.entries.toSet())
        BoxingStyle.entries.forEach { style ->
            check(BoxerCatalog.profilesFor(style).isNotEmpty())
            check(BoxerCatalog.profilesFor(style).all { it.style == style })
        }
    }

    private fun everyProfileHasValidPhysicalDimensions() {
        BoxerCatalog.all.forEach { profile ->
            check(profile.heightCm in 150..220)
            check(profile.reachCm in 150..230)
            check(kotlin.math.abs(profile.reachCm - profile.heightCm) <= 25)
        }
        check(runCatching { BoxerCatalog.eliasVega.copy(id = "invalid dimensions", heightCm = 149) }.isFailure)
        check(runCatching { BoxerCatalog.eliasVega.copy(id = "invalid-reach", reachCm = 231) }.isFailure)
    }

    private fun primaryAndSecondaryStatsRemainCompleteAndBounded() {
        BoxerCatalog.all.forEach { profile ->
            check(profile.primaryStats.size == 6)
            check(profile.secondaryStats.size == 6)
            check((profile.primaryStats + profile.secondaryStats).all { it in 1..100 })
        }
        check(runCatching { BoxerCatalog.eliasVega.copy(id = "invalid-stat", power = 101) }.isFailure)
    }

    private fun preferredRangesMatchStyleAnchors() {
        BoxerCatalog.all.forEach { profile ->
            val expected = when (profile.style) {
                BoxingStyle.OUT_BOXER, BoxingStyle.DEFENSIVE_SPECIALIST -> FightRange.OUTSIDE
                BoxingStyle.PRESSURE_FIGHTER, BoxingStyle.SWARMER -> FightRange.INSIDE
                BoxingStyle.COUNTERPUNCHER, BoxingStyle.BOXER_PUNCHER, BoxingStyle.SLUGGER -> FightRange.MID
            }
            check(profile.preferredRange == expected)
            check(TacticalPlanCatalog.naturalFor(profile).anchorStyle == profile.style)
        }
    }

    private fun catalogLookupIsStableAndRejectsUnknownIds() {
        BoxerCatalog.all.forEach { profile ->
            check(BoxerCatalog.findById(profile.id) === profile)
            check(BoxerCatalog.requireById(profile.id) === profile)
        }
        check(BoxerCatalog.findById("unknown-boxer") == null)
        check(runCatching { BoxerCatalog.requireById("unknown-boxer") }.isFailure)
    }

    private fun legacyTwoFighterBehaviorRemainsUnchangedAfterRosterExpansion() {
        val result = Jalon5Step1Auditor.run()
        Jalon5Step1Auditor.assertValid(result)
        check(result.legacyBehaviorFingerprintMismatches == 0)
    }


    private fun rosterIdentityAuditIsCompleteAndReproducible() {
        Jalon5Step2Auditor.assertIntegrity(jalon5Step2Audit)
        check(jalon5Step2Audit.profiles.size == 10)
        check(jalon5Step2Audit.profiles.sumOf { it.rounds } == 3_600)
        check(jalon5Step2Audit.reproducibilityChecks == 120)
        check(jalon5Step2Audit.reproducibilityMismatches == 0)
        check(jalon5Step2Audit.invalidMetricCount == 0)
    }

    private fun naturalPlansAreAppliedWithoutDriftDuringIdentityAudit() {
        check(jalon5Step2Audit.missingNaturalPlans == 0)
        check(jalon5Step2Audit.wrongAppliedPlans == 0)
        jalon5Step2Audit.profiles.forEach { profile ->
            check(profile.naturalPlanId == TacticalPlanCatalog.naturalFor(profile.style).id)
        }
    }

    private fun allTenProfilesHaveDistinctStatisticalSignatures() {
        check(jalon5Step2Audit.indistinguishablePairs.isEmpty())
        check(jalon5Step2Audit.profiles.map { it.fighterId }.distinct().size == 10)
    }

    private fun paceTargetAndCoreTraitsRemainVisible() {
        check(jalon5Step2Audit.averageAttacks(TacticalPace.SUSTAINED) > jalon5Step2Audit.averageAttacks(TacticalPace.MEASURED))
        check(jalon5Step2Audit.averageAttacks(TacticalPace.MEASURED) > jalon5Step2Audit.averageAttacks(TacticalPace.CAUTIOUS))

        val bodyTarget = jalon5Step2Audit.byStyle(BoxingStyle.PRESSURE_FIGHTER).map { it.bodyAttemptShare }.average()
        val closeMixed = jalon5Step2Audit.byStyle(BoxingStyle.SWARMER).single().bodyAttemptShare
        check(bodyTarget > closeMixed + 0.12)

        val defensive = jalon5Step2Audit.profile(BoxerCatalog.kenjiMori.id)
        val slugger = jalon5Step2Audit.profile(BoxerCatalog.viktorSokolov.id)
        val swarmer = jalon5Step2Audit.profile(BoxerCatalog.dariusCole.id)
        check(defensive.defensiveSuccessRate >= jalon5Step2Audit.profiles.map { it.defensiveSuccessRate }.average())
        check(slugger.averageImpact >= jalon5Step2Audit.profiles.map { it.averageImpact }.average())
        check(swarmer.attacksPerRound >= jalon5Step2Audit.profiles.map { it.attacksPerRound }.average())
    }

    private fun mediumRangeIdentityIsRestoredBeforeMatchupMatrix() {
        check(jalon5Step2Audit.identityAccepted)
        check(jalon5Step2Audit.dominantRangeMismatches.isEmpty())
        check(jalon5Step2Audit.acceptanceIssues.isEmpty())
        check(jalon5Step2Audit.averagePreferredRangeShare(TacticalDistance.MEDIUM) >= 0.30)
        check(jalon5Step2Audit.averagePreferredRangeShare(TacticalDistance.LONG) >= 0.60)
        check(jalon5Step2Audit.averagePreferredRangeShare(TacticalDistance.CLOSE) >= 0.55)
        listOf(
            BoxerCatalog.malikOkoro,
            BoxerCatalog.tomasAranda,
            BoxerCatalog.viktorSokolov,
            BoxerCatalog.mateoSilva,
        ).forEach { profile ->
            check(jalon5Step2Audit.profile(profile.id).dominantRange == FightRange.MID)
        }
    }

    private fun identityAuditPreservesHistoricalTwoFighterBehavior() {
        check(jalon5Step2Audit.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun matchupMatrixCoversAllFortyFiveUniqueDuels() {
        Jalon5Step3Auditor.assertTechnicalIntegrity(jalon5Step3Audit)
        check(jalon5Step3Audit.matchups.size == 45)
        check(jalon5Step3Audit.totalFights == 9_000)
        check(jalon5Step3Audit.matchups.map { setOf(it.fighterAId, it.fighterBId) }.distinct().size == 45)
    }

    private fun matchupMatrixAlternatesCornersExactly() {
        jalon5Step3Audit.boxers.forEach { boxer ->
            check(boxer.fights == 1_800)
            check(boxer.redAppearances == 900)
            check(boxer.blueAppearances == 900)
        }
        check(jalon5Step3Audit.matchups.all { it.seedPairs == 100 && it.fights == 200 })
    }

    private fun matchupMatrixIsDeterministicAcrossPairedReplays() {
        check(jalon5Step3Audit.reproducibilityChecks == 180)
        check(jalon5Step3Audit.reproducibilityMismatches == 0)
    }

    private fun matchupMatrixContainsOnlyValidOfficialOutcomes() {
        check(jalon5Step3Audit.invalidResults == 0)
        check(jalon5Step3Audit.redWins + jalon5Step3Audit.blueWins + jalon5Step3Audit.draws == 9_000)
        check(jalon5Step3Audit.ko + jalon5Step3Audit.tko + jalon5Step3Audit.decisions == 9_000)
        check(jalon5Step3Audit.matchups.all { it.fighterAWins + it.fighterBWins + it.draws == 200 })
    }

    private fun matchupMatrixKeepsTacticalPlansAttachedAndStopsFinal() {
        check(jalon5Step3Audit.missingAppliedPlans == 0)
        check(jalon5Step3Audit.planDecisionMismatches == 0)
        check(jalon5Step3Audit.decisionsAfterStoppage == 0)
    }

    private fun matchupMatrixProducesCompleteBoxerAndStyleSummaries() {
        check(jalon5Step3Audit.boxers.map { it.fighterId }.toSet() == BoxerCatalog.all.map { it.id }.toSet())
        check(jalon5Step3Audit.styles.map { it.style }.toSet() == BoxingStyle.entries.toSet())
        check(jalon5Step3Audit.styles.sumOf { it.appearances } == 18_000)
        check(jalon5Step3Audit.matchups.all { it.pairedSameWinner + it.pairedDifferentWinner + it.pairedContainsDraw == 100 })
    }

    private fun matchupMatrixPreservesHistoricalTwoFighterBehavior() {
        check(jalon5Step3Audit.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun calibratedRosterKeepsTechnicalIntegrity() {
        Jalon5Step4Auditor.assertAccepted(jalon5Step4Audit)
        check(jalon5Step4Audit.matrix.technicalIntegrityAccepted)
        check(jalon5Step4Audit.matrix.totalFights == 9_000)
        check(jalon5Step4Audit.matrix.reproducibilityMismatches == 0)
        check(jalon5Step4Audit.matrix.invalidResults == 0)
    }

    private fun calibrationBringsEveryBoxerIntoCompetitiveBand() {
        check(jalon5Step4Audit.boxerOutliersBefore == 5)
        check(jalon5Step4Audit.boxerOutliersAfter == 0)
        check(jalon5Step4Audit.matrix.boxers.all { it.nonDrawWinShare in 0.30..0.70 })
        check(jalon5Step4Audit.matrix.boxers.all { it.wins > 0 && it.losses > 0 })
    }

    private fun calibrationBringsEveryStyleIntoCompetitiveBand() {
        check(jalon5Step4Audit.styleOutliersBefore == 5)
        check(jalon5Step4Audit.styleOutliersAfter == 0)
        check(jalon5Step4Audit.matrix.styles.all { it.nonDrawWinShare in 0.35..0.65 })
        check(jalon5Step4Audit.matrix.styles.all { it.wins > 0 && it.losses > 0 })
    }

    private fun calibrationReducesRosterAndStyleDispersion() {
        check(jalon5Step4Audit.boxerSpreadAfter < jalon5Step4Audit.boxerSpreadBefore * 0.40)
        check(jalon5Step4Audit.styleSpreadAfter < jalon5Step4Audit.styleSpreadBefore * 0.40)
    }

    private fun calibratedRosterPreservesStatisticalIdentity() {
        Jalon5Step2Auditor.assertIntegrity(jalon5Step4Audit.identity)
        check(jalon5Step4Audit.identityPreserved)
        check(jalon5Step4Audit.identity.dominantRangeMismatches.isEmpty())
        check(jalon5Step4Audit.identity.indistinguishablePairs.isEmpty())
    }

    private fun calibratedRosterHasNoPersistentCornerBias() {
        check(jalon5Step4Audit.cornerNeutral)
        check(jalon5Step4Audit.matrix.redWinnerShare in 0.48..0.52)
        check(jalon5Step4Audit.maxBoxerCornerGap <= 0.08)
    }

    private fun calibrationPreservesHistoricalProfilesAndBehavior() {
        check(jalon5Step4Audit.historicalProfilesUnchanged)
        check(jalon5Step4Audit.approvedCalibratedProfileIds.size == 7)
        check(jalon5Step4Audit.matrix.legacyBehaviorFingerprintMismatches == 0)
    }

}
