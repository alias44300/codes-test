package titlefight

enum class ScorecardVerdict {
    RED,
    BLUE,
    DRAW,
}

enum class OfficialDecisionType(val frenchLabel: String) {
    UNANIMOUS_DECISION("décision unanime"),
    SPLIT_DECISION("décision partagée"),
    MAJORITY_DECISION("décision majoritaire"),
    UNANIMOUS_DRAW("match nul unanime"),
    MAJORITY_DRAW("match nul majoritaire"),
    SPLIT_DRAW("match nul partagé"),
}

/** Carte complète d'un juge sur les trois rounds arrivés à leur terme. */
data class JudgeScorecard(
    val judgeId: String,
    val judgeName: String,
    val judgeFocus: String,
    val redFighterId: String,
    val blueFighterId: String,
    val rounds: List<JudgeRoundScore>,
    val redTotal: Int,
    val blueTotal: Int,
    val verdict: ScorecardVerdict,
    val winnerId: String?,
    val explanation: String,
) {
    init {
        require(judgeId.isNotBlank())
        require(judgeName.isNotBlank())
        require(judgeFocus.isNotBlank())
        require(redFighterId.isNotBlank())
        require(blueFighterId.isNotBlank())
        require(redFighterId != blueFighterId)
        require(rounds.size == 3) { "Une carte officielle doit contenir exactement trois rounds terminés." }
        require(rounds.map { it.roundNumber } == listOf(1, 2, 3))
        require(rounds.all { it.judgeId == judgeId })
        require(rounds.all { it.redFighterId == redFighterId && it.blueFighterId == blueFighterId })
        require(redTotal == rounds.sumOf { it.redPoints })
        require(blueTotal == rounds.sumOf { it.bluePoints })
        require(redTotal in 21..30)
        require(blueTotal in 21..30)
        require(explanation.isNotBlank())

        when (verdict) {
            ScorecardVerdict.RED -> {
                require(redTotal > blueTotal)
                require(winnerId == redFighterId)
            }
            ScorecardVerdict.BLUE -> {
                require(blueTotal > redTotal)
                require(winnerId == blueFighterId)
            }
            ScorecardVerdict.DRAW -> {
                require(redTotal == blueTotal)
                require(winnerId == null)
            }
        }
    }
}

/** Résultat officiel des trois juges pour un combat arrivé à la distance. */
data class OfficialDecision(
    val type: OfficialDecisionType,
    val redFighterId: String,
    val blueFighterId: String,
    val winnerId: String?,
    val loserId: String?,
    val redCards: Int,
    val blueCards: Int,
    val drawCards: Int,
    val scorecards: List<JudgeScorecard>,
    val explanation: String,
) {
    init {
        require(redFighterId.isNotBlank())
        require(blueFighterId.isNotBlank())
        require(redFighterId != blueFighterId)
        require(scorecards.size == 3)
        require(scorecards.map { it.judgeId } == JudgeProfiles.ALL.map { it.id })
        require(scorecards.all { it.redFighterId == redFighterId && it.blueFighterId == blueFighterId })
        require(redCards == scorecards.count { it.verdict == ScorecardVerdict.RED })
        require(blueCards == scorecards.count { it.verdict == ScorecardVerdict.BLUE })
        require(drawCards == scorecards.count { it.verdict == ScorecardVerdict.DRAW })
        require(redCards + blueCards + drawCards == 3)
        require(explanation.isNotBlank())

        when (type) {
            OfficialDecisionType.UNANIMOUS_DECISION -> {
                require(drawCards == 0)
                require(redCards == 3 || blueCards == 3)
                requireWinnerAndLoser()
            }
            OfficialDecisionType.SPLIT_DECISION -> {
                require(drawCards == 0)
                require((redCards == 2 && blueCards == 1) || (blueCards == 2 && redCards == 1))
                requireWinnerAndLoser()
            }
            OfficialDecisionType.MAJORITY_DECISION -> {
                require(drawCards == 1)
                require(redCards == 2 || blueCards == 2)
                requireWinnerAndLoser()
            }
            OfficialDecisionType.UNANIMOUS_DRAW -> {
                require(drawCards == 3)
                requireDraw()
            }
            OfficialDecisionType.MAJORITY_DRAW -> {
                require(drawCards == 2)
                require(redCards + blueCards == 1)
                requireDraw()
            }
            OfficialDecisionType.SPLIT_DRAW -> {
                require(drawCards == 1 && redCards == 1 && blueCards == 1)
                requireDraw()
            }
        }
    }

    val isDraw: Boolean get() = winnerId == null

    private fun requireWinnerAndLoser() {
        require(winnerId in setOf(redFighterId, blueFighterId))
        require(loserId in setOf(redFighterId, blueFighterId))
        require(winnerId != loserId)
        val expectedWinner = if (redCards > blueCards) redFighterId else blueFighterId
        val expectedLoser = if (expectedWinner == redFighterId) blueFighterId else redFighterId
        require(winnerId == expectedWinner)
        require(loserId == expectedLoser)
    }

    private fun requireDraw() {
        require(winnerId == null)
        require(loserId == null)
    }
}

object OfficialDecisionResolver {
    fun resolve(redFighterId: String, blueFighterId: String, rounds: List<RoundResult>): OfficialDecision {
        require(redFighterId != blueFighterId)
        require(rounds.size == 3) { "Une décision aux points exige trois rounds terminés." }
        require(rounds.map { it.roundNumber } == listOf(1, 2, 3))
        require(rounds.all { it.stoppage == null }) { "Aucune décision aux points ne peut remplacer un KO ou un TKO." }
        require(rounds.all { it.judgeScores.size == 3 })

        val scorecards = JudgeProfiles.ALL.map { profile ->
            val scores = rounds.map { round ->
                round.judgeScores.single { it.judgeId == profile.id }
            }
            buildScorecard(profile, redFighterId, blueFighterId, scores)
        }

        val redCards = scorecards.count { it.verdict == ScorecardVerdict.RED }
        val blueCards = scorecards.count { it.verdict == ScorecardVerdict.BLUE }
        val drawCards = scorecards.count { it.verdict == ScorecardVerdict.DRAW }

        val type = classify(redCards, blueCards, drawCards)

        val winnerId = when {
            redCards >= 2 -> redFighterId
            blueCards >= 2 -> blueFighterId
            else -> null
        }
        val loserId = when (winnerId) {
            redFighterId -> blueFighterId
            blueFighterId -> redFighterId
            else -> null
        }

        return OfficialDecision(
            type = type,
            redFighterId = redFighterId,
            blueFighterId = blueFighterId,
            winnerId = winnerId,
            loserId = loserId,
            redCards = redCards,
            blueCards = blueCards,
            drawCards = drawCards,
            scorecards = scorecards,
            explanation = decisionExplanation(type, winnerId, redFighterId, redCards, blueCards, drawCards),
        )
    }


    fun classify(redCards: Int, blueCards: Int, drawCards: Int): OfficialDecisionType {
        require(redCards >= 0 && blueCards >= 0 && drawCards >= 0)
        require(redCards + blueCards + drawCards == 3)
        return when {
            redCards == 3 || blueCards == 3 -> OfficialDecisionType.UNANIMOUS_DECISION
            drawCards == 0 && (redCards == 2 || blueCards == 2) -> OfficialDecisionType.SPLIT_DECISION
            drawCards == 1 && (redCards == 2 || blueCards == 2) -> OfficialDecisionType.MAJORITY_DECISION
            drawCards == 3 -> OfficialDecisionType.UNANIMOUS_DRAW
            drawCards == 2 -> OfficialDecisionType.MAJORITY_DRAW
            redCards == 1 && blueCards == 1 && drawCards == 1 -> OfficialDecisionType.SPLIT_DRAW
            else -> error("Combinaison de cartes impossible : rouge=$redCards, bleu=$blueCards, nul=$drawCards")
        }
    }

    private fun buildScorecard(
        profile: JudgeProfile,
        redFighterId: String,
        blueFighterId: String,
        rounds: List<JudgeRoundScore>,
    ): JudgeScorecard {
        val redTotal = rounds.sumOf { it.redPoints }
        val blueTotal = rounds.sumOf { it.bluePoints }
        val verdict = when {
            redTotal > blueTotal -> ScorecardVerdict.RED
            blueTotal > redTotal -> ScorecardVerdict.BLUE
            else -> ScorecardVerdict.DRAW
        }
        val winnerId = when (verdict) {
            ScorecardVerdict.RED -> redFighterId
            ScorecardVerdict.BLUE -> blueFighterId
            ScorecardVerdict.DRAW -> null
        }
        val verdictText = when (verdict) {
            ScorecardVerdict.RED -> "coin rouge"
            ScorecardVerdict.BLUE -> "coin bleu"
            ScorecardVerdict.DRAW -> "égalité"
        }
        return JudgeScorecard(
            judgeId = profile.id,
            judgeName = profile.name,
            judgeFocus = profile.focus,
            redFighterId = redFighterId,
            blueFighterId = blueFighterId,
            rounds = rounds,
            redTotal = redTotal,
            blueTotal = blueTotal,
            verdict = verdict,
            winnerId = winnerId,
            explanation = "${profile.name} (${profile.focus}) : $redTotal-$blueTotal, verdict $verdictText.",
        )
    }

    private fun decisionExplanation(
        type: OfficialDecisionType,
        winnerId: String?,
        redFighterId: String,
        redCards: Int,
        blueCards: Int,
        drawCards: Int,
    ): String {
        val cards = "cartes rouge $redCards, bleu $blueCards, nulles $drawCards"
        return if (winnerId == null) {
            "${type.frenchLabel.replaceFirstChar { it.uppercase() }} : $cards."
        } else {
            val corner = if (winnerId == redFighterId) "coin rouge" else "coin bleu"
            "${type.frenchLabel.replaceFirstChar { it.uppercase() }} pour le $corner : $cards."
        }
    }
}
