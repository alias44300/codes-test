# Jalon 7 — Étape 1 — Base locale et narration enrichie

## Objectif

Remplacer le catalogue de démonstration codé en dur par une fondation locale extensible, jouable et versionnée, tout en enrichissant les commentaires sans modifier les probabilités du moteur validé.

## Base de boxeurs

- module Android `data-local` fondé sur `SQLiteOpenHelper` ;
- base hors ligne `title_fight_roster.db` ;
- sept tables : métadonnées, boxeurs, versions, notes, tendances, actions signatures et traits ;
- version de schéma 1 ;
- version de contenu `heavyweight-pilot-2026-07-21` ;
- vingt versions historiques poids lourds ;
- vingt-huit notes avancées par version ;
- neuf tendances comportementales ;
- trois actions signatures et trois traits par boxeur ;
- recherche locale par nom, surnom ou pays ;
- conversion déterministe vers le contrat `BoxerProfile` du moteur.

## Lot historique pilote

Muhammad Ali, Joe Louis, Mike Tyson, George Foreman, Rocky Marciano, Lennox Lewis, Evander Holyfield, Oleksandr Usyk, Joe Frazier, Larry Holmes, Jack Johnson, Jack Dempsey, Sonny Liston, Floyd Patterson, Wladimir Klitschko, Vitali Klitschko, Riddick Bowe, Tyson Fury, Deontay Wilder et Ezzard Charles.

Les notes constituent un calibrage de gameplay TITLE FIGHT. Les données historiques détaillées devront subir un audit documentaire avant la fermeture du roster final de 321 boxeurs.

## Sélection jouable

L'application charge désormais le roster depuis SQLite. Un écran permet :

- de rechercher un boxeur ;
- d'affecter un boxeur au coin rouge ;
- d'affecter un autre boxeur au coin bleu ;
- de lancer le combat interactif existant ;
- de conserver les décisions tactiques entre les rounds.

## Moteur narratif

`NarrativeCommentaryEngine` produit deux à cinq lignes par événement sportif :

1. installation et positionnement ;
2. attaque ;
3. défense ou impact ;
4. conséquence physique ou tactique ;
5. compte ou arrêt lorsque nécessaire.

La couche est strictement observationnelle. Elle n'utilise pas `DeterministicRandom`, ne déclenche aucune simulation et ne modifie aucune probabilité.

## Validation

- 26 contrôles statiques réussis ;
- 12 tests spécifiques réussis ;
- 20 profils historiques valides ;
- 190 affrontements uniques simulés ;
- 6 833 événements sportifs ;
- 21 126 lignes narratives ;
- 3 746 lignes narratives uniques ;
- 0 divergence déterministe ;
- intégrité SQLite : `ok` ;
- 0 erreur de clé étrangère ;
- 36 tests historiques des étapes 1, 3 et 4 du jalon 6 toujours réussis ;
- dix fichiers sportifs critiques strictement identiques à l'archive Android validée.

## Limites conservées

- le moteur sportif reste limité à trois rounds ;
- le lot pilote ne couvre encore que les poids lourds ;
- les notes avancées ne pilotent pas encore toutes directement les probabilités ;
- les coupures, fautes, médecin, clinch sportif et position réelle dans le ring restent narratifs, pas encore mécaniques ;
- aucune compilation Android de cette nouvelle étape n'a encore été exécutée.

## Prochaine étape

Jalon 7 étape 2 : compiler le nouveau projet Android, vérifier la création et la migration SQLite, exécuter les tests instrumentés, puis produire un APK contenant le sélecteur de vingt boxeurs et la narration enrichie.
