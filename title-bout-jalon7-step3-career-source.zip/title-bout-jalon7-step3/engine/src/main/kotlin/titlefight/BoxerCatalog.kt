package titlefight

/**
 * Catalogue fictif du prototype TITLE FIGHT.
 *
 * Le catalogue ne contient encore aucun boxeur réel. Les dix profils utilisent
 * exactement le même modèle de données et les mêmes règles de validation.
 */
object BoxerCatalog {
    val eliasVega = BoxerProfile(
        id = "elias-vega",
        name = "Elias Vega",
        nickname = "The Comet",
        stance = Stance.ORTHODOX,
        style = BoxingStyle.OUT_BOXER,
        preferredRange = FightRange.OUTSIDE,
        heightCm = 182,
        reachCm = 188,
        power = 74,
        speed = 92,
        technique = 89,
        defense = 88,
        endurance = 84,
        mental = 86,
        chin = 78,
        recovery = 84,
        accuracy = 90,
        mobility = 94,
        bodyResistance = 77,
        aggression = 62,
    )

    val brunoKessler = BoxerProfile(
        id = "bruno-kessler",
        name = "Bruno Kessler",
        nickname = "The Anvil",
        stance = Stance.ORTHODOX,
        style = BoxingStyle.PRESSURE_FIGHTER,
        preferredRange = FightRange.INSIDE,
        heightCm = 180,
        reachCm = 183,
        power = 92,
        speed = 73,
        technique = 80,
        defense = 76,
        endurance = 91,
        mental = 90,
        chin = 94,
        recovery = 92,
        accuracy = 82,
        mobility = 70,
        bodyResistance = 93,
        aggression = 95,
    )

    val malikOkoro = BoxerProfile(
        id = "malik-okoro",
        name = "Malik Okoro",
        nickname = "The Mirage",
        stance = Stance.SOUTHPAW,
        style = BoxingStyle.COUNTERPUNCHER,
        preferredRange = FightRange.MID,
        heightCm = 184,
        reachCm = 191,
        power = 84,
        speed = 91,
        technique = 94,
        defense = 92,
        endurance = 87,
        mental = 92,
        chin = 84,
        recovery = 88,
        accuracy = 95,
        mobility = 90,
        bodyResistance = 82,
        aggression = 72,
    )

    val tomasAranda = BoxerProfile(
        id = "tomas-aranda",
        name = "Tomas Aranda",
        nickname = "El Relámpago",
        stance = Stance.ORTHODOX,
        style = BoxingStyle.BOXER_PUNCHER,
        preferredRange = FightRange.MID,
        heightCm = 179,
        reachCm = 182,
        power = 87,
        speed = 85,
        technique = 90,
        defense = 84,
        endurance = 85,
        mental = 87,
        chin = 84,
        recovery = 85,
        accuracy = 90,
        mobility = 84,
        bodyResistance = 83,
        aggression = 72,
    )

    val dariusCole = BoxerProfile(
        id = "darius-cole",
        name = "Darius Cole",
        nickname = "The Furnace",
        stance = Stance.ORTHODOX,
        style = BoxingStyle.SWARMER,
        preferredRange = FightRange.INSIDE,
        heightCm = 173,
        reachCm = 175,
        power = 76,
        speed = 85,
        technique = 80,
        defense = 73,
        endurance = 86,
        mental = 86,
        chin = 84,
        recovery = 85,
        accuracy = 73,
        mobility = 84,
        bodyResistance = 86,
        aggression = 96,
    )

    val viktorSokolov = BoxerProfile(
        id = "viktor-sokolov",
        name = "Viktor Sokolov",
        nickname = "Iron Bell",
        stance = Stance.ORTHODOX,
        style = BoxingStyle.SLUGGER,
        preferredRange = FightRange.MID,
        heightCm = 189,
        reachCm = 194,
        power = 96,
        speed = 82,
        technique = 88,
        defense = 79,
        endurance = 89,
        mental = 90,
        chin = 93,
        recovery = 90,
        accuracy = 91,
        mobility = 78,
        bodyResistance = 91,
        aggression = 84,
    )

    val kenjiMori = BoxerProfile(
        id = "kenji-mori",
        name = "Kenji Mori",
        nickname = "The Lock",
        stance = Stance.SOUTHPAW,
        style = BoxingStyle.DEFENSIVE_SPECIALIST,
        preferredRange = FightRange.OUTSIDE,
        heightCm = 177,
        reachCm = 183,
        power = 80,
        speed = 94,
        technique = 96,
        defense = 96,
        endurance = 90,
        mental = 94,
        chin = 86,
        recovery = 91,
        accuracy = 95,
        mobility = 96,
        bodyResistance = 86,
        aggression = 74,
    )

    val lucaMoretti = BoxerProfile(
        id = "luca-moretti",
        name = "Luca Moretti",
        nickname = "The Maestro",
        stance = Stance.SWITCH,
        style = BoxingStyle.OUT_BOXER,
        preferredRange = FightRange.OUTSIDE,
        heightCm = 181,
        reachCm = 187,
        power = 76,
        speed = 89,
        technique = 94,
        defense = 86,
        endurance = 83,
        mental = 90,
        chin = 77,
        recovery = 83,
        accuracy = 92,
        mobility = 91,
        bodyResistance = 79,
        aggression = 64,
    )

    val idrisKane = BoxerProfile(
        id = "idris-kane",
        name = "Idris Kane",
        nickname = "Black Tide",
        stance = Stance.SOUTHPAW,
        style = BoxingStyle.PRESSURE_FIGHTER,
        preferredRange = FightRange.INSIDE,
        heightCm = 181,
        reachCm = 185,
        power = 80,
        speed = 81,
        technique = 80,
        defense = 74,
        endurance = 84,
        mental = 85,
        chin = 85,
        recovery = 84,
        accuracy = 75,
        mobility = 76,
        bodyResistance = 87,
        aggression = 95,
    )

    val mateoSilva = BoxerProfile(
        id = "mateo-silva",
        name = "Mateo Silva",
        nickname = "The Switchblade",
        stance = Stance.SWITCH,
        style = BoxingStyle.BOXER_PUNCHER,
        preferredRange = FightRange.MID,
        heightCm = 178,
        reachCm = 184,
        power = 85,
        speed = 87,
        technique = 90,
        defense = 87,
        endurance = 83,
        mental = 86,
        chin = 82,
        recovery = 83,
        accuracy = 93,
        mobility = 88,
        bodyResistance = 81,
        aggression = 70,
    )

    val all: List<BoxerProfile> = listOf(
        eliasVega,
        brunoKessler,
        malikOkoro,
        tomasAranda,
        dariusCole,
        viktorSokolov,
        kenjiMori,
        lucaMoretti,
        idrisKane,
        mateoSilva,
    )

    private val byId: Map<String, BoxerProfile> = all.associateBy { it.id }

    init {
        require(all.size == 10) { "Le prototype doit contenir exactement dix boxeurs." }
        require(byId.size == all.size) { "Chaque boxeur doit posséder un identifiant unique." }
        require(all.map { it.name }.distinct().size == all.size) { "Chaque nom de boxeur doit être unique." }
        require(all.map { it.nickname }.distinct().size == all.size) { "Chaque surnom doit être unique." }
        require(all.map { it.style }.toSet() == BoxingStyle.entries.toSet()) {
            "Les sept styles du prototype doivent être représentés."
        }
        require(all.map { it.stance }.toSet() == Stance.entries.toSet()) {
            "Les trois gardes du prototype doivent être représentées."
        }
        require(all.all { it.preferredRange == naturalRangeFor(it.style) }) {
            "La distance préférée doit rester cohérente avec le style naturel du profil."
        }
    }

    fun findById(id: String): BoxerProfile? = byId[id]

    fun requireById(id: String): BoxerProfile = requireNotNull(findById(id)) {
        "Boxeur inconnu : $id"
    }

    fun profilesFor(style: BoxingStyle): List<BoxerProfile> = all.filter { it.style == style }

    private fun naturalRangeFor(style: BoxingStyle): FightRange = when (style) {
        BoxingStyle.OUT_BOXER, BoxingStyle.DEFENSIVE_SPECIALIST -> FightRange.OUTSIDE
        BoxingStyle.PRESSURE_FIGHTER, BoxingStyle.SWARMER -> FightRange.INSIDE
        BoxingStyle.COUNTERPUNCHER, BoxingStyle.BOXER_PUNCHER, BoxingStyle.SLUGGER -> FightRange.MID
    }
}
