# HORRIVALS — prototype de combat de cartes Godot 4

Prototype jouable 5 cartes contre 5 pensé comme base technique pour HORRIVALS.

## Ce qui fonctionne

- Main de 5 cartes du joueur et 5 cartes IA.
- Cartes IA face cachée jusqu'à leur entrée dans l'arène.
- Survol / sélection / montée de carte.
- Sélection tactile ou souris.
- Entrée animée des deux cartes dans l'arène.
- Flip de la carte IA.
- Animation de charge / attaque.
- Secousse à l'impact.
- Flash d'impact et panneau de résultat.
- Sortie animée vers la défausse.
- Premier à 3 manches, maximum 5 manches.
- Rôles Attaquant / Défenseur alternés.
- Égalité gagnée par le Défenseur.
- 10 Effroi au départ.
- 0 à 3 Effroi dépensables par duel.
- +4 par Effroi sur la statistique utilisée.
- IA locale simple.
- Bouton Recommencer.

## Données actuellement verrouillées dans le prototype

| Carte | Attaque | Défense | Menace |
|---|---:|---:|---:|
| HOR-001 Freddy Krueger | 88 | 84 | 8 |
| HOR-002 Jason Voorhees | 80 | 88 | 8 |
| HOR-003 Michael Myers | 62 | 78 | 6 |
| HOR-005 Ghostface | 52 | 38 | 3 |
| HOR-008 Pinhead | 95 | 94 | 10 |

Les données sont dans `data/cards.json`. Les valeurs affichées par l'interface viennent de ce fichier, pas des chiffres éventuellement intégrés dans d'anciens PNG.

## Lancer

1. Installer Godot 4.x.
2. Ouvrir le dossier du projet dans Godot.
3. Ouvrir `project.godot`.
4. Appuyer sur **F6/F5 / Play**.

La fenêtre cible est en 1280×720 paysage et le projet utilise le renderer Compatibility pour faciliter les exports Android/Web.

## Contrôles

1. Cliquer/toucher une carte.
2. Régler l'Effroi avec `−` et `+`.
3. Appuyer sur **COMBATTRE**.
4. Les deux cartes entrent dans l'arène et le duel se résout automatiquement.

## Architecture

- `scripts/card_view.gd` : affichage, sélection et animations d'une carte.
- `scripts/main.gd` : match, IA, règles, Effroi, score et orchestration des animations.
- `data/cards.json` : données des cartes.
- `assets/cards/` : illustrations.

## Important

Ce prototype est volontairement indépendant du code OpenCards. OpenCards sert de référence d'architecture et prouve qu'un flux Godot joueur-vs-IA avec animations ordonnées fonctionne, mais cette base HORRIVALS reste beaucoup plus petite et directement adaptée au 5v5. Cela évite d'importer le deck-builder, le crédit, le HQ, les Support Lines et les autres systèmes inutiles.

Les PNG inclus proviennent des assets HORRIVALS de la bibliothèque utilisateur. Certains anciens PNG peuvent contenir des chiffres dessinés qui ne correspondent plus au master actuel ; la bande noire de stats du prototype affiche les valeurs actuelles par-dessus.
