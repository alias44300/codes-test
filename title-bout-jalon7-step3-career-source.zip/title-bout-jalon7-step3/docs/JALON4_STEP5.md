# Jalon 4 — Étape 5 — Audit statistique final

## Méthode

L’audit utilise dix fenêtres indépendantes de 1 000 combats adaptatifs. Dans chaque fenêtre :

- 500 graines sont jouées deux fois avec inversion systématique des coins ;
- les deux profils conservent leurs tactiques de base ;
- les décisions adaptatives sont prises avant chaque round réellement simulé ;
- 200 combats sont comparés à un scénario apparié utilisant les plans naturels fixes ;
- les premières paires sont répétées pour contrôler la reproductibilité.

Un benchmark distinct exécute 900 combats : neuf plans fixes représentatifs, deux profils, cinquante combats par combinaison profil/plan, avec inversion des coins.

## Premier diagnostic

La première version intégrée favorisait excessivement Bruno Kessler, avec environ 85 % de victoires adaptatives. Le jalon n’a pas été validé à ce stade.

La correction s’est limitée au calibrage des mécanismes existants :

- suppression d’une branche alternative de résolution de distance qui remplaçait le comportement historique ;
- bonus de distance réduit ;
- biais de cible devenu additif ;
- amplitudes d’activité, précision, défense, impact et énergie réduites.

Aucun nouveau mécanisme tactique n’a été ajouté.

## Résultats finaux

- 10 000 combats adaptatifs ;
- 2 000 combats appariés avec plans naturels fixes ;
- 900 combats de benchmark de plans fixes ;
- 400 contrôles de reproductibilité ;
- 4 530 victoires rouges, 4 570 victoires bleues et 900 nuls ;
- 4 065 victoires Vega et 5 035 victoires Kessler ;
- 7 KO et 26 TKO ;
- 214 résultats modifiés sur 2 000 comparaisons appariées, soit 10,70 % ;
- 23 133 décisions inter-rounds modifiées sur 39 998, soit 57,84 %.

## Réactions contextuelles

- retard exploitable : 17 750 réponses entreprenantes sur 17 750 ;
- forte fatigue : 7 réductions cohérentes sur 7 ;
- danger physique : 425 réponses de sécurité sur 425 ;
- aucune décision après KO ou TKO.

## Biais de coin

- part du coin rouge parmi les combats avec vainqueur : 49,78 % ;
- Vega : 40,34 % de victoires depuis le rouge et 40,96 % depuis le bleu ;
- Kessler : 50,26 % depuis le rouge et 50,44 % depuis le bleu.

Aucun biais persistant du coin n’est détecté.

## Recherche d’une tactique dominante

Entre les rounds :

- Vega utilise neuf plans distincts ; son plan le plus fréquent représente 39,76 % des décisions ;
- Kessler utilise huit plans distincts ; son plan le plus fréquent représente 72,57 % des décisions.

Benchmark fixe :

- meilleur plan de Vega : `measured-long-safe-mixed`, 50,00 % de victoires ;
- meilleur plan de Kessler : `measured-medium-balanced-mixed`, 58,00 % de victoires ;
- aucun plan n’atteint 60 % de victoires pour les deux profils ;
- le meilleur plan n’est pas le même pour les deux profils.

Aucun plan universellement dominant n’est détecté dans le périmètre du duel fictif de trois rounds.

## Bandes d’acceptation internes

Ces bandes sont spécifiques à ce duel fictif, elles ne constituent pas des statistiques universelles de boxe :

- part du coin rouge parmi les résultats avec vainqueur : 47 à 53 % ;
- écart de taux de victoire d’un même profil selon le coin : 3 points maximum ;
- écart de victoires entre les deux profils : 12 % des combats maximum ;
- résultats modifiés face au plan naturel fixe : au moins 10 % ;
- décisions inter-rounds modifiées : 15 à 75 % ;
- réponse au retard : au moins 85 % ;
- réponse à la fatigue et au danger : au moins 80 % ;
- au moins trois plans entre les rounds par profil ;
- part du plan le plus fréquent : 80 % maximum ;
- aucun plan fixe à 60 % ou plus pour les deux profils.

Toutes les bandes sont respectées.
