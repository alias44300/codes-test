package titlefight.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(
    rosterCount: Int,
    databaseVersion: String,
    onQuickFight: () -> Unit,
    onCareer: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(
            text = "TITLE BOUT",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary,
        )
        Text(
            text = "Carrière de boxe et combats historiques hors ligne",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text("BASE D’ADVERSAIRES", fontWeight = FontWeight.Black)
                Text("$rosterCount adversaires historiques · 15 catégories")
                Text(databaseVersion, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Button(
            onClick = onQuickFight,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("COMBAT RAPIDE", fontWeight = FontWeight.Black)
        }
        Button(
            onClick = onCareer,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text("MODE CARRIÈRE", fontWeight = FontWeight.Black)
        }
    }
}
