# Jalon 4 — Étape 4 — Intégration tactique au moteur

## Objectif

Appliquer réellement les plans tactiques sélectionnés avant chaque round, tout en conservant un mode désactivé qui reproduit exactement le comportement historique.

## Activation

```kotlin
FightEngine(adaptiveTacticsEnabled = true)
```

Le constructeur par défaut conserve `adaptiveTacticsEnabled = false`.

## Effets appliqués

Chaque `TacticalPlan` agit de manière bornée sur :

- le contrôle de la distance recherchée ;
- l’initiative et le volume d’attaque ;
- la priorité tête ou corps ;
- la précision offensive ;
- la protection défensive ;
- l’impact des coups ;
- le coût énergétique des attaques.

`TacticalPlanApplication` centralise les transformations. Toutes ses fonctions sont pures, ne consomment aucun tirage aléatoire et rendent la valeur historique lorsqu’aucun plan n’est fourni.

## Calibration issue de l’audit final

Le premier passage de l’étape 5 a révélé un avantage excessif du pressure fighter. Aucun mécanisme supplémentaire n’a été ajouté. Les effets existants ont été recalibrés :

- conservation du résolveur historique des distances avec un bonus tactique limité ;
- biais de cible ajouté au choix de coups existant au lieu de remplacer entièrement sa distribution ;
- réduction des amplitudes appliquées à l’activité, la précision, la défense, l’impact et le coût énergétique ;
- maintien de l’activation explicite et du mode historique intact.

## Audit recalculé de l’étape 4

- 1 000 combats ;
- 3 000 rounds ;
- 35 991 séquences ;
- 6 000 décisions tactiques ;
- 6 000 plans appliqués ;
- 3 combats arrêtés ;
- 0 décision après arrêt ;
- 0 plan manquant ;
- 0 divergence entre décision et plan appliqué ;
- 0 écart de reproductibilité ;
- 200 combats sur 200 modifiés par rapport au mode désactivé ;
- 0 empreinte historique modifiée lorsque le mode reste désactivé.

## Effets observés après calibration

- coups au corps avec cible mixte : 1,12 % ;
- coups au corps avec cible corps : 46,42 % ;
- distance longue obtenue par un plan longue distance : 88,90 % ;
- distance moyenne obtenue par un plan moyenne distance : 30,43 % ;
- distance courte obtenue par un plan courte distance : 33,83 % ;
- initiatives moyennes par round, rythme mesuré / soutenu : 5,84 / 6,93 ;
- impact moyen, risque sûr / agressif : 6,67 / 9,63.

Le faible taux de coups au corps pour la cible mixte provient du style et des distances réellement rencontrées dans ce duel fictif. Le plan BODY conserve un effet net sans reconstruire artificiellement tout le répertoire de coups.

## Limites conservées

- deux boxeurs fictifs ;
- trois rounds maximum ;
- aucune interface Android ;
- aucun APK ;
- aucun nouveau boxeur ;
- aucun changement des règles de KO, TKO ou jugement.
