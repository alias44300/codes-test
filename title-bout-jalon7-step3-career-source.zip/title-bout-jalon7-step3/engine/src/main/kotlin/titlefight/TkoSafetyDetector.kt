package titlefight

data class TkoSafetyEvaluation(
    val eligible: Boolean,
    val latestThreat: Boolean,
    val sustainedDefensiveFailure: Boolean,
    val severeDamage: Boolean,
    val criticalStability: Boolean,
    val exhaustion: Boolean,
    val reason: String,
)

/**
 * Détecteur déterministe d'arrêt de sécurité pour le jalon 2, étape 4.
 *
 * Il n'utilise aucun tirage aléatoire. Un TKO exige simultanément :
 * - une nouvelle frappe menaçante, sans chute sur cette même séquence ;
 * - au moins trois échecs défensifs lourds consécutifs ;
 * - des dégâts sévères ;
 * - une stabilité critique ;
 * - une fatigue importante.
 */
object TkoSafetyDetector {
    const val MIN_FAILURE_STREAK = 3
    const val MAX_STABILITY = 42.0
    const val MAX_STAMINA = 55.0
    const val MIN_HEAD_DAMAGE = 50.0
    const val MIN_BODY_DAMAGE = 60.0
    const val MIN_CLEAN_IMPACT = 5.0
    const val MIN_HEAVY_IMPACT = 8.0

    fun evaluate(defenderState: FighterState, latestEvent: SequenceEvent): TkoSafetyEvaluation {
        val latestThreat = latestEvent.landed && latestEvent.knockdown == null &&
            ((latestEvent.clean && latestEvent.impact >= MIN_CLEAN_IMPACT) || latestEvent.impact >= MIN_HEAVY_IMPACT)
        val sustainedFailure = defenderState.defensiveFailureStreak >= MIN_FAILURE_STREAK
        val severeDamage = defenderState.headDamage >= MIN_HEAD_DAMAGE || defenderState.bodyDamage >= MIN_BODY_DAMAGE
        val criticalStability = defenderState.stability <= MAX_STABILITY
        val exhaustion = defenderState.stamina <= MAX_STAMINA
        val eligible = latestThreat && sustainedFailure && severeDamage && criticalStability && exhaustion

        val reason = if (eligible) {
            "absence de défense intelligente : ${defenderState.defensiveFailureStreak} impacts lourds sans réponse, " +
                "stabilité ${format(defenderState.stability)}, énergie ${format(defenderState.stamina)}, " +
                "dégâts tête ${format(defenderState.headDamage)}, corps ${format(defenderState.bodyDamage)}"
        } else {
            "seuils de sécurité non réunis"
        }

        return TkoSafetyEvaluation(
            eligible = eligible,
            latestThreat = latestThreat,
            sustainedDefensiveFailure = sustainedFailure,
            severeDamage = severeDamage,
            criticalStability = criticalStability,
            exhaustion = exhaustion,
            reason = reason,
        )
    }

    private fun format(value: Double): String = "%.2f".format(java.util.Locale.US, value)
}
