package androidx.compose.ui.text.style
class TextAlign { companion object { val Center = TextAlign() } }
class TextOverflow { companion object { val Ellipsis = TextOverflow() } }
