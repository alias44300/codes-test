package titlefight.ui.compose

import titlefight.BoxerCatalog
import titlefight.BoxerProfile
import titlefight.BoxingStyle
import titlefight.FightScreenPhase
import titlefight.FightScreenStateMapper
import titlefight.FighterCorner
import titlefight.InteractiveFightPhase
import titlefight.InteractiveFightSession
import titlefight.PlayerTacticalDraft
import titlefight.Tactic
import titlefight.TacticalDistance
import titlefight.TacticalPace
import titlefight.TacticalRisk
import titlefight.TacticalTarget
import java.security.MessageDigest

data class Jalon6Step4AuditResult(
    val sessions: Int,
    val completedSessions: Int,
    val tacticalWindows: Int,
    val playerDecisions: Int,
    val staleWindowRejections: Int,
    val timelineStates: Int,
    val replayChecks: Int,
    val replayErrors: Int,
    val appliedPlanErrors: Int,
    val phaseErrors: Int,
    val lockErrors: Int,
    val timelineErrors: Int,
    val judgeLeakErrors: Int,
    val digest: String,
)

object Jalon6Step4Auditor {
    fun run(sessions: Int = 180): Jalon6Step4AuditResult {
        require(sessions >= 40)
        val roster = BoxerCatalog.all
        var completedSessions = 0
        var tacticalWindows = 0
        var playerDecisions = 0
        var staleWindowRejections = 0
        var timelineStates = 0
        var replayChecks = 0
        var replayErrors = 0
        var appliedPlanErrors = 0
        var phaseErrors = 0
        var lockErrors = 0
        var timelineErrors = 0
        var judgeLeakErrors = 0
        val digestLines = mutableListOf<String>()

        repeat(sessions) { index ->
            val red = roster[index % roster.size]
            var blue = roster[(index * 5 + 2) % roster.size]
            if (blue.id == red.id) blue = roster[(roster.indexOf(blue) + 1) % roster.size]
            val corner = if (index % 2 == 0) FighterCorner.RED else FighterCorner.BLUE
            val seed = 6_400_000L + index
            val session = session(red, blue, seed, corner)
            var advance = session.start()
            if (advance.state.phase != InteractiveFightPhase.BETWEEN_ROUNDS) phaseErrors++
            var window = advance.state.tacticalWindowId
            while (window != null) {
                tacticalWindows++
                val chosen = choices(index + advance.state.completedRounds, if (corner == FighterCorner.RED) red.style else blue.style)
                session.selectPace(window, chosen.pace)
                session.selectDistance(window, chosen.distance)
                session.selectTarget(window, chosen.target)
                session.selectRisk(window, chosen.risk)
                val before = session.state()
                if (!before.canEditTactics || !before.canConfirmTactics) lockErrors++
                advance = session.confirmAndContinue(window)
                playerDecisions++
                val applied = if (corner == FighterCorner.RED) {
                    advance.simulatedRound?.redAppliedTacticalPlan
                } else {
                    advance.simulatedRound?.blueAppliedTacticalPlan
                }
                if (applied != chosen.toPlan()) appliedPlanErrors++
                try {
                    session.selectPace(window, TacticalPace.MEASURED)
                    staleWindowRejections += 0
                    lockErrors++
                } catch (_: IllegalStateException) {
                    staleWindowRejections++
                }
                window = advance.state.tacticalWindowId
            }

            val finalState = session.state()
            if (finalState.phase != InteractiveFightPhase.COMPLETE || finalState.result == null) phaseErrors++
            if (finalState.canEditTactics || finalState.canConfirmTactics) lockErrors++
            completedSessions++
            val timeline = session.screenTimeline()
            timelineStates += timeline.size
            if (timeline.first().phase != FightScreenPhase.PRE_FIGHT || timeline.last().phase != FightScreenPhase.COMPLETE) {
                timelineErrors++
            }
            val direct = FightScreenStateMapper.buildTimeline(requireNotNull(finalState.result), red, blue)
            if (timeline != direct) timelineErrors++
            if (timeline.any { state ->
                    val text = FightScreenAccessibility.screenSummary(state).lowercase()
                    "scorecard" in text || "carte du juge" in text || "total du juge" in text
                }
            ) judgeLeakErrors++

            if (index < 60) {
                replayChecks++
                val replay = playScript(red, blue, seed, corner, index)
                if (requireNotNull(finalState.result) != replay.first || timeline != replay.second) replayErrors++
            }
            val completedResult = requireNotNull(finalState.result)
            digestLines += listOf(
                red.id,
                blue.id,
                corner,
                seed,
                completedResult.stoppage?.method ?: completedResult.officialDecision?.type,
                timeline.size,
                completedResult.rounds.joinToString("/") {
                    val plan = if (corner == FighterCorner.RED) it.redAppliedTacticalPlan else it.blueAppliedTacticalPlan
                    plan?.id.orEmpty()
                },
            ).joinToString("|")
        }

        return Jalon6Step4AuditResult(
            sessions = sessions,
            completedSessions = completedSessions,
            tacticalWindows = tacticalWindows,
            playerDecisions = playerDecisions,
            staleWindowRejections = staleWindowRejections,
            timelineStates = timelineStates,
            replayChecks = replayChecks,
            replayErrors = replayErrors,
            appliedPlanErrors = appliedPlanErrors,
            phaseErrors = phaseErrors,
            lockErrors = lockErrors,
            timelineErrors = timelineErrors,
            judgeLeakErrors = judgeLeakErrors,
            digest = sha256(digestLines.joinToString("\n")),
        )
    }

    private fun playScript(
        red: BoxerProfile,
        blue: BoxerProfile,
        seed: Long,
        corner: FighterCorner,
        scriptIndex: Int,
    ): Pair<titlefight.FightResult, List<titlefight.FightScreenState>> {
        val session = session(red, blue, seed, corner)
        var state = session.start().state
        while (state.tacticalWindowId != null) {
            val window = requireNotNull(state.tacticalWindowId)
            val chosen = choices(scriptIndex + state.completedRounds, if (corner == FighterCorner.RED) red.style else blue.style)
            session.replaceDraft(window, chosen)
            state = session.confirmAndContinue(window).state
        }
        return requireNotNull(state.result) to session.screenTimeline()
    }

    private fun choices(index: Int, style: BoxingStyle): PlayerTacticalDraft {
        return PlayerTacticalDraft(
            anchorStyle = style,
            pace = TacticalPace.entries[index % TacticalPace.entries.size],
            distance = TacticalDistance.entries[(index / 2) % TacticalDistance.entries.size],
            target = TacticalTarget.entries[(index / 3) % TacticalTarget.entries.size],
            risk = TacticalRisk.entries[(index / 5) % TacticalRisk.entries.size],
        )
    }

    private fun session(red: BoxerProfile, blue: BoxerProfile, seed: Long, corner: FighterCorner): InteractiveFightSession =
        InteractiveFightSession(
            red = red,
            blue = blue,
            redTactics = List(3) { legacyTactic(red.style) },
            blueTactics = List(3) { legacyTactic(blue.style) },
            seed = seed,
            playerCorner = corner,
            stopOnTenCount = false,
            stopOnTko = false,
        )

    private fun legacyTactic(style: BoxingStyle): Tactic = when (style) {
        BoxingStyle.OUT_BOXER -> Tactic.CONTROL
        BoxingStyle.PRESSURE_FIGHTER -> Tactic.PRESS
        BoxingStyle.COUNTERPUNCHER -> Tactic.COUNTER
        BoxingStyle.BOXER_PUNCHER -> Tactic.CONTROL
        BoxingStyle.SWARMER -> Tactic.PRESS
        BoxingStyle.SLUGGER -> Tactic.SEEK_KO
        BoxingStyle.DEFENSIVE_SPECIALIST -> Tactic.RECOVER
    }

    private fun sha256(text: String): String = MessageDigest.getInstance("SHA-256")
        .digest(text.toByteArray())
        .joinToString("") { "%02x".format(it) }
}

object Jalon6Step4Test {
    @JvmStatic
    fun main(args: Array<String>) {
        controlsOpenOnlyAfterRound()
        draftEditsDoNotAdvanceFight()
        confirmedPlanIsAppliedToNextRound()
        staleWindowCannotBeConfirmedTwice()
        controlsLockAfterFinalResult()
        earlyStoppageClosesTacticalFlow()
        editsDoNotConsumeRandomness()
        sameSeedAndChoicesReplayExactly()
        blueCornerCanBeControlled()
        anchorStyleCannotBeReplaced()
        coordinatorDispatchesSelectionsAndResume()
        uiSelectionExistsOnlyBetweenRounds()
        completedInteractiveTimelineMatchesValidatedMapper()
        auditIsClean()
        auditIsReproducible()
        println("15 tests Jalon 6 étape 4 réussis")
    }

    private val red = BoxerCatalog.eliasVega
    private val blue = BoxerCatalog.brunoKessler

    private fun controlsOpenOnlyAfterRound() {
        val session = session(7_001L)
        check(session.state().phase == InteractiveFightPhase.READY)
        check(!session.state().canEditTactics)
        val started = session.start().state
        check(started.phase == InteractiveFightPhase.BETWEEN_ROUNDS)
        check(started.canEditTactics)
        check(started.tacticalWindowId == 1)
    }

    private fun draftEditsDoNotAdvanceFight() {
        val session = session(7_002L)
        val initial = session.start().state
        val window = requireNotNull(initial.tacticalWindowId)
        val timelineSize = session.screenTimeline().size
        session.selectPace(window, TacticalPace.SUSTAINED)
        session.selectDistance(window, TacticalDistance.CLOSE)
        session.selectTarget(window, TacticalTarget.BODY)
        session.selectRisk(window, TacticalRisk.AGGRESSIVE)
        val edited = session.state()
        check(edited.completedRounds == 1)
        check(session.screenTimeline().size == timelineSize)
        check(edited.changedAxes.toSet().size == 4)
    }

    private fun confirmedPlanIsAppliedToNextRound() {
        val session = session(7_003L)
        val started = session.start().state
        val window = requireNotNull(started.tacticalWindowId)
        val expected = PlayerTacticalDraft(
            anchorStyle = red.style,
            pace = TacticalPace.SUSTAINED,
            distance = TacticalDistance.CLOSE,
            target = TacticalTarget.BODY,
            risk = TacticalRisk.AGGRESSIVE,
        )
        session.replaceDraft(window, expected)
        val next = session.confirmAndContinue(window)
        check(next.simulatedRound?.roundNumber == 2)
        check(next.simulatedRound?.redAppliedTacticalPlan == expected.toPlan())
        check(next.state.completedRounds == 2)
    }

    private fun staleWindowCannotBeConfirmedTwice() {
        val session = session(7_004L)
        val window = requireNotNull(session.start().state.tacticalWindowId)
        session.confirmAndContinue(window)
        check(runCatching { session.confirmAndContinue(window) }.isFailure)
        check(runCatching { session.selectRisk(window, TacticalRisk.SAFE) }.isFailure)
    }

    private fun controlsLockAfterFinalResult() {
        val session = session(7_005L)
        finish(session)
        val final = session.state()
        check(final.phase == InteractiveFightPhase.COMPLETE)
        check(!final.canEditTactics && !final.canConfirmTactics)
        check(final.tacticalWindowId == null)
    }

    private fun earlyStoppageClosesTacticalFlow() {
        val red = BoxerCatalog.eliasVega
        val blue = BoxerCatalog.viktorSokolov
        val session = InteractiveFightSession(
            red = red,
            blue = blue,
            redTactics = List(3) { Tactic.CONTROL },
            blueTactics = List(3) { Tactic.SEEK_KO },
            seed = 215L,
            playerCorner = FighterCorner.RED,
        )
        var state = session.start().state
        while (state.tacticalWindowId != null) {
            state = session.confirmAndContinue(requireNotNull(state.tacticalWindowId)).state
        }
        val stop = requireNotNull(requireNotNull(state.result).stoppage)
        check(stop.roundNumber == 2)
        check(state.phase == InteractiveFightPhase.COMPLETE)
        check(!state.canEditTactics && state.tacticalWindowId == null)
        check(session.screenTimeline().last().phase == FightScreenPhase.COMPLETE)
    }

    private fun editsDoNotConsumeRandomness() {
        val a = session(7_006L)
        val b = session(7_006L)
        var sa = a.start().state
        var sb = b.start().state
        while (sa.tacticalWindowId != null && sb.tacticalWindowId != null) {
            val wa = requireNotNull(sa.tacticalWindowId)
            val wb = requireNotNull(sb.tacticalWindowId)
            val finalDraft = PlayerTacticalDraft.from(sa.committedPlayerPlan).copy(
                pace = TacticalPace.MEASURED,
                distance = TacticalDistance.MEDIUM,
                target = TacticalTarget.MIXED,
                risk = TacticalRisk.BALANCED,
            )
            a.replaceDraft(wa, finalDraft)
            b.selectPace(wb, TacticalPace.SUSTAINED)
            b.selectDistance(wb, TacticalDistance.CLOSE)
            b.selectTarget(wb, TacticalTarget.BODY)
            b.selectRisk(wb, TacticalRisk.AGGRESSIVE)
            b.replaceDraft(wb, finalDraft)
            sa = a.confirmAndContinue(wa).state
            sb = b.confirmAndContinue(wb).state
        }
        check(sa.result == sb.result)
        check(a.screenTimeline() == b.screenTimeline())
    }

    private fun sameSeedAndChoicesReplayExactly() {
        val a = scripted(7_007L)
        val b = scripted(7_007L)
        check(a.first == b.first)
        check(a.second == b.second)
    }

    private fun blueCornerCanBeControlled() {
        val session = session(7_008L, FighterCorner.BLUE)
        val start = session.start().state
        val window = requireNotNull(start.tacticalWindowId)
        val draft = PlayerTacticalDraft.from(start.committedPlayerPlan).copy(target = TacticalTarget.HEAD)
        session.replaceDraft(window, draft)
        val next = session.confirmAndContinue(window)
        check(next.simulatedRound?.blueAppliedTacticalPlan == draft.toPlan())
    }

    private fun anchorStyleCannotBeReplaced() {
        val session = session(7_009L)
        val start = session.start().state
        val window = requireNotNull(start.tacticalWindowId)
        val invalid = PlayerTacticalDraft.from(start.committedPlayerPlan).copy(anchorStyle = BoxingStyle.SLUGGER)
        check(runCatching { session.replaceDraft(window, invalid) }.isFailure)
    }

    private fun coordinatorDispatchesSelectionsAndResume() {
        val coordinator = InteractiveFightCoordinator(session(7_010L))
        var view = coordinator.start()
        check(view.screenState.phase == FightScreenPhase.BETWEEN_ROUNDS)
        val window = requireNotNull(view.tacticalSelection).windowId
        view = coordinator.dispatch(TacticalSelectionAction.SelectPace(window, TacticalPace.SUSTAINED))
        check(view.tacticalSelection?.draft?.pace == TacticalPace.SUSTAINED)
        view = coordinator.dispatch(TacticalSelectionAction.Confirm(window))
        check(view.completedRounds == 2)
        check(view.screenState.phase == FightScreenPhase.BETWEEN_ROUNDS)
    }

    private fun uiSelectionExistsOnlyBetweenRounds() {
        val session = session(7_011L)
        check(TacticalSelectionUiState.from(session.state()) == null)
        val started = session.start().state
        check(TacticalSelectionUiState.from(started) != null)
        finish(session)
        check(TacticalSelectionUiState.from(session.state()) == null)
    }

    private fun completedInteractiveTimelineMatchesValidatedMapper() {
        val session = session(7_012L)
        finish(session)
        val result = requireNotNull(session.state().result)
        check(session.screenTimeline() == FightScreenStateMapper.buildTimeline(result, red, blue))
    }

    private fun auditIsClean() {
        val audit = Jalon6Step4Auditor.run(100)
        check(audit.completedSessions == audit.sessions)
        check(audit.tacticalWindows == audit.playerDecisions)
        check(audit.staleWindowRejections == audit.playerDecisions)
        check(audit.replayErrors == 0)
        check(audit.appliedPlanErrors == 0)
        check(audit.phaseErrors == 0)
        check(audit.lockErrors == 0)
        check(audit.timelineErrors == 0)
        check(audit.judgeLeakErrors == 0)
    }

    private fun auditIsReproducible() {
        check(Jalon6Step4Auditor.run(80) == Jalon6Step4Auditor.run(80))
    }

    private fun finish(session: InteractiveFightSession) {
        if (session.state().phase == InteractiveFightPhase.READY) session.start()
        while (session.state().tacticalWindowId != null) {
            session.confirmAndContinue(requireNotNull(session.state().tacticalWindowId))
        }
    }

    private fun scripted(seed: Long): Pair<titlefight.FightResult, List<titlefight.FightScreenState>> {
        val session = session(seed)
        var state = session.start().state
        while (state.tacticalWindowId != null) {
            val window = requireNotNull(state.tacticalWindowId)
            val draft = PlayerTacticalDraft.from(state.committedPlayerPlan).copy(
                pace = if (state.completedRounds == 1) TacticalPace.CAUTIOUS else TacticalPace.SUSTAINED,
                distance = if (state.completedRounds == 1) TacticalDistance.LONG else TacticalDistance.CLOSE,
                target = if (state.completedRounds == 1) TacticalTarget.BODY else TacticalTarget.HEAD,
                risk = if (state.completedRounds == 1) TacticalRisk.SAFE else TacticalRisk.AGGRESSIVE,
            )
            session.replaceDraft(window, draft)
            state = session.confirmAndContinue(window).state
        }
        return requireNotNull(state.result) to session.screenTimeline()
    }

    private fun session(seed: Long, corner: FighterCorner = FighterCorner.RED): InteractiveFightSession =
        InteractiveFightSession(
            red = red,
            blue = blue,
            redTactics = List(3) { Tactic.CONTROL },
            blueTactics = List(3) { Tactic.PRESS },
            seed = seed,
            playerCorner = corner,
            stopOnTenCount = false,
            stopOnTko = false,
        )
}

object Jalon6Step4AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val audit = Jalon6Step4Auditor.run()
        println("sessions=${audit.sessions}")
        println("sessions_terminees=${audit.completedSessions}")
        println("fenetres_tactiques=${audit.tacticalWindows}")
        println("decisions_joueur=${audit.playerDecisions}")
        println("rejets_fenetre_expiree=${audit.staleWindowRejections}")
        println("etats_ecran=${audit.timelineStates}")
        println("relectures=${audit.replayChecks}")
        println("erreurs_relecture=${audit.replayErrors}")
        println("erreurs_plan_applique=${audit.appliedPlanErrors}")
        println("erreurs_phase=${audit.phaseErrors}")
        println("erreurs_verrouillage=${audit.lockErrors}")
        println("erreurs_timeline=${audit.timelineErrors}")
        println("fuites_juges=${audit.judgeLeakErrors}")
        println("empreinte=${audit.digest}")
    }
}


object Jalon6Step4InteractionDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val red = BoxerCatalog.eliasVega
        val blue = BoxerCatalog.brunoKessler
        val session = InteractiveFightSession(
            red = red,
            blue = blue,
            redTactics = List(3) { Tactic.CONTROL },
            blueTactics = List(3) { Tactic.PRESS },
            seed = 20_260_721L,
            playerCorner = FighterCorner.RED,
            stopOnTenCount = false,
            stopOnTko = false,
        )
        var state = session.start().state
        println("Après round 1 : phase=${state.phase}, fenêtre=${state.tacticalWindowId}")
        println("Plan appliqué : ${state.committedPlayerPlan.id}")

        val window1 = requireNotNull(state.tacticalWindowId)
        session.selectPace(window1, TacticalPace.SUSTAINED)
        session.selectDistance(window1, TacticalDistance.CLOSE)
        session.selectTarget(window1, TacticalTarget.BODY)
        session.selectRisk(window1, TacticalRisk.AGGRESSIVE)
        println("Brouillon round 2 : ${requireNotNull(session.state().pendingPlayerPlan).id}")
        val round2 = session.confirmAndContinue(window1)
        state = round2.state
        println("Après round 2 : phase=${state.phase}, fenêtre=${state.tacticalWindowId}")
        println("Plan round 2 réellement appliqué : ${round2.simulatedRound?.redAppliedTacticalPlan?.id}")

        val window2 = requireNotNull(state.tacticalWindowId)
        val round3Draft = PlayerTacticalDraft.from(state.committedPlayerPlan).copy(
            pace = TacticalPace.CAUTIOUS,
            distance = TacticalDistance.LONG,
            target = TacticalTarget.HEAD,
            risk = TacticalRisk.SAFE,
        )
        session.replaceDraft(window2, round3Draft)
        val round3 = session.confirmAndContinue(window2)
        val final = round3.state
        val result = requireNotNull(final.result)
        println("Après round 3 : phase=${final.phase}")
        println("Plan round 3 réellement appliqué : ${round3.simulatedRound?.redAppliedTacticalPlan?.id}")
        println("Résultat : ${result.stoppage?.method ?: result.officialDecision?.type}")
        println("États d'écran : ${session.screenTimeline().size}")
    }
}
