# TITLE FIGHT — module Compose

Ce module contient la première traduction Jetpack Compose de la maquette de combat.

## Contrat

- entrée unique : `FightScreenState` ;
- aucune mutation du moteur ;
- aucune dépendance réseau ;
- aucune interaction tactique active avant le jalon 6 étape 4 ;
- les cartes détaillées des juges ne font pas partie du modèle d’écran.

## Intégration future

Le module suppose un projet Android racine fournissant :

- le module `:engine` ;
- un catalogue de versions `libs` avec Compose BOM, UI, Foundation, Material 3 et tooling ;
- la propriété optionnelle `titleFightCompileSdk`.

La compilation Android réelle et la création d’un APK restent réservées à l’étape 5, dans un environnement où le SDK Android est installé et vérifié.
