package androidx.compose.foundation.shape
import androidx.compose.ui.unit.Dp
class RoundedCornerShape(val radius: Dp)
