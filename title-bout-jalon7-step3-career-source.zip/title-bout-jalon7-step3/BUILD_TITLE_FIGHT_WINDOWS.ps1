[CmdletBinding()]
param(
    [switch]$SkipInstall,
    [switch]$RunInstrumentedTests,
    [switch]$Clean,
    [string]$SdkRoot = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Artifacts = Join-Path $Root "artifacts\windows-build"
$Logs = Join-Path $Artifacts "logs"
$PackageName = "com.titlefight.simulator"
$ActivityName = "titlefight.app.MainActivity"
$BuildToolsVersion = "36.0.0"
$StartedAt = Get-Date

New-Item -ItemType Directory -Force $Artifacts, $Logs | Out-Null

function Write-Step([string]$Message) {
    Write-Host ""
    Write-Host "=== $Message ===" -ForegroundColor Cyan
}

function Add-MachinePath([string]$PathToAdd) {
    if (-not [string]::IsNullOrWhiteSpace($PathToAdd) -and (Test-Path $PathToAdd)) {
        $parts = $env:Path -split ";"
        if ($parts -notcontains $PathToAdd) {
            $env:Path = "$PathToAdd;$env:Path"
        }
    }
}

function Invoke-Logged {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string[]]$Arguments = @(),
        [switch]$AllowFailure
    )
    $LogPath = Join-Path $Logs ("{0}.log" -f $Name)
    Write-Host "> $FilePath $($Arguments -join ' ')"
    & $FilePath @Arguments 2>&1 | Tee-Object -FilePath $LogPath
    $ExitCode = $LASTEXITCODE
    if ($null -eq $ExitCode) { $ExitCode = 0 }
    if (($ExitCode -ne 0) -and (-not $AllowFailure)) {
        throw "$Name a échoué avec le code $ExitCode. Voir $LogPath"
    }
    return $ExitCode
}

function Resolve-Java17 {
    Write-Step "Vérification de Java 17"
    $javaCommand = Get-Command java.exe -ErrorAction SilentlyContinue
    $javaOk = $false
    if ($javaCommand) {
        $versionLine = (& $javaCommand.Source -version 2>&1 | Select-Object -First 1) -join ""
        if ($versionLine -match 'version "(?<major>\d+)') {
            $javaOk = ([int]$Matches.major -ge 17)
        }
    }

    if (-not $javaOk) {
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $winget) {
            throw "Java 17 est absent et winget n'est pas disponible. Installez Temurin JDK 17, puis relancez ce script."
        }
        Write-Host "Installation de Temurin JDK 17 via winget..."
        & $winget.Source install --id EclipseAdoptium.Temurin.17.JDK --exact --accept-source-agreements --accept-package-agreements --silent
        if ($LASTEXITCODE -ne 0) { throw "L'installation de Temurin JDK 17 a échoué." }
    }

    $jdkCandidates = @(
        Get-ChildItem "C:\Program Files\Eclipse Adoptium" -Directory -Filter "jdk-17*" -ErrorAction SilentlyContinue
        Get-ChildItem "C:\Program Files\Java" -Directory -Filter "jdk-17*" -ErrorAction SilentlyContinue
    ) | Sort-Object FullName -Descending

    if ($jdkCandidates.Count -gt 0) {
        $env:JAVA_HOME = $jdkCandidates[0].FullName
        Add-MachinePath (Join-Path $env:JAVA_HOME "bin")
    }

    $javaCommand = Get-Command java.exe -ErrorAction Stop
    $versionOutput = & $javaCommand.Source -version 2>&1
    $versionOutput | Set-Content -Encoding UTF8 (Join-Path $Artifacts "java-version.txt")
    if (($versionOutput | Select-Object -First 1) -notmatch 'version "(?<major>\d+)') {
        throw "Impossible de lire la version de Java."
    }
    if ([int]$Matches.major -lt 17) {
        throw "Java 17 minimum requis. Version détectée : $($Matches.major)."
    }
    Write-Host "Java validé : $($javaCommand.Source)"
}

function Resolve-AndroidSdk {
    Write-Step "Installation et validation du SDK Android"
    if ([string]::IsNullOrWhiteSpace($SdkRoot)) {
        if ($env:ANDROID_SDK_ROOT) {
            $script:SdkRoot = $env:ANDROID_SDK_ROOT
        } else {
            $script:SdkRoot = Join-Path $env:LOCALAPPDATA "Android\Sdk"
        }
    } else {
        $script:SdkRoot = $SdkRoot
    }
    $env:ANDROID_SDK_ROOT = $script:SdkRoot
    $env:ANDROID_HOME = $script:SdkRoot

    & (Join-Path $Root "scripts\bootstrap-android-sdk.ps1")
    if ($LASTEXITCODE -ne 0) { throw "Le bootstrap du SDK Android a échoué." }

    $platformTools = Join-Path $script:SdkRoot "platform-tools"
    $buildTools = Join-Path $script:SdkRoot "build-tools\$BuildToolsVersion"
    Add-MachinePath $platformTools
    Add-MachinePath $buildTools

    $required = @(
        (Join-Path $script:SdkRoot "platforms\android-37\android.jar"),
        (Join-Path $buildTools "apksigner.bat"),
        (Join-Path $platformTools "adb.exe")
    )
    foreach ($item in $required) {
        if (-not (Test-Path $item)) { throw "Composant Android manquant : $item" }
    }

    @(
        "ANDROID_SDK_ROOT=$script:SdkRoot",
        "BUILD_TOOLS=$BuildToolsVersion",
        "PLATFORM=android-37"
    ) | Set-Content -Encoding UTF8 (Join-Path $Artifacts "android-environment.txt")
}

function Build-Project {
    Write-Step "Compilation et tests unitaires"
    Push-Location $Root
    try {
        if ($Clean) {
            Invoke-Logged -Name "gradle-clean" -FilePath (Join-Path $Root "gradlew.bat") -Arguments @("--no-daemon", "clean")
        }
        Invoke-Logged -Name "gradle-version" -FilePath (Join-Path $Root "gradlew.bat") -Arguments @("--version")
        Invoke-Logged -Name "gradle-build" -FilePath (Join-Path $Root "gradlew.bat") -Arguments @(
            "--no-daemon",
            "--stacktrace",
            ":engine:test",
            ":android-ui-compose:testDebugUnitTest",
            ":app:testDebugUnitTest",
            ":app:assembleDebug"
        )
    } finally {
        Pop-Location
    }
}

function Verify-Apk {
    Write-Step "Vérification de l'APK"
    $sourceApk = Join-Path $Root "app\build\outputs\apk\debug\app-debug.apk"
    if (-not (Test-Path $sourceApk)) { throw "APK introuvable après compilation : $sourceApk" }
    if ((Get-Item $sourceApk).Length -le 0) { throw "APK vide : $sourceApk" }

    $finalApk = Join-Path $Artifacts "TITLE-FIGHT-demo-debug.apk"
    Copy-Item $sourceApk $finalApk -Force
    $hash = (Get-FileHash $finalApk -Algorithm SHA256).Hash.ToLowerInvariant()
    "$hash  TITLE-FIGHT-demo-debug.apk" | Set-Content -Encoding ASCII (Join-Path $Artifacts "TITLE-FIGHT-demo-debug.apk.sha256")

    $apksigner = Join-Path $script:SdkRoot "build-tools\$BuildToolsVersion\apksigner.bat"
    Invoke-Logged -Name "apksigner-verify" -FilePath $apksigner -Arguments @("verify", "--verbose", "--print-certs", $finalApk)

    $aapt = Join-Path $script:SdkRoot "build-tools\$BuildToolsVersion\aapt.exe"
    if (Test-Path $aapt) {
        Invoke-Logged -Name "aapt-badging" -FilePath $aapt -Arguments @("dump", "badging", $finalApk)
    }

    return $finalApk
}

function Get-ConnectedDeviceIds {
    $adb = Join-Path $script:SdkRoot "platform-tools\adb.exe"
    & $adb start-server | Out-Null
    $lines = & $adb devices
    $deviceIds = @()
    foreach ($line in $lines) {
        if ($line -match '^(?<id>[^\s]+)\s+device$') { $deviceIds += $Matches.id }
    }
    return $deviceIds
}

function Install-And-Launch([string]$ApkPath) {
    Write-Step "Installation et lancement sur Android"
    if ($SkipInstall) {
        Write-Host "Installation ignorée par option -SkipInstall."
        return "SKIPPED"
    }

    $adb = Join-Path $script:SdkRoot "platform-tools\adb.exe"
    $devices = @(Get-ConnectedDeviceIds)
    (& $adb devices -l) | Set-Content -Encoding UTF8 (Join-Path $Artifacts "adb-devices.txt")
    if ($devices.Count -eq 0) {
        Write-Warning "APK compilé et vérifié, mais aucun téléphone autorisé n'est détecté."
        return "NO_DEVICE"
    }
    if ($devices.Count -gt 1) {
        throw "Plusieurs appareils Android sont connectés. Laissez un seul appareil actif, puis relancez."
    }

    Invoke-Logged -Name "adb-install" -FilePath $adb -Arguments @("-s", $devices[0], "install", "-r", "-t", $ApkPath)

    if ($RunInstrumentedTests) {
        Push-Location $Root
        try {
            Invoke-Logged -Name "gradle-instrumented-tests" -FilePath (Join-Path $Root "gradlew.bat") -Arguments @(
                "--no-daemon", ":app:connectedDebugAndroidTest"
            )
        } finally {
            Pop-Location
        }
    }

    Invoke-Logged -Name "adb-force-stop" -FilePath $adb -Arguments @("-s", $devices[0], "shell", "am", "force-stop", $PackageName)
    Invoke-Logged -Name "adb-launch" -FilePath $adb -Arguments @("-s", $devices[0], "shell", "am", "start", "-W", "-n", "$PackageName/$ActivityName")

    Start-Sleep -Seconds 2
    $pid = (& $adb -s $devices[0] shell pidof $PackageName 2>$null) -join ""
    $focus = (& $adb -s $devices[0] shell dumpsys window windows 2>$null | Select-String -Pattern "mCurrentFocus|mFocusedApp") -join "`n"
    @(
        "DEVICE=$($devices[0])",
        "PACKAGE=$PackageName",
        "PID=$pid",
        "FOCUS=$focus"
    ) | Set-Content -Encoding UTF8 (Join-Path $Artifacts "installation-verification.txt")

    if ([string]::IsNullOrWhiteSpace($pid)) {
        throw "L'installation a réussi, mais le processus de l'application n'est pas actif après le lancement."
    }
    return "VERIFIED"
}

$Status = "FAILED"
$Failure = ""
$ApkPath = ""
try {
    Resolve-Java17
    Resolve-AndroidSdk
    Build-Project
    $ApkPath = Verify-Apk
    $InstallStatus = Install-And-Launch -ApkPath $ApkPath
    if ($InstallStatus -eq "VERIFIED") {
        $Status = "BUILD_INSTALL_LAUNCH_VERIFIED"
    } elseif ($InstallStatus -eq "SKIPPED") {
        $Status = "BUILD_VERIFIED_INSTALL_SKIPPED"
    } else {
        $Status = "BUILD_VERIFIED_NO_DEVICE"
    }
} catch {
    $Failure = $_.Exception.Message
    Write-Error $Failure
} finally {
    $FinishedAt = Get-Date
    $duration = [math]::Round(($FinishedAt - $StartedAt).TotalSeconds, 2)
    $report = [ordered]@{
        status = $Status
        startedAt = $StartedAt.ToString("o")
        finishedAt = $FinishedAt.ToString("o")
        durationSeconds = $duration
        projectRoot = $Root
        sdkRoot = $script:SdkRoot
        apkPath = $ApkPath
        packageName = $PackageName
        activityName = $ActivityName
        failure = $Failure
    }
    $report | ConvertTo-Json -Depth 4 | Set-Content -Encoding UTF8 (Join-Path $Artifacts "build-report.json")
    @(
        "TITLE FIGHT - Rapport de compilation Windows",
        "STATUT=$Status",
        "DUREE_SECONDES=$duration",
        "APK=$ApkPath",
        "ERREUR=$Failure"
    ) | Set-Content -Encoding UTF8 (Join-Path $Artifacts "build-report.txt")
}

if ($Status -eq "FAILED") { exit 1 }
Write-Host ""
Write-Host "Statut final : $Status" -ForegroundColor Green
Write-Host "Livrables : $Artifacts"
if ($Status -eq "BUILD_VERIFIED_NO_DEVICE") {
    Write-Host "Branchez le téléphone avec le débogage USB autorisé, puis relancez le script pour valider installation et lancement." -ForegroundColor Yellow
}
exit 0
