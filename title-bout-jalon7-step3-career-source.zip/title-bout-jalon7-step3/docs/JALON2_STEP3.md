# Jalon 2 — Étape 3 : KO

## Fonction livrée

Lorsqu’une chute produit un compte à 10, le moteur termine immédiatement le combat par KO.

## Données enregistrées

- méthode : `KO` ;
- identifiant du vainqueur ;
- identifiant du perdant ;
- round de l’arrêt ;
- séquence de l’arrêt.

## Invariants

1. Un KO provient toujours d’un `KnockdownEvent` associé à un compte de 10.
2. La séquence du KO est la dernière séquence du round.
3. Le round du KO est le dernier round du combat.
4. Aucun événement n’est calculé après le KO.
5. Le résultat est strictement reproductible avec la même graine.
6. Le TKO, les juges et l’interface restent hors périmètre.

## Audit technique

L’audit utilise 1 000 scénarios volontairement compromis pour exercer l’arrêt. Il vérifie le câblage, pas la fréquence réaliste des KO.

- 806 KO ;
- 194 combats sans KO ;
- 0 combat continuant après KO ;
- 0 événement après KO ;
- 0 métadonnée d’arrêt invalide ;
- 403 KO depuis le coin rouge et 403 depuis le coin bleu.
