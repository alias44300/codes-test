# Jalon 4 — Étape 1 — Instantané tactique

## Objectif

Créer une observation déterministe de l’état du combat au début de chaque round réellement simulé, sans modifier les décisions, les séquences, les dégâts, les arrêts ou les cartes des juges.

## Structures ajoutées

- `TacticalRoundFacts`
- `FighterTacticalState`
- `TacticalStateSnapshot`
- `TacticalStateSnapshotExtractor`

`TacticalRoundFacts` ne contient aucune carte de juge. L’extracteur reçoit uniquement les performances internes, les événements déjà simulés et les états physiques courants.

## Moment des instantanés

Un instantané est créé :

1. avant le round 1 ;
2. avant le round 2, uniquement si le combat continue ;
3. avant le round 3, uniquement si le combat continue.

Aucun instantané n’est créé après un KO ou un TKO.

## Informations enregistrées

- rounds et séquences déjà terminés ;
- round suivant ;
- rounds et séquences maximales restants ;
- énergie et fatigue ;
- dégâts tête et corps ;
- stabilité ;
- knockdowns provoqués et subis ;
- estimation interne des rounds gagnés, perdus ou équilibrés ;
- marge de performance cumulée ;
- dynamique des quatre dernières séquences du dernier round terminé.

## Isolation

L’instantané :

- ne consomme aucun tirage aléatoire ;
- ne lit aucune future séquence ;
- ne lit aucune tactique d’un round futur ;
- ne lit aucune carte exacte des juges ;
- n’applique aucun bonus ou malus ;
- ne modifie aucun résultat historique du moteur.

## Périmètre explicitement exclu

- aucun `TacticalPlan` ;
- aucune adaptation de rythme ;
- aucune adaptation de distance ;
- aucune adaptation de cible ;
- aucune adaptation de prise de risque ;
- aucun écran Android ;
- aucun APK.
