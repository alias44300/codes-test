package titlefight

import java.util.Locale

data class KnockoutStep3AuditResult(
    val fightCount: Int,
    val koCount: Int,
    val completedWithoutKo: Int,
    val fightsContinuingAfterKo: Int,
    val eventsAfterKo: Int,
    val invalidStoppages: Int,
    val redCornerKOs: Int,
    val blueCornerKOs: Int,
    val koRoundTotal: Int,
    val koSequenceTotal: Int,
    val earliestKoRound: Int,
    val latestKoRound: Int,
    val earliestKoSequence: Int,
    val latestKoSequence: Int,
) {
    init {
        require(fightCount == koCount + completedWithoutKo)
        require(redCornerKOs + blueCornerKOs == koCount)
        require(fightsContinuingAfterKo >= 0)
        require(eventsAfterKo >= 0)
        require(invalidStoppages >= 0)
    }

    val averageKoRound: Double get() = if (koCount == 0) 0.0 else koRoundTotal.toDouble() / koCount
    val averageKoSequence: Double get() = if (koCount == 0) 0.0 else koSequenceTotal.toDouble() / koCount
}

object KnockoutStep3Auditor {
    fun run(fightCount: Int = 1000, seedStart: Long = 2026075000L): KnockoutStep3AuditResult {
        require(fightCount == 1000)
        val engine = FightEngine(stopOnTko = false)
        val compromised = FighterState(stamina = 3.0, headDamage = 94.0, bodyDamage = 80.0, stability = 3.0)

        var koCount = 0
        var completedWithoutKo = 0
        var continuingAfterKo = 0
        var eventsAfterKo = 0
        var invalidStoppages = 0
        var redCornerKOs = 0
        var blueCornerKOs = 0
        var koRoundTotal = 0
        var koSequenceTotal = 0
        var earliestRound = Int.MAX_VALUE
        var latestRound = 0
        var earliestSequence = Int.MAX_VALUE
        var latestSequence = 0

        repeat(fightCount) { index ->
            val attackerInRed = index % 2 == 0
            val fight = if (attackerInRed) {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.brunoKessler,
                    blue = TestProfiles.eliasVega,
                    redTactics = List(3) { Tactic.SEEK_KO },
                    blueTactics = List(3) { Tactic.RECOVER },
                    seed = seedStart + index,
                    redStart = FighterState(),
                    blueStart = compromised,
                )
            } else {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = List(3) { Tactic.RECOVER },
                    blueTactics = List(3) { Tactic.SEEK_KO },
                    seed = seedStart + index,
                    redStart = compromised,
                    blueStart = FighterState(),
                )
            }

            val stoppage = fight.stoppage
            if (stoppage == null) {
                completedWithoutKo++
                return@repeat
            }

            koCount++
            if (stoppage.winnerId == fight.redId) redCornerKOs++ else blueCornerKOs++
            koRoundTotal += stoppage.roundNumber
            koSequenceTotal += stoppage.sequenceNumber
            earliestRound = minOf(earliestRound, stoppage.roundNumber)
            latestRound = maxOf(latestRound, stoppage.roundNumber)
            earliestSequence = minOf(earliestSequence, stoppage.sequenceNumber)
            latestSequence = maxOf(latestSequence, stoppage.sequenceNumber)

            val stoppedRound = fight.rounds.getOrNull(stoppage.roundNumber - 1)
            val lastEvent = stoppedRound?.events?.lastOrNull()
            val count = lastEvent?.knockdown?.refereeCount
            val metadataValid = stoppedRound != null && lastEvent != null && count != null &&
                stoppage.method == FightMethod.KO &&
                fight.rounds.size == stoppage.roundNumber &&
                fight.rounds.last().stoppage == stoppage &&
                stoppedRound.stoppage == stoppage &&
                lastEvent.sequenceNumber == stoppage.sequenceNumber &&
                lastEvent.attackerId == stoppage.winnerId &&
                lastEvent.defenderId == stoppage.loserId &&
                count.countReached == 10 &&
                !count.recovered
            if (!metadataValid) invalidStoppages++

            val laterRounds = fight.rounds.drop(stoppage.roundNumber)
            val sameRoundEventsAfter = stoppedRound?.events?.count { it.sequenceNumber > stoppage.sequenceNumber } ?: 0
            val laterEvents = laterRounds.sumOf { it.events.size }
            val after = sameRoundEventsAfter + laterEvents
            eventsAfterKo += after
            if (laterRounds.isNotEmpty() || after > 0) continuingAfterKo++
        }

        return KnockoutStep3AuditResult(
            fightCount = fightCount,
            koCount = koCount,
            completedWithoutKo = completedWithoutKo,
            fightsContinuingAfterKo = continuingAfterKo,
            eventsAfterKo = eventsAfterKo,
            invalidStoppages = invalidStoppages,
            redCornerKOs = redCornerKOs,
            blueCornerKOs = blueCornerKOs,
            koRoundTotal = koRoundTotal,
            koSequenceTotal = koSequenceTotal,
            earliestKoRound = if (koCount == 0) 0 else earliestRound,
            latestKoRound = latestRound,
            earliestKoSequence = if (koCount == 0) 0 else earliestSequence,
            latestKoSequence = latestSequence,
        )
    }
}

object KnockoutStep3AuditFormatter {
    fun format(result: KnockoutStep3AuditResult): String = buildString {
        appendLine("TITLE FIGHT — Jalon 2, étape 3")
        appendLine("Audit technique de l’arrêt immédiat par KO")
        appendLine()
        appendLine("Scénarios à haut risque : ${result.fightCount}")
        appendLine("Combats terminés par KO : ${result.koCount}")
        appendLine("Combats arrivés au terme des 3 rounds sans KO : ${result.completedWithoutKo}")
        appendLine("Combats ayant continué après KO : ${result.fightsContinuingAfterKo}")
        appendLine("Événements calculés après KO : ${result.eventsAfterKo}")
        appendLine("Métadonnées d’arrêt invalides : ${result.invalidStoppages}")
        appendLine("KO coin rouge / bleu : ${result.redCornerKOs} / ${result.blueCornerKOs}")
        appendLine("Round moyen du KO : ${decimal(result.averageKoRound)}")
        appendLine("Séquence moyenne du KO : ${decimal(result.averageKoSequence)}")
        appendLine("Round KO min / max : ${result.earliestKoRound} / ${result.latestKoRound}")
        appendLine("Séquence KO min / max : ${result.earliestKoSequence} / ${result.latestKoSequence}")
        appendLine()
        appendLine("Cet audit vérifie le câblage technique avec des états volontairement compromis. Il ne constitue pas l’équilibrage final des fréquences de KO.")
        appendLine("Le TKO et les juges restent désactivés.")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
}

object KnockoutStep3AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        print(KnockoutStep3AuditFormatter.format(KnockoutStep3Auditor.run()))
    }
}
