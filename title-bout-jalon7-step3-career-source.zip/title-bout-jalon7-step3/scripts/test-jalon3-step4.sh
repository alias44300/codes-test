#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build-step4"
rm -rf "$BUILD"
mkdir -p "$BUILD"
kotlinc -J-Dfile.encoding=UTF-8 \
  "$ROOT"/engine/src/main/kotlin/titlefight/*.kt \
  "$ROOT"/engine/src/test/kotlin/titlefight/*.kt \
  -include-runtime -d "$BUILD/title-fight-step4-tests.jar"
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-step4-tests.jar" titlefight.FightEngineTest
