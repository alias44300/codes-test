package titlefight

import java.text.Normalizer
import kotlin.math.abs
import kotlin.math.roundToInt

enum class CareerBoutOutcome { WIN, LOSS, DRAW }
enum class CareerStatus { ACTIVE, RETIRED }

enum class CareerStage(val frenchLabel: String) {
    PROSPECT("Jeune professionnel"),
    REGIONAL("Circuit régional"),
    NATIONAL("Niveau national"),
    CONTINENTAL("Niveau continental"),
    WORLD_RANKED("Classé mondial"),
    WORLD_CHAMPION("Champion du monde"),
    UNIFIED_CHAMPION("Champion unifié"),
    UNDISPUTED_CHAMPION("Champion incontesté"),
    RETIRED("Retraité"),
}

enum class ChampionshipBelt(
    val frenchLabel: String,
    val isWorldTitle: Boolean,
) {
    REGIONAL("Ceinture régionale", false),
    NATIONAL("Ceinture nationale", false),
    CONTINENTAL("Ceinture continentale", false),
    WBA("Champion du monde WBA", true),
    WBC("Champion du monde WBC", true),
    IBF("Champion du monde IBF", true),
    WBO("Champion du monde WBO", true),
    THE_RING("Ceinture The Ring", true),
}

enum class TrainingFocus(val frenchLabel: String) {
    POWER("Puissance"),
    SPEED("Vitesse"),
    TECHNIQUE("Technique"),
    DEFENSE("Défense"),
    ENDURANCE("Endurance"),
    MENTAL("Mental"),
}

data class CareerCreationRequest(
    val name: String,
    val nickname: String,
    val country: String,
    val division: WeightClass,
    val stance: Stance,
    val style: BoxingStyle,
) {
    init {
        require(name.isNotBlank())
        require(country.isNotBlank())
    }
}

data class CareerRecord(
    val wins: Int = 0,
    val losses: Int = 0,
    val draws: Int = 0,
    val knockouts: Int = 0,
) {
    init {
        require(wins >= 0 && losses >= 0 && draws >= 0 && knockouts >= 0)
        require(knockouts <= wins)
    }

    val bouts: Int get() = wins + losses + draws
    val label: String get() = "$wins-$losses-$draws · $knockouts KO"
}

data class CareerHistoryEntry(
    val week: Int,
    val ageYears: Int,
    val opponentProfileId: String,
    val opponentName: String,
    val outcome: CareerBoutOutcome,
    val endedByKnockout: Boolean,
    val worldRankingAfterBout: Int?,
    val beltWon: ChampionshipBelt? = null,
    val beltLost: ChampionshipBelt? = null,
) {
    init {
        require(week >= 1)
        require(ageYears >= 18)
        require(opponentProfileId.isNotBlank())
        require(opponentName.isNotBlank())
        require(worldRankingAfterBout == null || worldRankingAfterBout in 1..15)
    }
}

data class CareerState(
    val fighter: BoxerProfile,
    val country: String,
    val division: WeightClass,
    val ageInWeeks: Int = 18 * 52,
    val record: CareerRecord = CareerRecord(),
    val worldRanking: Int? = null,
    val belts: Set<ChampionshipBelt> = emptySet(),
    val titleDefenses: Int = 0,
    val reputation: Int = 0,
    val purseBalance: Int = 500,
    val fatigue: Int = 0,
    val health: Int = 100,
    val week: Int = 1,
    val status: CareerStatus = CareerStatus.ACTIVE,
    val history: List<CareerHistoryEntry> = emptyList(),
) {
    init {
        require(country.isNotBlank())
        require(ageInWeeks >= 18 * 52)
        require(worldRanking == null || worldRanking in 1..15)
        require(titleDefenses >= 0)
        require(reputation in 0..100)
        require(purseBalance >= 0)
        require(fatigue in 0..100)
        require(health in 0..100)
        require(week >= 1)
    }

    val boxerProfileId: String get() = fighter.id
    val ageYears: Int get() = ageInWeeks / 52
    val ageMonths: Int get() = ((ageInWeeks % 52) * 12 / 52)
    val overall: Int get() = fighter.primaryStats.average().roundToInt()
    val worldBelts: Set<ChampionshipBelt> get() = belts.filterTo(linkedSetOf()) { it.isWorldTitle }
    val stage: CareerStage
        get() = when {
            status == CareerStatus.RETIRED -> CareerStage.RETIRED
            worldBelts.containsAll(setOf(ChampionshipBelt.WBA, ChampionshipBelt.WBC, ChampionshipBelt.IBF, ChampionshipBelt.WBO)) -> CareerStage.UNDISPUTED_CHAMPION
            worldBelts.size >= 2 -> CareerStage.UNIFIED_CHAMPION
            worldBelts.isNotEmpty() -> CareerStage.WORLD_CHAMPION
            worldRanking != null -> CareerStage.WORLD_RANKED
            ChampionshipBelt.CONTINENTAL in belts -> CareerStage.CONTINENTAL
            ChampionshipBelt.NATIONAL in belts -> CareerStage.NATIONAL
            ChampionshipBelt.REGIONAL in belts -> CareerStage.REGIONAL
            else -> CareerStage.PROSPECT
        }

    val rankingLabel: String get() = worldRanking?.let { "Classement mondial #$it" } ?: "Non classé mondial"
}

data class CareerOpponent(
    val source: OfficialBoxer,
    val profile: BoxerProfile,
    val worldRank: Int?,
    val purse: Int,
    val reputationReward: Int,
    val beltAtStake: ChampionshipBelt? = null,
    val isTitleDefense: Boolean = false,
    val scheduledRounds: Int,
) {
    init {
        require(worldRank == null || worldRank in 1..15)
        require(purse > 0)
        require(reputationReward > 0)
        require(scheduledRounds in setOf(4, 6, 8, 10, 12))
        require(!isTitleDefense || beltAtStake != null)
    }

    val isTitleFight: Boolean get() = beltAtStake != null
    val boutLabel: String
        get() = when {
            beltAtStake == null -> "Combat de classement"
            isTitleDefense -> "Défense · ${beltAtStake.frenchLabel}"
            else -> "Titre vacant · ${beltAtStake.frenchLabel}"
        }
}

object CareerEngine {
    private val divisions = WeightClass.entries
    private val worldSanctioningBelts = listOf(
        ChampionshipBelt.WBA,
        ChampionshipBelt.WBC,
        ChampionshipBelt.IBF,
        ChampionshipBelt.WBO,
    )

    fun create(request: CareerCreationRequest): CareerState = CareerState(
        fighter = rookieProfile(request),
        country = request.country.trim(),
        division = request.division,
    )

    fun availableOpponents(state: CareerState, limit: Int = 4): List<CareerOpponent> {
        require(limit in 1..8)
        require(state.status == CareerStatus.ACTIVE)
        val recent = state.history.takeLast(4).map { it.opponentProfileId }.toSet()
        val pool = OfficialRoster.cards
            .filter { it.weightClass == state.division && it.profile.id !in recent }
            .ifEmpty { OfficialRoster.cards.filter { it.weightClass == state.division } }
            .sortedBy { deterministicOrder(it.collectionId, state.week, state.record.bouts) }

        val titleOpportunity = nextNewBeltOpportunity(state)
        val defenseBelt = state.worldBelts.firstOrNull()
        val titleOpponent = when {
            titleOpportunity != null -> makeOpponent(
                state = state,
                source = pool.maxBy { it.overall },
                offset = 4,
                belt = titleOpportunity,
                defense = false,
            )
            defenseBelt != null -> makeOpponent(
                state = state,
                source = pool.maxBy { it.overall },
                offset = 3,
                belt = defenseBelt,
                defense = true,
            )
            else -> null
        }

        val ordinary = pool
            .filter { it.collectionId != titleOpponent?.source?.collectionId }
            .take(limit - if (titleOpponent == null) 0 else 1)
            .mapIndexed { index, source ->
                makeOpponent(
                    state = state,
                    source = source,
                    offset = listOf(-2, 0, 2, 3)[index.coerceAtMost(3)],
                    belt = null,
                    defense = false,
                )
            }

        return listOfNotNull(titleOpponent) + ordinary
    }

    fun applyBout(
        state: CareerState,
        opponent: CareerOpponent,
        outcome: CareerBoutOutcome,
        endedByKnockout: Boolean = false,
    ): CareerState {
        require(state.status == CareerStatus.ACTIVE)
        require(opponent.profile.id != state.fighter.id)
        require(opponent.source.weightClass == state.division)
        require(!endedByKnockout || outcome != CareerBoutOutcome.DRAW)

        val ownedBefore = opponent.beltAtStake != null && opponent.beltAtStake in state.belts
        val beltWon = if (outcome == CareerBoutOutcome.WIN && opponent.beltAtStake != null && !ownedBefore) {
            opponent.beltAtStake
        } else null
        val beltLost = if (outcome == CareerBoutOutcome.LOSS && opponent.beltAtStake != null && ownedBefore) {
            opponent.beltAtStake
        } else null

        val nextBelts = state.belts.toMutableSet().apply {
            beltWon?.let(::add)
            beltLost?.let(::remove)
        }.toSet()
        val nextRecord = when (outcome) {
            CareerBoutOutcome.WIN -> state.record.copy(
                wins = state.record.wins + 1,
                knockouts = state.record.knockouts + if (endedByKnockout) 1 else 0,
            )
            CareerBoutOutcome.LOSS -> state.record.copy(losses = state.record.losses + 1)
            CareerBoutOutcome.DRAW -> state.record.copy(draws = state.record.draws + 1)
        }
        val nextDefenses = when {
            outcome == CareerBoutOutcome.WIN && opponent.isTitleDefense -> state.titleDefenses + 1
            outcome == CareerBoutOutcome.LOSS && opponent.isTitleDefense -> 0
            else -> state.titleDefenses
        }
        val nextWorldRanking = updatedWorldRanking(
            state = state,
            outcome = outcome,
            endedByKnockout = endedByKnockout,
            beltWon = beltWon,
            beltLost = beltLost,
            nextBelts = nextBelts,
        )
        val campWeeks = if (opponent.isTitleFight) 8 else 6
        val newAge = state.ageInWeeks + campWeeks
        val healthLoss = when (outcome) {
            CareerBoutOutcome.WIN -> if (endedByKnockout) 2 else 4
            CareerBoutOutcome.DRAW -> 6
            CareerBoutOutcome.LOSS -> if (endedByKnockout) 12 else 8
        }
        val developed = developAfterBout(
            profile = state.fighter,
            outcome = outcome,
            endedByKnockout = endedByKnockout,
            boutNumber = nextRecord.bouts,
            ageYears = newAge / 52,
        )
        val earned = when (outcome) {
            CareerBoutOutcome.WIN -> opponent.purse
            CareerBoutOutcome.DRAW -> opponent.purse / 2
            CareerBoutOutcome.LOSS -> opponent.purse / 3
        }
        val reputationDelta = when (outcome) {
            CareerBoutOutcome.WIN -> opponent.reputationReward + if (opponent.isTitleFight) 4 else 0
            CareerBoutOutcome.DRAW -> 1
            CareerBoutOutcome.LOSS -> -2
        }
        val historyEntry = CareerHistoryEntry(
            week = state.week,
            ageYears = newAge / 52,
            opponentProfileId = opponent.profile.id,
            opponentName = opponent.profile.name,
            outcome = outcome,
            endedByKnockout = endedByKnockout,
            worldRankingAfterBout = nextWorldRanking,
            beltWon = beltWon,
            beltLost = beltLost,
        )
        val nextHealth = (state.health - healthLoss).coerceIn(0, 100)
        val nextStatus = if (newAge / 52 >= 42 || nextHealth <= 10) CareerStatus.RETIRED else CareerStatus.ACTIVE

        return state.copy(
            fighter = developed,
            ageInWeeks = newAge,
            record = nextRecord,
            worldRanking = nextWorldRanking,
            belts = nextBelts,
            titleDefenses = nextDefenses,
            reputation = (state.reputation + reputationDelta).coerceIn(0, 100),
            purseBalance = state.purseBalance + earned,
            fatigue = (state.fatigue + if (opponent.isTitleFight) 28 else 22).coerceAtMost(100),
            health = nextHealth,
            week = state.week + campWeeks,
            status = nextStatus,
            history = state.history + historyEntry,
        )
    }

    fun train(state: CareerState, focus: TrainingFocus): CareerState {
        require(state.status == CareerStatus.ACTIVE)
        require(state.fatigue <= 88) { "Le boxeur est trop fatigué pour s'entraîner." }
        val cap = when {
            state.ageYears <= 28 -> 96
            state.ageYears <= 33 -> 93
            else -> 89
        }
        val p = state.fighter
        fun plus(value: Int, amount: Int = 1): Int = (value + amount).coerceAtMost(cap)
        val improved = when (focus) {
            TrainingFocus.POWER -> p.copy(power = plus(p.power, 2), accuracy = plus(p.accuracy))
            TrainingFocus.SPEED -> p.copy(speed = plus(p.speed, 2), mobility = plus(p.mobility))
            TrainingFocus.TECHNIQUE -> p.copy(technique = plus(p.technique, 2), accuracy = plus(p.accuracy), mental = plus(p.mental))
            TrainingFocus.DEFENSE -> p.copy(defense = plus(p.defense, 2), chin = plus(p.chin), mobility = plus(p.mobility))
            TrainingFocus.ENDURANCE -> p.copy(endurance = plus(p.endurance, 2), recovery = plus(p.recovery), bodyResistance = plus(p.bodyResistance))
            TrainingFocus.MENTAL -> p.copy(mental = plus(p.mental, 2), recovery = plus(p.recovery), technique = plus(p.technique))
        }
        return state.copy(
            fighter = improved,
            ageInWeeks = state.ageInWeeks + 2,
            fatigue = (state.fatigue + 12).coerceAtMost(100),
            week = state.week + 2,
            purseBalance = (state.purseBalance - 75).coerceAtLeast(0),
        )
    }

    fun restCamp(state: CareerState): CareerState = state.copy(
        ageInWeeks = state.ageInWeeks + 3,
        fatigue = (state.fatigue - 42).coerceAtLeast(0),
        health = (state.health + 8).coerceAtMost(100),
        week = state.week + 3,
    )

    fun eligibleDivisionMoves(state: CareerState): List<WeightClass> {
        if (state.belts.isNotEmpty() || state.status == CareerStatus.RETIRED) return emptyList()
        val index = divisions.indexOf(state.division)
        return buildList {
            if (index > 0) add(divisions[index - 1])
            if (index < divisions.lastIndex) add(divisions[index + 1])
        }
    }

    fun moveDivision(state: CareerState, target: WeightClass): CareerState {
        require(target in eligibleDivisionMoves(state))
        val oldIndex = divisions.indexOf(state.division)
        val newIndex = divisions.indexOf(target)
        val movingUp = newIndex > oldIndex
        val profile = if (movingUp) {
            state.fighter.copy(
                power = (state.fighter.power + 2).coerceAtMost(100),
                speed = (state.fighter.speed - 1).coerceAtLeast(1),
                mobility = (state.fighter.mobility - 1).coerceAtLeast(1),
            )
        } else {
            state.fighter.copy(
                power = (state.fighter.power - 1).coerceAtLeast(1),
                speed = (state.fighter.speed + 1).coerceAtMost(100),
                mobility = (state.fighter.mobility + 1).coerceAtMost(100),
            )
        }
        return state.copy(
            fighter = profile,
            division = target,
            ageInWeeks = state.ageInWeeks + 8,
            worldRanking = null,
            fatigue = (state.fatigue + 14).coerceAtMost(100),
            week = state.week + 8,
        )
    }

    fun retire(state: CareerState): CareerState = state.copy(status = CareerStatus.RETIRED)

    fun nextNewBeltOpportunity(state: CareerState): ChampionshipBelt? = when {
        ChampionshipBelt.REGIONAL !in state.belts && state.record.wins >= 3 -> ChampionshipBelt.REGIONAL
        ChampionshipBelt.REGIONAL in state.belts && ChampionshipBelt.NATIONAL !in state.belts && state.record.wins >= 6 -> ChampionshipBelt.NATIONAL
        ChampionshipBelt.NATIONAL in state.belts && ChampionshipBelt.CONTINENTAL !in state.belts && state.record.wins >= 10 -> ChampionshipBelt.CONTINENTAL
        ChampionshipBelt.CONTINENTAL in state.belts && state.worldBelts.isEmpty() && (state.worldRanking ?: 99) <= 3 -> ChampionshipBelt.WBA
        ChampionshipBelt.WBA in state.belts && ChampionshipBelt.WBC !in state.belts && state.titleDefenses >= 1 -> ChampionshipBelt.WBC
        ChampionshipBelt.WBC in state.belts && ChampionshipBelt.IBF !in state.belts && state.titleDefenses >= 2 -> ChampionshipBelt.IBF
        ChampionshipBelt.IBF in state.belts && ChampionshipBelt.WBO !in state.belts && state.titleDefenses >= 3 -> ChampionshipBelt.WBO
        state.worldBelts.containsAll(worldSanctioningBelts) && ChampionshipBelt.THE_RING !in state.belts -> ChampionshipBelt.THE_RING
        else -> null
    }

    private fun makeOpponent(
        state: CareerState,
        source: OfficialBoxer,
        offset: Int,
        belt: ChampionshipBelt?,
        defense: Boolean,
    ): CareerOpponent {
        val target = if (belt == null) {
            (state.overall + offset).coerceIn(45, 96)
        } else {
            maxOf(state.overall + offset, beltTargetOverall(belt)).coerceAtMost(98)
        }
        val rank = when {
            belt?.isWorldTitle == true -> 1
            state.worldRanking != null -> (state.worldRanking + offset.coerceIn(-2, 2)).coerceIn(1, 15)
            else -> null
        }
        val scheduledRounds = when {
            belt?.isWorldTitle == true || defense -> 12
            belt == ChampionshipBelt.CONTINENTAL -> 12
            belt == ChampionshipBelt.NATIONAL -> 10
            belt == ChampionshipBelt.REGIONAL -> 8
            state.record.bouts < 3 -> 4
            state.record.bouts < 7 -> 6
            state.worldRanking == null -> 8
            else -> 10
        }
        val purse = when {
            belt?.isWorldTitle == true -> 25_000 + state.reputation * 500
            belt == ChampionshipBelt.CONTINENTAL -> 8_000
            belt == ChampionshipBelt.NATIONAL -> 3_500
            belt == ChampionshipBelt.REGIONAL -> 1_500
            state.worldRanking != null -> 2_000 + (16 - state.worldRanking) * 250
            else -> 500 + state.record.bouts * 125
        }
        return CareerOpponent(
            source = source,
            profile = scaleProfile(source.profile, target),
            worldRank = rank,
            purse = purse,
            reputationReward = when {
                belt?.isWorldTitle == true -> 15
                belt != null -> 10
                state.worldRanking != null -> 7
                else -> 4
            },
            beltAtStake = belt,
            isTitleDefense = defense,
            scheduledRounds = scheduledRounds,
        )
    }

    private fun updatedWorldRanking(
        state: CareerState,
        outcome: CareerBoutOutcome,
        endedByKnockout: Boolean,
        beltWon: ChampionshipBelt?,
        beltLost: ChampionshipBelt?,
        nextBelts: Set<ChampionshipBelt>,
    ): Int? {
        if (beltWon == ChampionshipBelt.CONTINENTAL) return 15
        if (beltWon?.isWorldTitle == true) return 1
        if (beltLost?.isWorldTitle == true && nextBelts.none { it.isWorldTitle }) return 3
        val current = state.worldRanking ?: return null
        return when (outcome) {
            CareerBoutOutcome.WIN -> (current - if (endedByKnockout) 2 else 1).coerceAtLeast(1)
            CareerBoutOutcome.LOSS -> (current + 2).coerceAtMost(15)
            CareerBoutOutcome.DRAW -> current
        }
    }

    private fun rookieProfile(request: CareerCreationRequest): BoxerProfile {
        val (height, reach) = OfficialRoster.physicalDefaults(request.division)
        val stats = when (request.style) {
            BoxingStyle.OUT_BOXER -> intArrayOf(47, 60, 58, 57, 54, 54, 50, 53, 56, 60, 52, 45)
            BoxingStyle.PRESSURE_FIGHTER -> intArrayOf(56, 53, 50, 48, 60, 50, 58, 57, 50, 51, 59, 62)
            BoxingStyle.COUNTERPUNCHER -> intArrayOf(51, 56, 59, 58, 52, 59, 52, 54, 59, 56, 52, 47)
            BoxingStyle.BOXER_PUNCHER -> intArrayOf(57, 56, 56, 53, 55, 54, 54, 53, 56, 54, 54, 55)
            BoxingStyle.SWARMER -> intArrayOf(55, 58, 51, 47, 60, 49, 57, 56, 52, 57, 58, 65)
            BoxingStyle.SLUGGER -> intArrayOf(63, 48, 49, 45, 54, 49, 58, 52, 50, 45, 56, 60)
            BoxingStyle.DEFENSIVE_SPECIALIST -> intArrayOf(45, 55, 58, 63, 52, 58, 52, 55, 55, 59, 53, 42)
        }
        val nickname = request.nickname.trim().ifBlank { "Le Prospect" }
        return BoxerProfile(
            id = "career-${slug(request.name)}-18",
            name = request.name.trim(),
            nickname = nickname,
            stance = request.stance,
            style = request.style,
            preferredRange = preferredRange(request.style),
            heightCm = height,
            reachCm = reach,
            power = stats[0],
            speed = stats[1],
            technique = stats[2],
            defense = stats[3],
            endurance = stats[4],
            mental = stats[5],
            chin = stats[6],
            recovery = stats[7],
            accuracy = stats[8],
            mobility = stats[9],
            bodyResistance = stats[10],
            aggression = stats[11],
        )
    }

    private fun developAfterBout(
        profile: BoxerProfile,
        outcome: CareerBoutOutcome,
        endedByKnockout: Boolean,
        boutNumber: Int,
        ageYears: Int,
    ): BoxerProfile {
        val cap = when {
            ageYears <= 28 -> 97
            ageYears <= 33 -> 94
            else -> 90
        }
        fun plus(value: Int, amount: Int): Int = (value + amount).coerceAtMost(cap)
        val gain = when (outcome) {
            CareerBoutOutcome.WIN -> 2
            CareerBoutOutcome.DRAW -> 1
            CareerBoutOutcome.LOSS -> 1
        }
        var developed = when (boutNumber % 6) {
            0 -> profile.copy(power = plus(profile.power, gain), accuracy = plus(profile.accuracy, 1))
            1 -> profile.copy(speed = plus(profile.speed, gain), mobility = plus(profile.mobility, 1))
            2 -> profile.copy(technique = plus(profile.technique, gain), mental = plus(profile.mental, 1))
            3 -> profile.copy(defense = plus(profile.defense, gain), chin = plus(profile.chin, 1))
            4 -> profile.copy(endurance = plus(profile.endurance, gain), recovery = plus(profile.recovery, 1))
            else -> profile.copy(mental = plus(profile.mental, gain), bodyResistance = plus(profile.bodyResistance, 1))
        }
        if (endedByKnockout && outcome == CareerBoutOutcome.WIN) {
            developed = developed.copy(power = plus(developed.power, 1), aggression = plus(developed.aggression, 1))
        }
        if (ageYears >= 35 && boutNumber % 3 == 0) {
            developed = developed.copy(
                speed = (developed.speed - 1).coerceAtLeast(1),
                mobility = (developed.mobility - 1).coerceAtLeast(1),
                recovery = (developed.recovery - 1).coerceAtLeast(1),
            )
        }
        return developed
    }

    private fun scaleProfile(profile: BoxerProfile, targetOverall: Int): BoxerProfile {
        val current = profile.primaryStats.average().roundToInt()
        val delta = targetOverall - current
        fun shifted(value: Int): Int = (value + delta).coerceIn(35, 100)
        return profile.copy(
            power = shifted(profile.power),
            speed = shifted(profile.speed),
            technique = shifted(profile.technique),
            defense = shifted(profile.defense),
            endurance = shifted(profile.endurance),
            mental = shifted(profile.mental),
            chin = shifted(profile.chin),
            recovery = shifted(profile.recovery),
            accuracy = shifted(profile.accuracy),
            mobility = shifted(profile.mobility),
            bodyResistance = shifted(profile.bodyResistance),
            aggression = shifted(profile.aggression),
        )
    }

    private fun beltTargetOverall(belt: ChampionshipBelt): Int = when (belt) {
        ChampionshipBelt.REGIONAL -> 60
        ChampionshipBelt.NATIONAL -> 67
        ChampionshipBelt.CONTINENTAL -> 74
        ChampionshipBelt.WBA -> 84
        ChampionshipBelt.WBC -> 88
        ChampionshipBelt.IBF -> 91
        ChampionshipBelt.WBO -> 94
        ChampionshipBelt.THE_RING -> 95
    }

    private fun preferredRange(style: BoxingStyle): FightRange = when (style) {
        BoxingStyle.OUT_BOXER, BoxingStyle.DEFENSIVE_SPECIALIST -> FightRange.OUTSIDE
        BoxingStyle.PRESSURE_FIGHTER, BoxingStyle.SWARMER -> FightRange.INSIDE
        else -> FightRange.MID
    }

    private fun deterministicOrder(collectionId: String, week: Int, bouts: Int): Int {
        val number = collectionId.removePrefix("BOX-").toInt()
        return abs(number * 97 + week * 31 + bouts * 53) % 10_000
    }

    private fun slug(value: String): String {
        val ascii = Normalizer.normalize(value.trim(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
        return ascii.ifBlank { "boxer" }
    }
}
