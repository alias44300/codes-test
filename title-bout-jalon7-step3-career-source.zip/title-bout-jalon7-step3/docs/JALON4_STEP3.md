# Jalon 4 — Étape 3 — Décision tactique adaptative

## Objectif

Choisir un plan déterministe avant le combat et entre les rounds, sans encore modifier les calculs du moteur.

## Structures ajoutées

- `TacticalDecisionPhase`
- `TacticalAxis`
- `TacticalDecisionTrigger`
- `TacticalDecision`
- `TacticalDecisionEngine`

Chaque décision enregistre le boxeur, le round à venir, le plan précédent, le plan retenu, les axes modifiés, les causes et une justification textuelle.

## Sources autorisées

Le sélecteur utilise uniquement :

- `TacticalStateSnapshot` ;
- le style et le profil du boxeur ;
- l’historique des décisions déjà prises.

Il ne lit aucune carte exacte des juges, aucune séquence future et ne consomme aucun RNG.

## Règles principales

- avant le round 1 : plan naturel du style ;
- retard estimé : rythme ou risque renforcé ;
- retard avant le dernier round : rythme, risque et rapprochement renforcés ;
- avance avant le dernier round : rythme et risque réduits ;
- fatigue élevée : rythme réduit et risque sécurisé ;
- danger physique : éloignement, rythme réduit et risque sûr ;
- vulnérabilité adverse : cible tête ou corps adaptée ;
- dynamique très défavorable : activité accrue si l’état physique le permet.

## Stabilité du comportement

- un seul niveau de changement par axe et par décision ;
- rythme, distance et risque restent dans un voisinage d’un niveau autour du plan naturel ;
- une inversion immédiate est bloquée sans urgence ou signal nettement plus fort ;
- le style d’ancrage ne change jamais.

## Audit réel

- 1 000 combats ;
- 3 000 rounds ;
- 6 000 décisions tactiques ;
- 2 000 décisions avant combat ;
- 4 000 décisions entre les rounds ;
- 2 290 plans modifiés ;
- 3 combats arrêtés ;
- 0 décision après arrêt ;
- 0 explication vide ;
- 0 erreur de plan naturel ;
- 0 dérive d’ancrage ou de style ;
- 0 retour tactique inexpliqué ;
- 1 748 réponses entreprenantes sur 1 748 situations de retard exploitables ;
- 53 réponses de sécurité sur 53 situations de danger physique ;
- 0 écart de reproductibilité ;
- 0 empreinte historique modifiée.

Aucune situation de fatigue inférieure ou égale à 42 % d’énergie n’est apparue dans l’échantillon standard. La règle de réduction du rythme dans cet état est couverte par un test contrôlé dédié.

## Limite conservée

Les plans sont enregistrés mais ne sont pas encore appliqués aux choix de distance, d’activité, de cible, de précision, d’impact ou de coût énergétique. Cette intégration appartient à l’étape 4.
