# Jalon 6 — Étape 2 — Maquette visuelle statique portrait

## Objectif

Définir la hiérarchie visuelle du futur écran Android sans Compose, sans interaction et sans connexion au moteur en temps réel.

## Livrables visuels

- écran combat actif à 320 × 720 dp ;
- écran combat actif à 360 × 800 dp ;
- écran combat actif à 412 × 915 dp ;
- écran entre les rounds à 360 × 800 dp ;
- écran de résultat à 360 × 800 dp ;
- planche de comparaison des cinq scénarios ;
- fichier HTML autonome et contrat JSON de dimensions.

## Hiérarchie retenue

1. Scoreboard : round, chronomètre et identité du jeu.
2. Deux fiches boxeur symétriques : énergie, dégâts tête/corps et stabilité.
3. Action courante ou statut de phase.
4. Commentaire principal.
5. Journal des trois événements récents.
6. Plans tactiques résumés pendant le combat ou zone de commandes statique entre les rounds.
7. Pied de phase : séquence, pause ou résultat.

## Confidentialité sportive

- aucune carte détaillée des juges ;
- aucun total individuel de juge ;
- résultat officiel seulement sur l’écran final ;
- explications tactiques résumées sans exposer les calculs internes.

## Règles de lisibilité

- police minimale : 10 dp à 320, 10,5 dp à 360 et 11 dp à 412 ;
- deux fiches boxeur de largeur égale ;
- aucune zone hors écran ou défilement horizontal ;
- futures zones tactiles : 44 dp minimum à 320/360 et 48 dp à 412 ;
- aucune interaction active dans cette étape.

## Hors périmètre

- aucun composant Jetpack Compose ;
- aucune animation ;
- aucun choix tactile réellement actif ;
- aucune dépendance Android ;
- aucun APK.
