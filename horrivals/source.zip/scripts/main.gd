extends Control

const CardViewScene = preload("res://scripts/card_view.gd")
const CARD_SIZE := Vector2(150, 225)
const EFFROI_BONUS := 4
const MAX_EFFROI_PER_DUEL := 3
const STARTING_EFFROI := 10

var cards_data: Array = []
var player_cards: Array[CardView] = []
var ai_cards: Array[CardView] = []
var selected_card: CardView = null
var round_index := 0
var player_score := 0
var ai_score := 0
var player_effroi := STARTING_EFFROI
var ai_effroi := STARTING_EFFROI
var selected_effroi := 0
var battle_locked := false

var title_label: Label
var score_label: Label
var role_label: Label
var effroi_label: Label
var message_label: Label
var resolve_button: Button
var minus_button: Button
var plus_button: Button
var effroi_value_label: Label
var restart_button: Button
var overlay: ColorRect
var overlay_label: Label

func _ready() -> void:
    randomize()
    _load_data()
    _build_ui()
    _spawn_cards()
    resized.connect(_layout_all)
    _layout_all()
    _update_ui()

func _load_data() -> void:
    var file := FileAccess.open("res://data/cards.json", FileAccess.READ)
    if file == null:
        push_error("Impossible de charger data/cards.json")
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if parsed is Array:
        cards_data = parsed
    else:
        push_error("cards.json invalide")

func _build_ui() -> void:
    var bg := ColorRect.new()
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.color = Color("0a0a10")
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(bg)

    var arena := Panel.new()
    arena.name = "Arena"
    arena.set_anchors_preset(Control.PRESET_FULL_RECT)
    arena.offset_left = 255
    arena.offset_top = 180
    arena.offset_right = -255
    arena.offset_bottom = -180
    arena.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var arena_style := StyleBoxFlat.new()
    arena_style.bg_color = Color("12131a")
    arena_style.border_color = Color("30313d")
    arena_style.set_border_width_all(2)
    arena_style.corner_radius_top_left = 22
    arena_style.corner_radius_top_right = 22
    arena_style.corner_radius_bottom_left = 22
    arena_style.corner_radius_bottom_right = 22
    arena.add_theme_stylebox_override("panel", arena_style)
    add_child(arena)

    var center_line := ColorRect.new()
    center_line.anchor_left = 0.5
    center_line.anchor_right = 0.5
    center_line.anchor_top = 0.0
    center_line.anchor_bottom = 1.0
    center_line.offset_left = -1
    center_line.offset_right = 1
    center_line.color = Color("2b2c35")
    center_line.mouse_filter = Control.MOUSE_FILTER_IGNORE
    arena.add_child(center_line)

    title_label = Label.new()
    title_label.text = "HORRIVALS · PROTOTYPE COMBAT"
    title_label.position = Vector2(24, 14)
    title_label.size = Vector2(420, 30)
    title_label.add_theme_font_size_override("font_size", 22)
    title_label.add_theme_color_override("font_color", Color("f3f3f5"))
    add_child(title_label)

    score_label = Label.new()
    score_label.position = Vector2(470, 15)
    score_label.size = Vector2(340, 28)
    score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    score_label.add_theme_font_size_override("font_size", 20)
    score_label.add_theme_color_override("font_color", Color("f3f3f5"))
    add_child(score_label)

    role_label = Label.new()
    role_label.position = Vector2(850, 15)
    role_label.size = Vector2(400, 28)
    role_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    role_label.add_theme_font_size_override("font_size", 16)
    role_label.add_theme_color_override("font_color", Color("c9c9d4"))
    add_child(role_label)

    message_label = Label.new()
    message_label.position = Vector2(390, 333)
    message_label.size = Vector2(500, 52)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    message_label.add_theme_font_size_override("font_size", 16)
    message_label.add_theme_color_override("font_color", Color("ededf2"))
    add_child(message_label)

    effroi_label = Label.new()
    effroi_label.position = Vector2(24, 670)
    effroi_label.size = Vector2(240, 28)
    effroi_label.add_theme_font_size_override("font_size", 15)
    effroi_label.add_theme_color_override("font_color", Color("d9d9e3"))
    add_child(effroi_label)

    var controls := HBoxContainer.new()
    controls.position = Vector2(450, 650)
    controls.size = Vector2(380, 52)
    controls.alignment = BoxContainer.ALIGNMENT_CENTER
    controls.add_theme_constant_override("separation", 8)
    add_child(controls)

    minus_button = Button.new()
    minus_button.text = "−"
    minus_button.custom_minimum_size = Vector2(46, 46)
    minus_button.add_theme_font_size_override("font_size", 22)
    minus_button.pressed.connect(_decrease_effroi)
    controls.add_child(minus_button)

    effroi_value_label = Label.new()
    effroi_value_label.custom_minimum_size = Vector2(86, 46)
    effroi_value_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    effroi_value_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    effroi_value_label.add_theme_font_size_override("font_size", 17)
    controls.add_child(effroi_value_label)

    plus_button = Button.new()
    plus_button.text = "+"
    plus_button.custom_minimum_size = Vector2(46, 46)
    plus_button.add_theme_font_size_override("font_size", 22)
    plus_button.pressed.connect(_increase_effroi)
    controls.add_child(plus_button)

    resolve_button = Button.new()
    resolve_button.text = "COMBATTRE"
    resolve_button.custom_minimum_size = Vector2(150, 46)
    resolve_button.add_theme_font_size_override("font_size", 15)
    resolve_button.pressed.connect(_resolve_round)
    controls.add_child(resolve_button)

    restart_button = Button.new()
    restart_button.text = "RECOMMENCER"
    restart_button.position = Vector2(1085, 658)
    restart_button.size = Vector2(165, 40)
    restart_button.visible = false
    restart_button.pressed.connect(_restart_match)
    add_child(restart_button)

    overlay = ColorRect.new()
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.color = Color(0.15, 0.02, 0.04, 0.0)
    overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(overlay)

    overlay_label = Label.new()
    overlay_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
    overlay_label.position = Vector2(-200, -45)
    overlay_label.size = Vector2(400, 90)
    overlay_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    overlay_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    overlay_label.add_theme_font_size_override("font_size", 34)
    overlay_label.add_theme_color_override("font_color", Color.WHITE)
    overlay_label.modulate.a = 0.0
    overlay.add_child(overlay_label)

func _spawn_cards() -> void:
    for c in player_cards:
        c.queue_free()
    for c in ai_cards:
        c.queue_free()
    player_cards.clear()
    ai_cards.clear()

    for data in cards_data:
        var p := CardView.new()
        p.setup(data, true)
        p.card_pressed.connect(_on_player_card_pressed)
        add_child(p)
        player_cards.append(p)

    var shuffled := cards_data.duplicate(true)
    shuffled.shuffle()
    for data in shuffled:
        var a := CardView.new()
        a.setup(data, false)
        a.set_selectable(false)
        add_child(a)
        ai_cards.append(a)

func _layout_all() -> void:
    var w := size.x
    var h := size.y
    if w <= 0 or h <= 0:
        return
    var spacing := min(165.0, (w - 100.0) / max(5.0, float(player_cards.size())))
    var total := spacing * float(max(0, player_cards.size() - 1)) + CARD_SIZE.x
    var start_x := (w - total) * 0.5

    for i in range(player_cards.size()):
        var card := player_cards[i]
        if not card.visible or card == selected_card and battle_locked:
            continue
        var x := start_x + i * spacing
        var pos := Vector2(x, h - CARD_SIZE.y - 72)
        var rot := deg_to_rad((i - 2) * 1.6)
        card.set_home(pos, rot, Vector2.ONE, not battle_locked)

    for i in range(ai_cards.size()):
        var card := ai_cards[i]
        if not card.visible:
            continue
        var x := start_x + i * spacing
        var pos := Vector2(x, 58)
        var rot := deg_to_rad((2 - i) * 1.6)
        card.set_home(pos, rot, Vector2.ONE, not battle_locked)

func _on_player_card_pressed(card: CardView) -> void:
    if battle_locked or not card.visible:
        return
    if selected_card and selected_card != card:
        selected_card.set_selected(false)
    selected_card = card
    card.set_selected(true)
    message_label.text = "%s sélectionné. Choisis 0 à %d Effroi puis COMBATTRE." % [card.card_data.get("name", "Carte"), min(MAX_EFFROI_PER_DUEL, player_effroi)]
    _update_ui()

func _increase_effroi() -> void:
    if battle_locked:
        return
    selected_effroi = min(selected_effroi + 1, min(MAX_EFFROI_PER_DUEL, player_effroi))
    _update_ui()

func _decrease_effroi() -> void:
    if battle_locked:
        return
    selected_effroi = max(0, selected_effroi - 1)
    _update_ui()

func _pick_ai_card() -> CardView:
    var candidates: Array[CardView] = []
    for card in ai_cards:
        if card.visible:
            candidates.append(card)
    if candidates.is_empty():
        return null

    var player_attacks_this_round := (round_index % 2 == 0)
    candidates.sort_custom(func(a: CardView, b: CardView):
        var av := int(a.card_data.get("defense" if player_attacks_this_round else "attack", 0))
        var bv := int(b.card_data.get("defense" if player_attacks_this_round else "attack", 0))
        return av > bv
    )
    var pool_size := min(3, candidates.size())
    return candidates[randi() % pool_size]

func _ai_effroi_choice(ai_card: CardView) -> int:
    var max_spend := min(MAX_EFFROI_PER_DUEL, ai_effroi)
    if max_spend <= 0:
        return 0
    var base := int(ai_card.card_data.get("attack" if round_index % 2 == 1 else "defense", 0))
    if base < 60:
        return min(2, max_spend)
    if base < 82:
        return min(1, max_spend)
    return 0

func _resolve_round() -> void:
    if battle_locked or selected_card == null:
        return
    var ai_card := _pick_ai_card()
    if ai_card == null:
        return

    battle_locked = true
    _set_cards_interactive(false)
    selected_card.set_selected(false)
    var player_card := selected_card
    var player_spend := selected_effroi
    var ai_spend := _ai_effroi_choice(ai_card)
    player_effroi -= player_spend
    ai_effroi -= ai_spend
    selected_effroi = 0
    _update_ui()

    var arena_y := size.y * 0.5 - CARD_SIZE.y * 0.5
    var player_target := Vector2(size.x * 0.5 - CARD_SIZE.x - 42, arena_y)
    var ai_target := Vector2(size.x * 0.5 + 42, arena_y)

    message_label.text = "Les cartes entrent dans l’arène…"
    await player_card.animate_play_to(player_target)
    await ai_card.animate_play_to(ai_target, true)
    await get_tree().create_timer(0.18).timeout

    var player_is_attacker := round_index % 2 == 0
    var attacker := player_card if player_is_attacker else ai_card
    var defender := ai_card if player_is_attacker else player_card

    var player_value := int(player_card.card_data.get("attack" if player_is_attacker else "defense", 0)) + player_spend * EFFROI_BONUS
    var ai_value := int(ai_card.card_data.get("defense" if player_is_attacker else "attack", 0)) + ai_spend * EFFROI_BONUS

    message_label.text = "%s %d  VS  %s %d" % [
        "ATTAQUE" if player_is_attacker else "DÉFENSE", player_value,
        "DÉFENSE" if player_is_attacker else "ATTAQUE", ai_value
    ]

    await attacker.animate_attack_toward(defender.position)
    await defender.animate_hit()
    await _impact_flash()

    var player_wins := false
    if player_value == ai_value:
        player_wins = not player_is_attacker
    else:
        player_wins = player_value > ai_value

    if player_wins:
        player_score += 1
        await _show_round_result("MANCHE GAGNÉE", Color(0.10, 0.35, 0.16, 0.72))
    else:
        ai_score += 1
        await _show_round_result("MANCHE PERDUE", Color(0.38, 0.06, 0.09, 0.76))

    var discard_y := size.y * 0.5 - 70
    var player_discard := Vector2(42, discard_y)
    var ai_discard := Vector2(size.x - CARD_SIZE.x - 42, discard_y)
    await player_card.animate_discard(player_discard)
    await ai_card.animate_discard(ai_discard)

    round_index += 1
    selected_card = null
    if _is_match_over():
        _finish_match()
        return

    battle_locked = false
    _set_cards_interactive(true)
    _layout_all()
    message_label.text = "Choisis ta carte pour la manche %d." % (round_index + 1)
    _update_ui()

func _impact_flash() -> void:
    overlay.color = Color(0.86, 0.86, 0.95, 0.0)
    var t := create_tween()
    t.tween_property(overlay, "color:a", 0.44, 0.045)
    t.tween_property(overlay, "color:a", 0.0, 0.12)
    await t.finished

func _show_round_result(text_value: String, tint: Color) -> void:
    overlay.color = tint
    overlay.color.a = 0.0
    overlay_label.text = text_value
    overlay_label.modulate.a = 0.0
    overlay_label.scale = Vector2(0.78, 0.78)
    overlay_label.pivot_offset = overlay_label.size * 0.5
    var t := create_tween().set_parallel(true)
    t.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    t.tween_property(overlay, "color:a", tint.a, 0.18)
    t.tween_property(overlay_label, "modulate:a", 1.0, 0.18)
    t.tween_property(overlay_label, "scale", Vector2.ONE, 0.22)
    await t.finished
    await get_tree().create_timer(0.48).timeout
    var out := create_tween().set_parallel(true)
    out.tween_property(overlay, "color:a", 0.0, 0.20)
    out.tween_property(overlay_label, "modulate:a", 0.0, 0.20)
    await out.finished

func _is_match_over() -> bool:
    return player_score >= 3 or ai_score >= 3 or round_index >= 5

func _finish_match() -> void:
    battle_locked = true
    _set_cards_interactive(false)
    resolve_button.disabled = true
    minus_button.disabled = true
    plus_button.disabled = true
    restart_button.visible = true
    var won := player_score > ai_score
    message_label.text = "VICTOIRE %d–%d" % [player_score, ai_score] if won else "DÉFAITE %d–%d" % [player_score, ai_score]
    role_label.text = "MATCH TERMINÉ"
    _update_ui()

func _restart_match() -> void:
    round_index = 0
    player_score = 0
    ai_score = 0
    player_effroi = STARTING_EFFROI
    ai_effroi = STARTING_EFFROI
    selected_effroi = 0
    selected_card = null
    battle_locked = false
    restart_button.visible = false
    _spawn_cards()
    _layout_all()
    _set_cards_interactive(true)
    message_label.text = "Choisis une carte pour commencer."
    _update_ui()

func _set_cards_interactive(enabled: bool) -> void:
    for c in player_cards:
        if c.visible:
            c.set_selectable(enabled)

func _update_ui() -> void:
    score_label.text = "TOI  %d  :  %d  IA" % [player_score, ai_score]
    var player_attacks := round_index % 2 == 0
    role_label.text = "MANCHE %d · TU %s" % [min(round_index + 1, 5), "ATTAQUES" if player_attacks else "DÉFENDS"]
    effroi_label.text = "EFFROI : %d / %d" % [player_effroi, STARTING_EFFROI]
    effroi_value_label.text = "%d Effroi  (+%d)" % [selected_effroi, selected_effroi * EFFROI_BONUS]
    var can_resolve := selected_card != null and not battle_locked
    resolve_button.disabled = not can_resolve
    minus_button.disabled = battle_locked or selected_effroi <= 0
    plus_button.disabled = battle_locked or selected_effroi >= min(MAX_EFFROI_PER_DUEL, player_effroi)

