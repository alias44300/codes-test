# Correction bornée de la distance moyenne

## Avant

- part moyenne des plans `MEDIUM` : 19,46 % ;
- quatre profils sur quatre avec une distance dominante incorrecte.

## Après

- part moyenne des plans `MEDIUM` : 50,42 % ;
- quatre profils sur quatre avec `MID` comme distance dominante ;
- plans `LONG` et `CLOSE` toujours au-dessus de leurs seuils ;
- 0 changement des empreintes historiques lorsque les effets tactiques sont désactivés.

## Portée du code

Seuls `TacticalPlanApplication.mediumRangeResistance` et son appel depuis `FightEngine.resolveRange` sont concernés. La formule est pure, symétrique, bornée et désactivée en l'absence de plan.
