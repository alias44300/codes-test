package titlefight

import kotlin.math.abs

data class MatchupMatrixRow(
    val fighterAId: String,
    val fighterAName: String,
    val fighterAStyle: BoxingStyle,
    val fighterBId: String,
    val fighterBName: String,
    val fighterBStyle: BoxingStyle,
    val seedPairs: Int,
    val fights: Int,
    val fighterAWins: Int,
    val fighterBWins: Int,
    val draws: Int,
    val ko: Int,
    val tko: Int,
    val decisions: Int,
    val fighterAWinsAsRed: Int,
    val fighterAWinsAsBlue: Int,
    val fighterBWinsAsRed: Int,
    val fighterBWinsAsBlue: Int,
    val pairedSameWinner: Int,
    val pairedDifferentWinner: Int,
    val pairedContainsDraw: Int,
) {
    val fighterAWinShare: Double get() = ratio(fighterAWins, fights)
    val fighterBWinShare: Double get() = ratio(fighterBWins, fights)
    val drawShare: Double get() = ratio(draws, fights)
    val fighterANonDrawWinShare: Double get() = ratioOrHalf(fighterAWins, fighterAWins + fighterBWins)
    val fighterBNonDrawWinShare: Double get() = ratioOrHalf(fighterBWins, fighterAWins + fighterBWins)
    val fighterACornerGap: Double get() = abs(ratio(fighterAWinsAsRed, seedPairs) - ratio(fighterAWinsAsBlue, seedPairs))
    val fighterBCornerGap: Double get() = abs(ratio(fighterBWinsAsRed, seedPairs) - ratio(fighterBWinsAsBlue, seedPairs))

    private fun ratio(value: Int, total: Int): Double = if (total == 0) 0.0 else value.toDouble() / total
    private fun ratioOrHalf(value: Int, total: Int): Double = if (total == 0) 0.5 else value.toDouble() / total
}

data class BoxerMatrixSummary(
    val fighterId: String,
    val fighterName: String,
    val style: BoxingStyle,
    val fights: Int,
    val redAppearances: Int,
    val blueAppearances: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val koWins: Int,
    val tkoWins: Int,
    val redWins: Int,
    val blueWins: Int,
) {
    val winShare: Double get() = ratio(wins, fights)
    val nonDrawWinShare: Double get() = ratioOrHalf(wins, wins + losses)
    val drawShare: Double get() = ratio(draws, fights)
    val redWinShare: Double get() = ratio(redWins, redAppearances)
    val blueWinShare: Double get() = ratio(blueWins, blueAppearances)
    val cornerGap: Double get() = abs(redWinShare - blueWinShare)

    private fun ratio(value: Int, total: Int): Double = if (total == 0) 0.0 else value.toDouble() / total
    private fun ratioOrHalf(value: Int, total: Int): Double = if (total == 0) 0.5 else value.toDouble() / total
}

data class StyleMatrixSummary(
    val style: BoxingStyle,
    val appearances: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
) {
    val winShare: Double get() = if (appearances == 0) 0.0 else wins.toDouble() / appearances
    val nonDrawWinShare: Double get() = if (wins + losses == 0) 0.5 else wins.toDouble() / (wins + losses)
}

data class Jalon5Step3AuditResult(
    val seedPairsPerDuel: Int,
    val matchups: List<MatchupMatrixRow>,
    val boxers: List<BoxerMatrixSummary>,
    val styles: List<StyleMatrixSummary>,
    val totalFights: Int,
    val redWins: Int,
    val blueWins: Int,
    val draws: Int,
    val ko: Int,
    val tko: Int,
    val decisions: Int,
    val reproducibilityChecks: Int,
    val reproducibilityMismatches: Int,
    val invalidResults: Int,
    val missingAppliedPlans: Int,
    val planDecisionMismatches: Int,
    val decisionsAfterStoppage: Int,
    val legacyBehaviorFingerprintMismatches: Int,
    val calibrationFlags: List<String>,
) {
    val redWinnerShare: Double get() = if (redWins + blueWins == 0) 0.5 else redWins.toDouble() / (redWins + blueWins)
    val stoppageShare: Double get() = if (totalFights == 0) 0.0 else (ko + tko).toDouble() / totalFights
    val technicalIntegrityAccepted: Boolean
        get() = matchups.size == 45 &&
            totalFights == 45 * seedPairsPerDuel * 2 &&
            reproducibilityMismatches == 0 &&
            invalidResults == 0 &&
            missingAppliedPlans == 0 &&
            planDecisionMismatches == 0 &&
            decisionsAfterStoppage == 0 &&
            legacyBehaviorFingerprintMismatches == 0
}

object Jalon5Step3Auditor {
    const val SEED_PAIRS_PER_DUEL = 100
    private const val REPRO_PAIRS_PER_DUEL = 2
    private const val SEED_START = 202607214000L

    private data class MutableBoxerTotals(
        var fights: Int = 0,
        var redAppearances: Int = 0,
        var blueAppearances: Int = 0,
        var wins: Int = 0,
        var losses: Int = 0,
        var draws: Int = 0,
        var koWins: Int = 0,
        var tkoWins: Int = 0,
        var redWins: Int = 0,
        var blueWins: Int = 0,
    )

    private data class MutableStyleTotals(
        var appearances: Int = 0,
        var wins: Int = 0,
        var losses: Int = 0,
        var draws: Int = 0,
    )

    private data class MutableGlobalTotals(
        var totalFights: Int = 0,
        var redWins: Int = 0,
        var blueWins: Int = 0,
        var draws: Int = 0,
        var ko: Int = 0,
        var tko: Int = 0,
        var decisions: Int = 0,
        var reproducibilityChecks: Int = 0,
        var reproducibilityMismatches: Int = 0,
        var invalidResults: Int = 0,
        var missingAppliedPlans: Int = 0,
        var planDecisionMismatches: Int = 0,
        var decisionsAfterStoppage: Int = 0,
    )

    fun run(): Jalon5Step3AuditResult = runWindow(
        seedPairsPerDuel = SEED_PAIRS_PER_DUEL,
        seedStart = SEED_START,
        reproducibilityPairsPerDuel = REPRO_PAIRS_PER_DUEL,
    )

    fun runWindow(
        seedPairsPerDuel: Int,
        seedStart: Long,
        reproducibilityPairsPerDuel: Int = 1,
    ): Jalon5Step3AuditResult {
        require(seedPairsPerDuel > 0)
        require(reproducibilityPairsPerDuel in 0..seedPairsPerDuel)
        val roster = BoxerCatalog.all
        val engine = FightEngine(adaptiveTacticsEnabled = true)
        val boxerTotals = roster.associate { it.id to MutableBoxerTotals() }.toMutableMap()
        val styleTotals = BoxingStyle.entries.associateWith { MutableStyleTotals() }.toMutableMap()
        val global = MutableGlobalTotals()
        val rows = mutableListOf<MatchupMatrixRow>()

        var duelIndex = 0
        roster.forEachIndexed { firstIndex, fighterA ->
            roster.drop(firstIndex + 1).forEach { fighterB ->
                var fighterAWins = 0
                var fighterBWins = 0
                var draws = 0
                var ko = 0
                var tko = 0
                var decisions = 0
                var fighterAWinsAsRed = 0
                var fighterAWinsAsBlue = 0
                var fighterBWinsAsRed = 0
                var fighterBWinsAsBlue = 0
                var pairedSameWinner = 0
                var pairedDifferentWinner = 0
                var pairedContainsDraw = 0

                repeat(seedPairsPerDuel) { pairIndex ->
                    val seed = seedStart + duelIndex * 1_000_000L + pairIndex
                    val aRed = simulate(engine, fighterA, fighterB, seed)
                    val bRed = simulate(engine, fighterB, fighterA, seed)

                    collectFight(aRed, fighterA, fighterB, boxerTotals, styleTotals, global)
                    collectFight(bRed, fighterB, fighterA, boxerTotals, styleTotals, global)

                    listOf(aRed, bRed).forEach { fight ->
                        val winner = winnerId(fight)
                        when (winner) {
                            fighterA.id -> fighterAWins++
                            fighterB.id -> fighterBWins++
                            null -> draws++
                            else -> global.invalidResults++
                        }
                        when (fight.stoppage?.method) {
                            FightMethod.KO -> ko++
                            FightMethod.TKO -> tko++
                            null -> decisions++
                        }
                    }

                    if (winnerId(aRed) == fighterA.id) fighterAWinsAsRed++
                    if (winnerId(bRed) == fighterA.id) fighterAWinsAsBlue++
                    if (winnerId(bRed) == fighterB.id) fighterBWinsAsRed++
                    if (winnerId(aRed) == fighterB.id) fighterBWinsAsBlue++

                    val winnerOne = winnerId(aRed)
                    val winnerTwo = winnerId(bRed)
                    if (winnerOne == null || winnerTwo == null) {
                        pairedContainsDraw++
                    } else if (winnerOne == winnerTwo) {
                        pairedSameWinner++
                    } else {
                        pairedDifferentWinner++
                    }

                    if (pairIndex < reproducibilityPairsPerDuel) {
                        val repeatedARed = simulate(engine, fighterA, fighterB, seed)
                        val repeatedBRed = simulate(engine, fighterB, fighterA, seed)
                        global.reproducibilityChecks += 2
                        if (repeatedARed != aRed) global.reproducibilityMismatches++
                        if (repeatedBRed != bRed) global.reproducibilityMismatches++
                    }
                }

                rows += MatchupMatrixRow(
                    fighterAId = fighterA.id,
                    fighterAName = fighterA.name,
                    fighterAStyle = fighterA.style,
                    fighterBId = fighterB.id,
                    fighterBName = fighterB.name,
                    fighterBStyle = fighterB.style,
                    seedPairs = seedPairsPerDuel,
                    fights = seedPairsPerDuel * 2,
                    fighterAWins = fighterAWins,
                    fighterBWins = fighterBWins,
                    draws = draws,
                    ko = ko,
                    tko = tko,
                    decisions = decisions,
                    fighterAWinsAsRed = fighterAWinsAsRed,
                    fighterAWinsAsBlue = fighterAWinsAsBlue,
                    fighterBWinsAsRed = fighterBWinsAsRed,
                    fighterBWinsAsBlue = fighterBWinsAsBlue,
                    pairedSameWinner = pairedSameWinner,
                    pairedDifferentWinner = pairedDifferentWinner,
                    pairedContainsDraw = pairedContainsDraw,
                )
                duelIndex++
            }
        }

        val boxerSummaries = roster.map { fighter ->
            val totals = boxerTotals.getValue(fighter.id)
            BoxerMatrixSummary(
                fighterId = fighter.id,
                fighterName = fighter.name,
                style = fighter.style,
                fights = totals.fights,
                redAppearances = totals.redAppearances,
                blueAppearances = totals.blueAppearances,
                wins = totals.wins,
                losses = totals.losses,
                draws = totals.draws,
                koWins = totals.koWins,
                tkoWins = totals.tkoWins,
                redWins = totals.redWins,
                blueWins = totals.blueWins,
            )
        }
        val styleSummaries = BoxingStyle.entries.map { style ->
            val totals = styleTotals.getValue(style)
            StyleMatrixSummary(style, totals.appearances, totals.wins, totals.losses, totals.draws)
        }
        val provisional = Jalon5Step3AuditResult(
            seedPairsPerDuel = seedPairsPerDuel,
            matchups = rows,
            boxers = boxerSummaries,
            styles = styleSummaries,
            totalFights = global.totalFights,
            redWins = global.redWins,
            blueWins = global.blueWins,
            draws = global.draws,
            ko = global.ko,
            tko = global.tko,
            decisions = global.decisions,
            reproducibilityChecks = global.reproducibilityChecks,
            reproducibilityMismatches = global.reproducibilityMismatches,
            invalidResults = global.invalidResults,
            missingAppliedPlans = global.missingAppliedPlans,
            planDecisionMismatches = global.planDecisionMismatches,
            decisionsAfterStoppage = global.decisionsAfterStoppage,
            legacyBehaviorFingerprintMismatches = LegacyBehaviorFingerprint.verify(),
            calibrationFlags = emptyList(),
        )
        return provisional.copy(calibrationFlags = calibrationFlags(provisional))
    }

    fun assertTechnicalIntegrity(result: Jalon5Step3AuditResult) {
        check(result.technicalIntegrityAccepted)
        check(result.matchups.size == 45)
        check(result.matchups.map { setOf(it.fighterAId, it.fighterBId) }.distinct().size == 45)
        check(result.matchups.all { it.seedPairs == SEED_PAIRS_PER_DUEL && it.fights == SEED_PAIRS_PER_DUEL * 2 })
        check(result.matchups.all { it.fighterAWins + it.fighterBWins + it.draws == it.fights })
        check(result.matchups.all { it.ko + it.tko + it.decisions == it.fights })
        check(result.matchups.all { it.pairedSameWinner + it.pairedDifferentWinner + it.pairedContainsDraw == it.seedPairs })
        check(result.totalFights == 9_000)
        check(result.redWins + result.blueWins + result.draws == result.totalFights)
        check(result.ko + result.tko + result.decisions == result.totalFights)
        check(result.reproducibilityChecks == 180)
        check(result.boxers.size == 10)
        result.boxers.forEach { summary ->
            check(summary.fights == 1_800)
            check(summary.redAppearances == 900)
            check(summary.blueAppearances == 900)
            check(summary.wins + summary.losses + summary.draws == summary.fights)
            check(summary.koWins + summary.tkoWins <= summary.wins)
        }
        check(result.styles.map { it.style }.toSet() == BoxingStyle.entries.toSet())
        check(result.styles.sumOf { it.appearances } == result.totalFights * 2)
        check(result.styles.sumOf { it.wins } == result.redWins + result.blueWins)
        check(result.styles.sumOf { it.draws } == result.draws * 2)
    }

    fun matchupsCsv(result: Jalon5Step3AuditResult): String = buildString {
        appendLine("fighter_a_id,fighter_a_name,fighter_a_style,fighter_b_id,fighter_b_name,fighter_b_style,seed_pairs,fights,a_wins,b_wins,draws,ko,tko,decisions,a_win_share,b_win_share,draw_share,a_non_draw_win_share,b_non_draw_win_share,a_wins_as_red,a_wins_as_blue,b_wins_as_red,b_wins_as_blue,a_corner_gap,b_corner_gap,paired_same_winner,paired_different_winner,paired_contains_draw")
        result.matchups.forEach { row ->
            appendLine(listOf(
                row.fighterAId, row.fighterAName, row.fighterAStyle,
                row.fighterBId, row.fighterBName, row.fighterBStyle,
                row.seedPairs, row.fights, row.fighterAWins, row.fighterBWins, row.draws,
                row.ko, row.tko, row.decisions,
                f(row.fighterAWinShare), f(row.fighterBWinShare), f(row.drawShare),
                f(row.fighterANonDrawWinShare), f(row.fighterBNonDrawWinShare),
                row.fighterAWinsAsRed, row.fighterAWinsAsBlue,
                row.fighterBWinsAsRed, row.fighterBWinsAsBlue,
                f(row.fighterACornerGap), f(row.fighterBCornerGap),
                row.pairedSameWinner, row.pairedDifferentWinner, row.pairedContainsDraw,
            ).joinToString(","))
        }
    }

    fun boxerCsv(result: Jalon5Step3AuditResult): String = buildString {
        appendLine("fighter_id,fighter_name,style,fights,wins,losses,draws,ko_wins,tko_wins,win_share,non_draw_win_share,draw_share,red_appearances,blue_appearances,red_wins,blue_wins,red_win_share,blue_win_share,corner_gap")
        result.boxers.forEach { row ->
            appendLine(listOf(
                row.fighterId, row.fighterName, row.style, row.fights,
                row.wins, row.losses, row.draws, row.koWins, row.tkoWins,
                f(row.winShare), f(row.nonDrawWinShare), f(row.drawShare),
                row.redAppearances, row.blueAppearances, row.redWins, row.blueWins,
                f(row.redWinShare), f(row.blueWinShare), f(row.cornerGap),
            ).joinToString(","))
        }
    }

    fun stylesCsv(result: Jalon5Step3AuditResult): String = buildString {
        appendLine("style,appearances,wins,losses,draws,win_share,non_draw_win_share")
        result.styles.forEach { row ->
            appendLine("${row.style},${row.appearances},${row.wins},${row.losses},${row.draws},${f(row.winShare)},${f(row.nonDrawWinShare)}")
        }
    }

    private fun simulate(engine: FightEngine, red: BoxerProfile, blue: BoxerProfile, seed: Long): FightResult =
        engine.simulateThreeRoundFight(
            red = red,
            blue = blue,
            redTactics = tacticsFor(red.style),
            blueTactics = tacticsFor(blue.style),
            seed = seed,
        )

    private fun tacticsFor(style: BoxingStyle): List<Tactic> = when (style) {
        BoxingStyle.OUT_BOXER -> listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
        BoxingStyle.PRESSURE_FIGHTER -> listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)
        BoxingStyle.COUNTERPUNCHER -> listOf(Tactic.COUNTER, Tactic.COUNTER, Tactic.CONTROL)
        BoxingStyle.BOXER_PUNCHER -> listOf(Tactic.CONTROL, Tactic.COUNTER, Tactic.PRESS)
        BoxingStyle.SWARMER -> listOf(Tactic.PRESS, Tactic.PRESS, Tactic.BODY_WORK)
        BoxingStyle.SLUGGER -> listOf(Tactic.SEEK_KO, Tactic.RECOVER, Tactic.SEEK_KO)
        BoxingStyle.DEFENSIVE_SPECIALIST -> listOf(Tactic.COUNTER, Tactic.CONTROL, Tactic.RECOVER)
    }

    private fun collectFight(
        fight: FightResult,
        red: BoxerProfile,
        blue: BoxerProfile,
        boxerTotals: MutableMap<String, MutableBoxerTotals>,
        styleTotals: MutableMap<BoxingStyle, MutableStyleTotals>,
        global: MutableGlobalTotals,
    ) {
        global.totalFights++
        val valid = validateFight(fight, red, blue)
        if (!valid) global.invalidResults++

        val redTotals = boxerTotals.getValue(red.id)
        val blueTotals = boxerTotals.getValue(blue.id)
        val redStyle = styleTotals.getValue(red.style)
        val blueStyle = styleTotals.getValue(blue.style)
        redTotals.fights++
        blueTotals.fights++
        redTotals.redAppearances++
        blueTotals.blueAppearances++
        redStyle.appearances++
        blueStyle.appearances++

        fight.rounds.forEach { round ->
            if (!round.tacticalEffectsEnabled || round.redAppliedTacticalPlan == null || round.blueAppliedTacticalPlan == null) {
                global.missingAppliedPlans++
            }
            val decisions = fight.tacticalDecisions.filter { it.beforeRound == round.roundNumber }
            if (decisions.size != 2 ||
                decisions[0].selectedPlan != round.redAppliedTacticalPlan ||
                decisions[1].selectedPlan != round.blueAppliedTacticalPlan
            ) {
                global.planDecisionMismatches++
            }
        }
        if (fight.stoppage != null && fight.tacticalDecisions.any { it.beforeRound > fight.stoppage.roundNumber }) {
            global.decisionsAfterStoppage++
        }

        val winner = winnerId(fight)
        when (winner) {
            red.id -> {
                global.redWins++
                redTotals.wins++
                blueTotals.losses++
                redTotals.redWins++
                redStyle.wins++
                blueStyle.losses++
                when (fight.stoppage?.method) {
                    FightMethod.KO -> redTotals.koWins++
                    FightMethod.TKO -> redTotals.tkoWins++
                    null -> Unit
                }
            }
            blue.id -> {
                global.blueWins++
                blueTotals.wins++
                redTotals.losses++
                blueTotals.blueWins++
                blueStyle.wins++
                redStyle.losses++
                when (fight.stoppage?.method) {
                    FightMethod.KO -> blueTotals.koWins++
                    FightMethod.TKO -> blueTotals.tkoWins++
                    null -> Unit
                }
            }
            null -> {
                global.draws++
                redTotals.draws++
                blueTotals.draws++
                redStyle.draws++
                blueStyle.draws++
            }
            else -> global.invalidResults++
        }

        when (fight.stoppage?.method) {
            FightMethod.KO -> global.ko++
            FightMethod.TKO -> global.tko++
            null -> global.decisions++
        }
    }

    private fun validateFight(fight: FightResult, red: BoxerProfile, blue: BoxerProfile): Boolean {
        if (fight.redId != red.id || fight.blueId != blue.id) return false
        if (!fight.adaptiveTacticsEnabled) return false
        if (fight.rounds.isEmpty() || fight.rounds.size > 3) return false
        if (fight.rounds.map { it.roundNumber } != (1..fight.rounds.size).toList()) return false
        if (fight.finalRedState != fight.rounds.last().redState || fight.finalBlueState != fight.rounds.last().blueState) return false
        if (fight.redPerformanceTotal.isNaN() || fight.bluePerformanceTotal.isNaN()) return false
        val winner = winnerId(fight)
        if (winner != null && winner !in setOf(red.id, blue.id)) return false
        return if (fight.stoppage != null) {
            fight.officialDecision == null &&
                fight.rounds.last().stoppage == fight.stoppage &&
                fight.stoppage.loserId in setOf(red.id, blue.id) &&
                fight.stoppage.winnerId != fight.stoppage.loserId
        } else {
            val decision = fight.officialDecision ?: return false
            fight.rounds.size == 3 &&
                fight.rounds.all { it.stoppage == null && it.judgeScores.size == 3 } &&
                decision.scorecards.size == 3 &&
                decision.scorecards.all { it.redTotal in 21..30 && it.blueTotal in 21..30 }
        }
    }

    private fun calibrationFlags(result: Jalon5Step3AuditResult): List<String> = buildList {
        result.boxers.filter { it.losses == 0 }.forEach { add("${it.fighterName} est invaincu sur ${it.fights} combats de matrice.") }
        result.boxers.filter { it.wins == 0 }.forEach { add("${it.fighterName} ne gagne aucun de ses ${it.fights} combats de matrice.") }
        result.boxers.filter { it.nonDrawWinShare !in 0.25..0.75 }.forEach {
            add("${it.fighterName} présente une part de victoires hors nuls de ${pct(it.nonDrawWinShare)}, hors de la bande exploratoire 25–75 %.")
        }
        result.styles.filter { it.nonDrawWinShare !in 0.35..0.65 }.forEach {
            add("Le style ${it.style} présente une part de victoires hors nuls de ${pct(it.nonDrawWinShare)}, hors de la bande exploratoire 35–65 %.")
        }
        result.boxers.filter { it.cornerGap > 0.08 }.forEach {
            add("${it.fighterName} présente un écart de coin de ${pct(it.cornerGap)}, à examiner pendant la calibration.")
        }
    }

    private fun winnerId(fight: FightResult): String? = fight.stoppage?.winnerId ?: fight.officialDecision?.winnerId
    private fun f(value: Double): String = "%.6f".format(java.util.Locale.ROOT, value)
    private fun pct(value: Double): String = "%.2f %%".format(java.util.Locale.ROOT, value * 100.0)
}

object Jalon5Step3AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step3Auditor.run()
        Jalon5Step3Auditor.assertTechnicalIntegrity(result)
        println("AUDIT JALON 5 — ÉTAPE 3")
        println("Duels uniques : ${result.matchups.size}")
        println("Paires de graines par duel : ${result.seedPairsPerDuel}")
        println("Combats : ${result.totalFights}")
        println("Victoires rouge / bleu / nuls : ${result.redWins} / ${result.blueWins} / ${result.draws}")
        println("Part rouge parmi les vainqueurs : ${pct(result.redWinnerShare)}")
        println("KO / TKO / décisions : ${result.ko} / ${result.tko} / ${result.decisions}")
        println("Contrôles de reproductibilité : ${result.reproducibilityChecks}")
        println("Écarts de reproductibilité : ${result.reproducibilityMismatches}")
        println("Résultats invalides : ${result.invalidResults}")
        println("Plans manquants / divergents : ${result.missingAppliedPlans} / ${result.planDecisionMismatches}")
        println("Décisions après arrêt : ${result.decisionsAfterStoppage}")
        println("Empreintes historiques modifiées : ${result.legacyBehaviorFingerprintMismatches}")
        println("Intégrité technique : ${if (result.technicalIntegrityAccepted) "VALIDÉE" else "ÉCHEC"}")
        println("Signaux pour l’étape 4 : ${result.calibrationFlags.size}")
        result.calibrationFlags.forEach { println("- $it") }
        println()
        result.boxers.sortedByDescending { it.nonDrawWinShare }.forEach { boxer ->
            println(
                "${boxer.fighterName} | ${boxer.style} | ${boxer.wins}-${boxer.losses}-${boxer.draws} | " +
                    "hors nuls ${pct(boxer.nonDrawWinShare)} | coin ${pct(boxer.cornerGap)} | KO/TKO ${boxer.koWins}/${boxer.tkoWins}",
            )
        }
    }

    private fun pct(value: Double): String = "%.2f%%".format(java.util.Locale.ROOT, value * 100.0)
}

object Jalon5Step3MatchupsCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step3Auditor.run()
        Jalon5Step3Auditor.assertTechnicalIntegrity(result)
        print(Jalon5Step3Auditor.matchupsCsv(result))
    }
}

object Jalon5Step3BoxersCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step3Auditor.run()
        Jalon5Step3Auditor.assertTechnicalIntegrity(result)
        print(Jalon5Step3Auditor.boxerCsv(result))
    }
}

object Jalon5Step3StylesCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step3Auditor.run()
        Jalon5Step3Auditor.assertTechnicalIntegrity(result)
        print(Jalon5Step3Auditor.stylesCsv(result))
    }
}
