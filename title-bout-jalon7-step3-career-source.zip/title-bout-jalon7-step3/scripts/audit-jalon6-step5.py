#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, re, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
checks: list[tuple[str,bool,str]] = []
def check(name: str, condition: bool, detail: str="") -> None: checks.append((name, bool(condition), detail))
def text(path: str) -> str: return (ROOT / path).read_text(encoding="utf-8")
required = [
 "settings.gradle.kts","build.gradle.kts","gradle/libs.versions.toml","gradle.properties",
 "gradlew","gradlew.bat","engine/build.gradle.kts","android-ui-compose/build.gradle.kts",
 "app/build.gradle.kts","app/src/main/AndroidManifest.xml",
 "app/src/main/kotlin/titlefight/app/MainActivity.kt",
 "app/src/test/kotlin/titlefight/app/DemoFightFactoryTest.kt",
 "app/src/androidTest/kotlin/titlefight/app/MainActivityTest.kt",
 ".github/workflows/android-build.yml",
 "scripts/bootstrap-android-sdk.sh","scripts/bootstrap-android-sdk.ps1",
 "scripts/build-android-demo.sh","scripts/install-and-verify-apk.sh",
]
for p in required: check(f"file:{p}", (ROOT/p).is_file())
versions = text("gradle/libs.versions.toml")
check("agp-9.3.0", 'agp = "9.3.0"' in versions)
check("kotlin-2.3.21", 'kotlin = "2.3.21"' in versions)
check("compose-bom-2026.06.00", 'composeBom = "2026.06.00"' in versions)
app = text("app/build.gradle.kts")
ui = text("android-ui-compose/build.gradle.kts")
manifest = text("app/src/main/AndroidManifest.xml")
main = text("app/src/main/kotlin/titlefight/app/MainActivity.kt")
check("compile-sdk-37", "compileSdk = 37" in app and "compileSdk = 37" in ui)
check("target-sdk-37", "targetSdk = 37" in app)
check("min-sdk-26", "minSdk = 26" in app and "minSdk = 26" in ui)
check("java-17", app.count("JavaVersion.VERSION_17") >= 2 and ui.count("JavaVersion.VERSION_17") >= 2)
check("portrait-activity", 'android:screenOrientation="portrait"' in manifest)
check("no-network-permission", "android.permission.INTERNET" not in manifest)
check("interactive-coordinator", "InteractiveFightCoordinator" in main and "onTacticalAction" in main)
check("no-real-boxers", "Muhammad" not in main and "Tyson" not in main)
check("no-pack-shop-currency", not re.search(r"\b(pack|shop|currency|coins)\b", main, re.I))
workflow = text(".github/workflows/android-build.yml")
check("ci-builds-apk", ":app:assembleDebug" in workflow and "upload-artifact@v4" in workflow)
check("gradle-checksum", "bafc141b619ad6350fd975fc903156dd5c151998cc8b058e8c1044ab5f7b031f" in text("gradlew"))
failed = [c for c in checks if not c[1]]
digest = hashlib.sha256("\n".join(f"{n}:{ok}:{d}" for n,ok,d in checks).encode()).hexdigest()
result = {"checks": len(checks), "passed": len(checks)-len(failed), "failed": len(failed), "digest": digest,
          "failures": [{"name":n,"detail":d} for n,_,d in failed]}
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(1 if failed else 0)
