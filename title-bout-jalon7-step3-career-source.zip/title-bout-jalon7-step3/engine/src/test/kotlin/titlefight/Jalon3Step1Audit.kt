package titlefight

import java.util.Locale

data class JudgingEvidenceStep1AuditResult(
    val fightCount: Int,
    val roundCount: Int,
    val sequenceCount: Int,
    val evidenceMismatchCount: Int,
    val emptyEvidenceCount: Int,
    val stoppedRounds: Int,
    val vegaInitiatives: Int,
    val kesslerInitiatives: Int,
    val vegaCleanHits: Int,
    val kesslerCleanHits: Int,
    val vegaKnockdowns: Int,
    val kesslerKnockdowns: Int,
) {
    init {
        require(fightCount == 1000)
        require(roundCount in fightCount..fightCount * 3)
        require(sequenceCount >= roundCount)
        require(evidenceMismatchCount >= 0)
        require(emptyEvidenceCount >= 0)
        require(stoppedRounds >= 0)
    }
}

object JudgingEvidenceStep1Auditor {
    private val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
    private val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

    fun run(seedStart: Long = 202607220000L): JudgingEvidenceStep1AuditResult {
        val engine = FightEngine()
        var roundCount = 0
        var sequenceCount = 0
        var evidenceMismatchCount = 0
        var emptyEvidenceCount = 0
        var stoppedRounds = 0
        var vegaInitiatives = 0
        var kesslerInitiatives = 0
        var vegaCleanHits = 0
        var kesslerCleanHits = 0
        var vegaKnockdowns = 0
        var kesslerKnockdowns = 0

        repeat(1000) { index ->
            val vegaInRed = index % 2 == 0
            val fight = if (vegaInRed) {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = vegaTactics,
                    blueTactics = kesslerTactics,
                    seed = seedStart + index,
                )
            } else {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.brunoKessler,
                    blue = TestProfiles.eliasVega,
                    redTactics = kesslerTactics,
                    blueTactics = vegaTactics,
                    seed = seedStart + index,
                )
            }

            fight.rounds.forEach { round ->
                roundCount++
                sequenceCount += round.events.size
                if (round.events.isEmpty()) emptyEvidenceCount++
                if (round.stoppage != null) stoppedRounds++

                val extracted = if (vegaInRed) {
                    RoundJudgingEvidenceExtractor.extract(
                        round.roundNumber,
                        TestProfiles.eliasVega,
                        TestProfiles.brunoKessler,
                        round.events,
                    )
                } else {
                    RoundJudgingEvidenceExtractor.extract(
                        round.roundNumber,
                        TestProfiles.brunoKessler,
                        TestProfiles.eliasVega,
                        round.events,
                    )
                }
                if (extracted != round.judgingEvidence) evidenceMismatchCount++

                val vegaEvidence = if (vegaInRed) round.judgingEvidence.red else round.judgingEvidence.blue
                val kesslerEvidence = if (vegaInRed) round.judgingEvidence.blue else round.judgingEvidence.red
                vegaInitiatives += vegaEvidence.initiatedSequences
                kesslerInitiatives += kesslerEvidence.initiatedSequences
                vegaCleanHits += vegaEvidence.cleanHits
                kesslerCleanHits += kesslerEvidence.cleanHits
                vegaKnockdowns += vegaEvidence.knockdownsScored
                kesslerKnockdowns += kesslerEvidence.knockdownsScored
            }
        }

        return JudgingEvidenceStep1AuditResult(
            fightCount = 1000,
            roundCount = roundCount,
            sequenceCount = sequenceCount,
            evidenceMismatchCount = evidenceMismatchCount,
            emptyEvidenceCount = emptyEvidenceCount,
            stoppedRounds = stoppedRounds,
            vegaInitiatives = vegaInitiatives,
            kesslerInitiatives = kesslerInitiatives,
            vegaCleanHits = vegaCleanHits,
            kesslerCleanHits = kesslerCleanHits,
            vegaKnockdowns = vegaKnockdowns,
            kesslerKnockdowns = kesslerKnockdowns,
        )
    }
}

object JudgingEvidenceStep1AuditFormatter {
    fun format(result: JudgingEvidenceStep1AuditResult): String = buildString {
        appendLine("TITLE FIGHT — JALON 3 — ÉTAPE 1")
        appendLine("AUDIT DES PREUVES OBJECTIVES DE ROUND")
        appendLine()
        appendLine("Combats : ${result.fightCount}")
        appendLine("Rounds réellement simulés : ${result.roundCount}")
        appendLine("Séquences réellement simulées : ${result.sequenceCount}")
        appendLine("Rounds interrompus par KO/TKO : ${result.stoppedRounds}")
        appendLine("Preuves vides : ${result.emptyEvidenceCount}")
        appendLine("Écarts entre preuves attachées et réextraction : ${result.evidenceMismatchCount}")
        appendLine()
        appendLine("Elias Vega — initiatives : ${result.vegaInitiatives}, coups nets : ${result.vegaCleanHits}, chutes provoquées : ${result.vegaKnockdowns}")
        appendLine("Bruno Kessler — initiatives : ${result.kesslerInitiatives}, coups nets : ${result.kesslerCleanHits}, chutes provoquées : ${result.kesslerKnockdowns}")
        appendLine()
        appendLine("Aucun point, vainqueur de round, carte ou décision officielle n’est calculé.")
    }
}

object JudgingEvidenceStep1AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        Locale.setDefault(Locale.FRANCE)
        print(JudgingEvidenceStep1AuditFormatter.format(JudgingEvidenceStep1Auditor.run()))
    }
}
