#!/usr/bin/env python3
from pathlib import Path
import json
import re

root = Path(__file__).resolve().parents[1]
roster_path = root / "database/seed/official-roster-321-v2.json"
roster = json.loads(roster_path.read_text(encoding="utf-8"))
boxers = roster["boxers"]
official = (root / "engine/src/main/kotlin/titlefight/OfficialRoster.kt").read_text(encoding="utf-8")
career = (root / "engine/src/main/kotlin/titlefight/CareerMode.kt").read_text(encoding="utf-8")
career_ui = (root / "app/src/main/kotlin/titlefight/app/CareerScreen.kt").read_text(encoding="utf-8")
home = (root / "app/src/main/kotlin/titlefight/app/HomeScreen.kt").read_text(encoding="utf-8")
main = (root / "app/src/main/kotlin/titlefight/app/MainActivity.kt").read_text(encoding="utf-8")

forbidden_fields = {"Rareté", "Coût", "Charisme"}
forbidden_words = re.compile(r"CardRarity|\.rarity\b|raret[ée]", re.IGNORECASE)
checks = {
    "roster_321": len(boxers) == 321,
    "continuous_ids": [b["ID"] for b in boxers] == [f"BOX-{i:03d}" for i in range(1, 322)],
    "no_card_game_fields_json": all(forbidden_fields.isdisjoint(b) for b in boxers),
    "no_rarity_in_runtime": not forbidden_words.search(official + career + career_ui + home + main),
    "young_created_boxer": "18 * 52" in career and "CareerCreationRequest" in career,
    "starts_unranked": "worldRanking: Int? = null" in career,
    "regional_belt": "ChampionshipBelt.REGIONAL" in career,
    "national_belt": "ChampionshipBelt.NATIONAL" in career,
    "continental_belt": "ChampionshipBelt.CONTINENTAL" in career,
    "four_world_belts": all(f"ChampionshipBelt.{belt}" in career for belt in ("WBA", "WBC", "IBF", "WBO")),
    "undisputed_stage": "UNDISPUTED_CHAMPION" in career,
    "training": "fun train(" in career and "TrainingFocus" in career_ui,
    "age_fatigue_health": all(token in career for token in ("ageInWeeks", "fatigue", "health")),
    "career_creation_screen": "COMMENCER À 18 ANS" in career_ui,
    "historical_roster_is_opponents": "adversaires historiques" in home.lower(),
}

result = {
    "status": "PASS" if all(checks.values()) else "FAIL",
    "checks": checks,
    "roster_count": len(boxers),
    "schema": roster.get("schema"),
}
out = root / "build-jalon7-step3/jalon7-step3-source-audit.json"
out.parent.mkdir(exist_ok=True)
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps(result, ensure_ascii=False, indent=2))
if result["status"] != "PASS":
    raise SystemExit(1)
