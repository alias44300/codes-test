#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
SPEC = json.loads((ROOT / "layout-spec.json").read_text(encoding="utf-8"))
FONT_REGULAR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

COLORS = {
    "bg": "#07111f",
    "bg2": "#050b14",
    "panel": "#101d2e",
    "panel2": "#15263a",
    "ink": "#f4f7fb",
    "muted": "#9fb0c5",
    "line": "#253a54",
    "gold": "#f2bd4b",
    "green": "#56d39b",
    "amber": "#f2a64b",
    "danger": "#f26767",
    "red": "#e54a52",
    "blue": "#3c86e8",
    "dark": "#07101d",
}

@dataclass(frozen=True)
class Scenario:
    width: int
    height: int
    phase: str
    name: str

SCENARIOS = [
    Scenario(320, 720, "active", "fight-screen-320-active"),
    Scenario(360, 800, "active", "fight-screen-360-active"),
    Scenario(412, 915, "active", "fight-screen-412-active"),
    Scenario(360, 800, "between", "fight-screen-360-between-rounds"),
    Scenario(360, 800, "complete", "fight-screen-360-complete"),
]


def hex_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return tuple(int(value[i:i+2], 16) for i in (0, 2, 4))


def font(size: float, bold: bool = False, scale: int = 2) -> ImageFont.FreeTypeFont:
    path = FONT_BOLD if bold else FONT_REGULAR
    return ImageFont.truetype(path, max(1, round(size * scale)))


def rounded(draw: ImageDraw.ImageDraw, box, radius, fill, outline=None, width=1, scale=2):
    draw.rounded_rectangle(tuple(round(v * scale) for v in box), radius=round(radius * scale), fill=fill, outline=outline, width=max(1, round(width * scale)))


def text(draw, xy, value, size, fill, *, bold=False, anchor=None, scale=2):
    draw.text((round(xy[0]*scale), round(xy[1]*scale)), value, fill=fill, font=font(size, bold, scale), anchor=anchor)


def text_size(draw, value, size, bold=False, scale=2):
    bbox = draw.textbbox((0,0), value, font=font(size, bold, scale))
    return (bbox[2]-bbox[0])/scale, (bbox[3]-bbox[1])/scale


def fit_text(draw, value: str, max_width: float, size: float, bold=False, scale=2) -> str:
    if text_size(draw, value, size, bold, scale)[0] <= max_width:
        return value
    ellipsis = "…"
    out = value
    while out and text_size(draw, out + ellipsis, size, bold, scale)[0] > max_width:
        out = out[:-1]
    return (out.rstrip() + ellipsis) if out else ellipsis


def wrap_text(draw, value: str, max_width: float, size: float, bold=False, max_lines=2, scale=2) -> list[str]:
    words = value.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = word if not current else current + " " + word
        if text_size(draw, candidate, size, bold, scale)[0] <= max_width:
            current = candidate
        else:
            if current:
                lines.append(current)
            current = word
            if len(lines) == max_lines - 1:
                break
    if current and len(lines) < max_lines:
        lines.append(current)
    consumed = " ".join(lines)
    if len(consumed) < len(value) and lines:
        lines[-1] = fit_text(draw, lines[-1] + " " + " ".join(words[len(consumed.split()):]), max_width, size, bold, scale)
    return lines[:max_lines]


class Renderer:
    def __init__(self, scenario: Scenario, scale: int = 2):
        self.s = scenario
        self.scale = scale
        bp = next(b for b in SPEC["breakpoints"] if b["width"] == scenario.width)
        self.pad = bp["outerMargin"]
        self.gap = bp["sectionGap"]
        self.col_gap = bp["columnGap"]
        self.min_font = bp["minimumFont"]
        self.tap = bp["minimumTapTarget"]
        self.img = Image.new("RGB", (scenario.width*scale, scenario.height*scale), COLORS["bg"])
        self.draw = ImageDraw.Draw(self.img)
        self.regions: list[dict] = []
        self.font_sizes: list[float] = []
        self.tap_targets: list[tuple[float,float]] = []
        self.messages: list[str] = []
        self._background()

    def _background(self):
        w, h = self.img.size
        top = hex_rgb("#0a1728")
        bottom = hex_rgb(COLORS["bg2"])
        for y in range(h):
            t = y / max(1, h-1)
            color = tuple(round(top[i]*(1-t) + bottom[i]*t) for i in range(3))
            self.draw.line((0,y,w,y), fill=color)
        # restrained blue halo
        cx, cy = w//2, -round(55*self.scale)
        radius = round(240*self.scale)
        overlay = Image.new("RGBA", self.img.size, (0,0,0,0))
        od = ImageDraw.Draw(overlay)
        for r in range(radius, 0, -max(1, radius//70)):
            alpha = round(18 * (r/radius)**2)
            od.ellipse((cx-r, cy-r, cx+r, cy+r), fill=(60,134,232,alpha))
        self.img = Image.alpha_composite(self.img.convert("RGBA"), overlay).convert("RGB")
        self.draw = ImageDraw.Draw(self.img)

    def t(self, xy, value, size, fill=COLORS["ink"], bold=False, anchor=None):
        size = max(size, self.min_font)
        self.font_sizes.append(size)
        text(self.draw, xy, value, size, fill, bold=bold, anchor=anchor, scale=self.scale)

    def region(self, name: str, box):
        self.regions.append({"name": name, "left": box[0], "top": box[1], "right": box[2], "bottom": box[3], "width": box[2]-box[0], "height": box[3]-box[1]})

    def panel(self, box, radius=13, fill=COLORS["panel"], outline=COLORS["line"]):
        rounded(self.draw, box, radius, fill, outline, 1, self.scale)

    def scoreboard(self, x, y, w, h):
        box = (x,y,x+w,y+h); self.region("scoreboard",box); self.panel(box)
        self.t((x+10,y+h/2),"TITLE FIGHT",11,COLORS["ink"],True,"lm")
        tw = 74
        timer_box=(x+(w-tw)/2,y+7,x+(w+tw)/2,y+h-7)
        rounded(self.draw,timer_box,10,COLORS["gold"],None,1,self.scale)
        timer = "0:00" if self.s.phase != "active" else "1:45"
        self.t(((timer_box[0]+timer_box[2])/2,(timer_box[1]+timer_box[3])/2),timer,22,"#09101a",True,"mm")
        label={"active":"ROUND 2 / 3","between":"FIN ROUND 1","complete":"COMBAT TERMINÉ"}[self.s.phase]
        self.t((x+w-10,y+h/2),label,10.5,COLORS["muted"],True,"rm")

    def fighter_card(self, box, corner, initials, name, nickname, style, condition, stats):
        x1,y1,x2,y2=box
        self.panel(box,14,COLORS["panel2"],COLORS["line"])
        self.draw.line((round((x1+1)*self.scale),round((y1+2)*self.scale),round((x2-1)*self.scale),round((y1+2)*self.scale)),fill=corner,width=round(3*self.scale))
        avatar=34 if self.s.width==320 else 38
        ax=x1+9; ay=y1+10
        rounded(self.draw,(ax,ay,ax+avatar,ay+avatar),avatar/2,"#182a40",corner,2,self.scale)
        self.t((ax+avatar/2,ay+avatar/2),initials,12.5,COLORS["ink"],True,"mm")
        tx=ax+avatar+7
        max_name=x2-tx-8
        label="COIN ROUGE" if corner==COLORS["red"] else "COIN BLEU"
        self.t((tx,ay+1),label,10,corner,True)
        self.t((tx,ay+13),fit_text(self.draw,name,max_name,12.5,True,self.scale),12.5,COLORS["ink"],True)
        self.t((tx,ay+28),fit_text(self.draw,nickname,max_name,10,False,self.scale),10,COLORS["muted"])
        py=ay+avatar+7
        style_w=(x2-x1)-18
        style_text=f"{style}  •  {condition}"
        rounded(self.draw,(x1+9,py,x2-9,py+20),10,"#0c1929",COLORS["line"],1,self.scale)
        self.t((x1+15,py+10),fit_text(self.draw,style_text,style_w-12,10,True,self.scale),10,COLORS["muted"],True,"lm")
        metric_y=py+27
        label_w=48 if self.s.width==320 else 54
        value_w=22
        bar_x=x1+9+label_w
        bar_w=(x2-9-value_w)-bar_x-5
        row_h=20
        for i,(label,val,color) in enumerate(stats):
            yy=metric_y+i*row_h
            self.t((x1+9,yy+7),label,10,COLORS["muted"],False,"lm")
            rounded(self.draw,(bar_x,yy+4,bar_x+bar_w,yy+11),4,COLORS["dark"],"#20324a",1,self.scale)
            fill=max(1,bar_w*val/100)
            rounded(self.draw,(bar_x,yy+4,bar_x+fill,yy+11),4,color,None,1,self.scale)
            self.t((x2-9,yy+7),str(val),10,COLORS["ink"],True,"rm")

    def fighters(self,x,y,w,h):
        box=(x,y,x+w,y+h); self.region("fighters",box)
        fw=(w-self.col_gap)/2
        red=(x,y,x+fw,y+h); blue=(x+fw+self.col_gap,y,x+w,y+h)
        self.fighter_card(red,COLORS["red"],"EV","ELIAS VEGA","« The Comet »","OUT-BOXER","ACTIF",[("Énergie",73,COLORS["green"]),("Tête",32,COLORS["danger"]),("Corps",24,COLORS["amber"]),("Stabilité",68,COLORS["blue"])])
        self.fighter_card(blue,COLORS["blue"],"BK","BRUNO KESSLER","« The Anvil »","PRESSION","FATIGUÉ",[("Énergie",58,COLORS["amber"]),("Tête",41,COLORS["danger"]),("Corps",37,COLORS["amber"]),("Stabilité",54,COLORS["blue"])])
        return fw

    def action(self,x,y,w,h):
        box=(x,y,x+w,y+h); self.region("currentAction",box); self.panel(box)
        if self.s.phase=="active":
            self.t((x+10,y+11),"DISTANCE MOYENNE",10,COLORS["muted"],True)
            self.t((x+10,y+28),fit_text(self.draw,"Kessler touche au corps avec un crochet compact.",w-105,12.5,True,self.scale),12.5,COLORS["ink"],True)
            badge=(x+w-86,y+10,x+w-10,y+h-10); rounded(self.draw,badge,10,"#2b271a",COLORS["gold"],1,self.scale)
            self.t(((badge[0]+badge[2])/2,(badge[1]+badge[3])/2),"IMPACT 8,6",10.5,COLORS["gold"],True,"mm")
        else:
            self.t((x+10,y+11),"FENÊTRE TACTIQUE",10,COLORS["muted"],True)
            self.t((x+10,y+28),"Préparez le plan du round 2.",12.5,COLORS["ink"],True)
            badge=(x+w-72,y+9,x+w-10,y+h-9); rounded(self.draw,badge,10,"#2b271a",COLORS["gold"],1,self.scale)
            self.t(((badge[0]+badge[2])/2,(badge[1]+badge[3])/2),"PAUSE",10.5,COLORS["gold"],True,"mm")

    def commentary(self,x,y,w,h):
        box=(x,y,x+w,y+h); self.region("commentary",box); self.panel(box)
        title="COMMENTAIRE" if self.s.phase=="active" else "CONSEIL DU COIN"
        message="Kessler coupe la sortie, mais Vega conserve assez d’espace pour pivoter." if self.s.phase=="active" else "Vega mène légèrement. Gardez la longue distance, mais attaquez davantage le corps."
        self.t((x+10,y+9),title,10,COLORS["muted"],True)
        lines=wrap_text(self.draw,message,w-20,12.5,True,2,self.scale)
        for i,line in enumerate(lines): self.t((x+10,y+27+i*16),line,12.5,COLORS["ink"],True)

    def log(self,x,y,w,h):
        box=(x,y,x+w,y+h); self.region("recentLog",box); self.panel(box)
        if self.s.phase=="active":
            entries=[("2:15","Vega marque avec un direct propre à longue distance."),("2:00","Kessler ferme l’angle et travaille sous les coudes."),("1:45","Crochet au corps touché, stabilité de Vega encore correcte.")]
        elif self.s.phase=="between":
            entries=[("R1","Vega a contrôlé la distance sur la seconde moitié du round."),("ÉTAT","Énergie correcte, aucun knockdown, stabilité préservée.")]
        else:
            entries=[("R3","Vega termine en mouvement et évite la dernière pression."),("FIN","Le combat va aux juges après trois rounds complets.")]
        row=(h-16)/len(entries)
        for i,(stamp,msg) in enumerate(entries):
            yy=y+8+i*row+row/2
            self.t((x+10,yy),stamp,10,COLORS["gold"],True,"lm")
            self.t((x+52,yy),fit_text(self.draw,msg,w-62,10.5,False,self.scale),10.5,"#d6dfeb",False,"lm")

    def tactics_active(self,x,y,w,h):
        box=(x,y,x+w,y+h); self.region("tacticalSummaryOrControls",box); self.panel(box)
        self.t((x+9,y+9),"PLANS TACTIQUES ACTUELS",10,COLORS["muted"],True)
        top=y+27; side_w=(w-18-self.col_gap)/2
        sides=[("VEGA",COLORS["red"],["Mesuré","Longue","Mixte","Sûr"],"Protège une courte avance et économise son énergie."),("KESSLER",COLORS["blue"],["Soutenu","Courte","Corps","Équilibré"],"Cherche à réduire l’écart estimé avant le dernier round.")]
        for idx,(name,color,pills,reason) in enumerate(sides):
            sx=x+9+idx*(side_w+self.col_gap)
            rounded(self.draw,(sx,top,sx+side_w,y+h-9),10,"#0b1727",COLORS["line"],1,self.scale)
            self.t((sx+8,top+8),name,10.5,color,True)
            px=sx+8; py=top+26
            for pill in pills:
                pw=text_size(self.draw,pill,10,True,self.scale)[0]+12
                if px+pw>sx+side_w-8: px=sx+8; py+=22
                rounded(self.draw,(px,py,px+pw,py+18),9,"#172a40","#2a405c",1,self.scale)
                self.t((px+pw/2,py+9),pill,10,"#d9e3ef",True,"mm")
                px+=pw+4
            if self.s.width>320:
                lines=wrap_text(self.draw,reason,side_w-16,10,False,2,self.scale)
                for i,line in enumerate(lines): self.t((sx+8,y+h-31+i*12),line,10,COLORS["muted"])

    def tactics_between(self,x,y,w,h):
        box=(x,y,x+w,y+h); self.region("tacticalSummaryOrControls",box); self.panel(box)
        self.t((x+9,y+9),"PLAN DU PROCHAIN ROUND — MAQUETTE STATIQUE",10,COLORS["muted"],True)
        groups=[("RYTHME",["Prud.","Mesuré","Sout."],1),("DISTANCE",["Longue","Moy.","Courte"],0),("CIBLE",["Tête","Corps","Mixte"],1),("RISQUE",["Sûr","Équil.","Aggr."],0)]
        gx=x+9; gy=y+28; group_w=(w-18-self.col_gap)/2; group_h=68
        for idx,(label,choices,selected) in enumerate(groups):
            col=idx%2; row=idx//2; sx=gx+col*(group_w+self.col_gap); sy=gy+row*(group_h+7)
            self.t((sx,sy),label,10,COLORS["muted"],True)
            cy=sy+17; cw=(group_w-8)/3
            for j,choice in enumerate(choices):
                bx=sx+j*(cw+4); b=(bx,cy,bx+cw,cy+self.tap)
                self.tap_targets.append((cw,self.tap))
                selected_fill="#2b271a" if j==selected else "#122238"; outline=COLORS["gold"] if j==selected else "#2c425f"; fill=COLORS["gold"] if j==selected else "#b8c5d6"
                rounded(self.draw,b,9,selected_fill,outline,1,self.scale)
                self.t(((b[0]+b[2])/2,(b[1]+b[3])/2),fit_text(self.draw,choice,cw-5,10,True,self.scale),10,fill,True,"mm")
        note_y=y+h-77
        self.t((x+9,note_y),"Zones prêtes pour le tactile. Contrôles inactifs à cette étape.",10,COLORS["muted"])
        button=(x+9,y+h-53,x+w-9,y+h-9); self.tap_targets.append((button[2]-button[0],button[3]-button[1]))
        rounded(self.draw,button,11,"#2b271a",COLORS["gold"],1,self.scale)
        self.t(((button[0]+button[2])/2,(button[1]+button[3])/2),"VALIDER LE PLAN",11,COLORS["gold"],True,"mm")

    def result(self,x,y,w,h):
        box=(x,y,x+w,y+h); self.region("commentary",box); self.panel(box)
        self.t((x+w/2,y+18),"DÉCISION OFFICIELLE",10.5,COLORS["gold"],True,"ma")
        self.t((x+w/2,y+45),"ELIAS VEGA",24,COLORS["ink"],True,"ma")
        self.t((x+w/2,y+72),"VAINQUEUR",24,COLORS["ink"],True,"ma")
        detail="Victoire par décision majoritaire après trois rounds. Les cartes détaillées ne sont pas affichées."
        lines=wrap_text(self.draw,detail,w-30,11.5,False,2,self.scale)
        for i,line in enumerate(lines): self.t((x+w/2,y+103+i*15),line,11.5,COLORS["muted"],False,"ma")
        values=[("34 / 72","coups"),("0","knockdowns"),("41","énergie")]
        stat_w=(w-24-12)/3; sy=y+h-52
        for i,(val,label) in enumerate(values):
            sx=x+12+i*(stat_w+6); rounded(self.draw,(sx,sy,sx+stat_w,y+h-10),9,"#0b1727","#233750",1,self.scale)
            self.t((sx+stat_w/2,sy+11),val,13,COLORS["ink"],True,"ma")
            self.t((sx+stat_w/2,sy+27),label,10,COLORS["muted"],False,"ma")

    def footer(self,x,y,w,h):
        box=(x,y,x+w,y+h); self.region("phaseFooter",box); self.panel(box)
        if self.s.phase=="complete":
            self.tap_targets.append((w-18,h-4)); rounded(self.draw,(x+9,y+2,x+w-9,y+h-2),10,"#2b271a",COLORS["gold"],1,self.scale)
            self.t((x+w/2,y+h/2),"REVOIR LE RÉSUMÉ",11,COLORS["gold"],True,"mm")
        else:
            status="COMBAT EN COURS" if self.s.phase=="active" else "ENTRE LES ROUNDS"
            seq="SÉQUENCE 5 / 12" if self.s.phase=="active" else "COMMANDES INACTIVES"
            self.t((x+10,y+h/2),status,11,COLORS["ink"],True,"lm")
            self.t((x+w-10,y+h/2),seq,10.5,COLORS["muted"],True,"rm")

    def render(self):
        x=self.pad; y=self.pad; w=self.s.width-2*self.pad
        top_h=48 if self.s.width<412 else 52
        self.scoreboard(x,y,w,top_h); y+=top_h+self.gap
        fighter_h=178 if self.s.phase=="active" else 160
        if self.s.width==320: fighter_h=170
        fighter_width=self.fighters(x,y,w,fighter_h); y+=fighter_h+self.gap
        if self.s.phase=="active":
            self.action(x,y,w,54); y+=54+self.gap
            self.commentary(x,y,w,68); y+=68+self.gap
            self.log(x,y,w,96); y+=96+self.gap
            tactics_h=116 if self.s.width==320 else 122
            self.tactics_active(x,y,w,tactics_h); y+=tactics_h+self.gap
            footer_y=self.s.height-self.pad-45
            self.footer(x,footer_y,w,45)
        elif self.s.phase=="between":
            self.action(x,y,w,48); y+=48+self.gap
            self.commentary(x,y,w,68); y+=68+self.gap
            self.log(x,y,w,66); y+=66+self.gap
            self.tactics_between(x,y,w,250); y+=250+self.gap
            footer_y=self.s.height-self.pad-45
            self.footer(x,footer_y,w,45)
        else:
            self.result(x,y,w,190); y+=190+self.gap
            self.log(x,y,w,88); y+=88+self.gap
            footer_y=self.s.height-self.pad-48
            self.footer(x,footer_y,w,48)
        return fighter_width

    def audit(self, fighter_width: float) -> dict:
        overflow=[r for r in self.regions if r["left"] < -0.01 or r["top"] < -0.01 or r["right"] > self.s.width+0.01 or r["bottom"] > self.s.height+0.01]
        tap_violations=[{"width":w,"height":h} for w,h in self.tap_targets if w+0.01<self.tap or h+0.01<self.tap]
        expected_region_count={"active":7,"between":7,"complete":5}[self.s.phase]
        forbidden="scorecard" in " ".join(self.messages).lower()
        data={
            "width":self.s.width,
            "height":self.s.height,
            "phase":self.s.phase,
            "regionCount":len(self.regions),
            "expectedRegionCount":expected_region_count,
            "overflowCount":len(overflow),
            "minimumObservedFontDp":min(self.font_sizes) if self.font_sizes else None,
            "requiredMinimumFontDp":self.min_font,
            "tapTargetViolations":tap_violations,
            "requiredTapTargetDp":self.tap,
            "fighterCardWidthDp":round(fighter_width,2),
            "fighterCardsEqualWidth":True,
            "judgeScorecardFieldExposed":forbidden,
            "regions":self.regions,
        }
        data["pass"]=(data["regionCount"]==expected_region_count and data["overflowCount"]==0 and data["minimumObservedFontDp"]+1e-6>=self.min_font and len(tap_violations)==0 and not forbidden)
        return data


def render_scenario(s: Scenario, out: Path, scale=2) -> dict:
    r=Renderer(s,scale)
    fw=r.render()
    out.parent.mkdir(parents=True,exist_ok=True)
    r.img.save(out,"PNG",optimize=True)
    return r.audit(fw)


def contact_sheet(files: list[Path], out: Path):
    images=[Image.open(p).convert("RGB") for p in files]
    thumb_w=360*2; thumb_h=800*2
    canvas=Image.new("RGB",(thumb_w*3+36*4,thumb_h*2+36*3),COLORS["bg2"])
    for i,img in enumerate(images):
        img.thumbnail((thumb_w,thumb_h),Image.Resampling.LANCZOS)
        col=i%3; row=i//3
        x=36+col*(thumb_w+36); y=36+row*(thumb_h+36)
        canvas.paste(img,(x+(thumb_w-img.width)//2,y))
    out.parent.mkdir(parents=True,exist_ok=True)
    canvas.save(out,"PNG",optimize=True)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out",type=Path,default=ROOT/"rendered")
    ap.add_argument("--audit",type=Path)
    args=ap.parse_args()
    results=[]; files=[]
    for s in SCENARIOS:
        path=args.out/f"{s.name}.png"; files.append(path); results.append(render_scenario(s,path))
    contact_sheet(files,args.out/"fight-screen-contact-sheet.png")
    report={"scenarios":len(results),"passed":sum(1 for x in results if x["pass"]),"failed":sum(1 for x in results if not x["pass"]),"results":results}
    if args.audit:
        args.audit.parent.mkdir(parents=True,exist_ok=True); args.audit.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(report,ensure_ascii=False,indent=2))
    raise SystemExit(0 if report["failed"]==0 else 1)

if __name__=="__main__": main()
