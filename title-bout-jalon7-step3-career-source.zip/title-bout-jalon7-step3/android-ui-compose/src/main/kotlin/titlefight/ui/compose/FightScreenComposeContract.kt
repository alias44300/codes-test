package titlefight.ui.compose

import titlefight.FightActionScreenState
import titlefight.FightResultScreenState
import titlefight.FightScreenPhase
import titlefight.FightScreenState
import titlefight.FighterScreenState
import kotlin.math.roundToInt

enum class FightScreenWidthClass {
    COMPACT,
    STANDARD,
    EXPANDED,
}

data class FightScreenLayoutTokens(
    val widthClass: FightScreenWidthClass,
    val horizontalPaddingDp: Int,
    val sectionGapDp: Int,
    val fighterGapDp: Int,
    val minimumBodySp: Double,
    val minimumTapTargetDp: Int,
    val fighterCardMinWidthDp: Int,
    val contentMaxWidthDp: Int,
) {
    init {
        require(horizontalPaddingDp >= 8)
        require(sectionGapDp >= 6)
        require(fighterGapDp >= 6)
        require(minimumBodySp >= 10.0)
        require(minimumTapTargetDp >= 44)
        require(fighterCardMinWidthDp >= 140)
        require(contentMaxWidthDp >= 320)
    }
}

object FightScreenLayoutPolicy {
    fun forWidth(widthDp: Int): FightScreenLayoutTokens {
        require(widthDp >= 280)
        return when {
            widthDp < 340 -> FightScreenLayoutTokens(
                widthClass = FightScreenWidthClass.COMPACT,
                horizontalPaddingDp = 10,
                sectionGapDp = 8,
                fighterGapDp = 8,
                minimumBodySp = 10.0,
                minimumTapTargetDp = 44,
                fighterCardMinWidthDp = 142,
                contentMaxWidthDp = 360,
            )

            widthDp < 400 -> FightScreenLayoutTokens(
                widthClass = FightScreenWidthClass.STANDARD,
                horizontalPaddingDp = 12,
                sectionGapDp = 9,
                fighterGapDp = 10,
                minimumBodySp = 10.5,
                minimumTapTargetDp = 44,
                fighterCardMinWidthDp = 158,
                contentMaxWidthDp = 400,
            )

            else -> FightScreenLayoutTokens(
                widthClass = FightScreenWidthClass.EXPANDED,
                horizontalPaddingDp = 14,
                sectionGapDp = 10,
                fighterGapDp = 12,
                minimumBodySp = 11.0,
                minimumTapTargetDp = 48,
                fighterCardMinWidthDp = 180,
                contentMaxWidthDp = 480,
            )
        }
    }

    fun forWidth(widthDp: Float): FightScreenLayoutTokens = forWidth(widthDp.roundToInt())
}

enum class FightScreenRegion {
    SCOREBOARD,
    FIGHTERS,
    CURRENT_ACTION,
    COMMENTARY,
    RECENT_LOG,
    TACTICAL_SUMMARY,
    BETWEEN_ROUNDS_TACTICS,
    RESULT,
    FOOTER,
}

data class FightScreenPresentation(
    val phase: FightScreenPhase,
    val visibleRegions: Set<FightScreenRegion>,
    val tacticalControlsEnabled: Boolean,
    val officialResultVisible: Boolean,
    val currentActionVisible: Boolean,
    val screenTitle: String,
) {
    init {
        require(visibleRegions.contains(FightScreenRegion.SCOREBOARD))
        require(visibleRegions.contains(FightScreenRegion.FIGHTERS))
        require(visibleRegions.contains(FightScreenRegion.COMMENTARY))
        require(visibleRegions.contains(FightScreenRegion.FOOTER))
        require(tacticalControlsEnabled == (phase == FightScreenPhase.BETWEEN_ROUNDS))
        require(officialResultVisible == (phase == FightScreenPhase.COMPLETE))
        require(currentActionVisible == (phase == FightScreenPhase.ROUND_IN_PROGRESS))
    }
}

object FightScreenPresentationMapper {
    fun from(state: FightScreenState): FightScreenPresentation {
        val common = linkedSetOf(
            FightScreenRegion.SCOREBOARD,
            FightScreenRegion.FIGHTERS,
            FightScreenRegion.COMMENTARY,
            FightScreenRegion.RECENT_LOG,
            FightScreenRegion.FOOTER,
        )
        when (state.phase) {
            FightScreenPhase.PRE_FIGHT -> common += FightScreenRegion.TACTICAL_SUMMARY
            FightScreenPhase.ROUND_IN_PROGRESS -> {
                common += FightScreenRegion.CURRENT_ACTION
                common += FightScreenRegion.TACTICAL_SUMMARY
            }
            FightScreenPhase.BETWEEN_ROUNDS -> common += FightScreenRegion.BETWEEN_ROUNDS_TACTICS
            FightScreenPhase.COMPLETE -> common += FightScreenRegion.RESULT
        }
        return FightScreenPresentation(
            phase = state.phase,
            visibleRegions = common,
            tacticalControlsEnabled = state.phase == FightScreenPhase.BETWEEN_ROUNDS,
            officialResultVisible = state.phase == FightScreenPhase.COMPLETE,
            currentActionVisible = state.phase == FightScreenPhase.ROUND_IN_PROGRESS,
            screenTitle = when (state.phase) {
                FightScreenPhase.PRE_FIGHT -> "Avant-combat"
                FightScreenPhase.ROUND_IN_PROGRESS -> "Round ${state.roundNumber}, ${state.clock.display} restantes"
                FightScreenPhase.BETWEEN_ROUNDS -> "Pause après le round ${state.roundNumber}"
                FightScreenPhase.COMPLETE -> "Résultat officiel"
            },
        )
    }
}

object FightScreenAccessibility {
    fun screenSummary(state: FightScreenState): String = buildString {
        append(FightScreenPresentationMapper.from(state).screenTitle)
        append(". Coin rouge, ")
        append(fighterSummary(state.red))
        append(". Coin bleu, ")
        append(fighterSummary(state.blue))
        append(". ")
        append(state.commentary)
        state.result?.let {
            append(". ")
            append(resultSummary(it))
        }
    }

    fun fighterSummary(fighter: FighterScreenState): String = buildString {
        append(fighter.name)
        append(", énergie ")
        append(fighter.stamina)
        append(" pour cent, dégâts tête ")
        append(fighter.headDamage)
        append(", dégâts corps ")
        append(fighter.bodyDamage)
        append(", stabilité ")
        append(fighter.stability)
        append(", condition ")
        append(fighter.condition.name.lowercase())
        if (fighter.knockdownsSuffered > 0) {
            append(", knockdowns subis ")
            append(fighter.knockdownsSuffered)
        }
    }

    fun actionSummary(action: FightActionScreenState?): String = when (action) {
        null -> "Aucune action en cours"
        else -> buildString {
            append(action.punch.name.lowercase())
            append(" à distance ")
            append(action.range.name.lowercase())
            append(if (action.landed) ", touche" else ", évité")
            if (action.clean) append(", impact net")
            if (action.knockdown) append(", knockdown")
            action.refereeCount?.let { append(", compte $it") }
        }
    }

    fun resultSummary(result: FightResultScreenState): String =
        "${result.headline}. ${result.detail}"
}
