package titlefight.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import titlefight.FightScreenPhase
import titlefight.ui.compose.TacticalSelectionAction

class DemoFightFactoryTest {
    @Test
    fun demoStartsAtFirstTacticalPauseAndCanContinue() {
        val coordinator = DemoFightFactory.coordinator(seed = 44L)
        val first = coordinator.start()
        assertEquals(FightScreenPhase.BETWEEN_ROUNDS, first.screenState.phase)
        assertNotNull(first.tacticalSelection)
        val window = requireNotNull(first.tacticalSelection).windowId

        val second = coordinator.dispatch(TacticalSelectionAction.Confirm(window))
        assertEquals(2, second.completedRounds)
    }

    @Test
    fun sameSeedProducesSameInitialScreen() {
        val first = DemoFightFactory.coordinator(seed = 77L).start()
        val replay = DemoFightFactory.coordinator(seed = 77L).start()
        assertEquals(first, replay)
    }
}
