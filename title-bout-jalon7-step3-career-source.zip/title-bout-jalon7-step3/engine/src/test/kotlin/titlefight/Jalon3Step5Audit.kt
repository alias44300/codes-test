package titlefight

import java.util.Locale
import kotlin.math.abs

private const val FINAL_AUDIT_WINDOWS = 10
private const val FIGHTS_PER_WINDOW = 1000
private const val PAIRS_PER_WINDOW = FIGHTS_PER_WINDOW / 2

data class FinalJudgeAuditStats(
    val judgeId: String,
    val judgeName: String,
    val judgedRounds: Int,
    val scorecards: Int,
    val redRoundWins: Int,
    val blueRoundWins: Int,
    val tiedRounds: Int,
    val redCardWins: Int,
    val blueCardWins: Int,
    val drawnCards: Int,
    val vegaCardWins: Int,
    val kesslerCardWins: Int,
    val tenNineRounds: Int,
    val tenEightRounds: Int,
    val tenSevenRounds: Int,
    val tenTenRounds: Int,
    val combinedRoundPoints: Long,
    val absoluteCardMarginTotal: Long,
) {
    init {
        require(judgedRounds == redRoundWins + blueRoundWins + tiedRounds)
        require(judgedRounds == tenNineRounds + tenEightRounds + tenSevenRounds + tenTenRounds)
        require(scorecards == redCardWins + blueCardWins + drawnCards)
        require(scorecards == vegaCardWins + kesslerCardWins + drawnCards)
    }

    val averageCombinedRoundPoints: Double
        get() = if (judgedRounds == 0) 0.0 else combinedRoundPoints.toDouble() / judgedRounds
    val averageAbsoluteCardMargin: Double
        get() = if (scorecards == 0) 0.0 else absoluteCardMarginTotal.toDouble() / scorecards
    val tenTenShare: Double
        get() = if (judgedRounds == 0) 0.0 else tenTenRounds.toDouble() / judgedRounds
    val redCardWinShare: Double
        get() = if (scorecards == 0) 0.0 else redCardWins.toDouble() / scorecards
    val blueCardWinShare: Double
        get() = if (scorecards == 0) 0.0 else blueCardWins.toDouble() / scorecards
    val vegaCardWinShare: Double
        get() = if (scorecards == 0) 0.0 else vegaCardWins.toDouble() / scorecards
}

data class Jalon3FinalAuditWindow(
    val windowIndex: Int,
    val seedStart: Long,
    val fights: Int,
    val distanceFights: Int,
    val stoppageFights: Int,
    val koFights: Int,
    val tkoFights: Int,
    val officialDecisions: Int,
    val redDecisionWins: Int,
    val blueDecisionWins: Int,
    val vegaDecisionWins: Int,
    val kesslerDecisionWins: Int,
    val draws: Int,
    val vegaWinsFromRed: Int,
    val vegaWinsFromBlue: Int,
    val kesslerWinsFromRed: Int,
    val kesslerWinsFromBlue: Int,
    val unanimousDecisions: Int,
    val splitDecisions: Int,
    val majorityDecisions: Int,
    val unanimousDraws: Int,
    val majorityDraws: Int,
    val splitDraws: Int,
    val invalidScorecards: Int,
    val majorityMismatches: Int,
    val missingDecisions: Int,
    val decisionsAfterStoppage: Int,
    val reproducibilityChecks: Int,
    val reproducibilityMismatches: Int,
    val judgeStats: List<FinalJudgeAuditStats>,
) {
    init {
        require(fights == FIGHTS_PER_WINDOW)
        require(distanceFights + stoppageFights == fights)
        require(koFights + tkoFights == stoppageFights)
        require(officialDecisions == distanceFights)
        require(redDecisionWins + blueDecisionWins + draws == officialDecisions)
        require(vegaDecisionWins + kesslerDecisionWins + draws == officialDecisions)
        require(
            unanimousDecisions + splitDecisions + majorityDecisions +
                unanimousDraws + majorityDraws + splitDraws == officialDecisions,
        )
        require(judgeStats.size == 3)
        require(judgeStats.all { it.scorecards == officialDecisions })
        require(reproducibilityChecks == 40)
    }

    val decidedFights: Int get() = redDecisionWins + blueDecisionWins
    val redWinShareAmongDecisions: Double
        get() = if (decidedFights == 0) 0.0 else redDecisionWins.toDouble() / decidedFights
}

data class Jalon3FinalAuditResult(
    val windows: List<Jalon3FinalAuditWindow>,
    val totalFights: Int,
    val totalDistanceFights: Int,
    val totalStoppageFights: Int,
    val totalKoFights: Int,
    val totalTkoFights: Int,
    val totalOfficialDecisions: Int,
    val redDecisionWins: Int,
    val blueDecisionWins: Int,
    val vegaDecisionWins: Int,
    val kesslerDecisionWins: Int,
    val draws: Int,
    val vegaWinsFromRed: Int,
    val vegaWinsFromBlue: Int,
    val kesslerWinsFromRed: Int,
    val kesslerWinsFromBlue: Int,
    val unanimousDecisions: Int,
    val splitDecisions: Int,
    val majorityDecisions: Int,
    val unanimousDraws: Int,
    val majorityDraws: Int,
    val splitDraws: Int,
    val invalidScorecards: Int,
    val majorityMismatches: Int,
    val missingDecisions: Int,
    val decisionsAfterStoppage: Int,
    val reproducibilityChecks: Int,
    val reproducibilityMismatches: Int,
    val judgeStats: List<FinalJudgeAuditStats>,
) {
    init {
        require(windows.size == FINAL_AUDIT_WINDOWS)
        require(totalFights == FINAL_AUDIT_WINDOWS * FIGHTS_PER_WINDOW)
        require(totalDistanceFights + totalStoppageFights == totalFights)
        require(totalKoFights + totalTkoFights == totalStoppageFights)
        require(totalOfficialDecisions == totalDistanceFights)
        require(redDecisionWins + blueDecisionWins + draws == totalOfficialDecisions)
        require(vegaDecisionWins + kesslerDecisionWins + draws == totalOfficialDecisions)
        require(judgeStats.size == 3)
        require(judgeStats.all { it.scorecards == totalOfficialDecisions })
        require(reproducibilityChecks == FINAL_AUDIT_WINDOWS * 40)
    }

    val decidedFights: Int get() = redDecisionWins + blueDecisionWins
    val redWinShareAmongDecisions: Double
        get() = if (decidedFights == 0) 0.0 else redDecisionWins.toDouble() / decidedFights
    val vegaRedBlueWinRateGap: Double
        get() = abs(vegaWinsFromRed - vegaWinsFromBlue).toDouble() / (FINAL_AUDIT_WINDOWS * PAIRS_PER_WINDOW)
    val kesslerRedBlueWinRateGap: Double
        get() = abs(kesslerWinsFromRed - kesslerWinsFromBlue).toDouble() / (FINAL_AUDIT_WINDOWS * PAIRS_PER_WINDOW)
    val judgeCombinedPointSpread: Double
        get() = judgeStats.maxOf { it.averageCombinedRoundPoints } - judgeStats.minOf { it.averageCombinedRoundPoints }
    val judgeAbsoluteMarginSpread: Double
        get() = judgeStats.maxOf { it.averageAbsoluteCardMargin } - judgeStats.minOf { it.averageAbsoluteCardMargin }
    val judgeTenTenShareSpread: Double
        get() = judgeStats.maxOf { it.tenTenShare } - judgeStats.minOf { it.tenTenShare }
    val judgeRedCardShareSpread: Double
        get() = judgeStats.maxOf { it.redCardWinShare } - judgeStats.minOf { it.redCardWinShare }
    val judgeVegaCardShareSpread: Double
        get() = judgeStats.maxOf { it.vegaCardWinShare } - judgeStats.minOf { it.vegaCardWinShare }
}

object Jalon3FinalAuditor {
    private val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
    private val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

    private data class MutableJudgeStats(
        val profile: JudgeProfile,
        var judgedRounds: Int = 0,
        var scorecards: Int = 0,
        var redRoundWins: Int = 0,
        var blueRoundWins: Int = 0,
        var tiedRounds: Int = 0,
        var redCardWins: Int = 0,
        var blueCardWins: Int = 0,
        var drawnCards: Int = 0,
        var vegaCardWins: Int = 0,
        var kesslerCardWins: Int = 0,
        var tenNine: Int = 0,
        var tenEight: Int = 0,
        var tenSeven: Int = 0,
        var tenTen: Int = 0,
        var combinedRoundPoints: Long = 0,
        var absoluteCardMarginTotal: Long = 0,
    )

    private data class MutableWindow(
        val windowIndex: Int,
        val seedStart: Long,
        var distanceFights: Int = 0,
        var stoppageFights: Int = 0,
        var koFights: Int = 0,
        var tkoFights: Int = 0,
        var officialDecisions: Int = 0,
        var redDecisionWins: Int = 0,
        var blueDecisionWins: Int = 0,
        var vegaDecisionWins: Int = 0,
        var kesslerDecisionWins: Int = 0,
        var draws: Int = 0,
        var vegaWinsFromRed: Int = 0,
        var vegaWinsFromBlue: Int = 0,
        var kesslerWinsFromRed: Int = 0,
        var kesslerWinsFromBlue: Int = 0,
        var unanimousDecisions: Int = 0,
        var splitDecisions: Int = 0,
        var majorityDecisions: Int = 0,
        var unanimousDraws: Int = 0,
        var majorityDraws: Int = 0,
        var splitDraws: Int = 0,
        var invalidScorecards: Int = 0,
        var majorityMismatches: Int = 0,
        var missingDecisions: Int = 0,
        var decisionsAfterStoppage: Int = 0,
        var reproducibilityChecks: Int = 0,
        var reproducibilityMismatches: Int = 0,
        val judges: MutableMap<String, MutableJudgeStats> = JudgeProfiles.ALL.associate { it.id to MutableJudgeStats(it) }.toMutableMap(),
    )

    fun run(seedStart: Long = 202607260000L): Jalon3FinalAuditResult {
        val engine = FightEngine()
        val windows = (0 until FINAL_AUDIT_WINDOWS).map { windowIndex ->
            val windowSeedStart = seedStart + windowIndex * 100_000L
            val window = MutableWindow(windowIndex + 1, windowSeedStart)
            repeat(PAIRS_PER_WINDOW) { pairIndex ->
                val seed = windowSeedStart + pairIndex
                auditFight(
                    window,
                    engine.simulateThreeRoundFight(
                        red = TestProfiles.eliasVega,
                        blue = TestProfiles.brunoKessler,
                        redTactics = vegaTactics,
                        blueTactics = kesslerTactics,
                        seed = seed,
                    ),
                    vegaInRed = true,
                    checkReproducibility = pairIndex < 20,
                )
                auditFight(
                    window,
                    engine.simulateThreeRoundFight(
                        red = TestProfiles.brunoKessler,
                        blue = TestProfiles.eliasVega,
                        redTactics = kesslerTactics,
                        blueTactics = vegaTactics,
                        seed = seed,
                    ),
                    vegaInRed = false,
                    checkReproducibility = pairIndex < 20,
                )
            }
            window.toImmutable()
        }
        return aggregate(windows)
    }

    private fun auditFight(window: MutableWindow, fight: FightResult, vegaInRed: Boolean, checkReproducibility: Boolean) {
        if (checkReproducibility) {
            window.reproducibilityChecks++
            val repeated = FightEngine().simulateThreeRoundFight(
            red = if (vegaInRed) TestProfiles.eliasVega else TestProfiles.brunoKessler,
            blue = if (vegaInRed) TestProfiles.brunoKessler else TestProfiles.eliasVega,
            redTactics = if (vegaInRed) vegaTactics else kesslerTactics,
            blueTactics = if (vegaInRed) kesslerTactics else vegaTactics,
                seed = fight.seed,
            )
            if (repeated != fight) window.reproducibilityMismatches++
        }

        if (fight.stoppage != null) {
            window.stoppageFights++
            when (fight.stoppage.method) {
                FightMethod.KO -> window.koFights++
                FightMethod.TKO -> window.tkoFights++
            }
            if (fight.officialDecision != null) window.decisionsAfterStoppage++
            return
        }

        window.distanceFights++
        val decision = fight.officialDecision
        if (decision == null) {
            window.missingDecisions++
            return
        }
        window.officialDecisions++

        when (decision.type) {
            OfficialDecisionType.UNANIMOUS_DECISION -> window.unanimousDecisions++
            OfficialDecisionType.SPLIT_DECISION -> window.splitDecisions++
            OfficialDecisionType.MAJORITY_DECISION -> window.majorityDecisions++
            OfficialDecisionType.UNANIMOUS_DRAW -> window.unanimousDraws++
            OfficialDecisionType.MAJORITY_DRAW -> window.majorityDraws++
            OfficialDecisionType.SPLIT_DRAW -> window.splitDraws++
        }

        when (decision.winnerId) {
            fight.redId -> {
                window.redDecisionWins++
                if (vegaInRed) {
                    window.vegaDecisionWins++
                    window.vegaWinsFromRed++
                } else {
                    window.kesslerDecisionWins++
                    window.kesslerWinsFromRed++
                }
            }
            fight.blueId -> {
                window.blueDecisionWins++
                if (vegaInRed) {
                    window.kesslerDecisionWins++
                    window.kesslerWinsFromBlue++
                } else {
                    window.vegaDecisionWins++
                    window.vegaWinsFromBlue++
                }
            }
            null -> window.draws++
            else -> window.majorityMismatches++
        }

        val expectedWinner = when {
            decision.redCards >= 2 -> fight.redId
            decision.blueCards >= 2 -> fight.blueId
            else -> null
        }
        val expectedType = OfficialDecisionResolver.classify(decision.redCards, decision.blueCards, decision.drawCards)
        if (decision.winnerId != expectedWinner || decision.type != expectedType) window.majorityMismatches++

        decision.scorecards.forEach { card ->
            val judge = window.judges.getValue(card.judgeId)
            judge.scorecards++
            judge.absoluteCardMarginTotal += abs(card.redTotal - card.blueTotal).toLong()
            when (card.verdict) {
                ScorecardVerdict.RED -> judge.redCardWins++
                ScorecardVerdict.BLUE -> judge.blueCardWins++
                ScorecardVerdict.DRAW -> judge.drawnCards++
            }
            when (card.winnerId) {
                TestProfiles.eliasVega.id -> judge.vegaCardWins++
                TestProfiles.brunoKessler.id -> judge.kesslerCardWins++
                null -> Unit
                else -> window.invalidScorecards++
            }

            val validRounds = card.rounds.size == 3 && card.rounds.map { it.roundNumber } == listOf(1, 2, 3)
            val validTotals = card.redTotal == card.rounds.sumOf { it.redPoints } && card.blueTotal == card.rounds.sumOf { it.bluePoints }
            val validVerdict = when (card.verdict) {
                ScorecardVerdict.RED -> card.redTotal > card.blueTotal && card.winnerId == fight.redId
                ScorecardVerdict.BLUE -> card.blueTotal > card.redTotal && card.winnerId == fight.blueId
                ScorecardVerdict.DRAW -> card.redTotal == card.blueTotal && card.winnerId == null
            }
            if (!validRounds || !validTotals || !validVerdict) window.invalidScorecards++

            card.rounds.forEach { score ->
                judge.judgedRounds++
                judge.combinedRoundPoints += score.redPoints + score.bluePoints
                when (score.winnerId) {
                    score.redFighterId -> judge.redRoundWins++
                    score.blueFighterId -> judge.blueRoundWins++
                    null -> judge.tiedRounds++
                    else -> window.invalidScorecards++
                }
                when (score.redPoints to score.bluePoints) {
                    10 to 9, 9 to 10 -> judge.tenNine++
                    10 to 8, 8 to 10 -> judge.tenEight++
                    10 to 7, 7 to 10 -> judge.tenSeven++
                    10 to 10 -> judge.tenTen++
                    else -> window.invalidScorecards++
                }
            }
        }
    }

    private fun MutableWindow.toImmutable(): Jalon3FinalAuditWindow = Jalon3FinalAuditWindow(
        windowIndex = windowIndex,
        seedStart = seedStart,
        fights = FIGHTS_PER_WINDOW,
        distanceFights = distanceFights,
        stoppageFights = stoppageFights,
        koFights = koFights,
        tkoFights = tkoFights,
        officialDecisions = officialDecisions,
        redDecisionWins = redDecisionWins,
        blueDecisionWins = blueDecisionWins,
        vegaDecisionWins = vegaDecisionWins,
        kesslerDecisionWins = kesslerDecisionWins,
        draws = draws,
        vegaWinsFromRed = vegaWinsFromRed,
        vegaWinsFromBlue = vegaWinsFromBlue,
        kesslerWinsFromRed = kesslerWinsFromRed,
        kesslerWinsFromBlue = kesslerWinsFromBlue,
        unanimousDecisions = unanimousDecisions,
        splitDecisions = splitDecisions,
        majorityDecisions = majorityDecisions,
        unanimousDraws = unanimousDraws,
        majorityDraws = majorityDraws,
        splitDraws = splitDraws,
        invalidScorecards = invalidScorecards,
        majorityMismatches = majorityMismatches,
        missingDecisions = missingDecisions,
        decisionsAfterStoppage = decisionsAfterStoppage,
        reproducibilityChecks = reproducibilityChecks,
        reproducibilityMismatches = reproducibilityMismatches,
        judgeStats = JudgeProfiles.ALL.map { judges.getValue(it.id).toImmutable() },
    )

    private fun MutableJudgeStats.toImmutable(): FinalJudgeAuditStats = FinalJudgeAuditStats(
        judgeId = profile.id,
        judgeName = profile.name,
        judgedRounds = judgedRounds,
        scorecards = scorecards,
        redRoundWins = redRoundWins,
        blueRoundWins = blueRoundWins,
        tiedRounds = tiedRounds,
        redCardWins = redCardWins,
        blueCardWins = blueCardWins,
        drawnCards = drawnCards,
        vegaCardWins = vegaCardWins,
        kesslerCardWins = kesslerCardWins,
        tenNineRounds = tenNine,
        tenEightRounds = tenEight,
        tenSevenRounds = tenSeven,
        tenTenRounds = tenTen,
        combinedRoundPoints = combinedRoundPoints,
        absoluteCardMarginTotal = absoluteCardMarginTotal,
    )

    private fun aggregate(windows: List<Jalon3FinalAuditWindow>): Jalon3FinalAuditResult {
        val judgeStats = JudgeProfiles.ALL.map { profile ->
            val stats = windows.map { it.judgeStats.single { stat -> stat.judgeId == profile.id } }
            FinalJudgeAuditStats(
                judgeId = profile.id,
                judgeName = profile.name,
                judgedRounds = stats.sumOf { it.judgedRounds },
                scorecards = stats.sumOf { it.scorecards },
                redRoundWins = stats.sumOf { it.redRoundWins },
                blueRoundWins = stats.sumOf { it.blueRoundWins },
                tiedRounds = stats.sumOf { it.tiedRounds },
                redCardWins = stats.sumOf { it.redCardWins },
                blueCardWins = stats.sumOf { it.blueCardWins },
                drawnCards = stats.sumOf { it.drawnCards },
                vegaCardWins = stats.sumOf { it.vegaCardWins },
                kesslerCardWins = stats.sumOf { it.kesslerCardWins },
                tenNineRounds = stats.sumOf { it.tenNineRounds },
                tenEightRounds = stats.sumOf { it.tenEightRounds },
                tenSevenRounds = stats.sumOf { it.tenSevenRounds },
                tenTenRounds = stats.sumOf { it.tenTenRounds },
                combinedRoundPoints = stats.sumOf { it.combinedRoundPoints },
                absoluteCardMarginTotal = stats.sumOf { it.absoluteCardMarginTotal },
            )
        }
        return Jalon3FinalAuditResult(
            windows = windows,
            totalFights = windows.sumOf { it.fights },
            totalDistanceFights = windows.sumOf { it.distanceFights },
            totalStoppageFights = windows.sumOf { it.stoppageFights },
            totalKoFights = windows.sumOf { it.koFights },
            totalTkoFights = windows.sumOf { it.tkoFights },
            totalOfficialDecisions = windows.sumOf { it.officialDecisions },
            redDecisionWins = windows.sumOf { it.redDecisionWins },
            blueDecisionWins = windows.sumOf { it.blueDecisionWins },
            vegaDecisionWins = windows.sumOf { it.vegaDecisionWins },
            kesslerDecisionWins = windows.sumOf { it.kesslerDecisionWins },
            draws = windows.sumOf { it.draws },
            vegaWinsFromRed = windows.sumOf { it.vegaWinsFromRed },
            vegaWinsFromBlue = windows.sumOf { it.vegaWinsFromBlue },
            kesslerWinsFromRed = windows.sumOf { it.kesslerWinsFromRed },
            kesslerWinsFromBlue = windows.sumOf { it.kesslerWinsFromBlue },
            unanimousDecisions = windows.sumOf { it.unanimousDecisions },
            splitDecisions = windows.sumOf { it.splitDecisions },
            majorityDecisions = windows.sumOf { it.majorityDecisions },
            unanimousDraws = windows.sumOf { it.unanimousDraws },
            majorityDraws = windows.sumOf { it.majorityDraws },
            splitDraws = windows.sumOf { it.splitDraws },
            invalidScorecards = windows.sumOf { it.invalidScorecards },
            majorityMismatches = windows.sumOf { it.majorityMismatches },
            missingDecisions = windows.sumOf { it.missingDecisions },
            decisionsAfterStoppage = windows.sumOf { it.decisionsAfterStoppage },
            reproducibilityChecks = windows.sumOf { it.reproducibilityChecks },
            reproducibilityMismatches = windows.sumOf { it.reproducibilityMismatches },
            judgeStats = judgeStats,
        )
    }

    fun assertAcceptable(result: Jalon3FinalAuditResult) {
        check(result.invalidScorecards == 0)
        check(result.majorityMismatches == 0)
        check(result.missingDecisions == 0)
        check(result.decisionsAfterStoppage == 0)
        check(result.reproducibilityMismatches == 0)
        check(result.redWinShareAmongDecisions in 0.47..0.53) {
            "Biais persistant du coin : part rouge ${result.redWinShareAmongDecisions}."
        }
        check(result.vegaRedBlueWinRateGap <= 0.04) {
            "Elias Vega dépend trop du coin : écart ${result.vegaRedBlueWinRateGap}."
        }
        check(result.kesslerRedBlueWinRateGap <= 0.04) {
            "Bruno Kessler dépend trop du coin : écart ${result.kesslerRedBlueWinRateGap}."
        }
        check(result.judgeCombinedPointSpread <= 0.08) {
            "Sévérité de points trop différente : ${result.judgeCombinedPointSpread}."
        }
        check(result.judgeAbsoluteMarginSpread <= 0.25) {
            "Écart de marge moyenne trop élevé : ${result.judgeAbsoluteMarginSpread}."
        }
        check(result.judgeTenTenShareSpread <= 0.03) {
            "Écart de fréquence 10-10 trop élevé : ${result.judgeTenTenShareSpread}."
        }
        check(result.judgeRedCardShareSpread <= 0.03) {
            "Un juge favorise trop un coin : ${result.judgeRedCardShareSpread}."
        }
        check(result.judgeVegaCardShareSpread <= 0.03) {
            "Un juge favorise trop un style : ${result.judgeVegaCardShareSpread}."
        }
        result.windows.forEach { window ->
            check(window.invalidScorecards == 0)
            check(window.majorityMismatches == 0)
            check(window.missingDecisions == 0)
            check(window.decisionsAfterStoppage == 0)
            check(window.reproducibilityMismatches == 0)
            check(window.redWinShareAmongDecisions in 0.42..0.58) {
                "Fenêtre ${window.windowIndex} trop déséquilibrée par coin : ${window.redWinShareAmongDecisions}."
            }
        }
    }
}

object Jalon3FinalAuditFormatter {
    fun format(result: Jalon3FinalAuditResult): String = buildString {
        appendLine("TITLE FIGHT — JALON 3 — AUDIT FINAL")
        appendLine("TROIS JUGES, CARTES ET DÉCISIONS")
        appendLine()
        appendLine("Fenêtres : ${result.windows.size}")
        appendLine("Combats : ${result.totalFights}")
        appendLine("Combats à la distance : ${result.totalDistanceFights}")
        appendLine("Arrêts : ${result.totalStoppageFights} (KO ${result.totalKoFights}, TKO ${result.totalTkoFights})")
        appendLine("Décisions officielles : ${result.totalOfficialDecisions}")
        appendLine()
        appendLine("Décisions unanimes : ${result.unanimousDecisions}")
        appendLine("Décisions partagées : ${result.splitDecisions}")
        appendLine("Décisions majoritaires : ${result.majorityDecisions}")
        appendLine("Nuls unanimes : ${result.unanimousDraws}")
        appendLine("Nuls majoritaires : ${result.majorityDraws}")
        appendLine("Nuls partagés : ${result.splitDraws}")
        appendLine()
        appendLine("Victoires coin rouge : ${result.redDecisionWins}")
        appendLine("Victoires coin bleu : ${result.blueDecisionWins}")
        appendLine("Part rouge parmi les décisions avec vainqueur : ${percent(result.redWinShareAmongDecisions)}")
        appendLine("Victoires Elias Vega : ${result.vegaDecisionWins} (rouge ${result.vegaWinsFromRed}, bleu ${result.vegaWinsFromBlue})")
        appendLine("Victoires Bruno Kessler : ${result.kesslerDecisionWins} (rouge ${result.kesslerWinsFromRed}, bleu ${result.kesslerWinsFromBlue})")
        appendLine("Matchs nuls : ${result.draws}")
        appendLine()
        appendLine("Écart Vega selon le coin : ${percent(result.vegaRedBlueWinRateGap)}")
        appendLine("Écart Kessler selon le coin : ${percent(result.kesslerRedBlueWinRateGap)}")
        appendLine("Écart maximal de points combinés moyens entre juges : ${decimal(result.judgeCombinedPointSpread)}")
        appendLine("Écart maximal de marge absolue moyenne entre juges : ${decimal(result.judgeAbsoluteMarginSpread)}")
        appendLine("Écart maximal de fréquence 10-10 : ${percent(result.judgeTenTenShareSpread)}")
        appendLine("Écart maximal de cartes rouges entre juges : ${percent(result.judgeRedCardShareSpread)}")
        appendLine("Écart maximal de cartes Vega entre juges : ${percent(result.judgeVegaCardShareSpread)}")
        appendLine()
        result.judgeStats.forEach { judge ->
            appendLine(
                "${judge.judgeName} : cartes rouge ${judge.redCardWins}, bleu ${judge.blueCardWins}, nulles ${judge.drawnCards}; " +
                    "Vega ${judge.vegaCardWins}, Kessler ${judge.kesslerCardWins}; " +
                    "10-10 ${judge.tenTenRounds}; points combinés moyens ${decimal(judge.averageCombinedRoundPoints)}; " +
                    "marge absolue moyenne ${decimal(judge.averageAbsoluteCardMargin)}",
            )
        }
        appendLine()
        appendLine("Cartes invalides : ${result.invalidScorecards}")
        appendLine("Décisions contraires à la majorité : ${result.majorityMismatches}")
        appendLine("Décisions manquantes : ${result.missingDecisions}")
        appendLine("Décisions après KO/TKO : ${result.decisionsAfterStoppage}")
        appendLine("Contrôles de reproductibilité : ${result.reproducibilityChecks}")
        appendLine("Écarts de reproductibilité : ${result.reproducibilityMismatches}")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.4f", value)
    private fun percent(value: Double): String = String.format(Locale.US, "%.2f %%", value * 100.0)
}

object Jalon3FinalAuditCsvFormatter {
    fun format(result: Jalon3FinalAuditResult): String = buildString {
        appendLine("window,seed_start,fights,distance,stoppages,ko,tko,red_wins,blue_wins,vega_wins,kessler_wins,draws,unanimous,split,majority,unanimous_draw,majority_draw,split_draw,red_win_share,invalid_cards,majority_mismatches,reproducibility_checks,reproducibility_mismatches")
        result.windows.forEach { window ->
            appendLine(
                listOf(
                    window.windowIndex,
                    window.seedStart,
                    window.fights,
                    window.distanceFights,
                    window.stoppageFights,
                    window.koFights,
                    window.tkoFights,
                    window.redDecisionWins,
                    window.blueDecisionWins,
                    window.vegaDecisionWins,
                    window.kesslerDecisionWins,
                    window.draws,
                    window.unanimousDecisions,
                    window.splitDecisions,
                    window.majorityDecisions,
                    window.unanimousDraws,
                    window.majorityDraws,
                    window.splitDraws,
                    String.format(Locale.US, "%.6f", window.redWinShareAmongDecisions),
                    window.invalidScorecards,
                    window.majorityMismatches,
                    window.reproducibilityChecks,
                    window.reproducibilityMismatches,
                ).joinToString(","),
            )
        }
    }
}

object Jalon3FinalAuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        Locale.setDefault(Locale.FRANCE)
        val result = Jalon3FinalAuditor.run()
        print(Jalon3FinalAuditFormatter.format(result))
    }
}

object Jalon3FinalAuditCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        Locale.setDefault(Locale.US)
        print(Jalon3FinalAuditCsvFormatter.format(Jalon3FinalAuditor.run()))
    }
}
