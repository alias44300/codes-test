package titlefight

import java.util.Locale

private val VEGA_TACTICS = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
private val KESSLER_TACTICS = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

data class FighterBatchMetrics(
    val fighterId: String,
    val performanceLeads: Int,
    val performanceTotal: Double,
    val thrown: Int,
    val landed: Int,
    val cleanHits: Int,
    val outsideActions: Int,
    val midActions: Int,
    val insideActions: Int,
    val finalStaminaTotal: Double,
    val headDamageReceivedTotal: Double,
    val bodyDamageReceivedTotal: Double,
    val finalStabilityTotal: Double,
) {
    val actionCount: Int get() = outsideActions + midActions + insideActions
    val averagePerformance: Double get() = performanceTotal / 100.0
    val accuracy: Double get() = if (thrown == 0) 0.0 else landed.toDouble() / thrown
    val outsideActionShare: Double get() = if (actionCount == 0) 0.0 else outsideActions.toDouble() / actionCount
    val midActionShare: Double get() = if (actionCount == 0) 0.0 else midActions.toDouble() / actionCount
    val insideActionShare: Double get() = if (actionCount == 0) 0.0 else insideActions.toDouble() / actionCount
    val averageFinalStamina: Double get() = finalStaminaTotal / 100.0
    val averageHeadDamageReceived: Double get() = headDamageReceivedTotal / 100.0
    val averageBodyDamageReceived: Double get() = bodyDamageReceivedTotal / 100.0
    val averageFinalStability: Double get() = finalStabilityTotal / 100.0
}

data class BatchFightRecord(
    val fightNumber: Int,
    val seed: Long,
    val vegaInRedCorner: Boolean,
    val vegaPerformance: Double,
    val kesslerPerformance: Double,
    val vegaFinalState: FighterState,
    val kesslerFinalState: FighterState,
)

data class BatchValidationResult(
    val fightCount: Int,
    val roundsPerFight: Int,
    val sequencesPerRound: Int,
    val seedStart: Long,
    val alternatedCorners: Boolean,
    val redCornerAppearancesByFighter: Map<String, Int>,
    val ties: Int,
    val records: List<BatchFightRecord>,
    val vega: FighterBatchMetrics,
    val kessler: FighterBatchMetrics,
) {
    val totalRounds: Int get() = fightCount * roundsPerFight
    val totalSequences: Int get() = totalRounds * sequencesPerRound

    init {
        require(fightCount == 100) { "L’étape 3 exige exactement 100 combats." }
        require(roundsPerFight == 3)
        require(sequencesPerRound == 12)
        require(vega.performanceLeads + kessler.performanceLeads + ties == fightCount)
        require(records.size == fightCount)
        require(records.map { it.fightNumber } == (1..fightCount).toList())
    }
}

object BatchValidator {
    fun run(
        fightCount: Int = 100,
        seedStart: Long = 2026072000L,
        alternateCorners: Boolean = true,
    ): BatchValidationResult {
        require(fightCount == 100) { "L’étape 3 est limitée à exactement 100 combats." }
        val engine = FightEngine(sequencesPerRound = 12, stopOnTenCount = false, stopOnTko = false)
        val vega = MutableFighterMetrics(TestProfiles.eliasVega.id)
        val kessler = MutableFighterMetrics(TestProfiles.brunoKessler.id)
        var ties = 0
        var vegaRedAppearances = 0
        var kesslerRedAppearances = 0
        val records = mutableListOf<BatchFightRecord>()

        repeat(fightCount) { index ->
            val vegaInRedCorner = !alternateCorners || index % 2 == 0
            val seed = seedStart + index
            val fight = if (vegaInRedCorner) {
                vegaRedAppearances++
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = VEGA_TACTICS,
                    blueTactics = KESSLER_TACTICS,
                    seed = seed,
                )
            } else {
                kesslerRedAppearances++
                engine.simulateThreeRoundFight(
                    red = TestProfiles.brunoKessler,
                    blue = TestProfiles.eliasVega,
                    redTactics = KESSLER_TACTICS,
                    blueTactics = VEGA_TACTICS,
                    seed = seed,
                )
            }

            require(fight.rounds.size == 3)
            require(fight.rounds.all { it.events.size == 12 })

            val vegaPerformance = if (vegaInRedCorner) fight.redPerformanceTotal else fight.bluePerformanceTotal
            val kesslerPerformance = if (vegaInRedCorner) fight.bluePerformanceTotal else fight.redPerformanceTotal
            val vegaState = if (vegaInRedCorner) fight.finalRedState else fight.finalBlueState
            val kesslerState = if (vegaInRedCorner) fight.finalBlueState else fight.finalRedState

            when {
                vegaPerformance > kesslerPerformance + 1e-9 -> vega.performanceLeads++
                kesslerPerformance > vegaPerformance + 1e-9 -> kessler.performanceLeads++
                else -> ties++
            }

            records += BatchFightRecord(
                fightNumber = index + 1,
                seed = seed,
                vegaInRedCorner = vegaInRedCorner,
                vegaPerformance = vegaPerformance,
                kesslerPerformance = kesslerPerformance,
                vegaFinalState = vegaState,
                kesslerFinalState = kesslerState,
            )
            vega.addFight(vegaPerformance, vegaState)
            kessler.addFight(kesslerPerformance, kesslerState)
            fight.rounds.asSequence().flatMap { it.events.asSequence() }.forEach { event ->
                when (event.attackerId) {
                    vega.fighterId -> vega.addAction(event)
                    kessler.fighterId -> kessler.addAction(event)
                    else -> error("Événement associé à un boxeur inconnu : ${event.attackerId}")
                }
            }
        }

        return BatchValidationResult(
            fightCount = fightCount,
            roundsPerFight = 3,
            sequencesPerRound = 12,
            seedStart = seedStart,
            alternatedCorners = alternateCorners,
            redCornerAppearancesByFighter = mapOf(
                TestProfiles.eliasVega.id to vegaRedAppearances,
                TestProfiles.brunoKessler.id to kesslerRedAppearances,
            ),
            ties = ties,
            records = records.toList(),
            vega = vega.freeze(),
            kessler = kessler.freeze(),
        )
    }

    private class MutableFighterMetrics(val fighterId: String) {
        var performanceLeads: Int = 0
        var performanceTotal: Double = 0.0
        var thrown: Int = 0
        var landed: Int = 0
        var cleanHits: Int = 0
        var outsideActions: Int = 0
        var midActions: Int = 0
        var insideActions: Int = 0
        var finalStaminaTotal: Double = 0.0
        var headDamageReceivedTotal: Double = 0.0
        var bodyDamageReceivedTotal: Double = 0.0
        var finalStabilityTotal: Double = 0.0

        fun addFight(performance: Double, state: FighterState) {
            performanceTotal += performance
            thrown += state.thrown
            landed += state.landed
            cleanHits += state.cleanHits
            finalStaminaTotal += state.stamina
            headDamageReceivedTotal += state.headDamage
            bodyDamageReceivedTotal += state.bodyDamage
            finalStabilityTotal += state.stability
        }

        fun addAction(event: SequenceEvent) {
            when (event.range) {
                FightRange.OUTSIDE -> outsideActions++
                FightRange.MID -> midActions++
                FightRange.INSIDE -> insideActions++
            }
        }

        fun freeze() = FighterBatchMetrics(
            fighterId = fighterId,
            performanceLeads = performanceLeads,
            performanceTotal = performanceTotal,
            thrown = thrown,
            landed = landed,
            cleanHits = cleanHits,
            outsideActions = outsideActions,
            midActions = midActions,
            insideActions = insideActions,
            finalStaminaTotal = finalStaminaTotal,
            headDamageReceivedTotal = headDamageReceivedTotal,
            bodyDamageReceivedTotal = bodyDamageReceivedTotal,
            finalStabilityTotal = finalStabilityTotal,
        )
    }
}

object BatchValidationFormatter {
    fun format(result: BatchValidationResult): String = buildString {
        appendLine("TITLE FIGHT — Jalon 1, étape 3")
        appendLine("Validation de 100 combats complets de trois rounds")
        appendLine("Graines : ${result.seedStart} à ${result.seedStart + result.fightCount - 1}")
        appendLine("Coins alternés : ${if (result.alternatedCorners) "oui" else "non"}")
        appendLine()
        appendLine("STABILITÉ")
        appendLine("Combats terminés : ${result.fightCount}/100")
        appendLine("Rounds calculés : ${result.totalRounds}")
        appendLine("Séquences calculées : ${result.totalSequences}")
        appendLine("Crash ou exception : 0")
        appendLine("Coin rouge : Elias Vega ${result.redCornerAppearancesByFighter.getValue(result.vega.fighterId)}, Bruno Kessler ${result.redCornerAppearancesByFighter.getValue(result.kessler.fighterId)}")
        appendLine()
        appendLine("INDICATEUR DE PERFORMANCE MOTEUR, SANS JUGES")
        appendLine("Avantage Elias Vega : ${result.vega.performanceLeads} combats")
        appendLine("Avantage Bruno Kessler : ${result.kessler.performanceLeads} combats")
        appendLine("Égalités numériques : ${result.ties}")
        appendLine("Performance moyenne : Elias ${decimal(result.vega.averagePerformance)}, Bruno ${decimal(result.kessler.averagePerformance)}")
        appendLine("Ces avantages ne constituent pas des victoires officielles.")
        appendLine()
        appendFighter("ELIAS VEGA — OUT-BOXER", result.vega)
        appendLine()
        appendFighter("BRUNO KESSLER — PRESSURE FIGHTER", result.kessler)
        appendLine()
        appendLine("LECTURE DES IDENTITÉS TACTIQUES")
        appendLine("Elias attaque à longue distance dans ${percent(result.vega.outsideActionShare)} de ses initiatives.")
        appendLine("Bruno attaque à courte distance dans ${percent(result.kessler.insideActionShare)} de ses initiatives.")
        appendLine("Bruno inflige davantage de dégâts au corps : Elias en reçoit ${decimal(result.vega.averageBodyDamageReceived)} en moyenne contre ${decimal(result.kessler.averageBodyDamageReceived)} pour Bruno.")
        appendLine("Bruno termine avec moins d’énergie en moyenne, conséquence cohérente de sa pression et de son volume offensif.")
        appendLine()
        appendLine("CONCLUSION TECHNIQUE")
        appendLine("Les 100 combats sont calculés sans crash, les coins sont équilibrés à 50/50 et les deux profils produisent des signatures tactiques distinctes.")
        appendLine("L’étape 3 satisfait ses critères. La décision finale du jalon est produite par l’audit séparé des seuils.")
    }

    private fun StringBuilder.appendFighter(title: String, metrics: FighterBatchMetrics) {
        appendLine(title)
        appendLine("Initiatives : ${metrics.actionCount}")
        appendLine("Répartition des distances : longue ${percent(metrics.outsideActionShare)}, moyenne ${percent(metrics.midActionShare)}, courte ${percent(metrics.insideActionShare)}")
        appendLine("Coups : ${metrics.landed}/${metrics.thrown}, précision ${percent(metrics.accuracy)}, touches nettes ${metrics.cleanHits}")
        appendLine("État final moyen : énergie ${decimal(metrics.averageFinalStamina)}, tête ${decimal(metrics.averageHeadDamageReceived)}, corps ${decimal(metrics.averageBodyDamageReceived)}, stabilité ${decimal(metrics.averageFinalStability)}")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
    private fun percent(value: Double): String = String.format(Locale.US, "%.1f %%", value * 100.0)
}


object BatchCsvFormatter {
    fun format(result: BatchValidationResult): String = buildString {
        appendLine("fight_number,seed,vega_corner,vega_performance,kessler_performance,vega_stamina,vega_head_damage,vega_body_damage,vega_stability,kessler_stamina,kessler_head_damage,kessler_body_damage,kessler_stability")
        result.records.forEach { record ->
            append(record.fightNumber).append(',')
            append(record.seed).append(',')
            append(if (record.vegaInRedCorner) "red" else "blue").append(',')
            append(csvDecimal(record.vegaPerformance)).append(',')
            append(csvDecimal(record.kesslerPerformance)).append(',')
            append(csvDecimal(record.vegaFinalState.stamina)).append(',')
            append(csvDecimal(record.vegaFinalState.headDamage)).append(',')
            append(csvDecimal(record.vegaFinalState.bodyDamage)).append(',')
            append(csvDecimal(record.vegaFinalState.stability)).append(',')
            append(csvDecimal(record.kesslerFinalState.stamina)).append(',')
            append(csvDecimal(record.kesslerFinalState.headDamage)).append(',')
            append(csvDecimal(record.kesslerFinalState.bodyDamage)).append(',')
            appendLine(csvDecimal(record.kesslerFinalState.stability))
        }
    }

    private fun csvDecimal(value: Double): String = String.format(Locale.US, "%.6f", value)
}
