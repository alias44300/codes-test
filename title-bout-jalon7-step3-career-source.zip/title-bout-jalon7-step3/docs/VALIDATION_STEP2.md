# Validation du jalon 1 — étape 2

Date : 20 juillet 2026

## Objectif

Simuler un combat complet de trois rounds, transmettre les états entre les rounds et vérifier la reproductibilité avec une graine globale.

## Résultats

- compilation Kotlin : réussie ;
- tests automatisés : 6/6 réussis ;
- rounds produits : 3/3 ;
- séquences produites : 36/36 ;
- graines de round distinctes : 3/3 ;
- continuité des états : vérifiée ;
- rapport complet : présent ;
- encodage UTF-8 : vérifié ;
- décision officielle : absente, conformément au périmètre ;
- deux exécutions indépendantes avec la graine 20260720 : sorties strictement identiques.

## Empreinte du rapport reproductible

`6712c2f0ef1a5bd8fe16853c22932d0c94a6d5d3c22e05d182e122f2e88d1b72`

## Hors périmètre

Les 100 simulations, l’analyse statistique, les knockdowns, les KO/TKO, les juges, Android et l’APK ne sont pas inclus dans cette étape.
