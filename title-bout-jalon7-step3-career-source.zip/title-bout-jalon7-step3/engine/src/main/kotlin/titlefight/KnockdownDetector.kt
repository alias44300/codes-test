package titlefight

import kotlin.math.max

data class KnockdownEvaluation(
    val eligible: Boolean,
    val score: Double,
    val probability: Double,
) {
    init {
        require(score >= 0.0)
        require(probability in 0.0..1.0)
        require(eligible || probability == 0.0)
    }
}

/**
 * Détecteur pur de chute pour le jalon 2, étape 1.
 *
 * Il ne gère ni compte, ni relèvement, ni KO, ni TKO. Il transforme uniquement
 * les caractéristiques du coup et l’état physique de la victime en score puis
 * en probabilité. Le tirage déterministe reste géré par FightEngine.
 */
object KnockdownDetector {
    fun evaluate(
        defender: BoxerProfile,
        defenderBefore: FighterState,
        defenderAfter: FighterState,
        punch: Punch,
        landed: Boolean,
        clean: Boolean,
        impact: Double,
    ): KnockdownEvaluation {
        if (!landed || impact <= 0.0) return KnockdownEvaluation(false, 0.0, 0.0)

        val bodyShot = punch == Punch.BODY_HOOK
        val resistance = if (bodyShot) defender.bodyResistance else defender.chin
        val accumulatedDamage = if (bodyShot) defenderAfter.bodyDamage else defenderAfter.headDamage
        val instability = 100.0 - defenderAfter.stability
        val fatigue = 100.0 - defenderBefore.stamina

        val punchBonus = when (punch) {
            Punch.JAB -> -7.0
            Punch.CROSS -> 2.0
            Punch.HOOK -> 4.5
            Punch.UPPERCUT -> 6.0
            Punch.BODY_HOOK -> 2.0
            Punch.COMBINATION -> 5.0
        }
        val cleanBonus = if (clean) 7.0 else 0.0
        val score = max(
            0.0,
            impact * 3.0 +
                instability * 0.30 +
                fatigue * 0.12 +
                accumulatedDamage * 0.16 +
                punchBonus +
                cleanBonus -
                resistance * 0.30 -
                18.0,
        )

        // Un impact très faible ne produit pas de chute dans cette première version.
        // Les états dégradés augmentent ensuite progressivement le risque.
        val minimumImpact = if (punch == Punch.JAB) 5.8 else 5.2
        val probability = if (impact < minimumImpact || score <= 4.0) {
            0.0
        } else {
            ((score - 4.0) / 100.0).coerceIn(0.0, 0.65)
        }
        return KnockdownEvaluation(probability > 0.0, score, probability)
    }
}
