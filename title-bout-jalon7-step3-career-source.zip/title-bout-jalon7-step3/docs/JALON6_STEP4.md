# Jalon 6 — Étape 4 — Interactions tactiques entre les rounds

## Décision

Étape validée en Kotlin pur et par audit statique Compose.

## Fonctionnalités ajoutées

- session de combat interactive simulant un round à la fois ;
- choix du joueur sur quatre axes : rythme, distance, cible et risque ;
- joueur contrôlable dans le coin rouge ou dans le coin bleu ;
- sélection modifiable uniquement entre les rounds ;
- brouillon sans effet sur le moteur avant validation ;
- application exacte du plan validé au round suivant ;
- reprise du combat après confirmation ;
- jeton unique par fenêtre tactique pour bloquer les doubles validations ;
- verrouillage immédiat après KO, TKO ou décision finale ;
- timeline progressive compatible avec `FightScreenState` ;
- coordinateur pur Kotlin entre la session et les composants Compose ;
- contrôles Compose accessibles et dimensionnés à 44 ou 48 dp ;
- écran vertical défilable pour conserver l'accès aux commandes sur petit téléphone.

## Garanties

- modifier un brouillon ne consomme aucun tirage aléatoire ;
- même graine et mêmes choix produisent le même combat ;
- plusieurs modifications ramenées au même plan produisent le même résultat ;
- aucune carte exacte des juges n'est exposée ;
- aucune formule de précision, impact, distance, KO, TKO ou jugement n'est modifiée ;
- la timeline interactive finale est identique à celle du mapper complet validé.

## Validation

- 30 contrôles statiques de source réussis ;
- 9 tests historiques du contrat d'écran réussis ;
- 12 tests historiques Compose/Kotlin réussis ;
- 15 tests spécifiques aux interactions réussis ;
- 180 sessions interactives complètes ;
- 360 fenêtres tactiques ;
- 360 décisions du joueur appliquées ;
- 360 rejets corrects de jetons expirés ;
- 7 200 états d'écran ;
- 60 relectures déterministes ;
- 0 erreur de plan appliqué ;
- 0 erreur de phase ou verrouillage ;
- 0 divergence de timeline ;
- 0 fuite des cartes de juges.

## Limite de l'environnement

Le SDK Android, Gradle, `sdkmanager` et `adb` ne sont pas installés. La syntaxe des composants est contrôlée avec des stubs locaux, mais cette vérification ne constitue pas une compilation Android réelle. Aucun APK n'est produit à cette étape.
