package titlefight

import java.util.Locale

data class NeutralJudgeStep2AuditResult(
    val fightCount: Int,
    val simulatedRounds: Int,
    val scoredRounds: Int,
    val stoppedRoundsSkipped: Int,
    val tenNineRounds: Int,
    val tenEightRounds: Int,
    val tenSevenRounds: Int,
    val tenTenRounds: Int,
    val redRoundWins: Int,
    val blueRoundWins: Int,
    val tiedRounds: Int,
    val scoreMismatchCount: Int,
    val invalidScoreCount: Int,
    val knockdownPriorityViolationCount: Int,
    val blankExplanationCount: Int,
) {
    init {
        require(fightCount == 1000)
        require(simulatedRounds in fightCount..fightCount * 3)
        require(scoredRounds + stoppedRoundsSkipped == simulatedRounds)
        require(tenNineRounds + tenEightRounds + tenSevenRounds + tenTenRounds == scoredRounds)
        require(redRoundWins + blueRoundWins + tiedRounds == scoredRounds)
        listOf(
            scoreMismatchCount,
            invalidScoreCount,
            knockdownPriorityViolationCount,
            blankExplanationCount,
        ).forEach { require(it >= 0) }
    }
}

object NeutralJudgeStep2Auditor {
    private val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
    private val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

    fun run(seedStart: Long = 202607230000L): NeutralJudgeStep2AuditResult {
        val engine = FightEngine()
        var simulatedRounds = 0
        var scoredRounds = 0
        var stoppedRoundsSkipped = 0
        var tenNineRounds = 0
        var tenEightRounds = 0
        var tenSevenRounds = 0
        var tenTenRounds = 0
        var redRoundWins = 0
        var blueRoundWins = 0
        var tiedRounds = 0
        var scoreMismatchCount = 0
        var invalidScoreCount = 0
        var knockdownPriorityViolationCount = 0
        var blankExplanationCount = 0

        repeat(1000) { index ->
            val vegaInRed = index % 2 == 0
            val fight = if (vegaInRed) {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = vegaTactics,
                    blueTactics = kesslerTactics,
                    seed = seedStart + index,
                )
            } else {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.brunoKessler,
                    blue = TestProfiles.eliasVega,
                    redTactics = kesslerTactics,
                    blueTactics = vegaTactics,
                    seed = seedStart + index,
                )
            }

            fight.rounds.forEach { round ->
                simulatedRounds++
                if (round.stoppage != null) {
                    stoppedRoundsSkipped++
                    if (round.neutralJudgeScore != null) invalidScoreCount++
                    return@forEach
                }

                val score = round.neutralJudgeScore
                if (score == null) {
                    invalidScoreCount++
                    return@forEach
                }
                scoredRounds++
                if (score != NeutralJudge.score(round.judgingEvidence)) scoreMismatchCount++
                if (score.explanation.isBlank() || score.decisiveFactors.isEmpty()) blankExplanationCount++

                when (score.redPoints to score.bluePoints) {
                    10 to 9, 9 to 10 -> tenNineRounds++
                    10 to 8, 8 to 10 -> tenEightRounds++
                    10 to 7, 7 to 10 -> tenSevenRounds++
                    10 to 10 -> tenTenRounds++
                    else -> invalidScoreCount++
                }
                when (score.winnerId) {
                    score.redFighterId -> redRoundWins++
                    score.blueFighterId -> blueRoundWins++
                    null -> tiedRounds++
                    else -> invalidScoreCount++
                }

                val kdDifference = round.judgingEvidence.red.knockdownsScored - round.judgingEvidence.blue.knockdownsScored
                if (kdDifference > 0) {
                    val expectedBlue = if (kdDifference >= 2) 7 else 8
                    if (score.winnerId != score.redFighterId || score.redPoints != 10 || score.bluePoints != expectedBlue) {
                        knockdownPriorityViolationCount++
                    }
                } else if (kdDifference < 0) {
                    val expectedRed = if (kdDifference <= -2) 7 else 8
                    if (score.winnerId != score.blueFighterId || score.bluePoints != 10 || score.redPoints != expectedRed) {
                        knockdownPriorityViolationCount++
                    }
                }
            }
        }

        return NeutralJudgeStep2AuditResult(
            fightCount = 1000,
            simulatedRounds = simulatedRounds,
            scoredRounds = scoredRounds,
            stoppedRoundsSkipped = stoppedRoundsSkipped,
            tenNineRounds = tenNineRounds,
            tenEightRounds = tenEightRounds,
            tenSevenRounds = tenSevenRounds,
            tenTenRounds = tenTenRounds,
            redRoundWins = redRoundWins,
            blueRoundWins = blueRoundWins,
            tiedRounds = tiedRounds,
            scoreMismatchCount = scoreMismatchCount,
            invalidScoreCount = invalidScoreCount,
            knockdownPriorityViolationCount = knockdownPriorityViolationCount,
            blankExplanationCount = blankExplanationCount,
        )
    }
}

object NeutralJudgeStep2AuditFormatter {
    fun format(result: NeutralJudgeStep2AuditResult): String = buildString {
        appendLine("TITLE FIGHT — JALON 3 — ÉTAPE 2")
        appendLine("AUDIT DU JUGE NEUTRE")
        appendLine()
        appendLine("Combats : ${result.fightCount}")
        appendLine("Rounds simulés : ${result.simulatedRounds}")
        appendLine("Rounds jugés : ${result.scoredRounds}")
        appendLine("Rounds interrompus et non jugés : ${result.stoppedRoundsSkipped}")
        appendLine()
        appendLine("10-9 : ${result.tenNineRounds}")
        appendLine("10-8 : ${result.tenEightRounds}")
        appendLine("10-7 : ${result.tenSevenRounds}")
        appendLine("10-10 : ${result.tenTenRounds}")
        appendLine("Rounds rouge / bleu / nuls : ${result.redRoundWins} / ${result.blueRoundWins} / ${result.tiedRounds}")
        appendLine()
        appendLine("Écarts de reproductibilité : ${result.scoreMismatchCount}")
        appendLine("Scores invalides : ${result.invalidScoreCount}")
        appendLine("Violations de priorité des knockdowns : ${result.knockdownPriorityViolationCount}")
        appendLine("Justifications vides : ${result.blankExplanationCount}")
        appendLine()
        appendLine("Aucun total de carte et aucune décision officielle ne sont produits à cette étape.")
    }
}

object NeutralJudgeStep2AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        Locale.setDefault(Locale.FRANCE)
        print(NeutralJudgeStep2AuditFormatter.format(NeutralJudgeStep2Auditor.run()))
    }
}
