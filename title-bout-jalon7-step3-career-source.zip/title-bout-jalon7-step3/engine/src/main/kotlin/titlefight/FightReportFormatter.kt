package titlefight

import java.util.Locale

object FightReportFormatter {
    fun format(result: FightResult, red: BoxerProfile, blue: BoxerProfile): String {
        require(result.redId == red.id)
        require(result.blueId == blue.id)

        return buildString {
            appendLine("TITLE FIGHT — Rapport de combat")
            appendLine("${red.name} contre ${blue.name}")
            appendLine("Graine globale : ${result.seed}")
            appendLine()

            result.rounds.forEach { round ->
                appendLine("ROUND ${round.roundNumber} — graine ${round.seed}")
                val roundDecisions = result.tacticalDecisions.filter { it.beforeRound == round.roundNumber }
                val redDecision = roundDecisions.first { it.fighterId == red.id }
                val blueDecision = roundDecisions.first { it.fighterId == blue.id }
                appendLine(
                    "Tactique ${red.name} : ${planLabel(redDecision.selectedPlan)} " +
                        "[${if (result.adaptiveTacticsEnabled) "effets actifs" else "observation seulement"}].",
                )
                appendLine("  ${redDecision.explanation}")
                appendLine(
                    "Tactique ${blue.name} : ${planLabel(blueDecision.selectedPlan)} " +
                        "[${if (result.adaptiveTacticsEnabled) "effets actifs" else "observation seulement"}].",
                )
                appendLine("  ${blueDecision.explanation}")
                round.events.forEach { event ->
                    appendLine("${event.sequenceNumber}. ${event.text}")
                    event.knockdown?.let { knockdown ->
                        appendLine(
                            "   Détection : score ${decimal(knockdown.score)}, " +
                                "probabilité ${percent(knockdown.probability)}, tirage ${decimal(knockdown.roll)}",
                        )
                        knockdown.refereeCount?.let { count ->
                            appendLine(
                                "   Compte : ${count.countReached}/10, relevé=${if (count.recovered) "oui" else "non"}, " +
                                    "récupération ${decimal(count.recoveryScore)}, exigence ${decimal(count.requiredScore)}, " +
                                    "vulnérabilité ${count.vulnerabilitySequences} séquence(s)",
                            )
                        }
                    }
                }
                appendLine(
                    "Performance moteur : ${red.name} ${decimal(round.redRoundScore)} - " +
                        "${decimal(round.blueRoundScore)} ${blue.name}",
                )
                if (round.judgeScores.isEmpty()) {
                    appendLine("Juges : round non jugé, car interrompu par ${round.stoppage?.method}.")
                } else {
                    round.judgeScores.forEach { score ->
                        appendLine(
                            "${score.judgeName} (${score.judgeFocus}) : ${red.name} ${score.redPoints}-${score.bluePoints} ${blue.name}. " +
                                score.explanation,
                        )
                    }
                }
                appendLine(
                    "État : ${red.name} énergie ${decimal(round.redState.stamina)}, " +
                        "tête ${decimal(round.redState.headDamage)}, corps ${decimal(round.redState.bodyDamage)}, " +
                        "stabilité ${decimal(round.redState.stability)}, chutes ${round.redState.knockdownsSuffered}, " +
                            "vulnérabilité ${round.redState.vulnerabilitySequencesRemaining}, " +
                            "échecs défensifs ${round.redState.defensiveFailureStreak}",
                )
                appendLine(
                    "État : ${blue.name} énergie ${decimal(round.blueState.stamina)}, " +
                        "tête ${decimal(round.blueState.headDamage)}, corps ${decimal(round.blueState.bodyDamage)}, " +
                        "stabilité ${decimal(round.blueState.stability)}, chutes ${round.blueState.knockdownsSuffered}, " +
                            "vulnérabilité ${round.blueState.vulnerabilitySequencesRemaining}, " +
                            "échecs défensifs ${round.blueState.defensiveFailureStreak}",
                )
                appendLine()
            }

            appendLine(if (result.stoppage == null) "BILAN MOTEUR APRÈS 3 ROUNDS" else "BILAN MOTEUR AU MOMENT DE L’ARRÊT")
            appendLine(
                "Performance cumulée : ${red.name} ${decimal(result.redPerformanceTotal)} - " +
                    "${decimal(result.bluePerformanceTotal)} ${blue.name}",
            )
            appendLine(
                "Coups : ${red.name} ${result.finalRedState.landed}/${result.finalRedState.thrown}, " +
                    "${blue.name} ${result.finalBlueState.landed}/${result.finalBlueState.thrown}",
            )
            appendLine(
                "Chutes détectées : ${result.finalRedState.knockdownsSuffered + result.finalBlueState.knockdownsSuffered}",
            )
            val stoppage = result.stoppage
            if (stoppage == null) {
                val decision = requireNotNull(result.officialDecision)
                appendLine("CARTES OFFICIELLES")
                decision.scorecards.forEach { card ->
                    val roundDetails = card.rounds.joinToString(" | ") { score ->
                        "R${score.roundNumber} ${score.redPoints}-${score.bluePoints}"
                    }
                    appendLine("${card.judgeName} (${card.judgeFocus}) : ${red.name} ${card.redTotal}-${card.blueTotal} ${blue.name} [$roundDetails].")
                }
                if (decision.winnerId == null) {
                    appendLine("RÉSULTAT OFFICIEL DU MOTEUR : ${decision.type.frenchLabel.uppercase()}.")
                } else {
                    val winner = if (decision.winnerId == red.id) red else blue
                    val loser = if (decision.loserId == red.id) red else blue
                    appendLine("RÉSULTAT OFFICIEL DU MOTEUR : ${winner.name} bat ${loser.name} par ${decision.type.frenchLabel}.")
                }
                appendLine(decision.explanation)
            } else {
                val winner = if (stoppage.winnerId == red.id) red else blue
                val loser = if (stoppage.loserId == red.id) red else blue
                appendLine("RÉSULTAT OFFICIEL DU MOTEUR : ${winner.name} bat ${loser.name} par ${stoppage.method}, round ${stoppage.roundNumber}, séquence ${stoppage.sequenceNumber}.")
                appendLine("Motif : ${stoppage.reason}.")
                appendLine("Aucun round ni aucune séquence n’est calculé après l’arrêt. Le round interrompu n’est pas jugé et aucune décision aux points n’est produite.")
            }
        }
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
    private fun percent(value: Double): String = String.format(Locale.US, "%.1f %%", value * 100.0)

    private fun planLabel(plan: TacticalPlan): String =
        "rythme ${plan.pace.name.lowercase()}, distance ${plan.distance.name.lowercase()}, " +
            "cible ${plan.target.name.lowercase()}, risque ${plan.risk.name.lowercase()}"
}
