#!/usr/bin/env bash
set -euo pipefail
SDK_ROOT="${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}"
TOOLS_VERSION="15859902"
TOOLS_SHA256="4e4c464f145a7512b57d088ac6c278c03c9eea610886b35a5e0804e74eedf583"
URL="https://dl.google.com/android/repository/commandlinetools-linux-${TOOLS_VERSION}_latest.zip"
CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/title-fight-android"
ZIP="$CACHE/commandlinetools.zip"
mkdir -p "$CACHE" "$SDK_ROOT/cmdline-tools"

if [ ! -x "$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]; then
  curl --fail --location --retry 2 --connect-timeout 10 --max-time 300 "$URL" -o "$ZIP"
  echo "$TOOLS_SHA256  $ZIP" | sha256sum --check --status
  rm -rf "$SDK_ROOT/cmdline-tools/latest" "$CACHE/unpack"
  mkdir -p "$CACHE/unpack" "$SDK_ROOT/cmdline-tools/latest"
  unzip -q "$ZIP" -d "$CACHE/unpack"
  cp -R "$CACHE/unpack/cmdline-tools/." "$SDK_ROOT/cmdline-tools/latest/"
fi

export ANDROID_SDK_ROOT="$SDK_ROOT"
export PATH="$SDK_ROOT/cmdline-tools/latest/bin:$SDK_ROOT/platform-tools:$PATH"
yes | sdkmanager --licenses >/dev/null
sdkmanager "platform-tools" "platforms;android-37" "build-tools;36.0.0"
printf 'SDK Android prêt dans %s\n' "$SDK_ROOT"
