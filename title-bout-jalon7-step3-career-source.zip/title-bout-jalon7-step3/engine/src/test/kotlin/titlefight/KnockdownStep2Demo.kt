package titlefight

import java.util.Locale

object KnockdownStep2Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val engine = FightEngine(stopOnTenCount = false, stopOnTko = false)
        val vulnerable = FighterState(stamina = 18.0, headDamage = 76.0, bodyDamage = 52.0, stability = 16.0)
        val example = (1L..10000L).asSequence().map { seed ->
            seed to engine.simulateRound(
                roundNumber = 1,
                red = TestProfiles.brunoKessler,
                blue = TestProfiles.eliasVega,
                redStart = FighterState(),
                blueStart = vulnerable,
                redTactic = Tactic.SEEK_KO,
                blueTactic = Tactic.RECOVER,
                seed = seed,
            )
        }.first { (_, round) ->
            round.events.any { it.knockdown?.refereeCount?.recovered == true }
        }

        println("TITLE FIGHT — Démonstration du compte et du relèvement")
        println("Graine : ${example.first}")
        println()
        example.second.events.forEach { event ->
            println("${event.sequenceNumber}. ${event.text}")
            event.knockdown?.let { kd ->
                val count = requireNotNull(kd.refereeCount)
                println(
                    "   Impact=${decimal(kd.impact)}, compte=${count.countReached}/10, " +
                        "relevé=${if (count.recovered) "oui" else "non"}, " +
                        "vulnérabilité=${count.vulnerabilitySequences}",
                )
            }
        }
        println()
        println("État final d’Elias : vulnérabilité restante=${example.second.blueState.vulnerabilitySequencesRemaining}, compte à 10 en attente=${example.second.blueState.pendingTenCount}")
        println("Aucun KO ou TKO n’est appliqué dans cette étape.")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
}
