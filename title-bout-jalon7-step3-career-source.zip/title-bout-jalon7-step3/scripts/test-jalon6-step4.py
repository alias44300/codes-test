#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMPOSE = ROOT / "android-ui-compose" / "src" / "main" / "kotlin" / "titlefight" / "ui" / "compose"
ENGINE = ROOT / "engine" / "src" / "main" / "kotlin" / "titlefight"
BUILD = ROOT / "build-jalon6-step4"
BUILD.mkdir(parents=True, exist_ok=True)

screen = (COMPOSE / "FightScreen.kt").read_text(encoding="utf-8")
interaction = (COMPOSE / "FightTacticalInteraction.kt").read_text(encoding="utf-8")
session = (ENGINE / "InteractiveFightSession.kt").read_text(encoding="utf-8")
decision = (ENGINE / "TacticalDecision.kt").read_text(encoding="utf-8")
previews = (COMPOSE / "FightScreenPreviews.kt").read_text(encoding="utf-8")
all_source = "\n".join(p.read_text(encoding="utf-8") for p in sorted(COMPOSE.glob("*.kt")))
pre_between = screen.split("private fun BetweenRoundsPanel", 1)[0]

checks: dict[str, bool] = {
    "interactive_session_exists": "class InteractiveFightSession" in session,
    "session_is_round_gated": "InteractiveFightPhase.BETWEEN_ROUNDS" in session,
    "four_draft_axes": all(name in session for name in ("withPace", "withDistance", "withTarget", "withRisk")),
    "player_plan_is_applied_to_round": "redPlan = redDecision.selectedPlan" in session and "bluePlan = blueDecision.selectedPlan" in session,
    "selection_does_not_draw_rng": "seedStream.nextLong()" in session and "private fun updateDraft" in session,
    "expired_window_guard": "Fenêtre tactique expirée ou déjà validée" in session,
    "window_closed_before_simulation": session.index("openWindowId = null") < session.index("simulateNextRound(playerPlanOverride = plan)"),
    "player_selection_trigger": "PLAYER_SELECTION" in decision and "TacticalDecisionTrigger.PLAYER_SELECTION" in session,
    "screen_timeline_progressive": "object InteractiveFightScreenStateMapper" in session,
    "completed_timeline_uses_official_mapper_contract": "FightScreenStateMapper.decisionResult" in session,
    "ui_action_contract": "sealed interface TacticalSelectionAction" in interaction,
    "ui_state_between_rounds_only": "session.phase != InteractiveFightPhase.BETWEEN_ROUNDS" in interaction,
    "coordinator_exists": "class InteractiveFightCoordinator" in interaction,
    "screen_accepts_tactical_state": bool(re.search(r"fun\s+TitleFightScreen\s*\([^)]*tacticalSelection:\s*TacticalSelectionUiState", screen, re.S)),
    "screen_accepts_action_callback": "onTacticalAction: (TacticalSelectionAction) -> Unit" in screen,
    "four_choice_groups": all(f'label = "{label}"' in screen for label in ("Rythme", "Distance", "Cible", "Risque")),
    "confirm_and_resume_control": "VALIDER ET REPRENDRE" in screen,
    "clicks_only_in_between_rounds_section": "onClick" not in pre_between and "onClick" in screen.split("private fun BetweenRoundsPanel", 1)[1],
    "minimum_touch_targets": "minimumTapTargetDp.dp" in screen,
    "interactive_accessibility": "sélectionné" in screen and "Valider le plan tactique" in screen,
    "scrollable_small_screen": "verticalScroll(scrollState)" in screen,
    "interactive_preview": "tacticalSelection = FightScreenPreviewFixtures.tacticalSelection()" in previews,
    "no_network_import": not bool(re.search(r"import\s+(java\.net|okhttp|retrofit|ktor)", all_source, re.I)),
    "no_fight_simulation_in_composable": "FightEngine(" not in screen and "simulateThreeRoundFight" not in screen,
    "no_exact_judge_cards": not bool(re.search(r"scorecard|judgeCards|redCards|blueCards", all_source, re.I)),
    "legacy_read_only_fallback": "TacticalReadOnlyGrid" in screen,
    "red_and_blue_player_supported": "playerCorner == FighterCorner.RED" in session,
    "anchor_style_locked": "Le style d'ancrage du joueur ne peut pas être remplacé" in session,
    "double_confirmation_protected": "requireOpenWindow(windowId)" in session,
    "official_result_only_after_complete": "phase = InteractiveFightPhase.COMPLETE" in session,
}
failed = [name for name, ok in checks.items() if not ok]
report = {"checks": checks, "passed": len(checks) - len(failed), "failed": failed}
(BUILD / "step4-source-audit.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
if failed:
    raise SystemExit("Échec audit source étape 4: " + ", ".join(failed))

jar = BUILD / "title-fight-jalon6-step4.jar"
main_sources = sorted(ENGINE.glob("*.kt"))
pure_sources = [
    COMPOSE / "FightScreenComposeContract.kt",
    COMPOSE / "FightScreenPreviewFixtures.kt",
    COMPOSE / "FightScreenTimelineAdapter.kt",
    COMPOSE / "FightTacticalInteraction.kt",
]
test_sources = [
    ROOT / "engine" / "src" / "test" / "kotlin" / "titlefight" / "Jalon6Step1Audit.kt",
    ROOT / "android-ui-compose" / "src" / "test" / "kotlin" / "titlefight" / "ui" / "compose" / "Jalon6Step3Audit.kt",
    ROOT / "android-ui-compose" / "src" / "test" / "kotlin" / "titlefight" / "ui" / "compose" / "Jalon6Step4Audit.kt",
]
cmd = [
    "kotlinc", "-J-Xmx2048m", "-J-Dfile.encoding=UTF-8",
    *map(str, main_sources), *map(str, pure_sources), *map(str, test_sources),
    "-include-runtime", "-d", str(jar),
]
subprocess.run(cmd, check=True)
for main in (
    "titlefight.Jalon6Step1Test",
    "titlefight.ui.compose.Jalon6Step3Test",
    "titlefight.ui.compose.Jalon6Step4Test",
    "titlefight.ui.compose.Jalon6Step4AuditDemo",
):
    subprocess.run(["java", "-Xmx2g", "-Dfile.encoding=UTF-8", "-cp", str(jar), main], check=True)
print(f"{report['passed']} contrôles source étape 4 réussis")
