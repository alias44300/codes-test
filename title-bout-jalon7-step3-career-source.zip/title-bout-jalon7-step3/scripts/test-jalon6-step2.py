#!/usr/bin/env python3
from __future__ import annotations
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build-jalon6-step2" / "mockups"
AUDIT = ROOT / "build-jalon6-step2" / "layout-audit.json"
subprocess.run(["python3", str(ROOT / "ui-mockups" / "render_fight_screen.py"), "--out", str(OUT), "--audit", str(AUDIT)], check=True)
report = json.loads(AUDIT.read_text(encoding="utf-8"))
if report["failed"]:
    raise SystemExit("Échec de la validation visuelle statique")
print(f"{report['passed']} scénarios de lisibilité Jalon 6 étape 2 réussis")
