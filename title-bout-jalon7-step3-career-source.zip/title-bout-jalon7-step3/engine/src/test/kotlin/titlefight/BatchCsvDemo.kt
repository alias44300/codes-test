package titlefight

object BatchCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        print(BatchCsvFormatter.format(BatchValidator.run()))
    }
}
