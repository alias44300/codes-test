package titlefight

import kotlin.math.abs

data class TacticalPlanStep2AuditResult(
    val naturalPlanCount: Int,
    val uniqueNaturalPlanIds: Int,
    val combinationCount: Int,
    val styleAnchorMismatches: Int,
    val modifierBoundViolations: Int,
    val targetShareViolations: Int,
    val reproducibilityMismatches: Int,
    val monotonicityViolations: Int,
    val legacyBehaviorFingerprintMismatches: Int,
    val minimumActivityDelta: Double,
    val maximumActivityDelta: Double,
    val minimumDefenseDelta: Double,
    val maximumDefenseDelta: Double,
    val minimumImpactDelta: Double,
    val maximumImpactDelta: Double,
    val minimumStaminaCostDelta: Double,
    val maximumStaminaCostDelta: Double,
)

object TacticalPlanStep2Auditor {
    fun run(): TacticalPlanStep2AuditResult {
        val naturalPlans = TacticalPlanCatalog.allNaturalPlans()
        val combinations = buildList {
            TacticalPace.entries.forEach { pace ->
                TacticalDistance.entries.forEach { distance ->
                    TacticalTarget.entries.forEach { target ->
                        TacticalRisk.entries.forEach { risk ->
                            add(
                                TacticalPlan(
                                    anchorStyle = BoxingStyle.OUT_BOXER,
                                    pace = pace,
                                    distance = distance,
                                    target = target,
                                    risk = risk,
                                ),
                            )
                        }
                    }
                }
            }
        }

        var boundViolations = 0
        var targetShareViolations = 0
        var reproducibilityMismatches = 0
        combinations.forEach { plan ->
            val modifiers = plan.modifiers
            if (modifiers.activityDelta !in TacticalPlanModifiers.MIN_ACTIVITY_DELTA..TacticalPlanModifiers.MAX_ACTIVITY_DELTA ||
                modifiers.accuracyDelta !in TacticalPlanModifiers.MIN_ACCURACY_DELTA..TacticalPlanModifiers.MAX_ACCURACY_DELTA ||
                modifiers.defenseDelta !in TacticalPlanModifiers.MIN_DEFENSE_DELTA..TacticalPlanModifiers.MAX_DEFENSE_DELTA ||
                modifiers.impactDelta !in TacticalPlanModifiers.MIN_IMPACT_DELTA..TacticalPlanModifiers.MAX_IMPACT_DELTA ||
                modifiers.staminaCostDelta !in TacticalPlanModifiers.MIN_STAMINA_COST_DELTA..TacticalPlanModifiers.MAX_STAMINA_COST_DELTA ||
                modifiers.preferredRangeControlDelta !in TacticalPlanModifiers.MIN_RANGE_CONTROL_DELTA..TacticalPlanModifiers.MAX_RANGE_CONTROL_DELTA
            ) {
                boundViolations++
            }
            if (abs(modifiers.headTargetShare + modifiers.bodyTargetShare - 1.0) > 1e-9) {
                targetShareViolations++
            }
            val repeated = TacticalPlan(
                anchorStyle = plan.anchorStyle,
                pace = plan.pace,
                distance = plan.distance,
                target = plan.target,
                risk = plan.risk,
            )
            if (plan != repeated) reproducibilityMismatches++
        }

        return TacticalPlanStep2AuditResult(
            naturalPlanCount = naturalPlans.size,
            uniqueNaturalPlanIds = naturalPlans.map { it.id }.distinct().size,
            combinationCount = combinations.size,
            styleAnchorMismatches = naturalPlans.count { TacticalPlanCatalog.naturalFor(it.anchorStyle) != it },
            modifierBoundViolations = boundViolations,
            targetShareViolations = targetShareViolations,
            reproducibilityMismatches = reproducibilityMismatches,
            monotonicityViolations = monotonicityViolations(),
            legacyBehaviorFingerprintMismatches = LegacyBehaviorFingerprint.verify(),
            minimumActivityDelta = combinations.minOf { it.modifiers.activityDelta },
            maximumActivityDelta = combinations.maxOf { it.modifiers.activityDelta },
            minimumDefenseDelta = combinations.minOf { it.modifiers.defenseDelta },
            maximumDefenseDelta = combinations.maxOf { it.modifiers.defenseDelta },
            minimumImpactDelta = combinations.minOf { it.modifiers.impactDelta },
            maximumImpactDelta = combinations.maxOf { it.modifiers.impactDelta },
            minimumStaminaCostDelta = combinations.minOf { it.modifiers.staminaCostDelta },
            maximumStaminaCostDelta = combinations.maxOf { it.modifiers.staminaCostDelta },
        )
    }

    fun assertValid(result: TacticalPlanStep2AuditResult) {
        check(result.naturalPlanCount == BoxingStyle.entries.size)
        check(result.uniqueNaturalPlanIds == BoxingStyle.entries.size)
        check(result.combinationCount == TacticalPace.entries.size * TacticalDistance.entries.size * TacticalTarget.entries.size * TacticalRisk.entries.size)
        check(result.styleAnchorMismatches == 0)
        check(result.modifierBoundViolations == 0)
        check(result.targetShareViolations == 0)
        check(result.reproducibilityMismatches == 0)
        check(result.monotonicityViolations == 0)
        check(result.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun monotonicityViolations(): Int {
        var violations = 0
        TacticalDistance.entries.forEach { distance ->
            TacticalTarget.entries.forEach { target ->
                val cautious = TacticalPlanModifierFactory.derive(TacticalPace.CAUTIOUS, distance, target, TacticalRisk.BALANCED)
                val measured = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, distance, target, TacticalRisk.BALANCED)
                val sustained = TacticalPlanModifierFactory.derive(TacticalPace.SUSTAINED, distance, target, TacticalRisk.BALANCED)
                if (!(cautious.activityDelta < measured.activityDelta && measured.activityDelta < sustained.activityDelta)) violations++
                if (!(cautious.staminaCostDelta < measured.staminaCostDelta && measured.staminaCostDelta < sustained.staminaCostDelta)) violations++

                val safe = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, distance, target, TacticalRisk.SAFE)
                val balanced = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, distance, target, TacticalRisk.BALANCED)
                val aggressive = TacticalPlanModifierFactory.derive(TacticalPace.MEASURED, distance, target, TacticalRisk.AGGRESSIVE)
                if (!(safe.defenseDelta > balanced.defenseDelta && balanced.defenseDelta > aggressive.defenseDelta)) violations++
                if (!(safe.impactDelta < balanced.impactDelta && balanced.impactDelta < aggressive.impactDelta)) violations++
            }
        }
        return violations
    }
}

object TacticalPlanStep2AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = TacticalPlanStep2Auditor.run()
        TacticalPlanStep2Auditor.assertValid(result)
        println("AUDIT JALON 4 — ÉTAPE 2")
        println("Plans naturels / identifiants uniques : ${result.naturalPlanCount} / ${result.uniqueNaturalPlanIds}")
        println("Combinaisons tactiques vérifiées : ${result.combinationCount}")
        println("Erreurs d'ancrage style : ${result.styleAnchorMismatches}")
        println("Violations de bornes : ${result.modifierBoundViolations}")
        println("Violations de cible : ${result.targetShareViolations}")
        println("Écarts de reproductibilité : ${result.reproducibilityMismatches}")
        println("Violations de monotonie : ${result.monotonicityViolations}")
        println("Empreintes historiques modifiées : ${result.legacyBehaviorFingerprintMismatches}")
        println("Activité min/max : ${"%.2f".format(result.minimumActivityDelta)} / ${"%.2f".format(result.maximumActivityDelta)}")
        println("Défense min/max : ${"%.2f".format(result.minimumDefenseDelta)} / ${"%.2f".format(result.maximumDefenseDelta)}")
        println("Impact min/max : ${"%.2f".format(result.minimumImpactDelta)} / ${"%.2f".format(result.maximumImpactDelta)}")
        println("Coût énergie min/max : ${"%.2f".format(result.minimumStaminaCostDelta)} / ${"%.2f".format(result.maximumStaminaCostDelta)}")
    }
}

object TacticalPlanStep2Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        println("PLANS TACTIQUES NATURELS")
        TacticalPlanCatalog.allNaturalPlans().forEach { plan ->
            val m = plan.modifiers
            println(
                "${plan.anchorStyle}: rythme=${plan.pace}, distance=${plan.distance}, cible=${plan.target}, risque=${plan.risk} | " +
                    "activité=${signed(m.activityDelta)}, précision=${signed(m.accuracyDelta)}, défense=${signed(m.defenseDelta)}, " +
                    "impact=${signed(m.impactDelta)}, coût énergie=${signed(m.staminaCostDelta)}, tête/corps=${percent(m.headTargetShare)}/${percent(m.bodyTargetShare)}",
            )
        }
        println("Ces valeurs sont descriptives et ne sont pas encore appliquées au moteur.")
    }

    private fun signed(value: Double): String = "%+.2f".format(value)
    private fun percent(value: Double): String = "%.0f%%".format(value * 100.0)
}
