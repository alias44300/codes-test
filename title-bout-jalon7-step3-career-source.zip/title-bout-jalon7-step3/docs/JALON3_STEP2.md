# Jalon 3 — Étape 2 — Juge neutre

## Statut

VALIDÉE

## Objectif

Ajouter un seul juge neutre capable de noter chaque round terminé selon un système simplifié des dix points obligatoires, sans totaliser de carte et sans produire de décision officielle.

## Structures ajoutées

- `NeutralJudgeRoundScore`
- `NeutralJudge`

Chaque `RoundResult` terminé contient désormais un `neutralJudgeScore`. Un round interrompu par KO ou TKO conserve ses preuves objectives, mais sa note reste `null`.

## Axes pondérés

- coups nets et qualité des impacts : 42 % ;
- agressivité efficace : 18 % ;
- défense : 18 % ;
- contrôle de la distance et du rythme : 14 % ;
- travail au corps : 8 %.

Aucun tirage aléatoire n'intervient dans la notation.

## Règles de score

- round gagné sans différence de knockdowns : 10-9 ;
- avantage d'un knockdown : 10-8 ;
- avantage d'au moins deux knockdowns : 10-7 ;
- round dont l'écart pondéré ne dépasse pas 2 points : 10-10 ;
- aucun score inférieur à 7 ;
- aucun round interrompu n'est jugé.

Les knockdowns ont priorité sur le mérite statistique global du round.

## Justification

Chaque note conserve :

- le mérite pondéré de chaque coin ;
- la marge de mérite ;
- la différence de knockdowns ;
- jusqu'à trois facteurs décisifs ;
- une explication textuelle déterministe.

## Validation

- 40 tests automatisés réussis ;
- audit reproductible de 1 000 combats ;
- 3 000 rounds simulés ;
- 2 995 rounds jugés ;
- 5 rounds interrompus et non jugés ;
- 2 484 scores 10-9 ;
- 388 scores 10-8 ;
- 49 scores 10-7 ;
- 74 scores 10-10, soit 2,47 % des rounds jugés ;
- 0 score impossible ;
- 0 violation de priorité des knockdowns ;
- 0 justification vide ;
- 0 écart de reproductibilité.

## Limite conservée

Le moteur ne totalise pas encore les rounds. Il n'existe encore ni deuxième juge, ni troisième juge, ni carte complète, ni décision officielle aux points.
