package androidx.compose.runtime
@Target(AnnotationTarget.FUNCTION, AnnotationTarget.TYPE)
annotation class Composable
fun <T> remember(vararg keys: Any?, calculation: () -> T): T = calculation()
