#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "engine" / "src" / "main" / "kotlin" / "titlefight"
APP = ROOT / "app" / "src" / "main" / "kotlin" / "titlefight" / "app"
DATA = ROOT / "data-local" / "src" / "main" / "kotlin" / "titlefight" / "data" / "local"
DB = ROOT / "database"

seed = json.loads((DB / "seed" / "boxers-heavyweight-v1.json").read_text(encoding="utf-8"))
schema_audit = json.loads((DB / "schema-v1-audit.json").read_text(encoding="utf-8"))
narrative = (ENGINE / "NarrativeCommentaryEngine.kt").read_text(encoding="utf-8")
models = (ENGINE / "BoxerDatabaseModels.kt").read_text(encoding="utf-8")
roster = (ENGINE / "PlayableBoxerDatabase.kt").read_text(encoding="utf-8")
sqlite_source = (DATA / "TitleFightDatabase.kt").read_text(encoding="utf-8")
main_activity = (APP / "MainActivity.kt").read_text(encoding="utf-8")
selector = (APP / "RosterSelectionScreen.kt").read_text(encoding="utf-8")
settings = (ROOT / "settings.gradle.kts").read_text(encoding="utf-8")

checks = {
    "20_historical_versions": len(seed["boxers"]) == 20,
    "28_rating_fields": all(len(item["ratings"]) == 28 for item in seed["boxers"]),
    "9_tendency_fields": all(len(item["tendencies"]) == 9 for item in seed["boxers"]),
    "60_signature_actions": sum(len(item["signatureActions"]) for item in seed["boxers"]) == 60,
    "60_traits": sum(len(item["traits"]) for item in seed["boxers"]) == 60,
    "seven_styles": len({item["style"] for item in seed["boxers"]}) == 7,
    "three_stances": {item["stance"] for item in seed["boxers"]} == {"ORTHODOX", "SOUTHPAW", "SWITCH"},
    "sqlite_integrity_ok": schema_audit["integrity"] == "ok",
    "sqlite_foreign_keys_ok": schema_audit["foreign_key_errors"] == [],
    "seven_sqlite_tables": len(schema_audit["schema_tables"]) == 7,
    "sqlite_seed_code": "class TitleFightDatabase" in sqlite_source and "seedV1" in sqlite_source,
    "offline_repository": "class AndroidBoxerRepository" in sqlite_source and "java.net" not in sqlite_source,
    "versioned_database": "SCHEMA_VERSION" in roster and "CONTENT_VERSION" in roster,
    "advanced_rating_model": "data class BoxerRatings" in models,
    "searchable_catalog": "fun search(" in roster and "searchProfiles" in sqlite_source,
    "selection_screen": "fun RosterSelectionScreen" in selector,
    "red_blue_selection": "onSelectRed" in selector and "onSelectBlue" in selector,
    "app_uses_sqlite_repository": "AndroidBoxerRepository" in main_activity,
    "data_module_enabled": 'include(\":data-local\")' in settings,
    "narrative_is_observation_only": "DeterministicRandom" not in narrative and "FightEngine(" not in narrative,
    "narrative_multi_line": "lines.size in 1..5" in narrative and "joinToString(\"\\n\")" in narrative,
    "narrative_context": all(token in narrative for token in ("previousEvent", "redState", "blueState", "roundNumber")),
    "knockdown_commentary": "KNOCKDOWN" in narrative and "COUNT" in narrative,
    "stoppage_commentary": "STOPPAGE" in narrative and "TKO" in narrative,
    "defensive_commentary": "defenseLine" in narrative and "clinch" in narrative.lower(),
    "no_network_in_new_modules": not re.search(r"okhttp|retrofit|ktor|java\.net|android\.permission\.INTERNET", "\n".join((models, roster, narrative, sqlite_source, main_activity, selector)), re.I),
}
failed = [name for name, passed in checks.items() if not passed]
report = {
    "checks": checks,
    "passed": len(checks) - len(failed),
    "failed": failed,
    "seed_sha256": hashlib.sha256((DB / "seed" / "boxers-heavyweight-v1.json").read_bytes()).hexdigest(),
    "schema_sha256": hashlib.sha256((DB / "schema-v1.sql").read_bytes()).hexdigest(),
}
(ROOT / "build-jalon7-step1" / "jalon7-step1-source-audit.json").write_text(
    json.dumps(report, indent=2, ensure_ascii=False) + "\n",
    encoding="utf-8",
)
if failed:
    raise SystemExit("Échec audit Jalon 7 étape 1: " + ", ".join(failed))
print(f"{report['passed']} contrôles statiques Jalon 7 étape 1 réussis")
