# Notices

## Prototype HORRIVALS

Le code de ce dossier a été créé spécifiquement pour ce prototype et ne copie pas le code source d'OpenCards.

## OpenCards

OpenCards (dustland/OpenCards) est un projet Godot open source distribué sous licence MIT. Il a été utilisé comme référence fonctionnelle pour les idées de flux : match joueur contre IA, mouvement de cartes et animation d'événements dans l'ordre.

Référence : https://github.com/dustland/OpenCards

## Illustrations

Les illustrations HORRIVALS incluses dans `assets/cards/` proviennent de la bibliothèque de travail de l'utilisateur et restent soumises aux droits applicables à leurs personnages et franchises respectives. Elles sont incluses ici uniquement pour prototypage privé du système de jeu.
