@echo off
setlocal
cd /d "%~dp0"
echo TITLE FIGHT - Compilation Android Windows
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_TITLE_FIGHT_WINDOWS.ps1" %*
set EXIT_CODE=%ERRORLEVEL%
echo.
if "%EXIT_CODE%"=="0" (
  echo Operation terminee. Consultez artifacts\windows-build.
) else (
  echo Echec de la compilation. Consultez artifacts\windows-build\logs.
)
pause
exit /b %EXIT_CODE%
