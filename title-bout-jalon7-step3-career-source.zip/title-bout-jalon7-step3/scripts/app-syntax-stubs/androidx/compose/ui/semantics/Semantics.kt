package androidx.compose.ui.semantics
import androidx.compose.ui.Modifier
class ProgressBarRangeInfo(val current: Float, val range: ClosedFloatingPointRange<Float>, val steps: Int = 0)
class SemanticsPropertyReceiver
private var cd: String = ""
private var pb: ProgressBarRangeInfo? = null
var SemanticsPropertyReceiver.contentDescription: String
    get() = cd
    set(value) { cd = value }
var SemanticsPropertyReceiver.progressBarRangeInfo: ProgressBarRangeInfo
    get() = pb ?: ProgressBarRangeInfo(0f, 0f..1f)
    set(value) { pb = value }
fun SemanticsPropertyReceiver.heading() {}
fun Modifier.semantics(mergeDescendants: Boolean = false, properties: SemanticsPropertyReceiver.() -> Unit): Modifier { SemanticsPropertyReceiver().properties(); return this }
