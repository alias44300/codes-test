$ErrorActionPreference = "Stop"
$SdkRoot = if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } else { Join-Path $env:LOCALAPPDATA "Android\Sdk" }
$Version = "15859902"
$Expected = "90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a"
$Cache = Join-Path $env:TEMP "title-fight-android"
$Zip = Join-Path $Cache "commandlinetools.zip"
$Latest = Join-Path $SdkRoot "cmdline-tools\latest"
New-Item -ItemType Directory -Force $Cache, (Join-Path $SdkRoot "cmdline-tools") | Out-Null
if (-not (Test-Path (Join-Path $Latest "bin\sdkmanager.bat"))) {
  Invoke-WebRequest "https://dl.google.com/android/repository/commandlinetools-win-$($Version)_latest.zip" -OutFile $Zip
  $Actual = (Get-FileHash $Zip -Algorithm SHA256).Hash.ToLower()
  if ($Actual -ne $Expected) { throw "Checksum Android CLI invalide: $Actual" }
  $Unpack = Join-Path $Cache "unpack"
  Remove-Item -Recurse -Force $Unpack, $Latest -ErrorAction SilentlyContinue
  Expand-Archive $Zip $Unpack
  New-Item -ItemType Directory -Force $Latest | Out-Null
  Copy-Item (Join-Path $Unpack "cmdline-tools\*") $Latest -Recurse -Force
}
$env:ANDROID_SDK_ROOT = $SdkRoot
$SdkManager = Join-Path $Latest "bin\sdkmanager.bat"
"y" * 20 | & $SdkManager --licenses | Out-Null
& $SdkManager "platform-tools" "platforms;android-37" "build-tools;36.0.0"
Write-Host "SDK Android prêt dans $SdkRoot"
