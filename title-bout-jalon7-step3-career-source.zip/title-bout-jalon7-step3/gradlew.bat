@echo off
setlocal enabledelayedexpansion
set VERSION=9.5.1
set SHA256=bafc141b619ad6350fd975fc903156dd5c151998cc8b058e8c1044ab5f7b031f
if "%USERPROFILE%"=="" (set BASE=%CD%\.gradle-bootstrap) else (set BASE=%USERPROFILE%\.gradle\title-fight-bootstrap)
set ZIP=%BASE%\gradle-%VERSION%-bin.zip
set DIST=%BASE%\gradle-%VERSION%
if not exist "%DIST%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip'; Invoke-WebRequest -UseBasicParsing $u -OutFile '%ZIP%'; $h=(Get-FileHash '%ZIP%' -Algorithm SHA256).Hash.ToLower(); if($h -ne '%SHA256%'){throw 'Checksum Gradle invalide'}; Expand-Archive -Force '%ZIP%' '%BASE%'"
  if errorlevel 1 exit /b 1
)
call "%DIST%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
