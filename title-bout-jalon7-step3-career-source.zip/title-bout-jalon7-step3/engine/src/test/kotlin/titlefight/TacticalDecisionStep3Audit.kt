package titlefight

import kotlin.math.abs

data class TacticalDecisionStep3AuditResult(
    val fightCount: Int,
    val totalRounds: Int,
    val totalDecisions: Int,
    val preFightDecisions: Int,
    val betweenRoundDecisions: Int,
    val changedDecisions: Int,
    val stoppedFights: Int,
    val decisionsAfterStoppage: Int,
    val blankExplanations: Int,
    val naturalPlanMismatches: Int,
    val styleAnchorMismatches: Int,
    val styleDriftViolations: Int,
    val reproducibilityMismatches: Int,
    val unexplainedReversals: Int,
    val trailingOpportunities: Int,
    val trailingEntrepreneurialResponses: Int,
    val highFatigueOpportunities: Int,
    val highFatiguePaceReductions: Int,
    val physicalDangerOpportunities: Int,
    val physicalDangerSafetyResponses: Int,
    val legacyBehaviorFingerprintMismatches: Int,
    val triggerCounts: Map<TacticalDecisionTrigger, Int>,
) {
    val trailingResponseRate: Double
        get() = ratio(trailingEntrepreneurialResponses, trailingOpportunities)
    val fatigueResponseRate: Double
        get() = ratio(highFatiguePaceReductions, highFatigueOpportunities)
    val dangerResponseRate: Double
        get() = ratio(physicalDangerSafetyResponses, physicalDangerOpportunities)

    private fun ratio(value: Int, total: Int): Double = if (total == 0) 1.0 else value.toDouble() / total
}

object TacticalDecisionStep3Auditor {
    fun run(fightCount: Int = 1_000, seedStart: Long = 202607210700L): TacticalDecisionStep3AuditResult {
        var totalRounds = 0
        var totalDecisions = 0
        var preFightDecisions = 0
        var betweenRoundDecisions = 0
        var changedDecisions = 0
        var stoppedFights = 0
        var decisionsAfterStoppage = 0
        var blankExplanations = 0
        var naturalPlanMismatches = 0
        var styleAnchorMismatches = 0
        var styleDriftViolations = 0
        var reproducibilityMismatches = 0
        var unexplainedReversals = 0
        var trailingOpportunities = 0
        var trailingEntrepreneurialResponses = 0
        var highFatigueOpportunities = 0
        var highFatiguePaceReductions = 0
        var physicalDangerOpportunities = 0
        var physicalDangerSafetyResponses = 0
        val triggerCounts = TacticalDecisionTrigger.entries.associateWith { 0 }.toMutableMap()

        repeat(fightCount) { index ->
            val seed = seedStart + index
            val setup = setup(index, seed)
            val fight = setup.fight
            totalRounds += fight.rounds.size
            totalDecisions += fight.tacticalDecisions.size
            if (fight.stoppage != null) stoppedFights++
            if (index < 200 && setup(index, seed).fight != fight) reproducibilityMismatches++

            fight.tacticalDecisions.forEach { decision ->
                val profile = if (decision.fighterId == fight.redId) setup.red else setup.blue
                val natural = TacticalPlanCatalog.naturalFor(profile)
                val snapshot = fight.tacticalSnapshots[decision.beforeRound - 1]
                val own = if (decision.fighterId == fight.redId) snapshot.red else snapshot.blue
                val signedPerformance = if (decision.fighterId == fight.redId) {
                    snapshot.estimatedPerformanceMargin
                } else {
                    -snapshot.estimatedPerformanceMargin
                }

                if (decision.beforeRound == 1) {
                    preFightDecisions++
                    if (decision.selectedPlan != natural) naturalPlanMismatches++
                } else {
                    betweenRoundDecisions++
                }
                if (decision.changed) changedDecisions++
                if (decision.explanation.isBlank()) blankExplanations++
                if (decision.selectedPlan.anchorStyle != profile.style) styleAnchorMismatches++
                if (abs(decision.selectedPlan.pace.ordinal - natural.pace.ordinal) > 1 ||
                    abs(decision.selectedPlan.distance.ordinal - natural.distance.ordinal) > 1 ||
                    abs(decision.selectedPlan.risk.ordinal - natural.risk.ordinal) > 1
                ) {
                    styleDriftViolations++
                }
                decision.triggers.forEach { triggerCounts[it] = triggerCounts.getValue(it) + 1 }

                val previous = decision.previousPlan
                if (previous != null) {
                    val trailing = own.estimatedRoundBalance < 0 ||
                        (own.estimatedRoundBalance == 0 && signedPerformance <= -TacticalDecisionEngine.PERFORMANCE_MARGIN_TRIGGER)
                    val physicalDanger = own.headDamage >= TacticalDecisionEngine.HEAD_DANGER ||
                        own.bodyDamage >= TacticalDecisionEngine.BODY_DANGER ||
                        own.stability <= TacticalDecisionEngine.STABILITY_DANGER ||
                        (own.knockdownsSuffered > own.knockdownsScored && own.stability <= 55.0)
                    val highFatigue = own.stamina <= TacticalDecisionEngine.HIGH_FATIGUE_STAMINA

                    if (trailing && !highFatigue && !physicalDanger) {
                        trailingOpportunities++
                        if (decision.selectedPlan.pace.ordinal > previous.pace.ordinal ||
                            decision.selectedPlan.risk.ordinal > previous.risk.ordinal ||
                            decision.selectedPlan.distance.ordinal > previous.distance.ordinal ||
                            decision.selectedPlan.pace == TacticalPace.SUSTAINED ||
                            decision.selectedPlan.risk == TacticalRisk.AGGRESSIVE ||
                            decision.selectedPlan.distance == TacticalDistance.CLOSE
                        ) {
                            trailingEntrepreneurialResponses++
                        }
                    }
                    if (highFatigue) {
                        highFatigueOpportunities++
                        if (decision.selectedPlan.pace.ordinal < previous.pace.ordinal || previous.pace == TacticalPace.CAUTIOUS) {
                            highFatiguePaceReductions++
                        }
                    }
                    if (physicalDanger) {
                        physicalDangerOpportunities++
                        if (decision.selectedPlan.risk == TacticalRisk.SAFE ||
                            TacticalDecisionTrigger.CONFLICT_MANAGEMENT in decision.triggers
                        ) {
                            physicalDangerSafetyResponses++
                        }
                    }
                }
            }

            fight.stoppage?.let { stoppage ->
                decisionsAfterStoppage += fight.tacticalDecisions.count { it.beforeRound > stoppage.roundNumber }
            }

            val byFighter = fight.tacticalDecisions.groupBy { it.fighterId }
            byFighter.values.forEach { decisions ->
                decisions.windowed(3).forEach { triple ->
                    val older = triple[0].selectedPlan
                    val previous = triple[1].selectedPlan
                    val current = triple[2]
                    val urgent = current.triggers.any {
                        it in setOf(
                            TacticalDecisionTrigger.PHYSICAL_DANGER,
                            TacticalDecisionTrigger.HIGH_FATIGUE,
                            TacticalDecisionTrigger.FINAL_ROUND_DEFICIT,
                            TacticalDecisionTrigger.LEAD_PROTECTION,
                        )
                    }
                    if (!urgent && TacticalDecisionTrigger.ANTI_OSCILLATION !in current.triggers) {
                        if (reversed(older.pace.ordinal, previous.pace.ordinal, current.selectedPlan.pace.ordinal) ||
                            reversed(older.distance.ordinal, previous.distance.ordinal, current.selectedPlan.distance.ordinal) ||
                            reversed(older.risk.ordinal, previous.risk.ordinal, current.selectedPlan.risk.ordinal)
                        ) unexplainedReversals++
                    }
                }
            }
        }

        return TacticalDecisionStep3AuditResult(
            fightCount,
            totalRounds,
            totalDecisions,
            preFightDecisions,
            betweenRoundDecisions,
            changedDecisions,
            stoppedFights,
            decisionsAfterStoppage,
            blankExplanations,
            naturalPlanMismatches,
            styleAnchorMismatches,
            styleDriftViolations,
            reproducibilityMismatches,
            unexplainedReversals,
            trailingOpportunities,
            trailingEntrepreneurialResponses,
            highFatigueOpportunities,
            highFatiguePaceReductions,
            physicalDangerOpportunities,
            physicalDangerSafetyResponses,
            LegacyBehaviorFingerprint.verify(),
            triggerCounts.toMap(),
        )
    }

    fun assertValid(result: TacticalDecisionStep3AuditResult) {
        check(result.totalDecisions == result.totalRounds * 2)
        check(result.preFightDecisions == result.fightCount * 2)
        check(result.preFightDecisions + result.betweenRoundDecisions == result.totalDecisions)
        check(result.changedDecisions > 0)
        check(result.decisionsAfterStoppage == 0)
        check(result.blankExplanations == 0)
        check(result.naturalPlanMismatches == 0)
        check(result.styleAnchorMismatches == 0)
        check(result.styleDriftViolations == 0)
        check(result.reproducibilityMismatches == 0)
        check(result.unexplainedReversals == 0)
        check(result.trailingOpportunities > 0)
        check(result.trailingResponseRate >= 0.85)
        check(result.highFatigueOpportunities == 0 || result.fatigueResponseRate >= 0.80)
        check(result.physicalDangerOpportunities == 0 || result.dangerResponseRate >= 0.80)
        check(result.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun reversed(older: Int, previous: Int, current: Int): Boolean {
        val first = previous.compareTo(older)
        val second = current.compareTo(previous)
        return first != 0 && second != 0 && first == -second
    }

    data class Setup(val red: BoxerProfile, val blue: BoxerProfile, val fight: FightResult)

    private fun setup(index: Int, seed: Long): Setup {
        val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
        val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)
        val redIsVega = index % 2 == 0
        val red = if (redIsVega) TestProfiles.eliasVega else TestProfiles.brunoKessler
        val blue = if (redIsVega) TestProfiles.brunoKessler else TestProfiles.eliasVega
        return Setup(
            red = red,
            blue = blue,
            fight = FightEngine().simulateThreeRoundFight(
                red = red,
                blue = blue,
                redTactics = if (redIsVega) vegaTactics else kesslerTactics,
                blueTactics = if (redIsVega) kesslerTactics else vegaTactics,
                seed = seed,
            ),
        )
    }
}

object TacticalDecisionStep3AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = TacticalDecisionStep3Auditor.run()
        TacticalDecisionStep3Auditor.assertValid(result)
        println("AUDIT JALON 4 — ÉTAPE 3")
        println("Combats / rounds / décisions : ${result.fightCount} / ${result.totalRounds} / ${result.totalDecisions}")
        println("Avant combat / entre rounds : ${result.preFightDecisions} / ${result.betweenRoundDecisions}")
        println("Décisions modifiées : ${result.changedDecisions}")
        println("Combats arrêtés / décisions après arrêt : ${result.stoppedFights} / ${result.decisionsAfterStoppage}")
        println("Explications vides : ${result.blankExplanations}")
        println("Erreurs plan naturel / ancrage / dérive : ${result.naturalPlanMismatches} / ${result.styleAnchorMismatches} / ${result.styleDriftViolations}")
        println("Écarts reproductibilité / retours inexpliqués : ${result.reproducibilityMismatches} / ${result.unexplainedReversals}")
        println("Réponse au retard : ${result.trailingEntrepreneurialResponses}/${result.trailingOpportunities} (${"%.2f".format(result.trailingResponseRate * 100)} %)")
        println("Réponse à la forte fatigue : ${result.highFatiguePaceReductions}/${result.highFatigueOpportunities} (${"%.2f".format(result.fatigueResponseRate * 100)} %)")
        println("Réponse au danger physique : ${result.physicalDangerSafetyResponses}/${result.physicalDangerOpportunities} (${"%.2f".format(result.dangerResponseRate * 100)} %)")
        println("Empreintes historiques modifiées : ${result.legacyBehaviorFingerprintMismatches}")
        println("Déclencheurs : ${result.triggerCounts.filterValues { it > 0 }}")
    }
}

object TacticalDecisionStep3Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val fight = FightEngine().simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = 202607210703L,
        )
        println("HISTORIQUE DES DÉCISIONS TACTIQUES — NON APPLIQUÉES AU MOTEUR")
        fight.tacticalDecisions.forEach { decision ->
            println("${decision.fighterId} avant R${decision.beforeRound} | ${decision.selectedPlan.id}")
            println("  ${decision.explanation}")
        }
    }
}
