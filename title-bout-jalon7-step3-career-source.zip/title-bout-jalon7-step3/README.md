# TITLE BOUT — Jalon 7, étape 3

Simulateur de boxe hors ligne avec moteur déterministe, combats historiques et véritable mode carrière.

## Mode carrière corrigé

Le joueur ne sélectionne plus une légende déjà classée. Il crée son propre boxeur professionnel qui débute à **18 ans**, sans classement mondial, sans ceinture et avec des statistiques de débutant.

La progression suit cette route :

1. jeune professionnel ;
2. circuit régional ;
3. titre national ;
4. titre continental ;
5. classement mondial ;
6. championnat du monde WBA ;
7. unifications WBC, IBF et WBO ;
8. statut de champion incontesté et ceinture The Ring.

La carrière gère également :

- âge en semaines, années et mois ;
- entraînement par spécialité ;
- fatigue et santé ;
- palmarès et victoires par KO ;
- réputation et bourses ;
- défenses de titre ;
- montée ou descente de catégorie lorsque le boxeur ne détient aucune ceinture ;
- retraite ;
- perte d'une ceinture après une défaite en défense.

## Base historique

Les **321 boxeurs officiels**, BOX-001 à BOX-321, servent uniquement d'adversaires historiques. La base couvre 15 catégories et conserve les identités, surnoms, styles et statistiques de combat utiles au simulateur.

**Aucun système de rareté, coût de carte ou charisme de collection n'est utilisé dans Title Bout.** Ces concepts appartenaient à Knockout Cards et ont été retirés du modèle, du JSON et de l'interface.

## Validation

```bash
./scripts/test-jalon7-step2.sh
./scripts/test-jalon7-step3.sh
python3 scripts/audit-jalon7-step3.py
./scripts/syntax-check-jalon7-step3-app.sh
```

Les validations couvrent :

- 321 adversaires et 15 catégories ;
- création d'un boxeur de 18 ans ;
- départ non classé et sans ceinture ;
- progression régionale, nationale, continentale et mondiale ;
- conquête WBA, WBC, IBF et WBO ;
- statut de champion incontesté ;
- entraînement, fatigue, santé, âge et bourses ;
- absence de rareté dans le moteur et les données.

## Limites actuelles

- le moteur de combat historique fonctionne encore sur son infrastructure validée de trois rounds ;
- les formats professionnels 4, 6, 8, 10 et 12 rounds sont enregistrés dans la carrière, mais ne pilotent pas encore la durée réelle du moteur interactif ;
- la sauvegarde persistante de la carrière n'est pas encore branchée ;
- aucun nouvel APK n'est revendiqué sans compilation Android complète et vérifiée.

Le prochain jalon technique doit étendre le moteur aux formats professionnels variables puis ajouter la sauvegarde versionnée de carrière.
