package titlefight

/**
 * Alias historiques conservés pour les audits des jalons 1 à 4.
 */
object TestProfiles {
    val eliasVega: BoxerProfile = BoxerCatalog.eliasVega
    val brunoKessler: BoxerProfile = BoxerCatalog.brunoKessler
}
