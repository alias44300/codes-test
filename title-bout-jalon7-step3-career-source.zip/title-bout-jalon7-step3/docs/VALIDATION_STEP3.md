# Jalon 1 — Étape 3 : lot de 100 combats

## Périmètre

- 100 combats exactement ;
- 3 rounds par combat ;
- 12 séquences par round ;
- coins rouge et bleu alternés à parts égales ;
- mêmes tactiques qu’à l’étape 2 ;
- aucune décision officielle ;
- aucun juge, knockdown avancé, KO, TKO, interface ou APK.

## Mesures

- stabilité d’exécution ;
- reproductibilité du lot ;
- volume et précision ;
- distances d’attaque ;
- énergie finale ;
- dégâts tête et corps reçus ;
- stabilité finale ;
- avantage de performance interne, sans valeur de décision officielle.

## Critères

- 100 combats terminés sans exception ;
- 300 rounds et 3 600 séquences ;
- 50 apparitions au coin rouge par boxeur ;
- même plage de graines = mêmes résultats ;
- Elias Vega réalise plus de 75 % de ses initiatives à longue distance ;
- Bruno Kessler réalise plus de 25 % de ses initiatives à courte distance ;
- le travail au corps et le coût énergétique de la pression de Kessler restent visibles ;
- aucun profil ne dépasse 75 avantages de performance sur 100.
