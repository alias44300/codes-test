package androidx.compose.foundation.lazy
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
class LazyListScope {
    fun item(content: @Composable () -> Unit) { content() }
    fun <T> items(items: List<T>, key: ((T) -> Any)? = null, itemContent: @Composable (T) -> Unit) { items.forEach(itemContent) }
}
@Composable fun LazyColumn(modifier: Modifier = Modifier, verticalArrangement: Any? = null, content: @Composable LazyListScope.() -> Unit) { LazyListScope().content() }
fun <T> LazyListScope.items(items: List<T>, key: ((T) -> Any)? = null, itemContent: @Composable (T) -> Unit) { items.forEach(itemContent) }
