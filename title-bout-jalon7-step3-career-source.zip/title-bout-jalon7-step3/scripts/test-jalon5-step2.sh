#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build-jalon5-step2"
rm -rf "$BUILD"
mkdir -p "$BUILD"
kotlinc -J-Xmx2g -J-Dfile.encoding=UTF-8 \
  "$ROOT"/engine/src/main/kotlin/titlefight/*.kt \
  "$ROOT"/engine/src/test/kotlin/titlefight/*.kt \
  -d "$BUILD/title-fight-jalon5-step2.jar"
kotlin -J-Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-jalon5-step2.jar" titlefight.FightEngineTest
kotlin -J-Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-jalon5-step2.jar" titlefight.Jalon5Step2AuditDemo
