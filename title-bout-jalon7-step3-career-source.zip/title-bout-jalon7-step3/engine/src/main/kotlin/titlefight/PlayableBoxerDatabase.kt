package titlefight

/**
 * Base locale versionnée du premier lot historique jouable.
 *
 * Les notes sont des valeurs de gameplay TITLE FIGHT et non un classement
 * historique universel. Le catalogue fictif validé du prototype reste séparé
 * afin de conserver toutes ses empreintes de régression.
 */
object PlayableBoxerDatabase {
    const val SCHEMA_VERSION: Int = 1
    const val CONTENT_VERSION: String = "heavyweight-pilot-2026-07-21"

    val historicalHeavyweights: List<BoxerDatabaseEntry> = listOf(
        entry(
            1, "muhammad-ali", "muhammad-ali-1966", "Muhammad Ali", "The Greatest", "US", "États-Unis",
            BoxerEra.MODERN_CLASSIC, 1964, 1967, Stance.ORTHODOX, BoxingStyle.OUT_BOXER, BoxingStyle.BOXER_PUNCHER,
            FightRange.OUTSIDE, 191, 198,
            core(88, 99, 98, 94, 96, 99, 94, 96, 98, 99, 91, 79, jab = 8, foot = 6, composure = 3),
            tendencies(96, 42, 83, 88, 25, 44, 67, 82, 91),
            listOf("Jab fouetté en recul", "Rafale éclair", "Pas de retrait et direct"),
            listOf("Réflexes d’élite", "Gestion du rythme", "Résilience tardive"),
        ),
        entry(
            2, "joe-louis", "joe-louis-1941", "Joe Louis", "The Brown Bomber", "US", "États-Unis",
            BoxerEra.GOLDEN_AGE, 1937, 1942, Stance.ORTHODOX, BoxingStyle.BOXER_PUNCHER, BoxingStyle.COUNTERPUNCHER,
            FightRange.MID, 188, 193,
            core(98, 91, 98, 91, 92, 98, 94, 93, 98, 89, 92, 84, rear = 4, hook = 3, timing = 5),
            tendencies(82, 63, 91, 89, 31, 70, 82, 72, 80),
            listOf("Direct compact", "Crochet court après parade", "Combinaison mécanique"),
            listOf("Précision chirurgicale", "Finisseur méthodique", "Garde compacte"),
        ),
        entry(
            3, "mike-tyson", "mike-tyson-1988", "Mike Tyson", "Iron Mike", "US", "États-Unis",
            BoxerEra.CONTEMPORARY, 1986, 1989, Stance.ORTHODOX, BoxingStyle.SWARMER, BoxingStyle.SLUGGER,
            FightRange.INSIDE, 178, 180,
            core(99, 98, 91, 88, 90, 90, 95, 91, 92, 96, 94, 99, hook = 5, inside = 5, finish = 5),
            tendencies(48, 79, 94, 74, 30, 100, 98, 100, 66),
            listOf("Crochet gauche au foie", "Uppercut puis crochet", "Entrée en peek-a-boo"),
            listOf("Démarrage explosif", "Angles courts", "Instinct de finition"),
        ),
        entry(
            4, "george-foreman", "george-foreman-1973", "George Foreman", "Big George", "US", "États-Unis",
            BoxerEra.MODERN_CLASSIC, 1972, 1974, Stance.ORTHODOX, BoxingStyle.SLUGGER, BoxingStyle.PRESSURE_FIGHTER,
            FightRange.MID, 193, 199,
            core(100, 78, 87, 82, 90, 90, 97, 91, 86, 75, 97, 96, rear = 5, body = 4, pressure = 5),
            tendencies(47, 82, 70, 42, 52, 98, 99, 94, 72),
            listOf("Poussée de garde et uppercut", "Crochet lourd", "Direct de puissance"),
            listOf("Force physique", "Pression écrasante", "Menton exceptionnel"),
        ),
        entry(
            5, "rocky-marciano", "rocky-marciano-1952", "Rocky Marciano", "The Brockton Blockbuster", "US", "États-Unis",
            BoxerEra.POST_WAR, 1951, 1955, Stance.ORTHODOX, BoxingStyle.PRESSURE_FIGHTER, BoxingStyle.SWARMER,
            FightRange.INSIDE, 179, 173,
            core(97, 82, 84, 78, 100, 97, 98, 98, 82, 80, 99, 100, hook = 4, body = 4, enduranceBonus = 3),
            tendencies(36, 91, 78, 38, 43, 100, 97, 84, 100),
            listOf("Suzie Q", "Crochet au corps en avançant", "Rafale tardive"),
            listOf("Endurance historique", "Pression constante", "Puissance tardive"),
        ),
        entry(
            6, "lennox-lewis", "lennox-lewis-1999", "Lennox Lewis", "The Lion", "GB", "Royaume-Uni",
            BoxerEra.CONTEMPORARY, 1998, 2002, Stance.ORTHODOX, BoxingStyle.BOXER_PUNCHER, BoxingStyle.OUT_BOXER,
            FightRange.OUTSIDE, 196, 213,
            core(98, 88, 96, 92, 91, 97, 91, 93, 96, 89, 92, 82, jab = 4, rear = 4, range = 5),
            tendencies(91, 58, 82, 78, 66, 63, 75, 70, 83),
            listOf("Jab lourd", "Direct à longue portée", "Uppercut de clinch"),
            listOf("Allonge dominante", "Adaptation tactique", "Contrôle du centre"),
        ),
        entry(
            7, "evander-holyfield", "evander-holyfield-1991", "Evander Holyfield", "The Real Deal", "US", "États-Unis",
            BoxerEra.CONTEMPORARY, 1990, 1993, Stance.ORTHODOX, BoxingStyle.BOXER_PUNCHER, BoxingStyle.PRESSURE_FIGHTER,
            FightRange.MID, 189, 197,
            core(92, 92, 94, 89, 99, 97, 98, 98, 93, 91, 99, 94, combo = 4, enduranceBonus = 3, composure = 3),
            tendencies(75, 84, 98, 76, 44, 87, 92, 82, 98),
            listOf("Rafale tête-corps", "Crochet gauche en sortie", "Échange prolongé"),
            listOf("Cœur de champion", "Volume élevé", "Récupération d’élite"),
        ),
        entry(
            8, "oleksandr-usyk", "oleksandr-usyk-2024", "Oleksandr Usyk", "The Cat", "UA", "Ukraine",
            BoxerEra.CONTEMPORARY, 2021, 2024, Stance.SOUTHPAW, BoxingStyle.OUT_BOXER, BoxingStyle.COUNTERPUNCHER,
            FightRange.OUTSIDE, 191, 198,
            core(86, 97, 99, 96, 99, 100, 92, 98, 98, 99, 94, 77, foot = 6, timing = 5, adaptability = 4),
            tendencies(93, 68, 96, 93, 27, 62, 67, 72, 100),
            listOf("Double jab de gaucher", "Pivot et direct gauche", "Accélération tardive"),
            listOf("Angles incessants", "Cardio d’élite", "Lecture adaptative"),
        ),
        entry(
            9, "joe-frazier", "joe-frazier-1971", "Joe Frazier", "Smokin' Joe", "US", "États-Unis",
            BoxerEra.MODERN_CLASSIC, 1968, 1971, Stance.ORTHODOX, BoxingStyle.SWARMER, BoxingStyle.PRESSURE_FIGHTER,
            FightRange.INSIDE, 182, 185,
            core(96, 91, 88, 83, 99, 96, 98, 97, 87, 90, 99, 100, hook = 6, body = 5, pressure = 5),
            tendencies(42, 96, 86, 54, 34, 100, 96, 91, 99),
            listOf("Crochet gauche plongeant", "Travail au corps", "Balancement et entrée"),
            listOf("Pression enfumée", "Menton d’élite", "Rythme infernal"),
        ),
        entry(
            10, "larry-holmes", "larry-holmes-1980", "Larry Holmes", "The Easton Assassin", "US", "États-Unis",
            BoxerEra.CONTEMPORARY, 1978, 1982, Stance.ORTHODOX, BoxingStyle.OUT_BOXER, BoxingStyle.BOXER_PUNCHER,
            FightRange.OUTSIDE, 191, 206,
            core(89, 93, 96, 93, 98, 98, 96, 97, 97, 95, 96, 74, jab = 7, range = 5, recoveryBonus = 3),
            tendencies(100, 48, 82, 82, 53, 50, 69, 74, 95),
            listOf("Jab piston", "Direct en recul", "Récupération après crise"),
            listOf("Jab historique", "Gestion de distance", "Résilience"),
        ),
        entry(
            11, "jack-johnson", "jack-johnson-1910", "Jack Johnson", "Galveston Giant", "US", "États-Unis",
            BoxerEra.PIONEER, 1908, 1912, Stance.ORTHODOX, BoxingStyle.DEFENSIVE_SPECIALIST, BoxingStyle.COUNTERPUNCHER,
            FightRange.MID, 184, 188,
            core(88, 87, 96, 99, 94, 99, 97, 96, 95, 92, 97, 68, defenseBonus = 5, counter = 5, composure = 5),
            tendencies(62, 53, 68, 100, 88, 43, 61, 44, 82),
            listOf("Parade et contre", "Contrôle des bras", "Uppercut intérieur"),
            listOf("Défense pionnière", "Calme absolu", "Maîtrise du clinch"),
        ),
        entry(
            12, "jack-dempsey", "jack-dempsey-1921", "Jack Dempsey", "The Manassa Mauler", "US", "États-Unis",
            BoxerEra.PIONEER, 1919, 1923, Stance.ORTHODOX, BoxingStyle.PRESSURE_FIGHTER, BoxingStyle.SWARMER,
            FightRange.INSIDE, 185, 196,
            core(97, 92, 88, 80, 94, 93, 95, 94, 88, 91, 96, 99, hook = 4, pressure = 5, fast = 4),
            tendencies(39, 85, 88, 61, 32, 100, 98, 100, 83),
            listOf("Dempsey roll", "Crochet en bondissant", "Rafale de démolition"),
            listOf("Agressivité instantanée", "Puissance des deux mains", "Entrées explosives"),
        ),
        entry(
            13, "sonny-liston", "sonny-liston-1962", "Sonny Liston", "The Big Bear", "US", "États-Unis",
            BoxerEra.MODERN_CLASSIC, 1959, 1963, Stance.ORTHODOX, BoxingStyle.SLUGGER, BoxingStyle.BOXER_PUNCHER,
            FightRange.OUTSIDE, 185, 213,
            core(99, 82, 89, 86, 91, 89, 97, 92, 89, 79, 98, 93, jab = 5, rear = 4, range = 4),
            tendencies(91, 72, 73, 58, 70, 86, 94, 92, 74),
            listOf("Jab de masse", "Direct destructeur", "Uppercut court"),
            listOf("Allonge hors norme", "Force intimidante", "Garde robuste"),
        ),
        entry(
            14, "floyd-patterson", "floyd-patterson-1957", "Floyd Patterson", "The Gentleman of Boxing", "US", "États-Unis",
            BoxerEra.POST_WAR, 1956, 1960, Stance.ORTHODOX, BoxingStyle.BOXER_PUNCHER, BoxingStyle.SWARMER,
            FightRange.MID, 183, 180,
            core(90, 97, 91, 84, 91, 94, 82, 91, 92, 96, 86, 86, combo = 5, foot = 4, inside = 3),
            tendencies(57, 67, 100, 71, 22, 82, 84, 93, 82),
            listOf("Gazelle punch", "Combinaison bondissante", "Double crochet"),
            listOf("Vitesse explosive", "Combinaisons fluides", "Courage au relèvement"),
        ),
        entry(
            15, "wladimir-klitschko", "wladimir-klitschko-2011", "Wladimir Klitschko", "Dr. Steelhammer", "UA", "Ukraine",
            BoxerEra.CONTEMPORARY, 2006, 2012, Stance.ORTHODOX, BoxingStyle.OUT_BOXER, BoxingStyle.BOXER_PUNCHER,
            FightRange.OUTSIDE, 198, 206,
            core(98, 87, 94, 93, 94, 97, 84, 91, 95, 85, 92, 68, jab = 6, rear = 5, discipline = 5),
            tendencies(99, 39, 65, 64, 93, 52, 63, 55, 88),
            listOf("Jab-main droite", "Accrochage défensif", "Direct long"),
            listOf("Discipline tactique", "Puissance droite", "Contrôle par l’allonge"),
        ),
        entry(
            16, "vitali-klitschko", "vitali-klitschko-2004", "Vitali Klitschko", "Dr. Ironfist", "UA", "Ukraine",
            BoxerEra.CONTEMPORARY, 2003, 2009, Stance.ORTHODOX, BoxingStyle.BOXER_PUNCHER, BoxingStyle.PRESSURE_FIGHTER,
            FightRange.MID, 201, 203,
            core(94, 84, 91, 89, 96, 96, 100, 97, 92, 83, 99, 86, chinBonus = 4, awkward = 4, pressure = 3),
            tendencies(72, 65, 72, 72, 48, 84, 80, 70, 92),
            listOf("Direct bras bas", "Uppercut décalé", "Pression à grand gabarit"),
            listOf("Menton exceptionnel", "Angles atypiques", "Volume constant"),
        ),
        entry(
            17, "riddick-bowe", "riddick-bowe-1992", "Riddick Bowe", "Big Daddy", "US", "États-Unis",
            BoxerEra.CONTEMPORARY, 1991, 1993, Stance.ORTHODOX, BoxingStyle.BOXER_PUNCHER, BoxingStyle.PRESSURE_FIGHTER,
            FightRange.MID, 196, 206,
            core(96, 88, 92, 84, 93, 90, 94, 92, 91, 85, 94, 91, inside = 5, body = 3, combo = 3),
            tendencies(71, 85, 91, 59, 56, 88, 90, 82, 87),
            listOf("Uppercut intérieur", "Combinaison de grand gabarit", "Crochet au corps"),
            listOf("Travail intérieur rare", "Puissance polyvalente", "Gros volume"),
        ),
        entry(
            18, "tyson-fury", "tyson-fury-2020", "Tyson Fury", "The Gypsy King", "GB", "Royaume-Uni",
            BoxerEra.CONTEMPORARY, 2015, 2022, Stance.SWITCH, BoxingStyle.OUT_BOXER, BoxingStyle.DEFENSIVE_SPECIALIST,
            FightRange.OUTSIDE, 206, 216,
            core(90, 91, 96, 95, 96, 98, 96, 99, 94, 96, 97, 72, foot = 5, defenseBonus = 4, adaptability = 5),
            tendencies(91, 49, 82, 87, 90, 66, 72, 59, 96),
            listOf("Changement de garde", "Jab mobile", "Clinch de contrôle"),
            listOf("Mobilité de géant", "Adaptation de garde", "Récupération spectaculaire"),
        ),
        entry(
            19, "deontay-wilder", "deontay-wilder-2019", "Deontay Wilder", "The Bronze Bomber", "US", "États-Unis",
            BoxerEra.CONTEMPORARY, 2015, 2020, Stance.ORTHODOX, BoxingStyle.SLUGGER, null,
            FightRange.OUTSIDE, 201, 211,
            core(100, 91, 80, 73, 88, 85, 89, 90, 79, 89, 89, 90, rear = 8, finish = 8, risk = 5),
            tendencies(64, 27, 43, 48, 24, 74, 100, 75, 91),
            listOf("Main droite en ligne", "Poursuite après ébranlement", "Crochet large"),
            listOf("Puissance exceptionnelle", "Portée dangereuse", "Instinct de chasse"),
        ),
        entry(
            20, "ezzard-charles", "ezzard-charles-1950", "Ezzard Charles", "The Cincinnati Cobra", "US", "États-Unis",
            BoxerEra.POST_WAR, 1948, 1951, Stance.ORTHODOX, BoxingStyle.COUNTERPUNCHER, BoxingStyle.BOXER_PUNCHER,
            FightRange.MID, 183, 185,
            core(88, 93, 98, 96, 94, 99, 91, 94, 97, 94, 92, 67, timing = 5, counter = 6, techniqueBonus = 3),
            tendencies(78, 67, 89, 100, 44, 52, 66, 63, 88),
            listOf("Contre du Cobra", "Direct après esquive", "Combinaison précise"),
            listOf("Timing supérieur", "Polyvalence technique", "Lecture défensive"),
        ),
    )

    val allEntries: List<BoxerDatabaseEntry> = historicalHeavyweights
    val allProfiles: List<BoxerProfile> = allEntries.map { it.profile }

    private val byVersionId = allEntries.associateBy { it.versionId }
    private val byBoxerId = allEntries.groupBy { it.boxerId }

    init {
        require(allEntries.size == 20) { "Le premier lot doit contenir exactement vingt boxeurs historiques." }
        require(byVersionId.size == allEntries.size) { "Chaque version historique doit être unique." }
        require(allEntries.map { it.databaseId }.distinct().size == allEntries.size)
        require(allEntries.map { it.style }.toSet() == BoxingStyle.entries.toSet()) {
            "Les sept styles doivent être couverts par le lot pilote."
        }
        require(allEntries.map { it.stance }.toSet().containsAll(listOf(Stance.ORTHODOX, Stance.SOUTHPAW, Stance.SWITCH)))
        require(allEntries.all { it.weightClass == WeightClass.HEAVYWEIGHT })
        require(allEntries.all { it.profile.id == it.versionId })
    }

    fun findVersion(versionId: String): BoxerDatabaseEntry? = byVersionId[versionId]
    fun versionsOf(boxerId: String): List<BoxerDatabaseEntry> = byBoxerId[boxerId].orEmpty()

    fun search(
        query: String = "",
        weightClass: WeightClass? = null,
        style: BoxingStyle? = null,
        stance: Stance? = null,
    ): List<BoxerDatabaseEntry> {
        val normalized = query.trim().lowercase()
        return allEntries.filter { entry ->
            (normalized.isBlank() || listOf(entry.name, entry.nickname, entry.countryName, entry.versionId)
                .any { normalized in it.lowercase() }) &&
                (weightClass == null || entry.weightClass == weightClass) &&
                (style == null || entry.style == style || entry.secondaryStyle == style) &&
                (stance == null || entry.stance == stance)
        }.sortedWith(compareBy<BoxerDatabaseEntry> { it.weightClass.ordinal }.thenBy { it.name })
    }

    private fun entry(
        databaseId: Int,
        boxerId: String,
        versionId: String,
        name: String,
        nickname: String,
        countryCode: String,
        countryName: String,
        era: BoxerEra,
        primeStartYear: Int,
        primeEndYear: Int,
        stance: Stance,
        style: BoxingStyle,
        secondaryStyle: BoxingStyle?,
        range: FightRange,
        heightCm: Int,
        reachCm: Int,
        ratings: BoxerRatings,
        tendencies: BoxerTendencies,
        signatureActions: List<String>,
        traits: List<String>,
    ) = BoxerDatabaseEntry(
        databaseId = databaseId,
        boxerId = boxerId,
        versionId = versionId,
        name = name,
        nickname = nickname,
        countryCode = countryCode,
        countryName = countryName,
        era = era,
        primeStartYear = primeStartYear,
        primeEndYear = primeEndYear,
        weightClass = WeightClass.HEAVYWEIGHT,
        stance = stance,
        style = style,
        secondaryStyle = secondaryStyle,
        preferredRange = range,
        heightCm = heightCm,
        reachCm = reachCm,
        ratings = ratings,
        tendencies = tendencies,
        signatureActions = signatureActions,
        traits = traits,
    )

    private fun tendencies(
        jab: Int,
        body: Int,
        combination: Int,
        counter: Int,
        clinch: Int,
        pressure: Int,
        risk: Int,
        fast: Int,
        late: Int,
    ) = BoxerTendencies(jab, body, combination, counter, clinch, pressure, risk, fast, late)

    @Suppress("LongParameterList")
    private fun core(
        power: Int,
        speed: Int,
        technique: Int,
        defense: Int,
        endurance: Int,
        mental: Int,
        chin: Int,
        recovery: Int,
        accuracy: Int,
        mobility: Int,
        bodyResistance: Int,
        aggression: Int,
        jab: Int = 0,
        rear: Int = 0,
        hook: Int = 0,
        body: Int = 0,
        foot: Int = 0,
        timing: Int = 0,
        defenseBonus: Int = 0,
        counter: Int = 0,
        pressure: Int = 0,
        range: Int = 0,
        inside: Int = 0,
        combo: Int = 0,
        finish: Int = 0,
        composure: Int = 0,
        adaptability: Int = 0,
        discipline: Int = 0,
        recoveryBonus: Int = 0,
        enduranceBonus: Int = 0,
        techniqueBonus: Int = 0,
        chinBonus: Int = 0,
        fast: Int = 0,
        risk: Int = 0,
        awkward: Int = 0,
    ): BoxerRatings {
        fun c(value: Int) = value.coerceIn(1, 100)
        return BoxerRatings(
            jabPower = c(power - 7 + jab),
            rearHandPower = c(power + rear),
            hookPower = c(power - 1 + hook),
            bodyPower = c((power + technique) / 2 - 4 + body),
            handSpeed = c(speed + fast),
            footSpeed = c(mobility + foot),
            accuracy = c(accuracy + techniqueBonus),
            timing = c((technique + mental + accuracy) / 3 + timing + combo / 2),
            headDefense = c(defense + defenseBonus),
            bodyDefense = c((defense + bodyResistance) / 2 + defenseBonus / 2),
            blocking = c((defense + chin) / 2 + awkward),
            evasiveness = c((defense + mobility + speed) / 3 + defenseBonus),
            countering = c((technique + accuracy + defense) / 3 + counter),
            pressure = c((aggression + endurance + chin) / 3 + pressure),
            rangeControl = c((technique + mobility + mental) / 3 + range),
            insideFighting = c((power + technique + aggression) / 3 + inside + combo / 2),
            endurance = c(endurance + enduranceBonus),
            recovery = c(recovery + recoveryBonus),
            chin = c(chin + chinBonus),
            bodyResistance = c(bodyResistance),
            balance = c((mobility + technique + chin) / 3 + awkward),
            cutResistance = c((chin + bodyResistance + recovery) / 3),
            ringIq = c((technique + mental) / 2 + techniqueBonus),
            adaptability = c((mental + technique + defense) / 3 + adaptability),
            discipline = c((mental + technique + endurance) / 3 + discipline),
            aggression = c(aggression + risk),
            finishing = c((power + aggression + accuracy) / 3 + finish),
            composure = c((mental + recovery + defense) / 3 + composure),
        )
    }
}
