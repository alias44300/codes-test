# Jalon 4 — Étape 2 — Modèle de plan tactique

## Objectif

Définir un modèle tactique explicite et borné, sans encore modifier la simulation.

## Modèle ajouté

`TacticalPlan` contient quatre choix :

- rythme : prudent, mesuré ou soutenu ;
- distance : longue, moyenne ou courte ;
- cible : tête, corps ou mixte ;
- prise de risque : sûre, équilibrée ou agressive.

`TacticalPlanModifiers` décrit les futurs effets possibles sur l’activité, la précision, la défense, l’impact, le coût énergétique, le contrôle de la distance et la répartition tête/corps.

Ces modificateurs ne sont pas branchés sur `FightEngine` à cette étape.

## Plans naturels par style

- Out-boxer : mesuré, longue distance, mixte, sûr
- Pressure fighter : soutenu, courte distance, corps, équilibré
- Counterpuncher : prudent, moyenne distance, tête, sûr
- Boxer-puncher : mesuré, moyenne distance, mixte, équilibré
- Swarmer : soutenu, courte distance, mixte, agressif
- Slugger : mesuré, moyenne distance, tête, agressif
- Spécialiste défensif : prudent, longue distance, mixte, sûr

## Bornes verrouillées

- activité : -15 % à +15 % ;
- précision : -10 % à +10 % ;
- défense : -10 % à +10 % ;
- impact : -12 % à +12 % ;
- coût énergétique : -12 % à +18 % ;
- contrôle de la distance préférée : +4 % à +12 % ;
- parts tête/corps : 20 % à 80 %, total obligatoire de 100 %.

## Validation

- 68 tests automatisés réussis ;
- 7 styles couverts par 7 plans naturels identifiables ;
- 81 combinaisons tactiques vérifiées ;
- 0 violation de bornes ;
- 0 violation de répartition des cibles ;
- 0 violation de monotonie entre prudent, mesuré, soutenu et entre sûr, équilibré, agressif ;
- 0 écart de reproductibilité ;
- 0 empreinte historique du moteur modifiée.

## Limite conservée

Aucun plan n’est sélectionné automatiquement et aucun modificateur n’est appliqué aux combats. Cette activation appartient aux étapes 3 et 4.
