package titlefight

import java.util.Locale

data class OfficialDecisionStep4AuditResult(
    val fightCount: Int,
    val distanceFights: Int,
    val stoppageFights: Int,
    val koFights: Int,
    val tkoFights: Int,
    val officialDecisionCount: Int,
    val unanimousDecisions: Int,
    val splitDecisions: Int,
    val majorityDecisions: Int,
    val unanimousDraws: Int,
    val majorityDraws: Int,
    val splitDraws: Int,
    val redDecisionWins: Int,
    val blueDecisionWins: Int,
    val draws: Int,
    val scorecardCount: Int,
    val decisionMismatchCount: Int,
    val invalidScorecardCount: Int,
    val majorityMismatchCount: Int,
    val missingDecisionCount: Int,
    val decisionAfterStoppageCount: Int,
    val blankExplanationCount: Int,
) {
    init {
        require(fightCount == 1000)
        require(distanceFights + stoppageFights == fightCount)
        require(koFights + tkoFights == stoppageFights)
        require(officialDecisionCount == distanceFights)
        require(scorecardCount == officialDecisionCount * 3)
        require(
            unanimousDecisions + splitDecisions + majorityDecisions +
                unanimousDraws + majorityDraws + splitDraws == officialDecisionCount,
        )
        require(redDecisionWins + blueDecisionWins + draws == officialDecisionCount)
    }
}

object OfficialDecisionStep4Auditor {
    private val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
    private val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

    fun run(seedStart: Long = 202607250000L): OfficialDecisionStep4AuditResult {
        val engine = FightEngine()
        var distanceFights = 0
        var stoppageFights = 0
        var koFights = 0
        var tkoFights = 0
        var officialDecisionCount = 0
        var unanimousDecisions = 0
        var splitDecisions = 0
        var majorityDecisions = 0
        var unanimousDraws = 0
        var majorityDraws = 0
        var splitDraws = 0
        var redDecisionWins = 0
        var blueDecisionWins = 0
        var draws = 0
        var scorecardCount = 0
        var decisionMismatchCount = 0
        var invalidScorecardCount = 0
        var majorityMismatchCount = 0
        var missingDecisionCount = 0
        var decisionAfterStoppageCount = 0
        var blankExplanationCount = 0

        repeat(1000) { index ->
            val vegaInRed = index % 2 == 0
            val fight = if (vegaInRed) {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.eliasVega,
                    blue = TestProfiles.brunoKessler,
                    redTactics = vegaTactics,
                    blueTactics = kesslerTactics,
                    seed = seedStart + index,
                )
            } else {
                engine.simulateThreeRoundFight(
                    red = TestProfiles.brunoKessler,
                    blue = TestProfiles.eliasVega,
                    redTactics = kesslerTactics,
                    blueTactics = vegaTactics,
                    seed = seedStart + index,
                )
            }

            if (fight.stoppage != null) {
                stoppageFights++
                when (fight.stoppage.method) {
                    FightMethod.KO -> koFights++
                    FightMethod.TKO -> tkoFights++
                }
                if (fight.officialDecision != null) decisionAfterStoppageCount++
                return@repeat
            }

            distanceFights++
            val decision = fight.officialDecision
            if (decision == null) {
                missingDecisionCount++
                return@repeat
            }
            officialDecisionCount++
            scorecardCount += decision.scorecards.size
            if (decision != OfficialDecisionResolver.resolve(fight.redId, fight.blueId, fight.rounds)) {
                decisionMismatchCount++
            }
            if (decision.explanation.isBlank() || decision.scorecards.any { it.explanation.isBlank() }) {
                blankExplanationCount++
            }

            when (decision.type) {
                OfficialDecisionType.UNANIMOUS_DECISION -> unanimousDecisions++
                OfficialDecisionType.SPLIT_DECISION -> splitDecisions++
                OfficialDecisionType.MAJORITY_DECISION -> majorityDecisions++
                OfficialDecisionType.UNANIMOUS_DRAW -> unanimousDraws++
                OfficialDecisionType.MAJORITY_DRAW -> majorityDraws++
                OfficialDecisionType.SPLIT_DRAW -> splitDraws++
            }
            when (decision.winnerId) {
                fight.redId -> redDecisionWins++
                fight.blueId -> blueDecisionWins++
                null -> draws++
                else -> majorityMismatchCount++
            }

            decision.scorecards.forEach { card ->
                val validRounds = card.rounds.size == 3 && card.rounds.map { it.roundNumber } == listOf(1, 2, 3)
                val validTotals = card.redTotal == card.rounds.sumOf { it.redPoints } &&
                    card.blueTotal == card.rounds.sumOf { it.bluePoints }
                val validVerdict = when (card.verdict) {
                    ScorecardVerdict.RED -> card.redTotal > card.blueTotal && card.winnerId == fight.redId
                    ScorecardVerdict.BLUE -> card.blueTotal > card.redTotal && card.winnerId == fight.blueId
                    ScorecardVerdict.DRAW -> card.redTotal == card.blueTotal && card.winnerId == null
                }
                if (!validRounds || !validTotals || !validVerdict) invalidScorecardCount++
            }

            val expectedWinner = when {
                decision.redCards >= 2 -> fight.redId
                decision.blueCards >= 2 -> fight.blueId
                else -> null
            }
            val expectedType = OfficialDecisionResolver.classify(
                decision.redCards,
                decision.blueCards,
                decision.drawCards,
            )
            if (decision.winnerId != expectedWinner || decision.type != expectedType) majorityMismatchCount++
        }

        return OfficialDecisionStep4AuditResult(
            fightCount = 1000,
            distanceFights = distanceFights,
            stoppageFights = stoppageFights,
            koFights = koFights,
            tkoFights = tkoFights,
            officialDecisionCount = officialDecisionCount,
            unanimousDecisions = unanimousDecisions,
            splitDecisions = splitDecisions,
            majorityDecisions = majorityDecisions,
            unanimousDraws = unanimousDraws,
            majorityDraws = majorityDraws,
            splitDraws = splitDraws,
            redDecisionWins = redDecisionWins,
            blueDecisionWins = blueDecisionWins,
            draws = draws,
            scorecardCount = scorecardCount,
            decisionMismatchCount = decisionMismatchCount,
            invalidScorecardCount = invalidScorecardCount,
            majorityMismatchCount = majorityMismatchCount,
            missingDecisionCount = missingDecisionCount,
            decisionAfterStoppageCount = decisionAfterStoppageCount,
            blankExplanationCount = blankExplanationCount,
        )
    }
}

object OfficialDecisionStep4AuditFormatter {
    fun format(result: OfficialDecisionStep4AuditResult): String = buildString {
        appendLine("TITLE FIGHT — JALON 3 — ÉTAPE 4")
        appendLine("AUDIT DES CARTES ET DÉCISIONS OFFICIELLES")
        appendLine()
        appendLine("Combats : ${result.fightCount}")
        appendLine("Combats à la distance : ${result.distanceFights}")
        appendLine("Arrêts : ${result.stoppageFights} (KO ${result.koFights}, TKO ${result.tkoFights})")
        appendLine("Décisions officielles : ${result.officialDecisionCount}")
        appendLine("Cartes totalisées : ${result.scorecardCount}")
        appendLine()
        appendLine("Décisions unanimes : ${result.unanimousDecisions}")
        appendLine("Décisions partagées : ${result.splitDecisions}")
        appendLine("Décisions majoritaires : ${result.majorityDecisions}")
        appendLine("Nuls unanimes : ${result.unanimousDraws}")
        appendLine("Nuls majoritaires : ${result.majorityDraws}")
        appendLine("Nuls partagés : ${result.splitDraws}")
        appendLine()
        appendLine("Victoires coin rouge : ${result.redDecisionWins}")
        appendLine("Victoires coin bleu : ${result.blueDecisionWins}")
        appendLine("Matchs nuls : ${result.draws}")
        appendLine()
        appendLine("Décisions différentes d'une nouvelle résolution : ${result.decisionMismatchCount}")
        appendLine("Cartes invalides : ${result.invalidScorecardCount}")
        appendLine("Décisions contraires à la majorité : ${result.majorityMismatchCount}")
        appendLine("Décisions manquantes à la distance : ${result.missingDecisionCount}")
        appendLine("Décisions présentes après KO/TKO : ${result.decisionAfterStoppageCount}")
        appendLine("Justifications vides : ${result.blankExplanationCount}")
        appendLine()
        appendLine("Les distributions ne sont pas encore utilisées pour valider un biais de coin ou de juge. Cet audit appartient à l'étape 5.")
    }
}

object OfficialDecisionStep4AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        Locale.setDefault(Locale.FRANCE)
        print(OfficialDecisionStep4AuditFormatter.format(OfficialDecisionStep4Auditor.run()))
    }
}
