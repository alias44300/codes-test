package androidx.compose.ui.unit
data class Dp(val value: Float)
data class TextUnit(val value: Float)
val Int.dp: Dp get() = Dp(toFloat())
val Float.dp: Dp get() = Dp(this)
val Double.dp: Dp get() = Dp(toFloat())
val Int.sp: TextUnit get() = TextUnit(toFloat())
val Float.sp: TextUnit get() = TextUnit(this)
val Double.sp: TextUnit get() = TextUnit(toFloat())
