package titlefight.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import titlefight.BoxingStyle
import titlefight.CareerCreationRequest
import titlefight.CareerEngine
import titlefight.CareerOpponent
import titlefight.CareerState
import titlefight.CareerStatus
import titlefight.ChampionshipBelt
import titlefight.Stance
import titlefight.TrainingFocus
import titlefight.WeightClass

@Composable
fun CareerCreationScreen(
    onCreate: (CareerCreationRequest) -> Unit,
    onBack: () -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var nickname by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("France") }
    var division by remember { mutableStateOf(WeightClass.WELTERWEIGHT) }
    var stance by remember { mutableStateOf(Stance.ORTHODOX) }
    var style by remember { mutableStateOf(BoxingStyle.BOXER_PUNCHER) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("NOUVELLE CARRIÈRE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                Text(
                    "Crée un boxeur de 18 ans. Il commence sans classement, sans titre et avec des statistiques de débutant.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Nom du boxeur") },
                    singleLine = true,
                )
                OutlinedTextField(
                    value = nickname,
                    onValueChange = { nickname = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Surnom facultatif") },
                    singleLine = true,
                )
                OutlinedTextField(
                    value = country,
                    onValueChange = { country = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Pays") },
                    singleLine = true,
                )
            }
        }
        item {
            SelectionSection(title = "CATÉGORIE DE DÉPART") {
                WeightClass.entries.chunked(2).forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { choice ->
                            ChoiceButton(
                                label = choice.frenchLabel,
                                selected = division == choice,
                                onClick = { division = choice },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        if (row.size == 1) Surface(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.background) {}
                    }
                }
            }
        }
        item {
            SelectionSection(title = "GARDE") {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Stance.entries.forEach { choice ->
                        ChoiceButton(
                            label = stanceLabel(choice),
                            selected = stance == choice,
                            onClick = { stance = choice },
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }
        item {
            SelectionSection(title = "STYLE DE BOXE") {
                BoxingStyle.entries.chunked(2).forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { choice ->
                            ChoiceButton(
                                label = styleLabel(choice),
                                selected = style == choice,
                                onClick = { style = choice },
                                modifier = Modifier.weight(1f),
                            )
                        }
                        if (row.size == 1) Surface(modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.background) {}
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = {
                        onCreate(
                            CareerCreationRequest(
                                name = name,
                                nickname = nickname,
                                country = country,
                                division = division,
                                stance = stance,
                                style = style,
                            ),
                        )
                    },
                    enabled = name.isNotBlank() && country.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text("COMMENCER À 18 ANS", fontWeight = FontWeight.Black)
                }
                OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                    Text("RETOUR")
                }
            }
        }
    }
}

@Composable
fun CareerDashboardScreen(
    state: CareerState,
    opponents: List<CareerOpponent>,
    onFight: (CareerOpponent) -> Unit,
    onTrain: (TrainingFocus) -> Unit,
    onRest: () -> Unit,
    onMoveDivision: (WeightClass) -> Unit,
    onRetire: () -> Unit,
    onBack: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text("CARRIÈRE PROFESSIONNELLE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        }
        item {
            CareerIdentityCard(state)
        }
        item {
            CareerProgressCard(state)
        }
        if (state.belts.isNotEmpty()) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("CEINTURES", fontWeight = FontWeight.Black)
                    state.belts.sortedBy { it.ordinal }.forEach { belt ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                        ) {
                            Text(belt.frenchLabel, modifier = Modifier.padding(10.dp), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (state.status == CareerStatus.ACTIVE) {
            item {
                SelectionSection(title = "CAMP D’ENTRAÎNEMENT") {
                    TrainingFocus.entries.chunked(2).forEach { row ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { focus ->
                                OutlinedButton(
                                    onClick = { onTrain(focus) },
                                    enabled = state.fatigue <= 88 && state.purseBalance >= 75,
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Text(focus.frenchLabel, maxLines = 1)
                                }
                            }
                        }
                    }
                    Text("Chaque séance coûte 75 € et fait progresser les statistiques.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onRest, modifier = Modifier.weight(1f)) { Text("REPOS") }
                    OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("MENU") }
                }
            }
            val moves = CareerEngine.eligibleDivisionMoves(state)
            if (moves.isNotEmpty()) {
                item {
                    SelectionSection(title = "CHANGER DE CATÉGORIE") {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            moves.forEach { target ->
                                OutlinedButton(onClick = { onMoveDivision(target) }, modifier = Modifier.weight(1f)) {
                                    Text(target.frenchLabel.replace("Poids ", ""), maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Text("PROCHAINS COMBATS", fontWeight = FontWeight.Black)
            }
            items(opponents, key = { "${it.source.collectionId}-${it.beltAtStake}-${it.isTitleDefense}" }) { opponent ->
                OpponentCard(state, opponent, onFight)
            }
            item {
                OutlinedButton(onClick = onRetire, modifier = Modifier.fillMaxWidth()) {
                    Text("PRENDRE SA RETRAITE")
                }
            }
        } else {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("CARRIÈRE TERMINÉE", fontWeight = FontWeight.Black)
                        Text("Palmarès final : ${state.record.label}")
                        Text("Ceintures remportées : ${state.belts.size}")
                        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("RETOUR AU MENU") }
                    }
                }
            }
        }
    }
}

@Composable
private fun CareerIdentityCard(state: CareerState) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(state.fighter.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text(
                        "${state.fighter.nickname} · ${state.country}",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text("GEN ${state.overall}", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
            }
            Text("${state.ageYears} ans ${state.ageMonths} mois · ${state.division.frenchLabel}")
            Text("${state.stage.frenchLabel} · ${state.rankingLabel}", fontWeight = FontWeight.Bold)
            Text("Palmarès ${state.record.label} · ${state.titleDefenses} défense(s)")
            Text("Bourse ${state.purseBalance} € · Réputation ${state.reputation}/100")
        }
    }
}

@Composable
private fun CareerProgressCard(state: CareerState) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("ÉTAT PHYSIQUE", fontWeight = FontWeight.Black)
            Text("Fatigue ${state.fatigue}%")
            LinearProgressIndicator(progress = { state.fatigue / 100f }, modifier = Modifier.fillMaxWidth())
            Text("Santé ${state.health}%")
            LinearProgressIndicator(progress = { state.health / 100f }, modifier = Modifier.fillMaxWidth())
            Text("Semaine ${state.week}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OpponentCard(
    state: CareerState,
    opponent: CareerOpponent,
    onFight: (CareerOpponent) -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (opponent.isTitleFight) 2.dp else 1.dp,
            color = if (opponent.isTitleFight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
        ),
    ) {
        Column(modifier = Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(opponent.boutLabel, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(opponent.profile.name, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text("GEN ${opponent.profile.primaryStats.average().toInt()}", fontWeight = FontWeight.Black)
            }
            Text(
                "${opponent.profile.nickname} · ${styleLabel(opponent.profile.style)}",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(opponent.worldRank?.let { "Classé mondial #$it" } ?: "Circuit ${state.stage.frenchLabel.lowercase()}")
            Text("Bourse ${opponent.purse} € · +${opponent.reputationReward} réputation")
            Button(
                onClick = { onFight(opponent) },
                enabled = state.fatigue < 85 && state.health > 20,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (opponent.isTitleFight) "COMBATTRE POUR LA CEINTURE" else "ACCEPTER LE COMBAT", fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun SelectionSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(title, fontWeight = FontWeight.Black)
            content()
        }
    }
}

@Composable
private fun ChoiceButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (selected) {
        Button(onClick = onClick, modifier = modifier) { Text(label, maxLines = 1) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier) { Text(label, maxLines = 1) }
    }
}

private fun stanceLabel(stance: Stance): String = when (stance) {
    Stance.ORTHODOX -> "Droitier"
    Stance.SOUTHPAW -> "Gaucher"
    Stance.SWITCH -> "Ambidextre"
}

private fun styleLabel(style: BoxingStyle): String = when (style) {
    BoxingStyle.OUT_BOXER -> "Out-boxer"
    BoxingStyle.PRESSURE_FIGHTER -> "Pression"
    BoxingStyle.COUNTERPUNCHER -> "Contreur"
    BoxingStyle.BOXER_PUNCHER -> "Boxeur-puncheur"
    BoxingStyle.SWARMER -> "Swarmer"
    BoxingStyle.SLUGGER -> "Slugger"
    BoxingStyle.DEFENSIVE_SPECIALIST -> "Défensif"
}
