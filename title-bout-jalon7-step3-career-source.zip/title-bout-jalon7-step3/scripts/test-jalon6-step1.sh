#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build-jalon6-step1"
rm -rf "$BUILD"
mkdir -p "$BUILD"

kotlinc -J-Xmx1536m -J-Dfile.encoding=UTF-8 \
  "$ROOT"/engine/src/main/kotlin/titlefight/*.kt \
  "$ROOT"/engine/src/test/kotlin/titlefight/Jalon6Step1Audit.kt \
  "$ROOT"/engine/src/test/kotlin/titlefight/FightScreenStateDemo.kt \
  -include-runtime -d "$BUILD/title-fight-jalon6-step1.jar"

java -Xmx2g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-jalon6-step1.jar" titlefight.Jalon6Step1Test
java -Xmx2g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-jalon6-step1.jar" titlefight.Jalon6Step1AuditDemo
java -Xmx2g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-jalon6-step1.jar" titlefight.FightScreenStateDemo
