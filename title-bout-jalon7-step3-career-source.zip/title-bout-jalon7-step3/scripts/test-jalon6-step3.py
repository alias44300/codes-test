#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMPOSE = ROOT / "android-ui-compose" / "src" / "main" / "kotlin" / "titlefight" / "ui" / "compose"
BUILD = ROOT / "build-jalon6-step3"
BUILD.mkdir(parents=True, exist_ok=True)

fight_screen = (COMPOSE / "FightScreen.kt").read_text(encoding="utf-8")
previews = (COMPOSE / "FightScreenPreviews.kt").read_text(encoding="utf-8")
contract = (COMPOSE / "FightScreenComposeContract.kt").read_text(encoding="utf-8")
adapter = (COMPOSE / "FightScreenTimelineAdapter.kt").read_text(encoding="utf-8")
all_source = "\n".join(p.read_text(encoding="utf-8") for p in sorted(COMPOSE.glob("*.kt")))

checks: dict[str, bool] = {
    "entrypoint_uses_fight_screen_state": bool(re.search(r"fun\s+TitleFightScreen\s*\(\s*state:\s*FightScreenState", fight_screen)),
    "responsive_box_with_constraints": "BoxWithConstraints" in fight_screen,
    "locked_layout_policy_used": "FightScreenLayoutPolicy.forWidth" in fight_screen,
    "fighter_pair_component": "private fun FighterPair" in fight_screen,
    "scoreboard_component": "private fun FightScoreboard" in fight_screen,
    "action_component": "private fun CurrentActionPanel" in fight_screen,
    "commentary_component": "private fun CommentaryPanel" in fight_screen,
    "recent_log_component": "private fun RecentLogPanel" in fight_screen,
    "tactical_component": "private fun TacticalSummaryPair" in fight_screen,
    "result_component": "private fun ResultPanel" in fight_screen,
    "content_descriptions": all_source.count("contentDescription") >= 6,
    "progress_semantics": "progressBarRangeInfo" in fight_screen,
    "merged_semantics": "mergeDescendants = true" in fight_screen,
    "minimum_touch_targets": "minimumTapTargetDp.dp" in fight_screen,
    "preview_320": 'widthDp = 320' in previews and 'heightDp = 720' in previews,
    "preview_360": 'widthDp = 360' in previews and 'heightDp = 800' in previews,
    "preview_412": 'widthDp = 412' in previews and 'heightDp = 915' in previews,
    "preview_between_rounds": "BetweenRoundsPreview" in previews,
    "preview_complete": "CompletePreview" in previews,
    "mapper_adapter_delegates": "FightScreenStateMapper.buildTimeline" in adapter,
    "no_network_import": not bool(re.search(r"import\s+(java\.net|okhttp|retrofit|ktor)", all_source, re.IGNORECASE)),
    "no_active_tactical_click": "onClick" not in fight_screen and "clickable(" not in fight_screen,
    "no_judge_scorecards": not bool(re.search(r"scorecard|judgeCards|redCards|blueCards", all_source, re.IGNORECASE)),
    "no_engine_mutation": not bool(re.search(r"simulateThreeRoundFight|FightEngine\(", fight_screen)),
    "three_width_classes": all(token in contract for token in ("COMPACT", "STANDARD", "EXPANDED")),
}

failed = [name for name, ok in checks.items() if not ok]
report = {
    "checks": checks,
    "passed": len(checks) - len(failed),
    "failed": failed,
    "composeFiles": [p.name for p in sorted(COMPOSE.glob("*.kt"))],
}
(BUILD / "compose-source-audit.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
if failed:
    raise SystemExit("Échec audit source Compose: " + ", ".join(failed))

jar = BUILD / "title-fight-jalon6-step3.jar"
main_sources = sorted((ROOT / "engine" / "src" / "main" / "kotlin" / "titlefight").glob("*.kt"))
pure_sources = [
    COMPOSE / "FightScreenComposeContract.kt",
    COMPOSE / "FightScreenPreviewFixtures.kt",
    COMPOSE / "FightScreenTimelineAdapter.kt",
]
test_source = ROOT / "android-ui-compose" / "src" / "test" / "kotlin" / "titlefight" / "ui" / "compose" / "Jalon6Step3Audit.kt"
cmd = [
    "kotlinc", "-J-Xmx1536m", "-J-Dfile.encoding=UTF-8",
    *map(str, main_sources),
    *map(str, pure_sources),
    str(test_source),
    "-include-runtime", "-d", str(jar),
]
subprocess.run(cmd, check=True)
subprocess.run(["java", "-Xmx2g", "-Dfile.encoding=UTF-8", "-cp", str(jar), "titlefight.ui.compose.Jalon6Step3Test"], check=True)
subprocess.run(["java", "-Xmx2g", "-Dfile.encoding=UTF-8", "-cp", str(jar), "titlefight.ui.compose.Jalon6Step3AuditDemo"], check=True)
print(f"{report['passed']} contrôles source Compose réussis")
