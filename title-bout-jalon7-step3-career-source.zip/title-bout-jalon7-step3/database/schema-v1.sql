PRAGMA foreign_keys = ON;

CREATE TABLE database_meta (
    meta_key TEXT PRIMARY KEY NOT NULL,
    meta_value TEXT NOT NULL
);

CREATE TABLE boxers (
    boxer_id TEXT PRIMARY KEY NOT NULL,
    name TEXT NOT NULL,
    nickname TEXT NOT NULL,
    country_code TEXT NOT NULL,
    country_name TEXT NOT NULL,
    era TEXT NOT NULL
);

CREATE TABLE boxer_versions (
    version_id TEXT PRIMARY KEY NOT NULL,
    boxer_id TEXT NOT NULL REFERENCES boxers(boxer_id) ON DELETE CASCADE,
    database_id INTEGER NOT NULL UNIQUE,
    prime_start_year INTEGER NOT NULL,
    prime_end_year INTEGER NOT NULL,
    weight_class TEXT NOT NULL,
    stance TEXT NOT NULL,
    style TEXT NOT NULL,
    secondary_style TEXT,
    preferred_range TEXT NOT NULL,
    height_cm INTEGER NOT NULL,
    reach_cm INTEGER NOT NULL,
    power INTEGER NOT NULL CHECK(power BETWEEN 1 AND 100),
    speed INTEGER NOT NULL CHECK(speed BETWEEN 1 AND 100),
    technique INTEGER NOT NULL CHECK(technique BETWEEN 1 AND 100),
    defense INTEGER NOT NULL CHECK(defense BETWEEN 1 AND 100),
    endurance INTEGER NOT NULL CHECK(endurance BETWEEN 1 AND 100),
    mental INTEGER NOT NULL CHECK(mental BETWEEN 1 AND 100),
    chin INTEGER NOT NULL CHECK(chin BETWEEN 1 AND 100),
    recovery INTEGER NOT NULL CHECK(recovery BETWEEN 1 AND 100),
    accuracy INTEGER NOT NULL CHECK(accuracy BETWEEN 1 AND 100),
    mobility INTEGER NOT NULL CHECK(mobility BETWEEN 1 AND 100),
    body_resistance INTEGER NOT NULL CHECK(body_resistance BETWEEN 1 AND 100),
    aggression INTEGER NOT NULL CHECK(aggression BETWEEN 1 AND 100)
);

CREATE TABLE ratings (
    version_id TEXT PRIMARY KEY NOT NULL REFERENCES boxer_versions(version_id) ON DELETE CASCADE,
    jab_power INTEGER NOT NULL,
    rear_hand_power INTEGER NOT NULL,
    hook_power INTEGER NOT NULL,
    body_power INTEGER NOT NULL,
    hand_speed INTEGER NOT NULL,
    foot_speed INTEGER NOT NULL,
    accuracy INTEGER NOT NULL,
    timing INTEGER NOT NULL,
    head_defense INTEGER NOT NULL,
    body_defense INTEGER NOT NULL,
    blocking INTEGER NOT NULL,
    evasiveness INTEGER NOT NULL,
    countering INTEGER NOT NULL,
    pressure INTEGER NOT NULL,
    range_control INTEGER NOT NULL,
    inside_fighting INTEGER NOT NULL,
    endurance INTEGER NOT NULL,
    recovery INTEGER NOT NULL,
    chin INTEGER NOT NULL,
    body_resistance INTEGER NOT NULL,
    balance INTEGER NOT NULL,
    cut_resistance INTEGER NOT NULL,
    ring_iq INTEGER NOT NULL,
    adaptability INTEGER NOT NULL,
    discipline INTEGER NOT NULL,
    aggression INTEGER NOT NULL,
    finishing INTEGER NOT NULL,
    composure INTEGER NOT NULL
);

CREATE TABLE tendencies (
    version_id TEXT PRIMARY KEY NOT NULL REFERENCES boxer_versions(version_id) ON DELETE CASCADE,
    jab_frequency INTEGER NOT NULL,
    body_attack_frequency INTEGER NOT NULL,
    combination_frequency INTEGER NOT NULL,
    counter_frequency INTEGER NOT NULL,
    clinch_frequency INTEGER NOT NULL,
    pressure_frequency INTEGER NOT NULL,
    risk_tolerance INTEGER NOT NULL,
    fast_start INTEGER NOT NULL,
    late_surge INTEGER NOT NULL
);

CREATE TABLE signature_actions (
    version_id TEXT NOT NULL REFERENCES boxer_versions(version_id) ON DELETE CASCADE,
    action_order INTEGER NOT NULL,
    label TEXT NOT NULL,
    PRIMARY KEY(version_id, action_order)
);

CREATE TABLE traits (
    version_id TEXT NOT NULL REFERENCES boxer_versions(version_id) ON DELETE CASCADE,
    trait_order INTEGER NOT NULL,
    label TEXT NOT NULL,
    PRIMARY KEY(version_id, trait_order)
);

CREATE INDEX idx_versions_weight ON boxer_versions(weight_class);
CREATE INDEX idx_versions_style ON boxer_versions(style);
CREATE INDEX idx_boxers_name ON boxers(name);
