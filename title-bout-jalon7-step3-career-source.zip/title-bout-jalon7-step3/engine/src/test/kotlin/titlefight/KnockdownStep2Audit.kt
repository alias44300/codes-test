package titlefight

import java.util.Locale

private val STEP2_VEGA_TACTICS = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
private val STEP2_KESSLER_TACTICS = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

data class KnockdownStep2AuditResult(
    val fightCount: Int,
    val totalCounts: Int,
    val recoveredCounts: Int,
    val tenCountsPending: Int,
    val countsOutsideBounds: Int,
    val countsWithoutKnockdown: Int,
    val averageCount: Double,
    val minimumCount: Int,
    val maximumCount: Int,
    val vulnerabilityApplied: Int,
    val redCornerCounts: Int,
    val blueCornerCounts: Int,
) {
    init {
        require(fightCount > 0)
        require(totalCounts == recoveredCounts + tenCountsPending)
        require(countsOutsideBounds == 0)
        require(countsWithoutKnockdown == 0)
        require(redCornerCounts + blueCornerCounts == totalCounts)
    }
}

object KnockdownStep2Auditor {
    fun run(fightCount: Int = 1000, seedStart: Long = 2026074000L): KnockdownStep2AuditResult {
        require(fightCount == 1000)
        val engine = FightEngine(stopOnTenCount = false, stopOnTko = false)
        val counts = mutableListOf<Int>()
        var recovered = 0
        var pending = 0
        var outside = 0
        var withoutKnockdown = 0
        var vulnerabilityApplied = 0
        var red = 0
        var blue = 0

        repeat(fightCount) { index ->
            val vegaRed = index % 2 == 0
            val fight = if (vegaRed) {
                engine.simulateThreeRoundFight(
                    TestProfiles.eliasVega, TestProfiles.brunoKessler,
                    STEP2_VEGA_TACTICS, STEP2_KESSLER_TACTICS,
                    seedStart + index,
                )
            } else {
                engine.simulateThreeRoundFight(
                    TestProfiles.brunoKessler, TestProfiles.eliasVega,
                    STEP2_KESSLER_TACTICS, STEP2_VEGA_TACTICS,
                    seedStart + index,
                )
            }

            fight.rounds.flatMap { it.events }.forEach { event ->
                val knockdown = event.knockdown ?: return@forEach
                val count = knockdown.refereeCount
                if (count == null) {
                    withoutKnockdown++
                    return@forEach
                }
                counts += count.countReached
                if (count.countReached !in 1..10) outside++
                if (count.recovered) recovered++ else pending++
                if (count.vulnerabilitySequences > 0) vulnerabilityApplied++
                if (event.attackerId == fight.redId) red++ else blue++
            }
        }

        return KnockdownStep2AuditResult(
            fightCount = fightCount,
            totalCounts = counts.size,
            recoveredCounts = recovered,
            tenCountsPending = pending,
            countsOutsideBounds = outside,
            countsWithoutKnockdown = withoutKnockdown,
            averageCount = counts.ifEmpty { listOf(0) }.average(),
            minimumCount = counts.minOrNull() ?: 0,
            maximumCount = counts.maxOrNull() ?: 0,
            vulnerabilityApplied = vulnerabilityApplied,
            redCornerCounts = red,
            blueCornerCounts = blue,
        )
    }
}

object KnockdownStep2AuditFormatter {
    fun format(result: KnockdownStep2AuditResult): String = buildString {
        appendLine("TITLE FIGHT — Jalon 2, étape 2")
        appendLine("Audit du compte, du relèvement et de la vulnérabilité temporaire")
        appendLine()
        appendLine("Combats : ${result.fightCount}")
        appendLine("Comptes déclenchés : ${result.totalCounts}")
        appendLine("Relèvements avant 10 : ${result.recoveredCounts}")
        appendLine("Comptes à 10 en attente de l’étape KO : ${result.tenCountsPending}")
        appendLine("Comptes hors bornes : ${result.countsOutsideBounds}")
        appendLine("Chutes sans compte attaché : ${result.countsWithoutKnockdown}")
        appendLine("Compte moyen : ${decimal(result.averageCount)}")
        appendLine("Minimum / maximum : ${result.minimumCount} / ${result.maximumCount}")
        appendLine("Vulnérabilités appliquées : ${result.vulnerabilityApplied}")
        appendLine("Coin rouge / bleu : ${result.redCornerCounts} / ${result.blueCornerCounts}")
        appendLine()
        appendLine("Le moteur continue provisoirement après un compte à 10. La fin par KO reste réservée à l’étape 3.")
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
}

object KnockdownStep2AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        print(KnockdownStep2AuditFormatter.format(KnockdownStep2Auditor.run()))
    }
}
