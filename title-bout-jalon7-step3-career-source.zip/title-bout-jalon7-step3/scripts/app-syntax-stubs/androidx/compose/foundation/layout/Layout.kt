package androidx.compose.foundation.layout
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

open class ColumnScope { fun Modifier.weight(value: Float): Modifier = this }
open class RowScope { fun Modifier.weight(value: Float): Modifier = this }
class BoxWithConstraintsScope { val maxWidth: Dp = 360.dp }
object Arrangement {
    object SpaceBetween
    object Center
    fun spacedBy(space: Dp): Any = Any()
}
@Composable fun Box(modifier: Modifier = Modifier, contentAlignment: Any? = null, content: @Composable () -> Unit) { content() }
@Composable fun BoxWithConstraints(modifier: Modifier = Modifier, contentAlignment: Any? = null, content: @Composable BoxWithConstraintsScope.() -> Unit) { BoxWithConstraintsScope().content() }
@Composable fun Column(modifier: Modifier = Modifier, verticalArrangement: Any? = null, horizontalAlignment: Any? = null, content: @Composable ColumnScope.() -> Unit) { ColumnScope().content() }
@Composable fun Row(modifier: Modifier = Modifier, horizontalArrangement: Any? = null, verticalAlignment: Any? = null, content: @Composable RowScope.() -> Unit) { RowScope().content() }
@Composable fun Spacer(modifier: Modifier = Modifier) {}
fun Modifier.fillMaxSize(): Modifier = this
fun Modifier.fillMaxWidth(): Modifier = this
fun Modifier.height(value: Dp): Modifier = this
fun Modifier.heightIn(min: Dp = 0.dp, max: Dp = 10000.dp): Modifier = this
fun Modifier.padding(all: Dp): Modifier = this
fun Modifier.padding(horizontal: Dp = 0.dp, vertical: Dp = 0.dp): Modifier = this
fun Modifier.size(value: Dp): Modifier = this
fun Modifier.widthIn(min: Dp = 0.dp, max: Dp = 10000.dp): Modifier = this
fun Modifier.weight(value: Float): Modifier = this
