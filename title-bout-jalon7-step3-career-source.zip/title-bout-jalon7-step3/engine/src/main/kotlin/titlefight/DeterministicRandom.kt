package titlefight

class DeterministicRandom(seed: Long) {
    private var state: Long = seed xor 0x9E3779B97F4A7C15UL.toLong()

    private fun nextLongInternal(): Long {
        var x = state
        x = x xor (x ushr 12)
        x = x xor (x shl 25)
        x = x xor (x ushr 27)
        state = x
        return x * 2685821657736338717L
    }

    fun nextLong(): Long = nextLongInternal()

    fun nextDouble(): Double {
        val bits = nextLongInternal().ushr(11)
        return bits.toDouble() / (1L shl 53).toDouble()
    }

    fun nextInt(bound: Int): Int {
        require(bound > 0)
        return (nextDouble() * bound).toInt().coerceAtMost(bound - 1)
    }

    fun chance(probability: Double): Boolean = nextDouble() < probability.coerceIn(0.0, 1.0)

    fun noise(amplitude: Double): Double = (nextDouble() * 2.0 - 1.0) * amplitude
}
