# Jalon 5 — Étape 2 — Identité statistique des dix profils

## Objectif

Mesurer les dix profils avec leur plan naturel, corriger l'asymétrie structurelle de la distance moyenne détectée lors du premier audit, puis répéter exactement le même protocole avant d'ouvrir la matrice des 45 affrontements.

## Protocole inchangé

Chaque boxeur affronte le même partenaire d'étalonnage fictif pendant 360 rounds indépendants :

- 12 séquences par round ;
- six tactiques historiques réparties à parts égales ;
- coins rouge et bleu alternés ;
- plan naturel fixé pendant le round ;
- KO et TKO désactivés uniquement pour conserver un échantillon de longueur constante ;
- 120 répétitions strictes avec les mêmes graines.

Le partenaire d'étalonnage ne fait pas partie du catalogue jouable.

## Défaut initial

Le premier passage a mesuré seulement 19,46 % de distance moyenne pour les profils `MEDIUM`. Malik Okoro, Tomas Aranda, Viktor Sokolov et Mateo Silva dérivaient tous vers la courte distance.

## Correctif unique

Une résistance bornée à l'aspiration vers les distances extrêmes a été ajoutée pour les plans `MEDIUM` :

- formule identique pour les deux coins ;
- maximum strict de 8,5 points ;
- soutien limité de la tactique `COUNTER` ;
- efficacité réduite avec la fatigue ;
- valeur nulle lorsque le plan est absent, afin de préserver le mode historique ;
- aucun profil ni aucune autre règle de combat modifiés.

## Résultats après correction

- 10 profils et 3 600 rounds mesurés ;
- 120 contrôles de reproductibilité, 0 écart ;
- 0 plan naturel manquant ou incorrect ;
- 0 métrique invalide ;
- 0 paire statistiquement indiscernable ;
- 0 distance dominante incohérente ;
- 0 empreinte historique Vega/Kessler modifiée ;
- longue distance naturelle : 78,92 % ;
- distance moyenne naturelle : 50,42 % ;
- courte distance naturelle : 75,13 %.

Les quatre profils `MEDIUM` ont maintenant `MID` comme distance dominante :

- Malik Okoro : 43,83 % ;
- Tomas Aranda : 56,60 % ;
- Viktor Sokolov : 46,01 % ;
- Mateo Silva : 55,24 %.

## Décision

**Étape 2 validée après correction.**

La prochaine étape autorisée est la matrice complète des 45 affrontements, avec inversion systématique des coins et plusieurs graines par duel. Aucune calibration du roster n'est encore autorisée pendant la collecte initiale.
