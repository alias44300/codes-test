package titlefight.ui.compose
import androidx.compose.runtime.Composable
import titlefight.FightScreenState
import titlefight.InteractiveFightSession
class TacticalSelection
class TacticalUiAction
class InteractiveFightViewState(val screenState: FightScreenState, val tacticalSelection: TacticalSelection?)
class InteractiveFightCoordinator(session: InteractiveFightSession) {
    fun start(): InteractiveFightViewState = error("stub")
    fun dispatch(action: TacticalUiAction): InteractiveFightViewState = error("stub")
}
@Composable fun TitleFightScreen(
    state: FightScreenState,
    tacticalSelection: TacticalSelection?,
    onTacticalAction: (TacticalUiAction) -> Unit,
    onExitFight: () -> Unit,
    exitLabel: String,
) {}
@Composable fun TitleFightTheme(darkTheme: Boolean, content: @Composable () -> Unit) { content() }
