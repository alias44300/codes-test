package androidx.compose.foundation
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
class ScrollState
@Composable fun rememberScrollState(): ScrollState = ScrollState()
fun Modifier.verticalScroll(state: ScrollState): Modifier = this
class BorderStroke(val width: Dp, val color: Color)
fun Modifier.background(color: Color): Modifier = this
@Composable fun isSystemInDarkTheme(): Boolean = true
