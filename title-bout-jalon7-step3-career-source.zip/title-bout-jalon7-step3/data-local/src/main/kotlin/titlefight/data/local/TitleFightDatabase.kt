package titlefight.data.local

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import titlefight.BoxerDatabaseEntry
import titlefight.BoxerProfile
import titlefight.PlayableBoxerDatabase
import titlefight.OfficialRoster

class TitleFightDatabase private constructor(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION,
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("PRAGMA foreign_keys = ON")
        createSchema(db)
        seedV1(db)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        require(oldVersion <= newVersion)
        if (oldVersion < 1) {
            createSchema(db)
            seedV1(db)
        }
    }

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS database_meta (
                meta_key TEXT PRIMARY KEY NOT NULL,
                meta_value TEXT NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS boxers (
                boxer_id TEXT PRIMARY KEY NOT NULL,
                name TEXT NOT NULL,
                nickname TEXT NOT NULL,
                country_code TEXT NOT NULL,
                country_name TEXT NOT NULL,
                era TEXT NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS boxer_versions (
                version_id TEXT PRIMARY KEY NOT NULL,
                boxer_id TEXT NOT NULL REFERENCES boxers(boxer_id) ON DELETE CASCADE,
                database_id INTEGER NOT NULL UNIQUE,
                prime_start_year INTEGER NOT NULL,
                prime_end_year INTEGER NOT NULL,
                weight_class TEXT NOT NULL,
                stance TEXT NOT NULL,
                style TEXT NOT NULL,
                secondary_style TEXT,
                preferred_range TEXT NOT NULL,
                height_cm INTEGER NOT NULL,
                reach_cm INTEGER NOT NULL,
                power INTEGER NOT NULL,
                speed INTEGER NOT NULL,
                technique INTEGER NOT NULL,
                defense INTEGER NOT NULL,
                endurance INTEGER NOT NULL,
                mental INTEGER NOT NULL,
                chin INTEGER NOT NULL,
                recovery INTEGER NOT NULL,
                accuracy INTEGER NOT NULL,
                mobility INTEGER NOT NULL,
                body_resistance INTEGER NOT NULL,
                aggression INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_versions_weight ON boxer_versions(weight_class)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_versions_style ON boxer_versions(style)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_boxers_name ON boxers(name)")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS ratings (
                version_id TEXT PRIMARY KEY NOT NULL REFERENCES boxer_versions(version_id) ON DELETE CASCADE,
                jab_power INTEGER NOT NULL,
                rear_hand_power INTEGER NOT NULL,
                hook_power INTEGER NOT NULL,
                body_power INTEGER NOT NULL,
                hand_speed INTEGER NOT NULL,
                foot_speed INTEGER NOT NULL,
                accuracy INTEGER NOT NULL,
                timing INTEGER NOT NULL,
                head_defense INTEGER NOT NULL,
                body_defense INTEGER NOT NULL,
                blocking INTEGER NOT NULL,
                evasiveness INTEGER NOT NULL,
                countering INTEGER NOT NULL,
                pressure INTEGER NOT NULL,
                range_control INTEGER NOT NULL,
                inside_fighting INTEGER NOT NULL,
                endurance INTEGER NOT NULL,
                recovery INTEGER NOT NULL,
                chin INTEGER NOT NULL,
                body_resistance INTEGER NOT NULL,
                balance INTEGER NOT NULL,
                cut_resistance INTEGER NOT NULL,
                ring_iq INTEGER NOT NULL,
                adaptability INTEGER NOT NULL,
                discipline INTEGER NOT NULL,
                aggression INTEGER NOT NULL,
                finishing INTEGER NOT NULL,
                composure INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS tendencies (
                version_id TEXT PRIMARY KEY NOT NULL REFERENCES boxer_versions(version_id) ON DELETE CASCADE,
                jab_frequency INTEGER NOT NULL,
                body_attack_frequency INTEGER NOT NULL,
                combination_frequency INTEGER NOT NULL,
                counter_frequency INTEGER NOT NULL,
                clinch_frequency INTEGER NOT NULL,
                pressure_frequency INTEGER NOT NULL,
                risk_tolerance INTEGER NOT NULL,
                fast_start INTEGER NOT NULL,
                late_surge INTEGER NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS signature_actions (
                version_id TEXT NOT NULL REFERENCES boxer_versions(version_id) ON DELETE CASCADE,
                action_order INTEGER NOT NULL,
                label TEXT NOT NULL,
                PRIMARY KEY(version_id, action_order)
            )
            """.trimIndent(),
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS traits (
                version_id TEXT NOT NULL REFERENCES boxer_versions(version_id) ON DELETE CASCADE,
                trait_order INTEGER NOT NULL,
                label TEXT NOT NULL,
                PRIMARY KEY(version_id, trait_order)
            )
            """.trimIndent(),
        )
    }

    private fun seedV1(db: SQLiteDatabase) {
        val count = db.rawQuery("SELECT COUNT(*) FROM boxer_versions", null).use { cursor ->
            cursor.moveToFirst()
            cursor.getInt(0)
        }
        if (count >= PlayableBoxerDatabase.allEntries.size) return

        db.beginTransaction()
        try {
            db.delete("traits", null, null)
            db.delete("signature_actions", null, null)
            db.delete("tendencies", null, null)
            db.delete("ratings", null, null)
            db.delete("boxer_versions", null, null)
            db.delete("boxers", null, null)
            db.delete("database_meta", null, null)

            putMeta(db, "schema_version", PlayableBoxerDatabase.SCHEMA_VERSION.toString())
            putMeta(db, "content_version", PlayableBoxerDatabase.CONTENT_VERSION)
            putMeta(db, "boxer_count", PlayableBoxerDatabase.allEntries.size.toString())

            PlayableBoxerDatabase.allEntries.forEach { seedEntry(db, it) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun putMeta(db: SQLiteDatabase, key: String, value: String) {
        db.insertOrThrow("database_meta", null, ContentValues().apply {
            put("meta_key", key)
            put("meta_value", value)
        })
    }

    private fun seedEntry(db: SQLiteDatabase, entry: BoxerDatabaseEntry) {
        db.insertWithOnConflict("boxers", null, ContentValues().apply {
            put("boxer_id", entry.boxerId)
            put("name", entry.name)
            put("nickname", entry.nickname)
            put("country_code", entry.countryCode)
            put("country_name", entry.countryName)
            put("era", entry.era.name)
        }, SQLiteDatabase.CONFLICT_REPLACE)

        val profile = entry.profile
        db.insertOrThrow("boxer_versions", null, ContentValues().apply {
            put("version_id", entry.versionId)
            put("boxer_id", entry.boxerId)
            put("database_id", entry.databaseId)
            put("prime_start_year", entry.primeStartYear)
            put("prime_end_year", entry.primeEndYear)
            put("weight_class", entry.weightClass.name)
            put("stance", entry.stance.name)
            put("style", entry.style.name)
            put("secondary_style", entry.secondaryStyle?.name)
            put("preferred_range", entry.preferredRange.name)
            put("height_cm", entry.heightCm)
            put("reach_cm", entry.reachCm)
            put("power", profile.power)
            put("speed", profile.speed)
            put("technique", profile.technique)
            put("defense", profile.defense)
            put("endurance", profile.endurance)
            put("mental", profile.mental)
            put("chin", profile.chin)
            put("recovery", profile.recovery)
            put("accuracy", profile.accuracy)
            put("mobility", profile.mobility)
            put("body_resistance", profile.bodyResistance)
            put("aggression", profile.aggression)
        })

        val ratings = entry.ratings
        db.insertOrThrow("ratings", null, ContentValues().apply {
            put("version_id", entry.versionId)
            put("jab_power", ratings.jabPower)
            put("rear_hand_power", ratings.rearHandPower)
            put("hook_power", ratings.hookPower)
            put("body_power", ratings.bodyPower)
            put("hand_speed", ratings.handSpeed)
            put("foot_speed", ratings.footSpeed)
            put("accuracy", ratings.accuracy)
            put("timing", ratings.timing)
            put("head_defense", ratings.headDefense)
            put("body_defense", ratings.bodyDefense)
            put("blocking", ratings.blocking)
            put("evasiveness", ratings.evasiveness)
            put("countering", ratings.countering)
            put("pressure", ratings.pressure)
            put("range_control", ratings.rangeControl)
            put("inside_fighting", ratings.insideFighting)
            put("endurance", ratings.endurance)
            put("recovery", ratings.recovery)
            put("chin", ratings.chin)
            put("body_resistance", ratings.bodyResistance)
            put("balance", ratings.balance)
            put("cut_resistance", ratings.cutResistance)
            put("ring_iq", ratings.ringIq)
            put("adaptability", ratings.adaptability)
            put("discipline", ratings.discipline)
            put("aggression", ratings.aggression)
            put("finishing", ratings.finishing)
            put("composure", ratings.composure)
        })

        val tendencies = entry.tendencies
        db.insertOrThrow("tendencies", null, ContentValues().apply {
            put("version_id", entry.versionId)
            put("jab_frequency", tendencies.jabFrequency)
            put("body_attack_frequency", tendencies.bodyAttackFrequency)
            put("combination_frequency", tendencies.combinationFrequency)
            put("counter_frequency", tendencies.counterFrequency)
            put("clinch_frequency", tendencies.clinchFrequency)
            put("pressure_frequency", tendencies.pressureFrequency)
            put("risk_tolerance", tendencies.riskTolerance)
            put("fast_start", tendencies.fastStart)
            put("late_surge", tendencies.lateSurge)
        })

        entry.signatureActions.forEachIndexed { index, action ->
            db.insertOrThrow("signature_actions", null, ContentValues().apply {
                put("version_id", entry.versionId)
                put("action_order", index)
                put("label", action)
            })
        }
        entry.traits.forEachIndexed { index, trait ->
            db.insertOrThrow("traits", null, ContentValues().apply {
                put("version_id", entry.versionId)
                put("trait_order", index)
                put("label", trait)
            })
        }
    }

    companion object {
        const val DATABASE_NAME = "title_fight_roster.db"
        const val DATABASE_VERSION = 1

        @Volatile
        private var instance: TitleFightDatabase? = null

        fun get(context: Context): TitleFightDatabase = instance ?: synchronized(this) {
            instance ?: TitleFightDatabase(context).also { instance = it }
        }
    }
}

class AndroidBoxerRepository(context: Context) {
    init {
        // Ouvre et conserve la base SQLite enrichie historique, tout en exposant
        // le catalogue officiel complet de 321 boxeurs au moteur de jeu.
        TitleFightDatabase.get(context).readableDatabase
    }

    fun allProfiles(): List<BoxerProfile> = OfficialRoster.profiles

    fun searchProfiles(query: String): List<BoxerProfile> =
        OfficialRoster.search(query).map { it.profile }

    fun requireProfile(versionId: String): BoxerProfile =
        OfficialRoster.profiles.single { it.id == versionId }

    fun contentVersion(): String = OfficialRoster.CONTENT_VERSION
}
