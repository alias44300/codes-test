package titlefight

object BatchDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = BatchValidator.run()
        print(BatchValidationFormatter.format(result))
    }
}
