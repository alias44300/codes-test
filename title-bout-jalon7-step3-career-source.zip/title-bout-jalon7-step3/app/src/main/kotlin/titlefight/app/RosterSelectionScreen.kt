package titlefight.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import titlefight.BoxerProfile

@Composable
fun RosterSelectionScreen(
    profiles: List<BoxerProfile>,
    query: String,
    red: BoxerProfile?,
    blue: BoxerProfile?,
    databaseVersion: String,
    onQueryChange: (String) -> Unit,
    onSelectRed: (BoxerProfile) -> Unit,
    onSelectBlue: (BoxerProfile) -> Unit,
    onStartFight: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = "TITLE BOUT",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary,
        )
        Text(
            text = "Base historique locale · ${profiles.size} boxeurs affichés · $databaseVersion",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Rechercher un boxeur") },
        )
        SelectedCorners(red = red, blue = blue)
        Button(
            onClick = onStartFight,
            enabled = red != null && blue != null && red.id != blue.id,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp),
        ) {
            Text("LANCER LE COMBAT", fontWeight = FontWeight.Black)
        }
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(7.dp),
        ) {
            items(profiles, key = { it.id }) { boxer ->
                BoxerSelectionRow(
                    profile = boxer,
                    selectedRed = boxer.id == red?.id,
                    selectedBlue = boxer.id == blue?.id,
                    onSelectRed = { onSelectRed(boxer) },
                    onSelectBlue = { onSelectBlue(boxer) },
                )
            }
        }
    }
}

@Composable
private fun SelectedCorners(red: BoxerProfile?, blue: BoxerProfile?) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        CornerSummary("COIN ROUGE", red, Modifier.weight(1f))
        CornerSummary("COIN BLEU", blue, Modifier.weight(1f))
    }
}

@Composable
private fun CornerSummary(label: String, profile: BoxerProfile?, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(3.dp))
            Text(
                text = profile?.name ?: "À sélectionner",
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = profile?.nickname ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun BoxerSelectionRow(
    profile: BoxerProfile,
    selectedRed: Boolean,
    selectedBlue: Boolean,
    onSelectRed: () -> Unit,
    onSelectBlue: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .semantics {
                contentDescription = "${profile.name}, ${profile.nickname}, style ${profile.style.name.lowercase()}"
            },
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(profile.name, fontWeight = FontWeight.Black)
                    Text(
                        "${profile.nickname} · ${profile.stance.name.lowercase()} · ${profile.style.name.lowercase()}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Text(
                    text = "${profile.heightCm} cm · ${profile.reachCm} cm",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CornerChoice(
                    label = if (selectedRed) "ROUGE ✓" else "CHOISIR ROUGE",
                    selected = selectedRed,
                    enabled = !selectedBlue,
                    onClick = onSelectRed,
                    modifier = Modifier.weight(1f),
                )
                CornerChoice(
                    label = if (selectedBlue) "BLEU ✓" else "CHOISIR BLEU",
                    selected = selectedBlue,
                    enabled = !selectedRed,
                    onClick = onSelectBlue,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun CornerChoice(
    label: String,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier
            .height(44.dp)
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Black,
                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
