package titlefight.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import titlefight.BoxerProfile
import titlefight.CareerBoutOutcome
import titlefight.CareerEngine
import titlefight.CareerOpponent
import titlefight.CareerState
import titlefight.FightResultKind
import titlefight.FighterCorner
import titlefight.InteractiveFightSession
import titlefight.Tactic
import titlefight.TrainingFocus
import titlefight.data.local.AndroidBoxerRepository
import titlefight.ui.compose.InteractiveFightCoordinator
import titlefight.ui.compose.TitleFightScreen
import titlefight.ui.compose.TitleFightTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TitleFightTheme(darkTheme = true) {
                TitleFightDemoApp()
            }
        }
    }
}

object DemoFightFactory {
    fun coordinator(
        red: BoxerProfile,
        blue: BoxerProfile,
        seed: Long = 6_202_607_21L,
    ): InteractiveFightCoordinator = InteractiveFightCoordinator(
        InteractiveFightSession(
            red = red,
            blue = blue,
            redTactics = tacticsFor(red),
            blueTactics = tacticsFor(blue),
            seed = seed xor red.id.hashCode().toLong() xor (blue.id.hashCode().toLong() shl 1),
            playerCorner = FighterCorner.RED,
        ),
    )

    private fun tacticsFor(profile: BoxerProfile): List<Tactic> = when (profile.style) {
        titlefight.BoxingStyle.OUT_BOXER -> listOf(Tactic.CONTROL, Tactic.COUNTER, Tactic.RECOVER)
        titlefight.BoxingStyle.PRESSURE_FIGHTER -> listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)
        titlefight.BoxingStyle.COUNTERPUNCHER -> listOf(Tactic.COUNTER, Tactic.CONTROL, Tactic.COUNTER)
        titlefight.BoxingStyle.BOXER_PUNCHER -> listOf(Tactic.CONTROL, Tactic.PRESS, Tactic.SEEK_KO)
        titlefight.BoxingStyle.SWARMER -> listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.SEEK_KO)
        titlefight.BoxingStyle.SLUGGER -> listOf(Tactic.CONTROL, Tactic.PRESS, Tactic.SEEK_KO)
        titlefight.BoxingStyle.DEFENSIVE_SPECIALIST -> listOf(Tactic.COUNTER, Tactic.CONTROL, Tactic.RECOVER)
    }
}

private enum class AppPage { HOME, QUICK_FIGHT, CAREER_CREATE, CAREER_DASHBOARD }
private enum class FightOrigin { QUICK, CAREER }

@Composable
fun TitleFightDemoApp() {
    val context = LocalContext.current
    val repository = remember { AndroidBoxerRepository(context.applicationContext) }
    val allProfiles = remember { repository.allProfiles() }
    val databaseVersion = remember { repository.contentVersion() }

    var page by remember { mutableStateOf(AppPage.HOME) }
    var query by remember { mutableStateOf("") }
    var red by remember { mutableStateOf<BoxerProfile?>(allProfiles.firstOrNull()) }
    var blue by remember { mutableStateOf<BoxerProfile?>(allProfiles.getOrNull(1)) }
    var career by remember { mutableStateOf<CareerState?>(null) }
    var careerOpponent by remember { mutableStateOf<CareerOpponent?>(null) }
    var fightOrigin by remember { mutableStateOf(FightOrigin.QUICK) }
    var coordinator by remember { mutableStateOf<InteractiveFightCoordinator?>(null) }
    var viewState by remember { mutableStateOf<titlefight.ui.compose.InteractiveFightViewState?>(null) }

    val activeCoordinator = coordinator
    val activeViewState = viewState
    if (activeCoordinator != null && activeViewState != null) {
        TitleFightScreen(
            state = activeViewState.screenState,
            tacticalSelection = activeViewState.tacticalSelection,
            onTacticalAction = { action ->
                viewState = activeCoordinator.dispatch(action)
            },
            onExitFight = {
                if (fightOrigin == FightOrigin.CAREER) {
                    val currentCareer = requireNotNull(career)
                    val opponent = requireNotNull(careerOpponent)
                    val result = requireNotNull(activeViewState.screenState.result)
                    val outcome = when (result.winnerId) {
                        currentCareer.fighter.id -> CareerBoutOutcome.WIN
                        null -> CareerBoutOutcome.DRAW
                        else -> CareerBoutOutcome.LOSS
                    }
                    val endedByKnockout = result.kind in setOf(FightResultKind.KO, FightResultKind.TKO)
                    career = CareerEngine.applyBout(
                        state = currentCareer,
                        opponent = opponent,
                        outcome = outcome,
                        endedByKnockout = endedByKnockout,
                    )
                    page = AppPage.CAREER_DASHBOARD
                } else {
                    page = AppPage.HOME
                }
                coordinator = null
                viewState = null
                careerOpponent = null
            },
            exitLabel = if (fightOrigin == FightOrigin.CAREER) "VALIDER LE RÉSULTAT" else "RETOUR AU MENU",
        )
        return
    }

    when (page) {
        AppPage.HOME -> HomeScreen(
            rosterCount = allProfiles.size,
            databaseVersion = databaseVersion,
            onQuickFight = {
                query = ""
                page = AppPage.QUICK_FIGHT
            },
            onCareer = {
                page = if (career == null) AppPage.CAREER_CREATE else AppPage.CAREER_DASHBOARD
            },
        )

        AppPage.QUICK_FIGHT -> {
            val filtered = remember(allProfiles, query) {
                val token = query.trim().lowercase()
                if (token.isBlank()) allProfiles else allProfiles.filter {
                    token in it.name.lowercase() || token in it.nickname.lowercase()
                }
            }
            RosterSelectionScreen(
                profiles = filtered,
                query = query,
                red = red,
                blue = blue,
                databaseVersion = databaseVersion,
                onQueryChange = { query = it },
                onSelectRed = { selected ->
                    red = selected
                    if (blue?.id == selected.id) blue = null
                },
                onSelectBlue = { selected ->
                    blue = selected
                    if (red?.id == selected.id) red = null
                },
                onStartFight = {
                    val redProfile = requireNotNull(red)
                    val blueProfile = requireNotNull(blue)
                    fightOrigin = FightOrigin.QUICK
                    val created = DemoFightFactory.coordinator(redProfile, blueProfile)
                    coordinator = created
                    viewState = created.start()
                },
            )
        }

        AppPage.CAREER_CREATE -> CareerCreationScreen(
            onCreate = { request ->
                career = CareerEngine.create(request)
                page = AppPage.CAREER_DASHBOARD
            },
            onBack = { page = AppPage.HOME },
        )

        AppPage.CAREER_DASHBOARD -> {
            val currentCareer = requireNotNull(career)
            CareerDashboardScreen(
                state = currentCareer,
                opponents = if (currentCareer.status == titlefight.CareerStatus.ACTIVE) {
                    CareerEngine.availableOpponents(currentCareer)
                } else {
                    emptyList()
                },
                onFight = { opponent ->
                    fightOrigin = FightOrigin.CAREER
                    careerOpponent = opponent
                    val created = DemoFightFactory.coordinator(
                        red = currentCareer.fighter,
                        blue = opponent.profile,
                        seed = 8_000_000L + currentCareer.week * 100L + opponent.source.collectionId.removePrefix("BOX-").toLong(),
                    )
                    coordinator = created
                    viewState = created.start()
                },
                onTrain = { focus: TrainingFocus -> career = CareerEngine.train(currentCareer, focus) },
                onRest = { career = CareerEngine.restCamp(currentCareer) },
                onMoveDivision = { target -> career = CareerEngine.moveDivision(currentCareer, target) },
                onRetire = { career = CareerEngine.retire(currentCareer) },
                onBack = { page = AppPage.HOME },
            )
        }
    }
}
