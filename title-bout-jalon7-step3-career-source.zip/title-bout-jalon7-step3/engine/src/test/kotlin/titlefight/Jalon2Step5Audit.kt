package titlefight

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

private val FINAL_AUDIT_VEGA_TACTICS = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
private val FINAL_AUDIT_KESSLER_TACTICS = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

data class Jalon2AuditWindow(
    val windowNumber: Int,
    val seedStart: Long,
    val fightCount: Int,
    val knockdowns: Int,
    val recoveredCounts: Int,
    val tenCounts: Int,
    val koCount: Int,
    val tkoCount: Int,
    val distanceCount: Int,
    val redCornerStoppages: Int,
    val blueCornerStoppages: Int,
    val vegaPerformanceLeadsAtDistance: Int,
    val kesslerPerformanceLeadsAtDistance: Int,
    val performanceTiesAtDistance: Int,
) {
    init {
        require(windowNumber >= 1)
        require(fightCount > 0)
        require(koCount + tkoCount + distanceCount == fightCount)
        require(recoveredCounts + tenCounts == knockdowns)
        require(redCornerStoppages + blueCornerStoppages == koCount + tkoCount)
        require(vegaPerformanceLeadsAtDistance + kesslerPerformanceLeadsAtDistance + performanceTiesAtDistance == distanceCount)
    }
}

data class Jalon2FinalAuditResult(
    val windowCount: Int,
    val fightsPerWindow: Int,
    val seedBase: Long,
    val seedStride: Long,
    val windows: List<Jalon2AuditWindow>,
    val knockdowns: Int,
    val recoveredCounts: Int,
    val tenCounts: Int,
    val koCount: Int,
    val tkoCount: Int,
    val distanceCount: Int,
    val redCornerStoppages: Int,
    val blueCornerStoppages: Int,
    val vegaKnockdownsCaused: Int,
    val kesslerKnockdownsCaused: Int,
    val vegaStoppageWins: Int,
    val kesslerStoppageWins: Int,
    val vegaPerformanceLeadsAtDistance: Int,
    val kesslerPerformanceLeadsAtDistance: Int,
    val performanceTiesAtDistance: Int,
    val weakImpactKnockdowns: Int,
    val impactTotal: Double,
    val minimumImpact: Double,
    val maximumImpact: Double,
    val countTotal: Int,
    val minimumCount: Int,
    val maximumCount: Int,
    val knockdownsOnMisses: Int,
    val knockdownsWithoutCount: Int,
    val countsOutsideBounds: Int,
    val invalidKoStoppages: Int,
    val invalidTkoStoppages: Int,
    val fightsContinuingAfterStoppage: Int,
    val eventsAfterStoppage: Int,
) {
    val totalFights: Int get() = windowCount * fightsPerWindow
    val stoppageCount: Int get() = koCount + tkoCount
    val knockdownsPerFight: Double get() = knockdowns.toDouble() / totalFights
    val recoveryRate: Double get() = if (knockdowns == 0) 0.0 else recoveredCounts.toDouble() / knockdowns
    val koRate: Double get() = koCount.toDouble() / totalFights
    val tkoRate: Double get() = tkoCount.toDouble() / totalFights
    val stoppageRate: Double get() = stoppageCount.toDouble() / totalFights
    val weakImpactShare: Double get() = if (knockdowns == 0) 0.0 else weakImpactKnockdowns.toDouble() / knockdowns
    val averageImpact: Double get() = if (knockdowns == 0) 0.0 else impactTotal / knockdowns
    val averageCount: Double get() = if (knockdowns == 0) 0.0 else countTotal.toDouble() / knockdowns
    val redStoppageShare: Double get() = if (stoppageCount == 0) 0.5 else redCornerStoppages.toDouble() / stoppageCount
    val vegaDistanceLeadShare: Double get() = if (distanceCount == 0) 0.0 else vegaPerformanceLeadsAtDistance.toDouble() / distanceCount

    init {
        require(windowCount == 10)
        require(fightsPerWindow == 1000)
        require(windows.size == windowCount)
        require(windows.map { it.windowNumber } == (1..windowCount).toList())
        require(knockdowns == recoveredCounts + tenCounts)
        require(koCount == tenCounts)
        require(koCount + tkoCount + distanceCount == totalFights)
        require(redCornerStoppages + blueCornerStoppages == stoppageCount)
        require(vegaKnockdownsCaused + kesslerKnockdownsCaused == knockdowns)
        require(vegaStoppageWins + kesslerStoppageWins == stoppageCount)
        require(vegaPerformanceLeadsAtDistance + kesslerPerformanceLeadsAtDistance + performanceTiesAtDistance == distanceCount)
        require(minimumImpact > 0.0)
        require(maximumImpact >= minimumImpact)
        require(minimumCount in 1..10)
        require(maximumCount in 1..10)
    }
}

object Jalon2FinalAuditor {
    const val WINDOW_COUNT = 10
    const val FIGHTS_PER_WINDOW = 1000
    const val WEAK_IMPACT_LIMIT = 7.0

    fun run(
        seedBase: Long = 202607210000L,
        seedStride: Long = 100000L,
    ): Jalon2FinalAuditResult {
        val engine = FightEngine()
        val windows = mutableListOf<Jalon2AuditWindow>()

        var knockdowns = 0
        var recoveredCounts = 0
        var tenCounts = 0
        var koCount = 0
        var tkoCount = 0
        var distanceCount = 0
        var redCornerStoppages = 0
        var blueCornerStoppages = 0
        var vegaKnockdownsCaused = 0
        var kesslerKnockdownsCaused = 0
        var vegaStoppageWins = 0
        var kesslerStoppageWins = 0
        var vegaPerformanceLeadsAtDistance = 0
        var kesslerPerformanceLeadsAtDistance = 0
        var performanceTiesAtDistance = 0
        var weakImpactKnockdowns = 0
        var impactTotal = 0.0
        var minimumImpact = Double.POSITIVE_INFINITY
        var maximumImpact = 0.0
        var countTotal = 0
        var minimumCount = 10
        var maximumCount = 1
        var knockdownsOnMisses = 0
        var knockdownsWithoutCount = 0
        var countsOutsideBounds = 0
        var invalidKoStoppages = 0
        var invalidTkoStoppages = 0
        var fightsContinuingAfterStoppage = 0
        var eventsAfterStoppage = 0

        repeat(WINDOW_COUNT) { windowIndex ->
            val windowSeedStart = seedBase + windowIndex * seedStride
            var windowKnockdowns = 0
            var windowRecovered = 0
            var windowTenCounts = 0
            var windowKo = 0
            var windowTko = 0
            var windowDistance = 0
            var windowRedStoppages = 0
            var windowBlueStoppages = 0
            var windowVegaLeads = 0
            var windowKesslerLeads = 0
            var windowTies = 0

            repeat(FIGHTS_PER_WINDOW) { fightIndex ->
                val globalIndex = windowIndex * FIGHTS_PER_WINDOW + fightIndex
                val vegaInRedCorner = globalIndex % 2 == 0
                val seed = windowSeedStart + fightIndex
                val fight = if (vegaInRedCorner) {
                    engine.simulateThreeRoundFight(
                        red = TestProfiles.eliasVega,
                        blue = TestProfiles.brunoKessler,
                        redTactics = FINAL_AUDIT_VEGA_TACTICS,
                        blueTactics = FINAL_AUDIT_KESSLER_TACTICS,
                        seed = seed,
                    )
                } else {
                    engine.simulateThreeRoundFight(
                        red = TestProfiles.brunoKessler,
                        blue = TestProfiles.eliasVega,
                        redTactics = FINAL_AUDIT_KESSLER_TACTICS,
                        blueTactics = FINAL_AUDIT_VEGA_TACTICS,
                        seed = seed,
                    )
                }

                val allEvents = fight.rounds.flatMap { it.events }
                allEvents.forEach { event ->
                    val kd = event.knockdown ?: return@forEach
                    knockdowns++
                    windowKnockdowns++
                    if (!event.landed) knockdownsOnMisses++
                    val count = kd.refereeCount
                    if (count == null) {
                        knockdownsWithoutCount++
                    } else {
                        if (count.countReached !in 1..10) countsOutsideBounds++
                        countTotal += count.countReached
                        minimumCount = minOf(minimumCount, count.countReached)
                        maximumCount = maxOf(maximumCount, count.countReached)
                        if (count.recovered) {
                            recoveredCounts++
                            windowRecovered++
                        } else {
                            tenCounts++
                            windowTenCounts++
                        }
                    }
                    when (kd.attackerId) {
                        TestProfiles.eliasVega.id -> vegaKnockdownsCaused++
                        TestProfiles.brunoKessler.id -> kesslerKnockdownsCaused++
                        else -> error("Auteur de chute inconnu : ${kd.attackerId}")
                    }
                    impactTotal += kd.impact
                    minimumImpact = minOf(minimumImpact, kd.impact)
                    maximumImpact = maxOf(maximumImpact, kd.impact)
                    if (kd.impact < WEAK_IMPACT_LIMIT) weakImpactKnockdowns++
                }

                val stoppage = fight.stoppage
                if (stoppage == null) {
                    distanceCount++
                    windowDistance++
                    val vegaPerformance = if (vegaInRedCorner) fight.redPerformanceTotal else fight.bluePerformanceTotal
                    val kesslerPerformance = if (vegaInRedCorner) fight.bluePerformanceTotal else fight.redPerformanceTotal
                    when {
                        vegaPerformance > kesslerPerformance + 1e-9 -> {
                            vegaPerformanceLeadsAtDistance++
                            windowVegaLeads++
                        }
                        kesslerPerformance > vegaPerformance + 1e-9 -> {
                            kesslerPerformanceLeadsAtDistance++
                            windowKesslerLeads++
                        }
                        else -> {
                            performanceTiesAtDistance++
                            windowTies++
                        }
                    }
                } else {
                    when (stoppage.method) {
                        FightMethod.KO -> {
                            koCount++
                            windowKo++
                            val finalEvent = fight.rounds.last().events.last()
                            if (finalEvent.knockdown?.refereeCount?.countReached != 10 ||
                                stoppage.winnerId != finalEvent.attackerId ||
                                stoppage.loserId != finalEvent.defenderId
                            ) invalidKoStoppages++
                        }
                        FightMethod.TKO -> {
                            tkoCount++
                            windowTko++
                            val finalRound = fight.rounds.last()
                            val finalEvent = finalRound.events.last()
                            val loserState = if (stoppage.loserId == fight.redId) finalRound.redState else finalRound.blueState
                            val evaluation = TkoSafetyDetector.evaluate(loserState, finalEvent)
                            if (!evaluation.eligible || finalEvent.knockdown != null ||
                                stoppage.winnerId != finalEvent.attackerId ||
                                stoppage.loserId != finalEvent.defenderId
                            ) invalidTkoStoppages++
                        }
                    }
                    if (stoppage.winnerId == fight.redId) {
                        redCornerStoppages++
                        windowRedStoppages++
                    } else {
                        blueCornerStoppages++
                        windowBlueStoppages++
                    }
                    when (stoppage.winnerId) {
                        TestProfiles.eliasVega.id -> vegaStoppageWins++
                        TestProfiles.brunoKessler.id -> kesslerStoppageWins++
                        else -> error("Vainqueur d’arrêt inconnu : ${stoppage.winnerId}")
                    }

                    val lastRound = fight.rounds.last()
                    if (lastRound.roundNumber != stoppage.roundNumber ||
                        lastRound.events.lastOrNull()?.sequenceNumber != stoppage.sequenceNumber
                    ) fightsContinuingAfterStoppage++
                    eventsAfterStoppage += fight.rounds
                        .filter { it.roundNumber > stoppage.roundNumber }
                        .sumOf { it.events.size }
                    eventsAfterStoppage += lastRound.events.count { it.sequenceNumber > stoppage.sequenceNumber }
                }
            }

            windows += Jalon2AuditWindow(
                windowNumber = windowIndex + 1,
                seedStart = windowSeedStart,
                fightCount = FIGHTS_PER_WINDOW,
                knockdowns = windowKnockdowns,
                recoveredCounts = windowRecovered,
                tenCounts = windowTenCounts,
                koCount = windowKo,
                tkoCount = windowTko,
                distanceCount = windowDistance,
                redCornerStoppages = windowRedStoppages,
                blueCornerStoppages = windowBlueStoppages,
                vegaPerformanceLeadsAtDistance = windowVegaLeads,
                kesslerPerformanceLeadsAtDistance = windowKesslerLeads,
                performanceTiesAtDistance = windowTies,
            )
        }

        return Jalon2FinalAuditResult(
            windowCount = WINDOW_COUNT,
            fightsPerWindow = FIGHTS_PER_WINDOW,
            seedBase = seedBase,
            seedStride = seedStride,
            windows = windows,
            knockdowns = knockdowns,
            recoveredCounts = recoveredCounts,
            tenCounts = tenCounts,
            koCount = koCount,
            tkoCount = tkoCount,
            distanceCount = distanceCount,
            redCornerStoppages = redCornerStoppages,
            blueCornerStoppages = blueCornerStoppages,
            vegaKnockdownsCaused = vegaKnockdownsCaused,
            kesslerKnockdownsCaused = kesslerKnockdownsCaused,
            vegaStoppageWins = vegaStoppageWins,
            kesslerStoppageWins = kesslerStoppageWins,
            vegaPerformanceLeadsAtDistance = vegaPerformanceLeadsAtDistance,
            kesslerPerformanceLeadsAtDistance = kesslerPerformanceLeadsAtDistance,
            performanceTiesAtDistance = performanceTiesAtDistance,
            weakImpactKnockdowns = weakImpactKnockdowns,
            impactTotal = impactTotal,
            minimumImpact = minimumImpact,
            maximumImpact = maximumImpact,
            countTotal = countTotal,
            minimumCount = minimumCount,
            maximumCount = maximumCount,
            knockdownsOnMisses = knockdownsOnMisses,
            knockdownsWithoutCount = knockdownsWithoutCount,
            countsOutsideBounds = countsOutsideBounds,
            invalidKoStoppages = invalidKoStoppages,
            invalidTkoStoppages = invalidTkoStoppages,
            fightsContinuingAfterStoppage = fightsContinuingAfterStoppage,
            eventsAfterStoppage = eventsAfterStoppage,
        )
    }

    fun assertAcceptable(result: Jalon2FinalAuditResult) {
        check(result.totalFights == 10_000)
        check(result.knockdownsOnMisses == 0)
        check(result.knockdownsWithoutCount == 0)
        check(result.countsOutsideBounds == 0)
        check(result.invalidKoStoppages == 0)
        check(result.invalidTkoStoppages == 0)
        check(result.fightsContinuingAfterStoppage == 0)
        check(result.eventsAfterStoppage == 0)

        // Bandes d'acceptation internes à ce duel de trois rounds, pas statistiques historiques universelles.
        check(result.knockdownsPerFight in 0.30..0.70) {
            "Fréquence de chute hors bande interne : ${result.knockdownsPerFight}"
        }
        check(result.weakImpactShare <= 0.01) {
            "Trop de chutes sous ${WEAK_IMPACT_LIMIT} points d'impact : ${result.weakImpactShare}"
        }
        check(result.koRate in 0.0005..0.01) { "Fréquence KO hors bande interne : ${result.koRate}" }
        check(result.tkoRate in 0.0005..0.02) { "Fréquence TKO hors bande interne : ${result.tkoRate}" }
        check(result.stoppageRate <= 0.03) { "Trop d'arrêts sur trois rounds : ${result.stoppageRate}" }
        check(abs(result.redStoppageShare - 0.5) <= 0.15) {
            "Biais de coin excessif sur les arrêts : ${result.redStoppageShare}"
        }
        check(result.vegaDistanceLeadShare in 0.35..0.65) {
            "Domination interne excessive dans les combats allant au terme : ${result.vegaDistanceLeadShare}"
        }
    }
}

object Jalon2FinalAuditFormatter {
    fun format(result: Jalon2FinalAuditResult): String = buildString {
        appendLine("TITLE FIGHT — Jalon 2, étape 5")
        appendLine("Audit statistique final multi-fenêtres")
        appendLine()
        appendLine("ÉCHANTILLON")
        appendLine("Fenêtres indépendantes : ${result.windowCount}")
        appendLine("Combats par fenêtre : ${result.fightsPerWindow}")
        appendLine("Combats totaux : ${result.totalFights}")
        appendLine("Coins alternés à parts égales : oui")
        appendLine()
        appendLine("CHUTES ET COMPTES")
        appendLine("Chutes : ${result.knockdowns} (${decimal(result.knockdownsPerFight)} par combat)")
        appendLine("Relèvements : ${result.recoveredCounts}")
        appendLine("Comptes à 10 : ${result.tenCounts}")
        appendLine("Taux de relèvement : ${percent(result.recoveryRate)}")
        appendLine("Compte moyen : ${decimal(result.averageCount)}")
        appendLine("Compte min / max : ${result.minimumCount} / ${result.maximumCount}")
        appendLine("Impact moyen : ${decimal(result.averageImpact)}")
        appendLine("Impact min / max : ${decimal(result.minimumImpact)} / ${decimal(result.maximumImpact)}")
        appendLine("Chutes sous ${decimal(Jalon2FinalAuditor.WEAK_IMPACT_LIMIT)} d'impact : ${result.weakImpactKnockdowns} (${percent(result.weakImpactShare)})")
        appendLine("Chutes sur attaque manquée : ${result.knockdownsOnMisses}")
        appendLine("Chutes sans compte : ${result.knockdownsWithoutCount}")
        appendLine()
        appendLine("ISSUES")
        appendLine("KO : ${result.koCount} (${percent(result.koRate)})")
        appendLine("TKO : ${result.tkoCount} (${percent(result.tkoRate)})")
        appendLine("Sans arrêt après 3 rounds : ${result.distanceCount}")
        appendLine("Taux total d'arrêt : ${percent(result.stoppageRate)}")
        appendLine("Arrêts coin rouge / bleu : ${result.redCornerStoppages} / ${result.blueCornerStoppages}")
        appendLine("Arrêts Elias Vega / Bruno Kessler : ${result.vegaStoppageWins} / ${result.kesslerStoppageWins}")
        appendLine("Chutes causées Elias Vega / Bruno Kessler : ${result.vegaKnockdownsCaused} / ${result.kesslerKnockdownsCaused}")
        appendLine()
        appendLine("COMBATS ALLANT AU TERME, INDICATEUR INTERNE SANS JUGES")
        appendLine("Avantages Elias Vega : ${result.vegaPerformanceLeadsAtDistance}")
        appendLine("Avantages Bruno Kessler : ${result.kesslerPerformanceLeadsAtDistance}")
        appendLine("Égalités numériques : ${result.performanceTiesAtDistance}")
        appendLine("Part d'avantages Vega : ${percent(result.vegaDistanceLeadShare)}")
        appendLine("Ces valeurs ne constituent pas des décisions officielles.")
        appendLine()
        appendLine("GARDE-FOUS")
        appendLine("Comptes hors bornes : ${result.countsOutsideBounds}")
        appendLine("KO invalides : ${result.invalidKoStoppages}")
        appendLine("TKO invalides : ${result.invalidTkoStoppages}")
        appendLine("Combats poursuivis après arrêt : ${result.fightsContinuingAfterStoppage}")
        appendLine("Événements après arrêt : ${result.eventsAfterStoppage}")
        appendLine()
        appendLine("SEUILS TKO APRÈS MICRO-RÉGLAGE")
        appendLine("Échecs défensifs consécutifs : au moins ${TkoSafetyDetector.MIN_FAILURE_STREAK}")
        appendLine("Stabilité : au plus ${decimal(TkoSafetyDetector.MAX_STABILITY)}")
        appendLine("Énergie : au plus ${decimal(TkoSafetyDetector.MAX_STAMINA)}")
        appendLine("Dégâts tête : au moins ${decimal(TkoSafetyDetector.MIN_HEAD_DAMAGE)}")
        appendLine("Dégâts corps : au moins ${decimal(TkoSafetyDetector.MIN_BODY_DAMAGE)}")
        appendLine()
        appendLine("DÉCISION")
        appendLine("Les bandes d'acceptation internes sont respectées. Le jalon 2 peut être validé.")
        appendLine("Aucun juge, écran Android ou APK n'a été ajouté.")
    }

    fun csv(result: Jalon2FinalAuditResult): String = buildString {
        appendLine("window,seed_start,fights,knockdowns,recovered,ten_counts,ko,tko,distance,red_stoppages,blue_stoppages,vega_distance_leads,kessler_distance_leads,ties")
        result.windows.forEach { window ->
            appendLine(listOf(
                window.windowNumber,
                window.seedStart,
                window.fightCount,
                window.knockdowns,
                window.recoveredCounts,
                window.tenCounts,
                window.koCount,
                window.tkoCount,
                window.distanceCount,
                window.redCornerStoppages,
                window.blueCornerStoppages,
                window.vegaPerformanceLeadsAtDistance,
                window.kesslerPerformanceLeadsAtDistance,
                window.performanceTiesAtDistance,
            ).joinToString(","))
        }
    }

    private fun decimal(value: Double): String = String.format(Locale.US, "%.2f", value)
    private fun percent(value: Double): String = String.format(Locale.US, "%.2f %%", value * 100.0)
}

object Jalon2FinalAuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon2FinalAuditor.run()
        Jalon2FinalAuditor.assertAcceptable(result)
        println(Jalon2FinalAuditFormatter.format(result))
    }
}

object Jalon2FinalAuditCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon2FinalAuditor.run()
        Jalon2FinalAuditor.assertAcceptable(result)
        print(Jalon2FinalAuditFormatter.csv(result))
    }
}
