package titlefight

object NeutralJudgeStep2Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val fight = FightEngine().simulateThreeRoundFight(
            red = TestProfiles.eliasVega,
            blue = TestProfiles.brunoKessler,
            redTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER),
            blueTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS),
            seed = 202607230123L,
        )

        println("TITLE FIGHT — DÉMONSTRATION DU JUGE NEUTRE")
        println("${TestProfiles.eliasVega.name} contre ${TestProfiles.brunoKessler.name}")
        println("Graine : ${fight.seed}")
        println()
        fight.rounds.forEach { round ->
            val score = round.neutralJudgeScore
            if (score == null) {
                println("Round ${round.roundNumber} : non jugé (${round.stoppage?.method}).")
            } else {
                println("Round ${round.roundNumber} : ${score.redPoints}-${score.bluePoints}")
                println("  ${score.explanation}")
                println("  Facteurs : ${score.decisiveFactors.joinToString()}")
            }
        }
        println()
        println("Aucun total de carte et aucune décision officielle ne sont calculés.")
    }
}
