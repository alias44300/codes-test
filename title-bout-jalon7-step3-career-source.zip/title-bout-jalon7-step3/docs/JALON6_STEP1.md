# Jalon 6 — Étape 1 — Contrat d’état de l’écran de combat

## Objectif

Créer un contrat d’interface immuable et testable en Kotlin pur pour le futur écran Android, sans dépendance Compose et sans modification des probabilités du moteur.

## Production ajoutée

- `SequenceStateFrame` : état physique observationnel exact après chaque séquence.
- `FightScreenState` : état complet de l’écran.
- `FighterScreenState` : énergie, fatigue, dégâts, stabilité, coups et état critique.
- `TacticalPlanScreenState` : rythme, distance, cible, risque et explication.
- `FightActionScreenState` : attaque courante, portée, coup, impact et compte.
- `FightResultScreenState` : KO, TKO, décision ou nul sans cartes détaillées des juges.
- `FightScreenStateMapper` : timeline précombat, séquences, entre-rounds et résultat.
- `FightCommentaryFormatter` : commentaires courts et déterministes.

## Garanties

- Aucun tirage aléatoire supplémentaire.
- Aucun changement des probabilités, des juges, des KO ou des TKO.
- Une observation exacte est enregistrée après chaque séquence.
- La fenêtre tactique n’est ouverte qu’entre les rounds.
- Les cartes exactes et totaux individuels des juges ne figurent dans aucun état d’écran.
- Le résultat officiel n’est exposé qu’à la fin.
- Même combat et même graine produisent la même timeline d’écran.

## Hors périmètre

- Aucun composant Jetpack Compose.
- Aucune interaction tactile.
- Aucune animation.
- Aucun SDK Android.
- Aucun APK.
