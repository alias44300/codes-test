# Jalon 6 — Étape 3 — Composants Jetpack Compose

## Objectif

Traduire la maquette statique validée en composants Jetpack Compose qui consomment exclusivement `FightScreenState`, sans interaction tactique active et sans modification du moteur.

## Module ajouté

`android-ui-compose/` contient :

- `TitleFightScreen`, point d’entrée unique ;
- la hiérarchie Compose du scoreboard, des deux coins, de l’action, des commentaires, du journal, des tactiques et du résultat ;
- `FightScreenLayoutPolicy`, contrat responsive pur Kotlin ;
- `FightScreenPresentationMapper`, règles de visibilité par phase ;
- `FightScreenAccessibility`, descriptions vocales déterministes ;
- `FightScreenPreviewFixtures`, trois états factices valides ;
- cinq aperçus Compose aux formats 320 × 720, 360 × 800 et 412 × 915 ;
- `FightScreenTimelineAdapter`, délégation explicite vers `FightScreenStateMapper`.

## Redimensionnement

Trois classes de largeur sont conservées :

- compact : moins de 340 dp ;
- standard : 340 à 399 dp ;
- étendu : 400 dp et plus.

Les marges, espaces, tailles minimales de texte, largeurs des fiches et futures cibles tactiles reprennent les valeurs verrouillées lors de l’étape 2.

## Accessibilité

- résumé complet de l’écran ;
- description fusionnée de chaque boxeur ;
- sémantique de progression pour énergie, tête, corps et stabilité ;
- titres de sections et résultat officiel explicitement annoncés ;
- futurs contrôles tactiques dimensionnés à 44 ou 48 dp ;
- aucune carte exacte de juge dans les composants ou descriptions.

## Limites de l’étape

- les axes tactiques sont affichés en lecture seule ;
- aucun `onClick` et aucun `Modifier.clickable` ;
- aucun appel réseau ;
- aucune simulation déclenchée depuis un composant ;
- aucune compilation Android réelle, car le SDK, Gradle et le plugin Compose ne sont pas présents dans l’environnement ;
- aucun APK.

## Vérifications locales

Le code pur Kotlin du contrat, des fixtures et de l’adaptateur est compilé avec le moteur. Les fichiers Compose sont contrôlés par audit statique puis par une compilation syntaxique contre des stubs locaux reproduisant les signatures utilisées. Cette compilation syntaxique détecte les erreurs Kotlin, mais ne remplace pas l’étape 5 avec le véritable SDK Android.
