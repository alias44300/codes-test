package titlefight

import kotlin.math.abs

data class TacticalFinalWindowResult(
    val window: Int,
    val adaptiveFights: Int,
    val fixedNaturalFights: Int,
    val adaptiveRedWins: Int,
    val adaptiveBlueWins: Int,
    val adaptiveDraws: Int,
    val adaptiveVegaWins: Int,
    val adaptiveKesslerWins: Int,
    val adaptiveStops: Int,
    val fixedVegaWins: Int,
    val fixedKesslerWins: Int,
    val fixedDraws: Int,
    val fixedStops: Int,
    val pairedOutcomeChanges: Int,
    val changedBetweenRoundDecisions: Int,
)

data class FixedPlanBenchmarkResult(
    val presetId: String,
    val fighterId: String,
    val fights: Int,
    val wins: Int,
    val losses: Int,
    val draws: Int,
    val stoppageWins: Int,
) {
    val winShare: Double get() = if (fights == 0) 0.0 else wins.toDouble() / fights
    val nonDrawWinShare: Double get() = if (wins + losses == 0) 0.5 else wins.toDouble() / (wins + losses)
}

data class Jalon4FinalAuditResult(
    val windows: List<TacticalFinalWindowResult>,
    val adaptiveFights: Int,
    val fixedNaturalFights: Int,
    val adaptiveRedWins: Int,
    val adaptiveBlueWins: Int,
    val adaptiveDraws: Int,
    val adaptiveVegaWins: Int,
    val adaptiveKesslerWins: Int,
    val adaptiveStops: Int,
    val adaptiveKo: Int,
    val adaptiveTko: Int,
    val fixedVegaWins: Int,
    val fixedKesslerWins: Int,
    val fixedDraws: Int,
    val fixedStops: Int,
    val pairedOutcomeChanges: Int,
    val reproducibilityChecks: Int,
    val reproducibilityMismatches: Int,
    val invalidAdaptiveResults: Int,
    val decisionsAfterStoppage: Int,
    val missingAppliedPlans: Int,
    val planDecisionMismatches: Int,
    val trailingOpportunities: Int,
    val trailingResponses: Int,
    val fatigueOpportunities: Int,
    val fatigueResponses: Int,
    val dangerOpportunities: Int,
    val dangerResponses: Int,
    val changedBetweenRoundDecisions: Int,
    val betweenRoundDecisions: Int,
    val planCountsByFighter: Map<String, Map<String, Int>>,
    val winsByProfileAndCorner: Map<String, Map<String, Int>>,
    val appearancesByProfileAndCorner: Map<String, Map<String, Int>>,
    val fixedPlanBenchmarks: List<FixedPlanBenchmarkResult>,
    val legacyBehaviorFingerprintMismatches: Int,
) {
    val adaptiveRedWinnerShare: Double
        get() = ratio(adaptiveRedWins, adaptiveRedWins + adaptiveBlueWins)
    val pairedOutcomeChangeShare: Double
        get() = ratio(pairedOutcomeChanges, fixedNaturalFights)
    val trailingResponseRate: Double
        get() = ratioOrOne(trailingResponses, trailingOpportunities)
    val fatigueResponseRate: Double
        get() = ratioOrOne(fatigueResponses, fatigueOpportunities)
    val dangerResponseRate: Double
        get() = ratioOrOne(dangerResponses, dangerOpportunities)
    val tacticalChangeShare: Double
        get() = ratio(changedBetweenRoundDecisions, betweenRoundDecisions)
    val adaptiveVegaWinShare: Double
        get() = ratio(adaptiveVegaWins, adaptiveFights)
    val fixedVegaWinShare: Double
        get() = ratio(fixedVegaWins, fixedNaturalFights)

    fun profileCornerWinShare(profileId: String, corner: String): Double {
        val wins = winsByProfileAndCorner[profileId]?.get(corner) ?: 0
        val appearances = appearancesByProfileAndCorner[profileId]?.get(corner) ?: 0
        return ratio(wins, appearances)
    }

    fun topBetweenRoundPlanShare(profileId: String): Double {
        val counts = planCountsByFighter[profileId].orEmpty()
        val total = counts.values.sum()
        return if (total == 0) 0.0 else counts.values.maxOrNull()!!.toDouble() / total
    }

    fun distinctBetweenRoundPlans(profileId: String): Int =
        planCountsByFighter[profileId].orEmpty().count { it.value > 0 }

    fun bestBenchmark(profileId: String): FixedPlanBenchmarkResult =
        fixedPlanBenchmarks.filter { it.fighterId == profileId }
            .maxWith(compareBy<FixedPlanBenchmarkResult> { it.winShare }.thenBy { it.presetId })

    private fun ratio(value: Int, total: Int): Double = if (total == 0) 0.0 else value.toDouble() / total
    private fun ratioOrOne(value: Int, total: Int): Double = if (total == 0) 1.0 else value.toDouble() / total
}

private data class FixedPlanFightOutcome(
    val redId: String,
    val blueId: String,
    val rounds: List<RoundResult>,
    val stoppage: FightStoppage?,
    val officialDecision: OfficialDecision?,
) {
    val winnerId: String? get() = stoppage?.winnerId ?: officialDecision?.winnerId
    val methodLabel: String get() = stoppage?.method?.name ?: officialDecision?.type?.name ?: "NONE"
}

private object FixedPlanFightSimulator {
    fun simulate(
        red: BoxerProfile,
        blue: BoxerProfile,
        redTactics: List<Tactic>,
        blueTactics: List<Tactic>,
        redPlan: TacticalPlan,
        bluePlan: TacticalPlan,
        seed: Long,
    ): FixedPlanFightOutcome {
        val engine = FightEngine(adaptiveTacticsEnabled = true)
        val seedStream = DeterministicRandom(seed)
        var redState = FighterState()
        var blueState = FighterState()
        val rounds = mutableListOf<RoundResult>()
        for (index in 0 until 3) {
            val round = engine.simulateRound(
                roundNumber = index + 1,
                red = red,
                blue = blue,
                redStart = redState,
                blueStart = blueState,
                redTactic = redTactics[index],
                blueTactic = blueTactics[index],
                seed = seedStream.nextLong(),
                redPlan = redPlan,
                bluePlan = bluePlan,
            )
            rounds += round
            redState = round.redState
            blueState = round.blueState
            if (round.stoppage != null) break
        }
        val stoppage = rounds.last().stoppage
        val decision = if (stoppage == null) OfficialDecisionResolver.resolve(red.id, blue.id, rounds) else null
        return FixedPlanFightOutcome(red.id, blue.id, rounds, stoppage, decision)
    }
}

object Jalon4FinalAuditor {
    private const val WINDOW_COUNT = 10
    private const val FIGHTS_PER_WINDOW = 1_000
    private const val PAIRS_PER_WINDOW = FIGHTS_PER_WINDOW / 2
    private const val FIXED_COMPARISON_PAIRS_PER_WINDOW = 100
    private const val REPRO_PAIRS_PER_WINDOW = 10
    private const val BENCHMARK_FIGHTS_PER_PROFILE_AND_PRESET = 50

    private val vegaTactics = listOf(Tactic.CONTROL, Tactic.CONTROL, Tactic.RECOVER)
    private val kesslerTactics = listOf(Tactic.PRESS, Tactic.BODY_WORK, Tactic.PRESS)

    private data class Setup(
        val red: BoxerProfile,
        val blue: BoxerProfile,
        val redTactics: List<Tactic>,
        val blueTactics: List<Tactic>,
    )

    private data class MutableTotals(
        var adaptiveFights: Int = 0,
        var fixedFights: Int = 0,
        var redWins: Int = 0,
        var blueWins: Int = 0,
        var draws: Int = 0,
        var vegaWins: Int = 0,
        var kesslerWins: Int = 0,
        var adaptiveStops: Int = 0,
        var adaptiveKo: Int = 0,
        var adaptiveTko: Int = 0,
        var fixedVegaWins: Int = 0,
        var fixedKesslerWins: Int = 0,
        var fixedDraws: Int = 0,
        var fixedStops: Int = 0,
        var outcomeChanges: Int = 0,
        var reproChecks: Int = 0,
        var reproMismatches: Int = 0,
        var invalidResults: Int = 0,
        var decisionsAfterStop: Int = 0,
        var missingPlans: Int = 0,
        var planMismatches: Int = 0,
        var trailingOpportunities: Int = 0,
        var trailingResponses: Int = 0,
        var fatigueOpportunities: Int = 0,
        var fatigueResponses: Int = 0,
        var dangerOpportunities: Int = 0,
        var dangerResponses: Int = 0,
        var changedBetweenRounds: Int = 0,
        var betweenRoundDecisions: Int = 0,
    )

    fun run(seedStart: Long = 202607212000L): Jalon4FinalAuditResult {
        val adaptiveEngine = FightEngine(adaptiveTacticsEnabled = true)
        val totals = MutableTotals()
        val windowResults = mutableListOf<TacticalFinalWindowResult>()
        val planCounts = mutableMapOf<String, MutableMap<String, Int>>()
        val winsByProfileCorner = mutableMapOf<String, MutableMap<String, Int>>()
        val appearancesByProfileCorner = mutableMapOf<String, MutableMap<String, Int>>()

        repeat(WINDOW_COUNT) { windowIndex ->
            val before = totals.copy()
            repeat(PAIRS_PER_WINDOW) { pairIndex ->
                val seed = seedStart + windowIndex * 100_000L + pairIndex
                listOf(true, false).forEach { vegaInRed ->
                    val setup = setup(vegaInRed)
                    val adaptive = adaptiveEngine.simulateThreeRoundFight(
                        red = setup.red,
                        blue = setup.blue,
                        redTactics = setup.redTactics,
                        blueTactics = setup.blueTactics,
                        seed = seed,
                    )
                    collectAdaptive(adaptive, setup, totals, planCounts, winsByProfileCorner, appearancesByProfileCorner)

                    if (pairIndex < FIXED_COMPARISON_PAIRS_PER_WINDOW) {
                        val fixed = FixedPlanFightSimulator.simulate(
                            red = setup.red,
                            blue = setup.blue,
                            redTactics = setup.redTactics,
                            blueTactics = setup.blueTactics,
                            redPlan = TacticalPlanCatalog.naturalFor(setup.red),
                            bluePlan = TacticalPlanCatalog.naturalFor(setup.blue),
                            seed = seed,
                        )
                        collectFixed(fixed, totals)
                        if (outcomeSignature(adaptive) != outcomeSignature(fixed)) totals.outcomeChanges++

                        if (pairIndex < REPRO_PAIRS_PER_WINDOW) {
                        val repeatedAdaptive = adaptiveEngine.simulateThreeRoundFight(
                            red = setup.red,
                            blue = setup.blue,
                            redTactics = setup.redTactics,
                            blueTactics = setup.blueTactics,
                            seed = seed,
                        )
                        totals.reproChecks++
                        if (repeatedAdaptive != adaptive) totals.reproMismatches++
                        val repeatedFixed = FixedPlanFightSimulator.simulate(
                            red = setup.red,
                            blue = setup.blue,
                            redTactics = setup.redTactics,
                            blueTactics = setup.blueTactics,
                            redPlan = TacticalPlanCatalog.naturalFor(setup.red),
                            bluePlan = TacticalPlanCatalog.naturalFor(setup.blue),
                            seed = seed,
                        )
                        totals.reproChecks++
                        if (repeatedFixed != fixed) totals.reproMismatches++
                        }
                    } else if (pairIndex < REPRO_PAIRS_PER_WINDOW) {
                        error("La fenêtre de comparaison fixe doit couvrir les paires de reproductibilité.")
                    }
                }
            }
            windowResults += TacticalFinalWindowResult(
                window = windowIndex + 1,
                adaptiveFights = totals.adaptiveFights - before.adaptiveFights,
                fixedNaturalFights = totals.fixedFights - before.fixedFights,
                adaptiveRedWins = totals.redWins - before.redWins,
                adaptiveBlueWins = totals.blueWins - before.blueWins,
                adaptiveDraws = totals.draws - before.draws,
                adaptiveVegaWins = totals.vegaWins - before.vegaWins,
                adaptiveKesslerWins = totals.kesslerWins - before.kesslerWins,
                adaptiveStops = totals.adaptiveStops - before.adaptiveStops,
                fixedVegaWins = totals.fixedVegaWins - before.fixedVegaWins,
                fixedKesslerWins = totals.fixedKesslerWins - before.fixedKesslerWins,
                fixedDraws = totals.fixedDraws - before.fixedDraws,
                fixedStops = totals.fixedStops - before.fixedStops,
                pairedOutcomeChanges = totals.outcomeChanges - before.outcomeChanges,
                changedBetweenRoundDecisions = totals.changedBetweenRounds - before.changedBetweenRounds,
            )
        }

        val benchmarks = runFixedPlanBenchmarks(seedStart + 2_000_000L)

        return Jalon4FinalAuditResult(
            windows = windowResults,
            adaptiveFights = totals.adaptiveFights,
            fixedNaturalFights = totals.fixedFights,
            adaptiveRedWins = totals.redWins,
            adaptiveBlueWins = totals.blueWins,
            adaptiveDraws = totals.draws,
            adaptiveVegaWins = totals.vegaWins,
            adaptiveKesslerWins = totals.kesslerWins,
            adaptiveStops = totals.adaptiveStops,
            adaptiveKo = totals.adaptiveKo,
            adaptiveTko = totals.adaptiveTko,
            fixedVegaWins = totals.fixedVegaWins,
            fixedKesslerWins = totals.fixedKesslerWins,
            fixedDraws = totals.fixedDraws,
            fixedStops = totals.fixedStops,
            pairedOutcomeChanges = totals.outcomeChanges,
            reproducibilityChecks = totals.reproChecks,
            reproducibilityMismatches = totals.reproMismatches,
            invalidAdaptiveResults = totals.invalidResults,
            decisionsAfterStoppage = totals.decisionsAfterStop,
            missingAppliedPlans = totals.missingPlans,
            planDecisionMismatches = totals.planMismatches,
            trailingOpportunities = totals.trailingOpportunities,
            trailingResponses = totals.trailingResponses,
            fatigueOpportunities = totals.fatigueOpportunities,
            fatigueResponses = totals.fatigueResponses,
            dangerOpportunities = totals.dangerOpportunities,
            dangerResponses = totals.dangerResponses,
            changedBetweenRoundDecisions = totals.changedBetweenRounds,
            betweenRoundDecisions = totals.betweenRoundDecisions,
            planCountsByFighter = planCounts.mapValues { it.value.toMap() },
            winsByProfileAndCorner = winsByProfileCorner.mapValues { it.value.toMap() },
            appearancesByProfileAndCorner = appearancesByProfileCorner.mapValues { it.value.toMap() },
            fixedPlanBenchmarks = benchmarks,
            legacyBehaviorFingerprintMismatches = LegacyBehaviorFingerprint.verify(),
        )
    }

    fun assertAcceptable(result: Jalon4FinalAuditResult) {
        check(result.windows.size == WINDOW_COUNT)
        check(result.windows.all { it.adaptiveFights == FIGHTS_PER_WINDOW && it.fixedNaturalFights == FIXED_COMPARISON_PAIRS_PER_WINDOW * 2 })
        check(result.adaptiveFights == WINDOW_COUNT * FIGHTS_PER_WINDOW)
        check(result.fixedNaturalFights == WINDOW_COUNT * FIXED_COMPARISON_PAIRS_PER_WINDOW * 2)
        check(result.reproducibilityChecks == WINDOW_COUNT * REPRO_PAIRS_PER_WINDOW * 4)
        check(result.reproducibilityMismatches == 0)
        check(result.invalidAdaptiveResults == 0)
        check(result.decisionsAfterStoppage == 0)
        check(result.missingAppliedPlans == 0)
        check(result.planDecisionMismatches == 0)
        check(result.legacyBehaviorFingerprintMismatches == 0)

        check(result.adaptiveRedWinnerShare in 0.47..0.53)
        check(abs(result.profileCornerWinShare(TestProfiles.eliasVega.id, "RED") - result.profileCornerWinShare(TestProfiles.eliasVega.id, "BLUE")) <= 0.03)
        check(abs(result.profileCornerWinShare(TestProfiles.brunoKessler.id, "RED") - result.profileCornerWinShare(TestProfiles.brunoKessler.id, "BLUE")) <= 0.03)

        check(result.pairedOutcomeChangeShare >= 0.10)
        check(abs(result.adaptiveVegaWinShare - result.fixedVegaWinShare) <= 0.06)
        check(abs(result.adaptiveVegaWins - result.adaptiveKesslerWins).toDouble() / result.adaptiveFights <= 0.12)
        check(result.tacticalChangeShare in 0.15..0.75)
        check(result.trailingOpportunities > 0 && result.trailingResponseRate >= 0.85)
        check(result.fatigueOpportunities == 0 || result.fatigueResponseRate >= 0.80)
        check(result.dangerOpportunities == 0 || result.dangerResponseRate >= 0.80)

        listOf(TestProfiles.eliasVega.id, TestProfiles.brunoKessler.id).forEach { profileId ->
            check(result.distinctBetweenRoundPlans(profileId) >= 3)
            check(result.topBetweenRoundPlanShare(profileId) <= 0.80)
        }

        val vegaBest = result.bestBenchmark(TestProfiles.eliasVega.id)
        val kesslerBest = result.bestBenchmark(TestProfiles.brunoKessler.id)
        check(vegaBest.presetId != kesslerBest.presetId)
        val benchmarksByPreset = result.fixedPlanBenchmarks.groupBy { it.presetId }
        check(benchmarksByPreset.values.none { rows -> rows.size == 2 && rows.all { it.winShare >= 0.60 } })
    }

    fun csv(result: Jalon4FinalAuditResult): String = buildString {
        appendLine("window,adaptive_fights,fixed_natural_fights,adaptive_red_wins,adaptive_blue_wins,adaptive_draws,adaptive_vega_wins,adaptive_kessler_wins,adaptive_stops,fixed_vega_wins,fixed_kessler_wins,fixed_draws,fixed_stops,paired_outcome_changes,changed_between_round_decisions")
        result.windows.forEach { w ->
            appendLine(listOf(
                w.window, w.adaptiveFights, w.fixedNaturalFights, w.adaptiveRedWins, w.adaptiveBlueWins,
                w.adaptiveDraws, w.adaptiveVegaWins, w.adaptiveKesslerWins, w.adaptiveStops,
                w.fixedVegaWins, w.fixedKesslerWins, w.fixedDraws, w.fixedStops,
                w.pairedOutcomeChanges, w.changedBetweenRoundDecisions,
            ).joinToString(","))
        }
    }

    fun benchmarkCsv(result: Jalon4FinalAuditResult): String = buildString {
        appendLine("preset_id,fighter_id,fights,wins,losses,draws,stoppage_wins,win_share,non_draw_win_share")
        result.fixedPlanBenchmarks.sortedWith(compareBy({ it.fighterId }, { it.presetId })).forEach { row ->
            appendLine("${row.presetId},${row.fighterId},${row.fights},${row.wins},${row.losses},${row.draws},${row.stoppageWins},${"%.6f".format(row.winShare)},${"%.6f".format(row.nonDrawWinShare)}")
        }
    }

    private fun collectAdaptive(
        fight: FightResult,
        setup: Setup,
        totals: MutableTotals,
        planCounts: MutableMap<String, MutableMap<String, Int>>,
        winsByProfileCorner: MutableMap<String, MutableMap<String, Int>>,
        appearancesByProfileCorner: MutableMap<String, MutableMap<String, Int>>,
    ) {
        totals.adaptiveFights++
        increment(appearancesByProfileCorner, setup.red.id, "RED")
        increment(appearancesByProfileCorner, setup.blue.id, "BLUE")
        val winner = fight.stoppage?.winnerId ?: fight.officialDecision?.winnerId
        when (winner) {
            null -> totals.draws++
            setup.red.id -> {
                totals.redWins++
                increment(winsByProfileCorner, setup.red.id, "RED")
            }
            setup.blue.id -> {
                totals.blueWins++
                increment(winsByProfileCorner, setup.blue.id, "BLUE")
            }
            else -> totals.invalidResults++
        }
        when (winner) {
            TestProfiles.eliasVega.id -> totals.vegaWins++
            TestProfiles.brunoKessler.id -> totals.kesslerWins++
        }
        fight.stoppage?.let {
            totals.adaptiveStops++
            when (it.method) {
                FightMethod.KO -> totals.adaptiveKo++
                FightMethod.TKO -> totals.adaptiveTko++
            }
            totals.decisionsAfterStop += fight.tacticalDecisions.count { d -> d.beforeRound > it.roundNumber }
        }
        if (fight.stoppage == null && fight.officialDecision == null) totals.invalidResults++
        if (fight.stoppage != null && fight.officialDecision != null) totals.invalidResults++

        fight.rounds.forEach { round ->
            val roundDecisions = fight.tacticalDecisions.filter { it.beforeRound == round.roundNumber }
            if (round.redAppliedTacticalPlan == null || round.blueAppliedTacticalPlan == null) totals.missingPlans++
            if (roundDecisions.size != 2) totals.invalidResults++
            if (round.redAppliedTacticalPlan != roundDecisions.firstOrNull { it.fighterId == fight.redId }?.selectedPlan) totals.planMismatches++
            if (round.blueAppliedTacticalPlan != roundDecisions.firstOrNull { it.fighterId == fight.blueId }?.selectedPlan) totals.planMismatches++
        }

        fight.tacticalDecisions.filter { it.beforeRound > 1 }.forEach { decision ->
            totals.betweenRoundDecisions++
            if (decision.changed) totals.changedBetweenRounds++
            val counts = planCounts.getOrPut(decision.fighterId) { mutableMapOf() }
            counts[decision.selectedPlan.id] = (counts[decision.selectedPlan.id] ?: 0) + 1
            val snapshot = fight.tacticalSnapshots[decision.beforeRound - 1]
            val own = if (decision.fighterId == fight.redId) snapshot.red else snapshot.blue
            val signedPerformance = if (decision.fighterId == fight.redId) snapshot.estimatedPerformanceMargin else -snapshot.estimatedPerformanceMargin
            val previous = decision.previousPlan ?: return@forEach
            val trailing = own.estimatedRoundBalance < 0 ||
                (own.estimatedRoundBalance == 0 && signedPerformance <= -TacticalDecisionEngine.PERFORMANCE_MARGIN_TRIGGER)
            val danger = own.headDamage >= TacticalDecisionEngine.HEAD_DANGER ||
                own.bodyDamage >= TacticalDecisionEngine.BODY_DANGER ||
                own.stability <= TacticalDecisionEngine.STABILITY_DANGER ||
                (own.knockdownsSuffered > own.knockdownsScored && own.stability <= 55.0)
            val fatigue = own.stamina <= TacticalDecisionEngine.HIGH_FATIGUE_STAMINA
            if (trailing && !danger && !fatigue) {
                totals.trailingOpportunities++
                if (decision.selectedPlan.pace.ordinal > previous.pace.ordinal ||
                    decision.selectedPlan.risk.ordinal > previous.risk.ordinal ||
                    decision.selectedPlan.distance.ordinal > previous.distance.ordinal ||
                    decision.selectedPlan.pace == TacticalPace.SUSTAINED ||
                    decision.selectedPlan.risk == TacticalRisk.AGGRESSIVE ||
                    decision.selectedPlan.distance == TacticalDistance.CLOSE
                ) totals.trailingResponses++
            }
            if (fatigue) {
                totals.fatigueOpportunities++
                if (decision.selectedPlan.pace.ordinal < previous.pace.ordinal || previous.pace == TacticalPace.CAUTIOUS) totals.fatigueResponses++
            }
            if (danger) {
                totals.dangerOpportunities++
                if (decision.selectedPlan.risk == TacticalRisk.SAFE || TacticalDecisionTrigger.CONFLICT_MANAGEMENT in decision.triggers) totals.dangerResponses++
            }
        }
    }

    private fun collectFixed(fight: FixedPlanFightOutcome, totals: MutableTotals) {
        totals.fixedFights++
        val winner = fight.winnerId
        when (winner) {
            TestProfiles.eliasVega.id -> totals.fixedVegaWins++
            TestProfiles.brunoKessler.id -> totals.fixedKesslerWins++
            null -> totals.fixedDraws++
        }
        if (fight.stoppage != null) totals.fixedStops++
    }

    private data class PlanPreset(
        val id: String,
        val pace: TacticalPace,
        val distance: TacticalDistance,
        val target: TacticalTarget,
        val risk: TacticalRisk,
    ) {
        fun forProfile(profile: BoxerProfile) = TacticalPlan(profile.style, pace, distance, target, risk)
    }

    private fun runFixedPlanBenchmarks(seedStart: Long): List<FixedPlanBenchmarkResult> {
        val presets = listOf(
            PlanPreset("cautious-long-safe-mixed", TacticalPace.CAUTIOUS, TacticalDistance.LONG, TacticalTarget.MIXED, TacticalRisk.SAFE),
            PlanPreset("cautious-medium-safe-head", TacticalPace.CAUTIOUS, TacticalDistance.MEDIUM, TacticalTarget.HEAD, TacticalRisk.SAFE),
            PlanPreset("measured-long-safe-mixed", TacticalPace.MEASURED, TacticalDistance.LONG, TacticalTarget.MIXED, TacticalRisk.SAFE),
            PlanPreset("measured-medium-balanced-mixed", TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.BALANCED),
            PlanPreset("measured-medium-aggressive-head", TacticalPace.MEASURED, TacticalDistance.MEDIUM, TacticalTarget.HEAD, TacticalRisk.AGGRESSIVE),
            PlanPreset("sustained-close-balanced-body", TacticalPace.SUSTAINED, TacticalDistance.CLOSE, TacticalTarget.BODY, TacticalRisk.BALANCED),
            PlanPreset("sustained-close-aggressive-head", TacticalPace.SUSTAINED, TacticalDistance.CLOSE, TacticalTarget.HEAD, TacticalRisk.AGGRESSIVE),
            PlanPreset("sustained-close-aggressive-mixed", TacticalPace.SUSTAINED, TacticalDistance.CLOSE, TacticalTarget.MIXED, TacticalRisk.AGGRESSIVE),
            PlanPreset("sustained-medium-balanced-mixed", TacticalPace.SUSTAINED, TacticalDistance.MEDIUM, TacticalTarget.MIXED, TacticalRisk.BALANCED),
        )
        val results = mutableListOf<FixedPlanBenchmarkResult>()
        listOf(TestProfiles.eliasVega, TestProfiles.brunoKessler).forEachIndexed { fighterIndex, fighter ->
            val opponent = if (fighter.id == TestProfiles.eliasVega.id) TestProfiles.brunoKessler else TestProfiles.eliasVega
            val fighterTactics = if (fighter.id == TestProfiles.eliasVega.id) vegaTactics else kesslerTactics
            val opponentTactics = if (opponent.id == TestProfiles.eliasVega.id) vegaTactics else kesslerTactics
            presets.forEachIndexed { presetIndex, preset ->
                var wins = 0
                var losses = 0
                var draws = 0
                var stopWins = 0
                repeat(BENCHMARK_FIGHTS_PER_PROFILE_AND_PRESET / 2) { pairIndex ->
                    val seed = seedStart + fighterIndex * 1_000_000L + presetIndex * 10_000L + pairIndex
                    listOf(true, false).forEach { fighterInRed ->
                        val red = if (fighterInRed) fighter else opponent
                        val blue = if (fighterInRed) opponent else fighter
                        val outcome = FixedPlanFightSimulator.simulate(
                            red = red,
                            blue = blue,
                            redTactics = if (fighterInRed) fighterTactics else opponentTactics,
                            blueTactics = if (fighterInRed) opponentTactics else fighterTactics,
                            redPlan = if (fighterInRed) preset.forProfile(fighter) else TacticalPlanCatalog.naturalFor(opponent),
                            bluePlan = if (fighterInRed) TacticalPlanCatalog.naturalFor(opponent) else preset.forProfile(fighter),
                            seed = seed,
                        )
                        when (outcome.winnerId) {
                            fighter.id -> {
                                wins++
                                if (outcome.stoppage != null) stopWins++
                            }
                            opponent.id -> losses++
                            null -> draws++
                        }
                    }
                }
                results += FixedPlanBenchmarkResult(preset.id, fighter.id, wins + losses + draws, wins, losses, draws, stopWins)
            }
        }
        return results
    }

    private fun setup(vegaInRed: Boolean): Setup = Setup(
        red = if (vegaInRed) TestProfiles.eliasVega else TestProfiles.brunoKessler,
        blue = if (vegaInRed) TestProfiles.brunoKessler else TestProfiles.eliasVega,
        redTactics = if (vegaInRed) vegaTactics else kesslerTactics,
        blueTactics = if (vegaInRed) kesslerTactics else vegaTactics,
    )

    private fun outcomeSignature(fight: FightResult): String =
        "${fight.stoppage?.winnerId ?: fight.officialDecision?.winnerId}|${fight.stoppage?.method?.name ?: fight.officialDecision?.type?.name ?: "NONE"}"

    private fun outcomeSignature(fight: FixedPlanFightOutcome): String = "${fight.winnerId}|${fight.methodLabel}"

    private fun increment(target: MutableMap<String, MutableMap<String, Int>>, profileId: String, key: String) {
        val values = target.getOrPut(profileId) { mutableMapOf() }
        values[key] = (values[key] ?: 0) + 1
    }
}

object Jalon4FinalAuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon4FinalAuditor.run()
        Jalon4FinalAuditor.assertAcceptable(result)
        println("AUDIT FINAL JALON 4 — IA TACTIQUE ADAPTATIVE")
        println("Fenêtres / combats adaptatifs / combats fixes naturels : ${result.windows.size} / ${result.adaptiveFights} / ${result.fixedNaturalFights}")
        println("Résultats adaptatifs rouge / bleu / nuls : ${result.adaptiveRedWins} / ${result.adaptiveBlueWins} / ${result.adaptiveDraws}")
        println("Victoires adaptatives Vega / Kessler : ${result.adaptiveVegaWins} / ${result.adaptiveKesslerWins}")
        println("Arrêts adaptatifs KO / TKO : ${result.adaptiveKo} / ${result.adaptiveTko}")
        println("Résultats fixes Vega / Kessler / nuls : ${result.fixedVegaWins} / ${result.fixedKesslerWins} / ${result.fixedDraws}")
        println("Combats dont le résultat change face au plan naturel fixe : ${result.pairedOutcomeChanges}/${result.fixedNaturalFights} (${"%.2f".format(result.pairedOutcomeChangeShare * 100)} %)")
        println("Part rouge parmi les combats avec vainqueur : ${"%.2f".format(result.adaptiveRedWinnerShare * 100)} %")
        println("Vega rouge / bleu : ${"%.2f".format(result.profileCornerWinShare(TestProfiles.eliasVega.id, "RED") * 100)} % / ${"%.2f".format(result.profileCornerWinShare(TestProfiles.eliasVega.id, "BLUE") * 100)} %")
        println("Kessler rouge / bleu : ${"%.2f".format(result.profileCornerWinShare(TestProfiles.brunoKessler.id, "RED") * 100)} % / ${"%.2f".format(result.profileCornerWinShare(TestProfiles.brunoKessler.id, "BLUE") * 100)} %")
        println("Décisions inter-rounds modifiées : ${result.changedBetweenRoundDecisions}/${result.betweenRoundDecisions} (${"%.2f".format(result.tacticalChangeShare * 100)} %)")
        println("Réponse au retard : ${result.trailingResponses}/${result.trailingOpportunities} (${"%.2f".format(result.trailingResponseRate * 100)} %)")
        println("Réponse à la fatigue : ${result.fatigueResponses}/${result.fatigueOpportunities} (${"%.2f".format(result.fatigueResponseRate * 100)} %)")
        println("Réponse au danger : ${result.dangerResponses}/${result.dangerOpportunities} (${"%.2f".format(result.dangerResponseRate * 100)} %)")
        println("Plans Vega distincts / part dominante : ${result.distinctBetweenRoundPlans(TestProfiles.eliasVega.id)} / ${"%.2f".format(result.topBetweenRoundPlanShare(TestProfiles.eliasVega.id) * 100)} %")
        println("Plans Kessler distincts / part dominante : ${result.distinctBetweenRoundPlans(TestProfiles.brunoKessler.id)} / ${"%.2f".format(result.topBetweenRoundPlanShare(TestProfiles.brunoKessler.id) * 100)} %")
        val vegaBest = result.bestBenchmark(TestProfiles.eliasVega.id)
        val kesslerBest = result.bestBenchmark(TestProfiles.brunoKessler.id)
        println("Meilleur plan fixe Vega : ${vegaBest.presetId} (${"%.2f".format(vegaBest.winShare * 100)} %)")
        println("Meilleur plan fixe Kessler : ${kesslerBest.presetId} (${"%.2f".format(kesslerBest.winShare * 100)} %)")
        println("Contrôles de reproductibilité / écarts : ${result.reproducibilityChecks} / ${result.reproducibilityMismatches}")
        println("Erreurs résultat / après arrêt / plans manquants / divergents : ${result.invalidAdaptiveResults} / ${result.decisionsAfterStoppage} / ${result.missingAppliedPlans} / ${result.planDecisionMismatches}")
        println("Empreintes historiques modifiées : ${result.legacyBehaviorFingerprintMismatches}")
    }
}

object Jalon4FinalAuditCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon4FinalAuditor.run()
        Jalon4FinalAuditor.assertAcceptable(result)
        println(Jalon4FinalAuditor.csv(result))
    }
}

object Jalon4FinalBenchmarkCsvDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon4FinalAuditor.run()
        Jalon4FinalAuditor.assertAcceptable(result)
        println(Jalon4FinalAuditor.benchmarkCsv(result))
    }
}
