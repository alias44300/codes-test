# Jalon 6, étape 5 — Validation Android réelle

Date : 2026-07-21

## Projet préparé

- application `app` portrait, identifiant `com.titlefight.simulator`
- moteur Kotlin dans `engine`
- interface Compose dans `android-ui-compose`
- AGP 9.3.0, Gradle 9.5.1, Kotlin/Compose compiler 2.3.21
- Compose BOM 2026.06.00
- compileSdk/targetSdk 37, minSdk 26, Java 17
- tests unitaires et test instrumenté de lancement
- scripts Linux et Windows pour installer le SDK
- pipeline GitHub Actions fourni dans l'archive

## Porte de validation

Le jalon n'est validé que lorsque les cinq preuves existent :

1. compilation Gradle réelle réussie ;
2. tests unitaires Android réussis ;
3. `assembleDebug` réussi ;
4. APK non vide avec SHA-256 ;
5. installation et lancement vérifiés avec `adb` sur appareil ou émulateur.

Une archive de sources ou un contrôle syntaxique ne constitue pas un APK.
