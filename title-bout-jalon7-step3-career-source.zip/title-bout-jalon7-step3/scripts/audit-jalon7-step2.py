#!/usr/bin/env python3
"""Compatibilité : l'ancien audit de l'étape 2 délègue au correctif de l'étape 3."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name("audit-jalon7-step3.py")), run_name="__main__")
