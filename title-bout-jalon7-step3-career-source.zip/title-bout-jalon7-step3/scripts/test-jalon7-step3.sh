#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build-jalon7-step3"
rm -rf "$BUILD"
mkdir -p "$BUILD"
kotlinc -J-Xmx3072m -J-Dfile.encoding=UTF-8 \
  "$ROOT"/engine/src/main/kotlin/titlefight/*.kt \
  "$ROOT"/engine/src/test/kotlin/titlefight/Jalon7Step3Audit.kt \
  -include-runtime -d "$BUILD/title-bout-jalon7-step3.jar"
java -Xmx3g -Dfile.encoding=UTF-8 -cp "$BUILD/title-bout-jalon7-step3.jar" titlefight.Jalon7Step3Test
