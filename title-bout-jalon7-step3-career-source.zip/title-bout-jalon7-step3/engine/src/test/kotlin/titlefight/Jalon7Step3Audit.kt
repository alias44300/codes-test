package titlefight

object Jalon7Step3Test {
    @JvmStatic
    fun main(args: Array<String>) {
        var career = CareerEngine.create(
            CareerCreationRequest(
                name = "Alex Martin",
                nickname = "Le Nantais",
                country = "France",
                division = WeightClass.WELTERWEIGHT,
                stance = Stance.ORTHODOX,
                style = BoxingStyle.BOXER_PUNCHER,
            ),
        )
        check(career.ageYears == 18)
        check(career.record.bouts == 0)
        check(career.belts.isEmpty())
        check(career.worldRanking == null)
        check(career.stage == CareerStage.PROSPECT)
        check(career.overall in 45..65)

        repeat(3) { career = winOrdinary(career) }
        career = winTitle(career, ChampionshipBelt.REGIONAL)
        check(ChampionshipBelt.REGIONAL in career.belts)

        while (career.record.wins < 6) career = winOrdinary(career)
        career = winTitle(career, ChampionshipBelt.NATIONAL)
        check(ChampionshipBelt.NATIONAL in career.belts)

        while (career.record.wins < 10) career = winOrdinary(career)
        career = winTitle(career, ChampionshipBelt.CONTINENTAL)
        check(ChampionshipBelt.CONTINENTAL in career.belts)
        check(career.worldRanking == 15)

        while ((career.worldRanking ?: 99) > 3) career = winOrdinary(career, byKo = true)
        career = winTitle(career, ChampionshipBelt.WBA)
        check(ChampionshipBelt.WBA in career.belts)
        check(career.stage == CareerStage.WORLD_CHAMPION)

        career = winDefense(career)
        career = winTitle(career, ChampionshipBelt.WBC)
        check(career.stage == CareerStage.UNIFIED_CHAMPION)

        career = winDefense(career)
        career = winTitle(career, ChampionshipBelt.IBF)
        career = winDefense(career)
        career = winTitle(career, ChampionshipBelt.WBO)
        check(career.stage == CareerStage.UNDISPUTED_CHAMPION)
        check(career.worldBelts.containsAll(setOf(
            ChampionshipBelt.WBA,
            ChampionshipBelt.WBC,
            ChampionshipBelt.IBF,
            ChampionshipBelt.WBO,
        )))
        check(career.ageYears in 18..30)
        check(career.record.wins >= 20)

        val trained = CareerEngine.train(CareerEngine.restCamp(career), TrainingFocus.TECHNIQUE)
        check(trained.fighter.technique >= career.fighter.technique)

        println("Création d'un boxeur de 18 ans : PASS")
        println("Progression régional -> national -> continental -> mondial : PASS")
        println("WBA, WBC, IBF, WBO et champion incontesté : PASS")
        println("Entraînement, fatigue, âge et bourses : PASS")
        println("Jalon 7 étape 3 : PASS")
    }

    private fun winOrdinary(state: CareerState, byKo: Boolean = false): CareerState {
        val opponent = CareerEngine.availableOpponents(state).first { !it.isTitleFight }
        return CareerEngine.applyBout(state, opponent, CareerBoutOutcome.WIN, endedByKnockout = byKo)
    }

    private fun winTitle(state: CareerState, belt: ChampionshipBelt): CareerState {
        val opponent = CareerEngine.availableOpponents(state).first { it.beltAtStake == belt && !it.isTitleDefense }
        return CareerEngine.applyBout(state, opponent, CareerBoutOutcome.WIN, endedByKnockout = false)
    }

    private fun winDefense(state: CareerState): CareerState {
        val opponent = CareerEngine.availableOpponents(state).first { it.isTitleDefense }
        return CareerEngine.applyBout(state, opponent, CareerBoutOutcome.WIN, endedByKnockout = false)
    }
}
