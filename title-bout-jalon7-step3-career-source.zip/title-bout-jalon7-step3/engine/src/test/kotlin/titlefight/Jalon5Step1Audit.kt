package titlefight

data class Jalon5Step1AuditResult(
    val profileCount: Int,
    val uniqueIdCount: Int,
    val uniqueNameCount: Int,
    val uniqueNicknameCount: Int,
    val representedStyleCount: Int,
    val representedStanceCount: Int,
    val styleCounts: Map<BoxingStyle, Int>,
    val stanceCounts: Map<Stance, Int>,
    val invalidDimensionCount: Int,
    val invalidPrimaryStatCount: Int,
    val invalidSecondaryStatCount: Int,
    val preferredRangeMismatchCount: Int,
    val lookupMismatchCount: Int,
    val legacyBehaviorFingerprintMismatches: Int,
    val minimumHeightCm: Int,
    val maximumHeightCm: Int,
    val minimumReachCm: Int,
    val maximumReachCm: Int,
    val minimumStat: Int,
    val maximumStat: Int,
)

object Jalon5Step1Auditor {
    fun run(): Jalon5Step1AuditResult {
        val profiles = BoxerCatalog.all
        return Jalon5Step1AuditResult(
            profileCount = profiles.size,
            uniqueIdCount = profiles.map { it.id }.distinct().size,
            uniqueNameCount = profiles.map { it.name }.distinct().size,
            uniqueNicknameCount = profiles.map { it.nickname }.distinct().size,
            representedStyleCount = profiles.map { it.style }.distinct().size,
            representedStanceCount = profiles.map { it.stance }.distinct().size,
            styleCounts = BoxingStyle.entries.associateWith { style -> profiles.count { it.style == style } },
            stanceCounts = Stance.entries.associateWith { stance -> profiles.count { it.stance == stance } },
            invalidDimensionCount = profiles.count {
                it.heightCm !in 150..220 || it.reachCm !in 150..230 || kotlin.math.abs(it.reachCm - it.heightCm) > 25
            },
            invalidPrimaryStatCount = profiles.sumOf { profile -> profile.primaryStats.count { it !in 1..100 } },
            invalidSecondaryStatCount = profiles.sumOf { profile -> profile.secondaryStats.count { it !in 1..100 } },
            preferredRangeMismatchCount = profiles.count { profile ->
                profile.preferredRange != expectedRange(profile.style)
            },
            lookupMismatchCount = profiles.count { BoxerCatalog.findById(it.id) != it } +
                if (BoxerCatalog.findById("unknown-boxer") == null) 0 else 1,
            legacyBehaviorFingerprintMismatches = LegacyBehaviorFingerprint.verify(),
            minimumHeightCm = profiles.minOf { it.heightCm },
            maximumHeightCm = profiles.maxOf { it.heightCm },
            minimumReachCm = profiles.minOf { it.reachCm },
            maximumReachCm = profiles.maxOf { it.reachCm },
            minimumStat = profiles.minOf { (it.primaryStats + it.secondaryStats).min() },
            maximumStat = profiles.maxOf { (it.primaryStats + it.secondaryStats).max() },
        )
    }

    fun assertValid(result: Jalon5Step1AuditResult) {
        check(result.profileCount == 10)
        check(result.uniqueIdCount == 10)
        check(result.uniqueNameCount == 10)
        check(result.uniqueNicknameCount == 10)
        check(result.representedStyleCount == BoxingStyle.entries.size)
        check(result.representedStanceCount == Stance.entries.size)
        check(result.styleCounts.values.all { it >= 1 })
        check(result.stanceCounts.values.all { it >= 1 })
        check(result.invalidDimensionCount == 0)
        check(result.invalidPrimaryStatCount == 0)
        check(result.invalidSecondaryStatCount == 0)
        check(result.preferredRangeMismatchCount == 0)
        check(result.lookupMismatchCount == 0)
        check(result.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun expectedRange(style: BoxingStyle): FightRange = when (style) {
        BoxingStyle.OUT_BOXER, BoxingStyle.DEFENSIVE_SPECIALIST -> FightRange.OUTSIDE
        BoxingStyle.PRESSURE_FIGHTER, BoxingStyle.SWARMER -> FightRange.INSIDE
        BoxingStyle.COUNTERPUNCHER, BoxingStyle.BOXER_PUNCHER, BoxingStyle.SLUGGER -> FightRange.MID
    }
}

object Jalon5Step1AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step1Auditor.run()
        Jalon5Step1Auditor.assertValid(result)
        println("AUDIT JALON 5 — ÉTAPE 1")
        println("Profils / IDs / noms / surnoms uniques : ${result.profileCount} / ${result.uniqueIdCount} / ${result.uniqueNameCount} / ${result.uniqueNicknameCount}")
        println("Styles représentés : ${result.representedStyleCount}/${BoxingStyle.entries.size} ${result.styleCounts}")
        println("Gardes représentées : ${result.representedStanceCount}/${Stance.entries.size} ${result.stanceCounts}")
        println("Taille min/max : ${result.minimumHeightCm}/${result.maximumHeightCm} cm")
        println("Allonge min/max : ${result.minimumReachCm}/${result.maximumReachCm} cm")
        println("Statistique min/max : ${result.minimumStat}/${result.maximumStat}")
        println("Dimensions invalides : ${result.invalidDimensionCount}")
        println("Statistiques principales invalides : ${result.invalidPrimaryStatCount}")
        println("Attributs secondaires invalides : ${result.invalidSecondaryStatCount}")
        println("Distances préférées incohérentes : ${result.preferredRangeMismatchCount}")
        println("Erreurs de recherche catalogue : ${result.lookupMismatchCount}")
        println("Empreintes historiques modifiées : ${result.legacyBehaviorFingerprintMismatches}")
    }
}

object Jalon5Step1Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        println("CATALOGUE TITLE FIGHT — 10 BOXEURS FICTIFS")
        BoxerCatalog.all.forEachIndexed { index, boxer ->
            println(
                "${index + 1}. ${boxer.name} « ${boxer.nickname} » | ${boxer.style} | ${boxer.stance} | " +
                    "${boxer.heightCm} cm, allonge ${boxer.reachCm} cm | distance ${boxer.preferredRange}",
            )
            println(
                "   PUI ${boxer.power} · VIT ${boxer.speed} · TEC ${boxer.technique} · DEF ${boxer.defense} · " +
                    "END ${boxer.endurance} · MEN ${boxer.mental} | CHI/REC/ACC/MOB/COR/AGR " +
                    boxer.secondaryStats.joinToString("/"),
            )
        }
    }
}
