#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
"$ROOT/scripts/validate-android-environment.sh"
./gradlew --no-daemon :app:testDebugUnitTest :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
test -s "$APK"
sha256sum "$APK" > "$APK.sha256"
printf 'APK généré: %s\n' "$APK"
