#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build"
rm -rf "$BUILD"
mkdir -p "$BUILD"
kotlinc -J-Dfile.encoding=UTF-8 \
  "$ROOT"/engine/src/main/kotlin/titlefight/*.kt \
  "$ROOT"/engine/src/test/kotlin/titlefight/*.kt \
  -include-runtime -d "$BUILD/title-fight-tests.jar"
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.FightEngineTest
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.Demo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.BatchDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.ThresholdAuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.KnockdownStep1AuditDemo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.KnockdownStep2Demo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.KnockdownStep2AuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.KnockoutStep3Demo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.KnockoutStep3AuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TkoStep4Demo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TkoStep4AuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.Jalon2FinalAuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.JudgingEvidenceStep1Demo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.JudgingEvidenceStep1AuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.NeutralJudgeStep2Demo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.NeutralJudgeStep2AuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.ThreeJudgeStep3Demo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.ThreeJudgeStep3AuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.OfficialDecisionStep4Demo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.OfficialDecisionStep4AuditDemo

java -Xmx1g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.Jalon3FinalAuditDemo
java -Xmx1g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.Jalon3FinalAuditCsvDemo

java -Xmx1g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalStateStep1AuditDemo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalStateStep1Demo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalPlanStep2AuditDemo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalPlanStep2Demo

java -Xmx1g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalDecisionStep3AuditDemo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalDecisionStep3Demo

java -Xmx1g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalIntegrationStep4AuditDemo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalIntegrationStep4Demo

java -Xmx2g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.Jalon4FinalAuditDemo

java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.Jalon5Step1AuditDemo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.Jalon5Step1Demo
