package titlefight.ui.compose

import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview

@Preview(name = "Combat compact 320", widthDp = 320, heightDp = 720, showBackground = true)
@Composable
private fun ActiveCompactPreview() = TitleFightTheme(darkTheme = true) {
    TitleFightScreen(FightScreenPreviewFixtures.active())
}

@Preview(name = "Combat standard 360", widthDp = 360, heightDp = 800, showBackground = true)
@Composable
private fun ActiveStandardPreview() = TitleFightTheme(darkTheme = true) {
    TitleFightScreen(FightScreenPreviewFixtures.active())
}

@Preview(name = "Combat étendu 412", widthDp = 412, heightDp = 915, showBackground = true)
@Composable
private fun ActiveExpandedPreview() = TitleFightTheme(darkTheme = true) {
    TitleFightScreen(FightScreenPreviewFixtures.active())
}

@Preview(name = "Entre les rounds", widthDp = 360, heightDp = 800, showBackground = true)
@Composable
private fun BetweenRoundsPreview() = TitleFightTheme(darkTheme = true) {
    TitleFightScreen(
        state = FightScreenPreviewFixtures.betweenRounds(),
        tacticalSelection = FightScreenPreviewFixtures.tacticalSelection(),
    )
}

@Preview(name = "Résultat", widthDp = 360, heightDp = 800, showBackground = true)
@Composable
private fun CompletePreview() = TitleFightTheme(darkTheme = true) {
    TitleFightScreen(FightScreenPreviewFixtures.complete())
}
