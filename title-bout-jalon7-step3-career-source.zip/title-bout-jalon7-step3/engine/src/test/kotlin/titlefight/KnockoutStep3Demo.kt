package titlefight

object KnockoutStep3Demo {
    @JvmStatic
    fun main(args: Array<String>) {
        val compromised = FighterState(stamina = 3.0, headDamage = 94.0, bodyDamage = 80.0, stability = 3.0)
        val engine = FightEngine(stopOnTko = false)
        val example = (1L..20000L).asSequence().map { seed ->
            seed to engine.simulateThreeRoundFight(
                red = TestProfiles.brunoKessler,
                blue = TestProfiles.eliasVega,
                redTactics = List(3) { Tactic.SEEK_KO },
                blueTactics = List(3) { Tactic.RECOVER },
                seed = seed,
                redStart = FighterState(),
                blueStart = compromised,
            )
        }.first { (_, fight) -> fight.stoppage?.method == FightMethod.KO }

        println(FightReportFormatter.format(example.second, TestProfiles.brunoKessler, TestProfiles.eliasVega))
        println()
        println("Graine de démonstration KO : ${example.first}")
    }
}
