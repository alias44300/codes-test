# Jalon 3 — Étape 4 — Cartes et décision officielle

## Périmètre

Cette étape totalise les trois cartes de juge sur les combats arrivant au terme des trois rounds et produit un résultat officiel.

Aucun écran Android, APK, nouveau boxeur, retrait de point ou mécanisme de faute n'est ajouté.

## Carte complète d'un juge

Chaque `JudgeScorecard` contient :

- les trois scores de round du même juge ;
- le total rouge et le total bleu ;
- le verdict rouge, bleu ou nul ;
- une justification explicite.

Une carte officielle exige exactement trois rounds terminés. Les totaux sont recalculés depuis les scores de round et validés par le modèle.

## Types de décision

- décision unanime : trois cartes pour le même boxeur ;
- décision partagée : deux cartes pour un boxeur et une pour l'autre ;
- décision majoritaire : deux cartes pour un boxeur et une carte nulle ;
- match nul unanime : trois cartes nulles ;
- match nul majoritaire : deux cartes nulles et une carte pour un boxeur ;
- match nul partagé : une carte rouge, une carte bleue et une carte nulle.

La décision officielle est dérivée exclusivement du verdict des trois cartes. Aucun tirage aléatoire ou correctif caché n'intervient.

## Priorité des arrêts

- un KO ou un TKO interdit toute décision aux points ;
- le round interrompu reste non jugé ;
- aucune carte complète n'est créée ;
- `officialDecision` reste nul.

## Audit reproductible

- 1 000 combats ;
- 998 combats à la distance ;
- 2 arrêts, dont 1 KO et 1 TKO ;
- 998 décisions officielles ;
- 2 994 cartes totalisées ;
- 818 décisions unanimes ;
- 5 décisions partagées ;
- 41 décisions majoritaires ;
- 101 nuls unanimes ;
- 22 nuls majoritaires ;
- 11 nuls partagés ;
- 0 décision différente d'une nouvelle résolution ;
- 0 carte invalide ;
- 0 décision contraire à la majorité ;
- 0 décision manquante à la distance ;
- 0 décision présente après KO/TKO ;
- 0 justification vide.

## Statut

Étape 4 validée. L'étape 5 restera limitée à l'audit statistique multi-fenêtres des cartes, types de décision, biais de coin et sévérité relative des juges.
