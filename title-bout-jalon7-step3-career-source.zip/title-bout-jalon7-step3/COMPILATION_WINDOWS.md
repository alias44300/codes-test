# TITLE FIGHT — Compilation automatisée sous Windows

## Préparation du téléphone

1. Activez les options pour les développeurs sur le téléphone Android.
2. Activez **Débogage USB**.
3. Branchez le téléphone au PC avec un câble de données.
4. Acceptez la demande d’autorisation RSA affichée sur le téléphone.

## Compilation en un double-clic

1. Décompressez entièrement le ZIP dans un dossier simple, par exemple `C:\TITLE-FIGHT`.
2. Double-cliquez sur `BUILD_TITLE_FIGHT_WINDOWS.cmd`.
3. Laissez la fenêtre ouverte pendant les téléchargements et la compilation.

Le script :

- vérifie Java 17 et l’installe via `winget` lorsque nécessaire ;
- télécharge les outils Android officiels et contrôle leur SHA-256 ;
- installe la plateforme Android 37, les Build Tools 36.0.0 et ADB ;
- télécharge Gradle 9.5.1 avec contrôle SHA-256 ;
- exécute les tests unitaires ;
- compile `app-debug.apk` ;
- vérifie la signature de l’APK ;
- installe l’application sur le téléphone lorsqu’il est détecté ;
- lance `TITLE FIGHT` et vérifie que son processus reste actif.

## Résultats

Les fichiers sont placés dans :

```text
artifacts\windows-build\
```

Fichiers principaux :

- `TITLE-FIGHT-demo-debug.apk`
- `TITLE-FIGHT-demo-debug.apk.sha256`
- `build-report.json`
- `build-report.txt`
- `installation-verification.txt`, lorsque le téléphone a été validé
- `logs\`, pour les journaux détaillés

## Statuts possibles

- `BUILD_INSTALL_LAUNCH_VERIFIED` : APK compilé, installé et lancé avec succès.
- `BUILD_VERIFIED_NO_DEVICE` : APK compilé et vérifié, mais aucun téléphone autorisé n’était connecté.
- `BUILD_VERIFIED_INSTALL_SKIPPED` : compilation validée avec l’option `-SkipInstall`.
- `FAILED` : un rapport et les journaux indiquent l’étape en échec.

## Options avancées

PowerShell :

```powershell
.\BUILD_TITLE_FIGHT_WINDOWS.ps1 -Clean
.\BUILD_TITLE_FIGHT_WINDOWS.ps1 -RunInstrumentedTests
.\BUILD_TITLE_FIGHT_WINDOWS.ps1 -SkipInstall
```

L’étape du projet n’est considérée comme totalement validée qu’avec le statut `BUILD_INSTALL_LAUNCH_VERIFIED`.
