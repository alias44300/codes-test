# Jalon 1 — Étape 4 : audit final des seuils

## Objectif

Décider si le moteur nécessite un micro-réglage avant la validation du jalon 1, sans ajouter de mécanique de jeu.

## Méthode

- dix fenêtres indépendantes ;
- cent combats de trois rounds par fenêtre ;
- 1 000 combats au total ;
- 3 000 rounds ;
- 36 000 séquences ;
- alternance des coins dans chaque fenêtre ;
- profils, tactiques et moteur inchangés.

## Seuils d’acceptation

Pour chaque fenêtre :

- avantages de Vega entre 35 et 65 sur 100 ;
- avantages du coin rouge entre 35 et 65 sur 100 ;
- écart moyen entre profils inférieur ou égal à 5 points ;
- écart moyen entre coins inférieur ou égal à 5 points ;
- énergie et stabilité moyennes hors saturation ;
- signature de pression de Kessler toujours visible.

Sur l’agrégat :

- chaque profil entre 450 et 550 avantages sur 1 000 ;
- chaque coin entre 450 et 550 avantages sur 1 000 ;
- écart moyen entre profils inférieur ou égal à 2 points ;
- écart moyen entre coins inférieur ou égal à 2 points.

## Décision

Les seuils sont respectés sans modification du moteur. Aucun micro-réglage n’est nécessaire pour le jalon 1.
