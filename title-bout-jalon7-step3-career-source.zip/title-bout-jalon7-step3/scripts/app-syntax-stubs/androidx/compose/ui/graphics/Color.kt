package androidx.compose.ui.graphics
class Color(val value: Long) {
    constructor(value: Int) : this(value.toLong())
    fun copy(alpha: Float = 1f): Color = this
    companion object { val White = Color(0xFFFFFFFFL) }
}
