#!/usr/bin/env bash
set -euo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BUILD="$ROOT/build-jalon4-step2"
rm -rf "$BUILD"
mkdir -p "$BUILD"
kotlinc -J-Dfile.encoding=UTF-8 \
  "$ROOT"/engine/src/main/kotlin/titlefight/*.kt \
  "$ROOT"/engine/src/test/kotlin/titlefight/*.kt \
  -include-runtime -d "$BUILD/title-fight-tests.jar"
java -Xmx1g -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.FightEngineTest
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalPlanStep2AuditDemo
java -Dfile.encoding=UTF-8 -cp "$BUILD/title-fight-tests.jar" titlefight.TacticalPlanStep2Demo
