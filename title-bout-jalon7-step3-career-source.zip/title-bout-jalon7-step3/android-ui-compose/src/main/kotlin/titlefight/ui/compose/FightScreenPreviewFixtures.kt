package titlefight.ui.compose

import titlefight.BoxingStyle
import titlefight.FightActionScreenState
import titlefight.FightClockState
import titlefight.FightRange
import titlefight.FightResultKind
import titlefight.FightResultScreenState
import titlefight.FightScreenPhase
import titlefight.FightScreenState
import titlefight.FighterCondition
import titlefight.FighterCorner
import titlefight.FighterScreenState
import titlefight.Punch
import titlefight.PlayerTacticalDraft
import titlefight.Stance
import titlefight.TacticalDistance
import titlefight.TacticalPace
import titlefight.TacticalPlanScreenState
import titlefight.TacticalRisk
import titlefight.TacticalTarget

object FightScreenPreviewFixtures {
    private fun plan(
        pace: TacticalPace,
        distance: TacticalDistance,
        target: TacticalTarget,
        risk: TacticalRisk,
        explanation: String,
    ) = TacticalPlanScreenState(pace, distance, target, risk, explanation)

    private fun red() = FighterScreenState(
        id = "elias-vega",
        name = "Elias Vega",
        nickname = "The Comet",
        corner = FighterCorner.RED,
        stance = Stance.ORTHODOX,
        style = BoxingStyle.OUT_BOXER,
        stamina = 73,
        fatigue = 27,
        headDamage = 18,
        bodyDamage = 31,
        stability = 79,
        landed = 22,
        thrown = 54,
        knockdownsSuffered = 0,
        vulnerabilitySequencesRemaining = 0,
        pendingTenCount = false,
        condition = FighterCondition.WORKING,
        tacticalPlan = plan(
            TacticalPace.MEASURED,
            TacticalDistance.LONG,
            TacticalTarget.MIXED,
            TacticalRisk.SAFE,
            "Conserver la longue distance et protéger l'avance estimée.",
        ),
    )

    private fun blue() = FighterScreenState(
        id = "bruno-kessler",
        name = "Bruno Kessler",
        nickname = "The Anvil",
        corner = FighterCorner.BLUE,
        stance = Stance.ORTHODOX,
        style = BoxingStyle.PRESSURE_FIGHTER,
        stamina = 61,
        fatigue = 39,
        headDamage = 37,
        bodyDamage = 24,
        stability = 58,
        landed = 26,
        thrown = 63,
        knockdownsSuffered = 1,
        vulnerabilitySequencesRemaining = 2,
        pendingTenCount = false,
        condition = FighterCondition.HURT,
        tacticalPlan = plan(
            TacticalPace.SUSTAINED,
            TacticalDistance.CLOSE,
            TacticalTarget.BODY,
            TacticalRisk.AGGRESSIVE,
            "Retard estimé au score et vulnérabilité adverse au corps.",
        ),
    )

    fun active(): FightScreenState = FightScreenState(
        fightSeed = 20260721L,
        phase = FightScreenPhase.ROUND_IN_PROGRESS,
        roundNumber = 2,
        totalRounds = 3,
        sequenceNumber = 7,
        sequencesPerRound = 12,
        clock = FightClockState(75),
        red = red(),
        blue = blue(),
        currentAction = FightActionScreenState(
            attackerId = "bruno-kessler",
            defenderId = "elias-vega",
            range = FightRange.INSIDE,
            punch = Punch.BODY_HOOK,
            landed = true,
            clean = true,
            impact = 10.8,
            knockdown = false,
            refereeCount = null,
        ),
        commentary = "Bruno Kessler touche nettement avec un crochet au corps.",
        recentCommentary = listOf(
            "Elias Vega évite un direct.",
            "Bruno Kessler accélère à courte distance.",
            "Bruno Kessler touche nettement avec un crochet au corps.",
        ),
        tacticalWindowOpen = false,
        result = null,
    )

    fun betweenRounds(): FightScreenState = active().copy(
        phase = FightScreenPhase.BETWEEN_ROUNDS,
        roundNumber = 2,
        sequenceNumber = 12,
        clock = FightClockState(0),
        currentAction = null,
        commentary = "Fin du round 2. La fenêtre tactique est ouverte.",
        tacticalWindowOpen = true,
    )


    fun tacticalSelection(): TacticalSelectionUiState = TacticalSelectionUiState(
        windowId = 2,
        playerCorner = FighterCorner.RED,
        draft = PlayerTacticalDraft(
            anchorStyle = BoxingStyle.OUT_BOXER,
            pace = TacticalPace.MEASURED,
            distance = TacticalDistance.LONG,
            target = TacticalTarget.BODY,
            risk = TacticalRisk.SAFE,
        ),
        changedAxes = listOf(titlefight.TacticalAxis.TARGET),
        enabled = true,
        confirmEnabled = true,
    )

    fun complete(): FightScreenState = active().copy(
        phase = FightScreenPhase.COMPLETE,
        roundNumber = 3,
        sequenceNumber = 12,
        clock = FightClockState(0),
        currentAction = null,
        commentary = "Elias Vega remporte le combat par décision unanime.",
        recentCommentary = listOf(
            "La cloche met fin au troisième round.",
            "Les juges rendent leur décision.",
            "Elias Vega remporte le combat par décision unanime.",
        ),
        tacticalWindowOpen = false,
        result = FightResultScreenState(
            kind = FightResultKind.DECISION,
            winnerId = "elias-vega",
            loserId = "bruno-kessler",
            headline = "Elias Vega gagne aux points",
            detail = "Décision unanime.",
        ),
    )
}
