# Jalon 7 — Étape 2 — Remplacée

Cette étape avait intégré le catalogue officiel de 321 boxeurs, mais elle contenait deux erreurs de conception :

1. le joueur choisissait une légende historique déjà très forte au lieu de créer un jeune boxeur ;
2. des champs de collection issus de Knockout Cards, notamment la rareté et le coût, avaient été importés dans Title Bout.

Ces deux erreurs sont corrigées dans le **Jalon 7, étape 3**. Le document de référence actuel est `docs/JALON7_STEP3.md`.
