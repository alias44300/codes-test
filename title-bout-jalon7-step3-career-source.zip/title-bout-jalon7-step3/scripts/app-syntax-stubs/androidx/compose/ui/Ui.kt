package androidx.compose.ui
open class Modifier { companion object : Modifier() }
object Alignment {
    object TopCenter
    object Center
    object CenterVertically
    object CenterHorizontally
    object End
}
