# Jalon 5 — Étape 5 — Audit final multi-fenêtres

## Objectif

Vérifier le roster calibré dans dix fenêtres de graines indépendantes, sans modifier les profils ni le moteur pendant l’audit.

## Protocole

- 10 fenêtres indépendantes ;
- 45 duels uniques dans chaque fenêtre ;
- 5 paires de graines par duel ;
- inversion systématique des coins ;
- 450 combats par fenêtre ;
- 4 500 combats supplémentaires au total ;
- 900 répétitions déterministes ;
- IA tactique adaptative activée ;
- audit d’identité statistique rejoué en parallèle.

La matrice de calibration de l’étape 4 comportait déjà 9 000 combats. Le roster calibré est donc contrôlé sur 13 500 combats cumulés, dont 4 500 dans des fenêtres totalement nouvelles.

## Bandes finales

- chaque boxeur agrégé : 30 à 70 % de victoires hors nuls ;
- chaque style agrégé : 35 à 65 % ;
- part rouge agrégée : 48 à 52 % ;
- écart maximal de coin agrégé par boxeur : 8 % ;
- stabilité entre fenêtres mesurée par dispersion et écart-type ;
- aucun résultat invalide ;
- aucun plan manquant ou divergent ;
- aucune décision après arrêt ;
- KO, TKO, décisions et nuls présents dans l’échantillon agrégé ;
- empreintes historiques préservées.

## Résultat

Toutes les bandes sont respectées. Aucune calibration n’a été appliquée pendant l’étape 5.
