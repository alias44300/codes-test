package titlefight

import kotlin.math.max
import kotlin.math.min

class FightEngine(
    private val sequencesPerRound: Int = 12,
    private val stopOnTenCount: Boolean = true,
    private val stopOnTko: Boolean = true,
    private val adaptiveTacticsEnabled: Boolean = false,
) {

    fun simulateThreeRoundFight(
        red: BoxerProfile,
        blue: BoxerProfile,
        redTactics: List<Tactic>,
        blueTactics: List<Tactic>,
        seed: Long,
        redStart: FighterState = FighterState(),
        blueStart: FighterState = FighterState(),
    ): FightResult {
        require(red.id != blue.id)
        require(redTactics.size == 3) { "Trois tactiques rouges sont requises, une par round." }
        require(blueTactics.size == 3) { "Trois tactiques bleues sont requises, une par round." }

        val seedStream = DeterministicRandom(seed)
        var redState = redStart
        var blueState = blueStart
        val rounds = mutableListOf<RoundResult>()
        val tacticalSnapshots = mutableListOf<TacticalStateSnapshot>()
        val tacticalDecisions = mutableListOf<TacticalDecision>()
        val redDecisionHistory = mutableListOf<TacticalDecision>()
        val blueDecisionHistory = mutableListOf<TacticalDecision>()

        for (index in 0 until 3) {
            val roundNumber = index + 1
            val tacticalSnapshot = TacticalStateSnapshotExtractor.extract(
                red = red,
                blue = blue,
                redState = redState,
                blueState = blueState,
                completedRounds = rounds.map(TacticalRoundFacts::fromCompletedRound),
                nextRoundNumber = roundNumber,
                sequencesPerRound = sequencesPerRound,
            )
            tacticalSnapshots += tacticalSnapshot
            val redDecision = TacticalDecisionEngine.decide(red, tacticalSnapshot, redDecisionHistory)
            val blueDecision = TacticalDecisionEngine.decide(blue, tacticalSnapshot, blueDecisionHistory)
            redDecisionHistory += redDecision
            blueDecisionHistory += blueDecision
            tacticalDecisions += redDecision
            tacticalDecisions += blueDecision

            val round = simulateRound(
                roundNumber = roundNumber,
                red = red,
                blue = blue,
                redStart = redState,
                blueStart = blueState,
                redTactic = redTactics[index],
                blueTactic = blueTactics[index],
                seed = seedStream.nextLong(),
                redPlan = redDecision.selectedPlan,
                bluePlan = blueDecision.selectedPlan,
            )
            rounds += round
            redState = round.redState
            blueState = round.blueState
            if (round.stoppage != null) break
        }

        val stoppage = rounds.lastOrNull()?.stoppage
        val officialDecision = if (stoppage == null) {
            OfficialDecisionResolver.resolve(red.id, blue.id, rounds)
        } else {
            null
        }
        return FightResult(
            redId = red.id,
            blueId = blue.id,
            seed = seed,
            rounds = rounds,
            finalRedState = redState,
            finalBlueState = blueState,
            redPerformanceTotal = rounds.sumOf { it.redRoundScore },
            bluePerformanceTotal = rounds.sumOf { it.blueRoundScore },
            tacticalSnapshots = tacticalSnapshots,
            tacticalDecisions = tacticalDecisions,
            adaptiveTacticsEnabled = adaptiveTacticsEnabled,
            stoppage = stoppage,
            officialDecision = officialDecision,
        )
    }

    fun simulateRound(
        roundNumber: Int,
        red: BoxerProfile,
        blue: BoxerProfile,
        redStart: FighterState,
        blueStart: FighterState,
        redTactic: Tactic,
        blueTactic: Tactic,
        seed: Long,
        redPlan: TacticalPlan? = null,
        bluePlan: TacticalPlan? = null,
    ): RoundResult {
        require(roundNumber >= 1)
        require(red.id != blue.id)

        val rng = DeterministicRandom(seed)
        // Flux séparés : les chutes et les comptes ne consomment jamais les tirages offensifs historiques.
        // Le TKO est entièrement déterministe et ne consomme aucun tirage.
        val knockdownRng = DeterministicRandom(seed xor 0x4B4E4F434B444F57L)
        val countRng = DeterministicRandom(seed xor 0x434F554E5452494EL)
        val appliedRedPlan = if (adaptiveTacticsEnabled) redPlan ?: TacticalPlanCatalog.naturalFor(red) else null
        val appliedBluePlan = if (adaptiveTacticsEnabled) bluePlan ?: TacticalPlanCatalog.naturalFor(blue) else null
        var redState = redStart
        var blueState = blueStart
        val events = mutableListOf<SequenceEvent>()
        val sequenceFrames = mutableListOf<SequenceStateFrame>()
        var stoppage: FightStoppage? = null

        for (sequenceIndex in 0 until sequencesPerRound) {
            val sequenceNumber = sequenceIndex + 1
            val range = resolveRange(red, blue, redState, blueState, redTactic, blueTactic, appliedRedPlan, appliedBluePlan, rng)
            val redInitiative = initiativeScore(red, redState, redTactic, appliedRedPlan, range, rng)
            val blueInitiative = initiativeScore(blue, blueState, blueTactic, appliedBluePlan, range, rng)
            val redAttacks = redInitiative >= blueInitiative

            if (redAttacks) {
                val outcome = resolveAttack(
                    red, blue, redState, blueState, redTactic, blueTactic, appliedRedPlan, appliedBluePlan, range, rng,
                    knockdownRng, countRng, roundNumber, sequenceNumber,
                )
                redState = tickVulnerability(outcome.attackerState, preserveNew = false)
                blueState = tickVulnerability(outcome.defenderState, preserveNew = outcome.event.knockdown != null)
                var event = outcome.event
                val tenCount = event.knockdown?.refereeCount?.countReached == 10
                if (stopOnTenCount && tenCount) {
                    stoppage = FightStoppage(
                        winnerId = red.id,
                        loserId = blue.id,
                        roundNumber = roundNumber,
                        sequenceNumber = sequenceNumber,
                        method = FightMethod.KO,
                        reason = "compte de l’arbitre arrivé à 10",
                    )
                } else if (stopOnTko) {
                    val safety = TkoSafetyDetector.evaluate(blueState, event)
                    if (safety.eligible) {
                        event = event.copy(text = "${event.text} ARRÊT : l’arbitre intervient pour protéger ${blue.name}. TKO.")
                        stoppage = FightStoppage(
                            winnerId = red.id,
                            loserId = blue.id,
                            roundNumber = roundNumber,
                            sequenceNumber = sequenceNumber,
                            method = FightMethod.TKO,
                            reason = safety.reason,
                        )
                    }
                }
                events += event
                sequenceFrames += SequenceStateFrame(
                    roundNumber = roundNumber,
                    sequenceNumber = sequenceNumber,
                    event = event,
                    redState = redState,
                    blueState = blueState,
                    stoppage = stoppage,
                )
                if (stoppage != null) break
            } else {
                val outcome = resolveAttack(
                    blue, red, blueState, redState, blueTactic, redTactic, appliedBluePlan, appliedRedPlan, range, rng,
                    knockdownRng, countRng, roundNumber, sequenceNumber,
                )
                blueState = tickVulnerability(outcome.attackerState, preserveNew = false)
                redState = tickVulnerability(outcome.defenderState, preserveNew = outcome.event.knockdown != null)
                var event = outcome.event
                val tenCount = event.knockdown?.refereeCount?.countReached == 10
                if (stopOnTenCount && tenCount) {
                    stoppage = FightStoppage(
                        winnerId = blue.id,
                        loserId = red.id,
                        roundNumber = roundNumber,
                        sequenceNumber = sequenceNumber,
                        method = FightMethod.KO,
                        reason = "compte de l’arbitre arrivé à 10",
                    )
                } else if (stopOnTko) {
                    val safety = TkoSafetyDetector.evaluate(redState, event)
                    if (safety.eligible) {
                        event = event.copy(text = "${event.text} ARRÊT : l’arbitre intervient pour protéger ${red.name}. TKO.")
                        stoppage = FightStoppage(
                            winnerId = blue.id,
                            loserId = red.id,
                            roundNumber = roundNumber,
                            sequenceNumber = sequenceNumber,
                            method = FightMethod.TKO,
                            reason = safety.reason,
                        )
                    }
                }
                events += event
                sequenceFrames += SequenceStateFrame(
                    roundNumber = roundNumber,
                    sequenceNumber = sequenceNumber,
                    event = event,
                    redState = redState,
                    blueState = blueState,
                    stoppage = stoppage,
                )
                if (stoppage != null) break
            }
        }

        if (stoppage == null) {
            redState = recoverAfterRound(red, redState, redTactic)
            blueState = recoverAfterRound(blue, blueState, blueTactic)
        }

        val redScore = roundPerformance(
            fighterId = red.id,
            opponentStart = blueStart,
            opponentEnd = blueState,
            events = events,
        )
        val blueScore = roundPerformance(
            fighterId = blue.id,
            opponentStart = redStart,
            opponentEnd = redState,
            events = events,
        )
        val judgingEvidence = RoundJudgingEvidenceExtractor.extract(
            roundNumber = roundNumber,
            red = red,
            blue = blue,
            events = events,
        )

        val judgeScores = if (stoppage == null) ThreeJudgePanel.score(judgingEvidence) else emptyList()
        val neutralJudgeScore = judgeScores.firstOrNull()?.toNeutralScore()

        return RoundResult(
            roundNumber = roundNumber,
            seed = seed,
            redState = redState,
            blueState = blueState,
            events = events,
            redRoundScore = redScore,
            blueRoundScore = blueScore,
            judgingEvidence = judgingEvidence,
            neutralJudgeScore = neutralJudgeScore,
            judgeScores = judgeScores,
            redAppliedTacticalPlan = appliedRedPlan,
            blueAppliedTacticalPlan = appliedBluePlan,
            tacticalEffectsEnabled = adaptiveTacticsEnabled,
            sequenceFrames = sequenceFrames,
            stoppage = stoppage,
        )
    }

    private data class AttackOutcome(
        val attackerState: FighterState,
        val defenderState: FighterState,
        val event: SequenceEvent,
    )

    private fun resolveRange(
        red: BoxerProfile,
        blue: BoxerProfile,
        redState: FighterState,
        blueState: FighterState,
        redTactic: Tactic,
        blueTactic: Tactic,
        redPlan: TacticalPlan?,
        bluePlan: TacticalPlan?,
        rng: DeterministicRandom,
    ): FightRange {
        val redOutside = rangeControl(red, redState, redTactic, redPlan, FightRange.OUTSIDE)
        val blueOutside = rangeControl(blue, blueState, blueTactic, bluePlan, FightRange.OUTSIDE)
        val redInside = rangeControl(red, redState, redTactic, redPlan, FightRange.INSIDE)
        val blueInside = rangeControl(blue, blueState, blueTactic, bluePlan, FightRange.INSIDE)
        val redMidResistance = mediumRangeResistance(redTactic, redPlan, redState)
        val blueMidResistance = mediumRangeResistance(blueTactic, bluePlan, blueState)

        return when {
            redOutside + rng.noise(8.0) > blueInside + blueMidResistance + 10.0 -> FightRange.OUTSIDE
            blueOutside + rng.noise(8.0) > redInside + redMidResistance + 10.0 -> FightRange.OUTSIDE
            redInside + blueInside + rng.noise(12.0) > redOutside + blueOutside + redMidResistance + blueMidResistance -> FightRange.INSIDE
            else -> FightRange.MID
        }
    }

    private fun rangeControl(profile: BoxerProfile, state: FighterState, tactic: Tactic, plan: TacticalPlan?, range: FightRange): Double {
        val preference = if (profile.preferredRange == range) 12.0 else 0.0
        val tacticBonus = when (tactic) {
            Tactic.CONTROL -> if (range == FightRange.OUTSIDE) 10.0 else 0.0
            Tactic.PRESS, Tactic.BODY_WORK, Tactic.SEEK_KO -> if (range == FightRange.INSIDE) 10.0 else 0.0
            Tactic.COUNTER -> if (range == FightRange.MID) 8.0 else 0.0
            Tactic.RECOVER -> if (range == FightRange.OUTSIDE) 6.0 else 0.0
        }
        val planBonus = TacticalPlanApplication.rangeControlBonus(plan, range)
        val fatigueFactor = state.stamina / 100.0
        return (profile.mobility * 0.55 + profile.technique * 0.45) * fatigueFactor + preference + tacticBonus + planBonus
    }

    private fun initiativeScore(
        profile: BoxerProfile,
        state: FighterState,
        tactic: Tactic,
        plan: TacticalPlan?,
        range: FightRange,
        rng: DeterministicRandom,
    ): Double {
        val tacticBonus = when (tactic) {
            Tactic.PRESS -> 12.0
            Tactic.SEEK_KO -> 15.0
            Tactic.COUNTER -> 2.0
            Tactic.CONTROL -> 6.0
            Tactic.BODY_WORK -> 8.0
            Tactic.RECOVER -> -12.0
        }
        val styleBonus = when (profile.style) {
            BoxingStyle.SWARMER, BoxingStyle.PRESSURE_FIGHTER -> if (range == FightRange.INSIDE) 8.0 else 2.0
            BoxingStyle.OUT_BOXER -> if (range == FightRange.OUTSIDE) 8.0 else -2.0
            BoxingStyle.COUNTERPUNCHER -> 1.0
            BoxingStyle.SLUGGER -> 4.0
            BoxingStyle.BOXER_PUNCHER -> 5.0
            BoxingStyle.DEFENSIVE_SPECIALIST -> -2.0
        }
        val planActivity = TacticalPlanApplication.activityScoreDelta(plan)
        return profile.speed * 0.45 + profile.aggression * 0.25 + profile.technique * 0.30 + tacticBonus + styleBonus + planActivity + rng.noise(10.0) - (100.0 - state.stamina) * 0.25
    }

    private fun resolveAttack(
        attacker: BoxerProfile,
        defender: BoxerProfile,
        attackerState: FighterState,
        defenderState: FighterState,
        attackerTactic: Tactic,
        defenderTactic: Tactic,
        attackerPlan: TacticalPlan?,
        defenderPlan: TacticalPlan?,
        range: FightRange,
        rng: DeterministicRandom,
        knockdownRng: DeterministicRandom,
        countRng: DeterministicRandom,
        roundNumber: Int,
        sequenceNumber: Int,
    ): AttackOutcome {
        val punch = choosePunch(attacker, attackerTactic, attackerPlan, range, rng)
        val baseAccuracy = attacker.accuracy * 0.42 + attacker.technique * 0.33 + attacker.speed * 0.25
        val defenseValue = defender.defense * 0.50 + defender.mobility * 0.30 + defender.technique * 0.20
        val rangeModifier = rangeAccuracyModifier(punch, range)
        val tacticModifier = attackAccuracyModifier(attackerTactic) - defenseAccuracyModifier(defenderTactic)
        val fatiguePenalty = (100.0 - attackerState.stamina) * 0.30
        val damagePenalty = attackerState.headDamage * 0.12 + attackerState.bodyDamage * 0.10
        val vulnerabilityBonus = defenderState.vulnerabilitySequencesRemaining * 0.04
        val historicalHitProbability = 0.48 + (baseAccuracy - defenseValue) / 220.0 + rangeModifier + tacticModifier + vulnerabilityBonus - fatiguePenalty / 100.0 - damagePenalty / 100.0
        val hitProbability = TacticalPlanApplication.adjustedHitProbability(
            historicalProbability = historicalHitProbability,
            attackerPlan = attackerPlan,
            defenderPlan = defenderPlan,
        )

        val landed = rng.chance(hitProbability)
        val clean = landed && rng.chance(
            (0.18 + (attacker.technique - defender.defense) / 250.0 +
                defenderState.vulnerabilitySequencesRemaining * 0.018).coerceIn(0.08, 0.52),
        )
        val rawImpact = if (landed) {
            val punchPower = punchPowerMultiplier(punch)
            val tacticPower = when (attackerTactic) {
                Tactic.SEEK_KO -> 1.18
                Tactic.PRESS -> 1.07
                Tactic.BODY_WORK -> 1.03
                else -> 1.0
            }
            val cleanMultiplier = if (clean) 1.35 else 1.0
            val historicalRawImpact = (attacker.power * 0.095 + attacker.technique * 0.025 + rng.noise(1.5)) * punchPower * tacticPower * cleanMultiplier
            TacticalPlanApplication.adjustedImpact(historicalRawImpact, attackerPlan)
        } else 0.0

        val bodyShot = punch == Punch.BODY_HOOK
        val resistance = if (bodyShot) defender.bodyResistance else defender.chin
        val vulnerabilityImpact = 1.0 + defenderState.vulnerabilitySequencesRemaining * 0.03
        val impact = max(0.0, rawImpact * (1.22 - resistance / 200.0) * vulnerabilityImpact)
        val staminaCost = attackStaminaCost(punch, attackerTactic, attacker.endurance, attackerPlan)

        val newAttackerState = attackerState.copy(
            stamina = clamp(attackerState.stamina - staminaCost),
            thrown = attackerState.thrown + 1,
            landed = attackerState.landed + if (landed) 1 else 0,
            cleanHits = attackerState.cleanHits + if (clean) 1 else 0,
            defensiveFailureStreak = 0,
        )

        val newDefenderState = if (!landed) defenderState.copy(
            stamina = clamp(defenderState.stamina - 0.25),
        ) else if (bodyShot) defenderState.copy(
            stamina = clamp(defenderState.stamina - impact * 0.50),
            bodyDamage = clamp(defenderState.bodyDamage + impact * 0.80),
            stability = clamp(defenderState.stability - impact * 0.25),
        ) else defenderState.copy(
            headDamage = clamp(defenderState.headDamage + impact * 0.72),
            stability = clamp(defenderState.stability - impact * 0.75),
        )

        val knockdownEvaluation = KnockdownDetector.evaluate(
            defender = defender,
            defenderBefore = defenderState,
            defenderAfter = newDefenderState,
            punch = punch,
            landed = landed,
            clean = clean,
            impact = impact,
        )
        val knockdownRoll = knockdownRng.nextDouble()
        val baseKnockdown = if (knockdownEvaluation.eligible && knockdownRoll < knockdownEvaluation.probability) {
            KnockdownEvent(
                attackerId = attacker.id,
                defenderId = defender.id,
                roundNumber = roundNumber,
                sequenceNumber = sequenceNumber,
                punch = punch,
                impact = impact,
                score = knockdownEvaluation.score,
                probability = knockdownEvaluation.probability,
                roll = knockdownRoll,
            )
        } else null

        val countedDefenderState = if (baseKnockdown == null) {
            newDefenderState
        } else {
            newDefenderState.copy(knockdownsSuffered = newDefenderState.knockdownsSuffered + 1)
        }
        val countRoll = if (baseKnockdown == null) null else countRng.nextDouble()
        val countEvaluation = if (baseKnockdown == null || countRoll == null) null else {
            RefereeCountResolver.evaluate(
                defender = defender,
                defenderBefore = defenderState,
                defenderAfterKnockdown = countedDefenderState,
                knockdown = baseKnockdown,
                roll = countRoll,
            )
        }
        val refereeCount = if (countEvaluation == null || countRoll == null) null else RefereeCount(
            countReached = countEvaluation.countReached,
            recovered = countEvaluation.recovered,
            recoveryScore = countEvaluation.recoveryScore,
            requiredScore = countEvaluation.requiredScore,
            roll = countRoll,
            vulnerabilitySequences = countEvaluation.vulnerabilitySequences,
        )
        val knockdown = baseKnockdown?.copy(refereeCount = refereeCount)
        val stateAfterCount = if (refereeCount == null) {
            countedDefenderState
        } else {
            countedDefenderState.copy(
                vulnerabilitySequencesRemaining = if (refereeCount.recovered) {
                    max(countedDefenderState.vulnerabilitySequencesRemaining, refereeCount.vulnerabilitySequences)
                } else 0,
                pendingTenCount = countedDefenderState.pendingTenCount || !refereeCount.recovered,
            )
        }
        val newFailureStreak = when {
            !landed -> 0
            clean && impact >= TkoSafetyDetector.MIN_CLEAN_IMPACT -> (defenderState.defensiveFailureStreak + 1).coerceAtMost(12)
            impact >= TkoSafetyDetector.MIN_HEAVY_IMPACT -> (defenderState.defensiveFailureStreak + 1).coerceAtMost(12)
            else -> (defenderState.defensiveFailureStreak - 1).coerceAtLeast(0)
        }
        val finalDefenderState = stateAfterCount.copy(defensiveFailureStreak = newFailureStreak)

        val text = eventText(attacker, defender, punch, landed, clean, range, refereeCount, stopOnTenCount)
        return AttackOutcome(
            newAttackerState,
            finalDefenderState,
            SequenceEvent(
                sequenceNumber = sequenceNumber,
                attackerId = attacker.id,
                defenderId = defender.id,
                range = range,
                punch = punch,
                landed = landed,
                clean = clean,
                impact = impact,
                knockdown = knockdown,
                text = text,
            ),
        )
    }

    private fun choosePunch(profile: BoxerProfile, tactic: Tactic, plan: TacticalPlan?, range: FightRange, rng: DeterministicRandom): Punch {
        val options = when (range) {
            FightRange.OUTSIDE -> listOf(Punch.JAB, Punch.JAB, Punch.CROSS, Punch.COMBINATION)
            FightRange.MID -> listOf(Punch.JAB, Punch.CROSS, Punch.HOOK, Punch.COMBINATION)
            FightRange.INSIDE -> listOf(Punch.HOOK, Punch.UPPERCUT, Punch.BODY_HOOK, Punch.BODY_HOOK, Punch.COMBINATION)
        }.toMutableList()
        if (tactic == Tactic.BODY_WORK) repeat(3) { options += Punch.BODY_HOOK }
        if (tactic == Tactic.SEEK_KO || profile.style == BoxingStyle.SLUGGER) {
            options += Punch.HOOK
            options += Punch.UPPERCUT
        }
        if (plan != null) {
            val headPool = options.filter { it != Punch.BODY_HOOK }.ifEmpty { listOf(Punch.JAB) }
            when (plan.target) {
                TacticalTarget.HEAD -> repeat(1) { options += headPool[it % headPool.size] }
                TacticalTarget.BODY -> repeat(2) { options += Punch.BODY_HOOK }
                TacticalTarget.MIXED -> Unit
            }
        }
        return options[rng.nextInt(options.size)]
    }

    private fun attackStaminaCost(punch: Punch, tactic: Tactic, endurance: Int, plan: TacticalPlan?): Double {
        val base = when (punch) {
            Punch.JAB -> 1.2
            Punch.CROSS -> 1.8
            Punch.HOOK -> 2.1
            Punch.UPPERCUT -> 2.3
            Punch.BODY_HOOK -> 2.0
            Punch.COMBINATION -> 3.4
        }
        val tacticFactor = when (tactic) {
            Tactic.SEEK_KO -> 1.25
            Tactic.PRESS -> 1.12
            Tactic.RECOVER -> 0.78
            else -> 1.0
        }
        val historicalCost = base * tacticFactor * (1.28 - endurance / 250.0)
        return TacticalPlanApplication.adjustedStaminaCost(historicalCost, plan)
    }

    private fun recoverAfterRound(profile: BoxerProfile, state: FighterState, tactic: Tactic): FighterState {
        val recovery = profile.recovery / 100.0 * if (tactic == Tactic.RECOVER) 4.5 else 1.8
        return state.copy(
            stamina = clamp(state.stamina + recovery),
            vulnerabilitySequencesRemaining = (state.vulnerabilitySequencesRemaining - 1).coerceAtLeast(0),
            defensiveFailureStreak = 0,
        )
    }

    private fun roundPerformance(
        fighterId: String,
        opponentStart: FighterState,
        opponentEnd: FighterState,
        events: List<SequenceEvent>,
    ): Double {
        val attacks = events.filter { it.attackerId == fighterId }
        val landed = attacks.count { it.landed }
        val cleanHits = attacks.count { it.clean }
        val accuracy = if (attacks.isEmpty()) 0.0 else landed.toDouble() / attacks.size
        val offense = landed * 2.0 + cleanHits * 2.8 + accuracy * 8.0
        val damageInflicted = (
            opponentEnd.headDamage - opponentStart.headDamage +
                opponentEnd.bodyDamage - opponentStart.bodyDamage
            ).coerceAtLeast(0.0)
        val stabilityDamage = (opponentStart.stability - opponentEnd.stability).coerceAtLeast(0.0)
        return offense + damageInflicted * 0.18 + stabilityDamage * 0.08
    }

    private fun rangeAccuracyModifier(punch: Punch, range: FightRange): Double = when {
        punch == Punch.JAB && range == FightRange.OUTSIDE -> 0.10
        punch == Punch.BODY_HOOK && range == FightRange.INSIDE -> 0.10
        punch == Punch.UPPERCUT && range == FightRange.INSIDE -> 0.08
        punch == Punch.HOOK && range == FightRange.OUTSIDE -> -0.12
        punch == Punch.BODY_HOOK && range == FightRange.OUTSIDE -> -0.15
        else -> 0.0
    }

    private fun attackAccuracyModifier(tactic: Tactic): Double = when (tactic) {
        Tactic.CONTROL -> 0.05
        Tactic.COUNTER -> 0.07
        Tactic.SEEK_KO -> -0.07
        Tactic.RECOVER -> -0.04
        else -> 0.0
    }

    private fun defenseAccuracyModifier(tactic: Tactic): Double = when (tactic) {
        Tactic.COUNTER -> 0.04
        Tactic.RECOVER -> 0.06
        Tactic.SEEK_KO -> -0.05
        else -> 0.0
    }

    private fun punchPowerMultiplier(punch: Punch): Double = when (punch) {
        Punch.JAB -> 0.68
        Punch.CROSS -> 1.0
        Punch.HOOK -> 1.08
        Punch.UPPERCUT -> 1.12
        Punch.BODY_HOOK -> 0.95
        Punch.COMBINATION -> 1.18
    }

    private fun eventText(
        attacker: BoxerProfile,
        defender: BoxerProfile,
        punch: Punch,
        landed: Boolean,
        clean: Boolean,
        range: FightRange,
        refereeCount: RefereeCount?,
        koApplied: Boolean,
    ): String {
        if (!landed) return "${attacker.name} tente ${label(punch)}, mais ${defender.name} évite l’attaque à distance ${label(range)}."
        val quality = if (clean) "nettement" else "partiellement"
        val base = "${attacker.name} touche $quality avec ${label(punch)} à distance ${label(range)}."
        return when {
            refereeCount == null -> base
            refereeCount.recovered -> "$base CHUTE : ${defender.name} tombe. L’arbitre compte jusqu’à ${refereeCount.countReached}, puis ${defender.name} se relève."
            koApplied -> "$base CHUTE : ${defender.name} tombe et le compte atteint 10. KO, le combat est terminé."
            else -> "$base CHUTE : ${defender.name} tombe et le compte atteint 10. L’arrêt KO est désactivé pour cet audit historique."
        }
    }

    private fun label(punch: Punch): String = when (punch) {
        Punch.JAB -> "un jab"
        Punch.CROSS -> "un direct arrière"
        Punch.HOOK -> "un crochet"
        Punch.UPPERCUT -> "un uppercut"
        Punch.BODY_HOOK -> "un crochet au corps"
        Punch.COMBINATION -> "une combinaison"
    }

    private fun label(range: FightRange): String = when (range) {
        FightRange.OUTSIDE -> "longue"
        FightRange.MID -> "moyenne"
        FightRange.INSIDE -> "courte"
    }

    private fun tickVulnerability(state: FighterState, preserveNew: Boolean): FighterState {
        if (preserveNew || state.vulnerabilitySequencesRemaining == 0) return state
        return state.copy(vulnerabilitySequencesRemaining = state.vulnerabilitySequencesRemaining - 1)
    }

    private fun clamp(value: Double): Double = min(100.0, max(0.0, value))

    private fun mediumRangeResistance(tactic: Tactic, plan: TacticalPlan?, state: FighterState): Double =
        TacticalPlanApplication.mediumRangeResistance(plan, tactic, state.stamina)
}
