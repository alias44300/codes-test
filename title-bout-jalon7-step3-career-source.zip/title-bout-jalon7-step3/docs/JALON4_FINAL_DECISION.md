# Jalon 4 — Décision finale

## Verdict

**Jalon 4 validé.**

L’IA tactique adaptative observe uniquement le passé du combat, choisit des plans déterministes, les applique avec des effets bornés et conserve une explication complète avant chaque round.

## Garanties validées

- même graine, mêmes instantanés, plans, séquences et résultat ;
- aucune information future ni carte exacte de juge consultée ;
- réponse cohérente au retard, à la fatigue et au danger physique ;
- identité de style conservée ;
- aucun changement après KO ou TKO ;
- aucun biais persistant du coin ;
- aucun plan universellement dominant dans le périmètre audité ;
- mode tactique désactivable reproduisant les empreintes historiques.

## Calibration

Le premier audit a correctement refusé une version trop favorable au pressure fighter. La validation finale repose sur une calibration des effets existants, et non sur l’ajout d’une règle cachée ou d’un correcteur de résultat.

## Périmètre inchangé

- deux boxeurs fictifs ;
- trois rounds ;
- Kotlin pur ;
- aucune interface Android ;
- aucun APK ;
- aucun apprentissage automatique ;
- aucun appel réseau.
