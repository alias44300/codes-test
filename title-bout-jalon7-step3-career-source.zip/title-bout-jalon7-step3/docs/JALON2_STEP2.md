# Jalon 2 — Étape 2 — Compte et récupération

## Livré

- modèle `RefereeCount` ;
- résolveur pur `RefereeCountResolver` ;
- flux aléatoire dédié au compte ;
- compte de 1 à 10 ;
- relèvement avant 10 ;
- vulnérabilité temporaire de 1 à 4 séquences ;
- état `pendingTenCount` pour préparer l’étape KO sans l’activer ;
- rapports détaillant récupération, exigence, tirage et durée de vulnérabilité.

## Formule de principe

La capacité de récupération combine :

- récupération ;
- mental ;
- menton ou résistance au corps ;
- énergie disponible.

L’exigence du relèvement combine :

- impact de la frappe ;
- score de chute ;
- dégâts accumulés ;
- instabilité ;
- fatigue ;
- chutes antérieures.

Un tirage déterministe séparé ajoute une variance limitée sans modifier les tirages offensifs ou ceux de la détection de chute.

## Limite volontaire

Un compte à 10 est mémorisé, mais le combat continue encore dans cette étape. L’arrêt effectif par KO appartient exclusivement à l’étape 3.
