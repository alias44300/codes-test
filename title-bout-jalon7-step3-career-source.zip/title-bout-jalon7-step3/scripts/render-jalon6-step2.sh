#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
python3 "$ROOT/ui-mockups/render_fight_screen.py" \
  --out "$ROOT/build-jalon6-step2/mockups" \
  --audit "$ROOT/build-jalon6-step2/layout-audit.json" >/dev/null
printf 'Mockups rendus dans %s\n' "$ROOT/build-jalon6-step2/mockups"
