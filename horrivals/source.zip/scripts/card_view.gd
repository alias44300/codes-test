extends Control
class_name CardView

signal card_pressed(card)

var card_data: Dictionary = {}
var selectable := true
var selected := false
var face_up := true
var home_position := Vector2.ZERO
var home_rotation := 0.0
var home_scale := Vector2.ONE
var _hovered := false
var _animating := false

var art_rect: TextureRect
var dimmer: ColorRect
var back_panel: ColorRect
var id_label: Label
var name_label: Label
var stats_panel: ColorRect
var attack_label: Label
var defense_label: Label
var threat_label: Label
var selection_outline: Panel

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    pivot_offset = size * 0.5
    mouse_entered.connect(_on_mouse_entered)
    mouse_exited.connect(_on_mouse_exited)
    gui_input.connect(_on_gui_input)

func setup(data: Dictionary, is_face_up := true) -> void:
    card_data = data.duplicate(true)
    face_up = is_face_up
    custom_minimum_size = Vector2(150, 225)
    size = Vector2(150, 225)
    pivot_offset = size * 0.5
    _build_visuals()
    set_face_up(face_up)

func _build_visuals() -> void:
    for child in get_children():
        child.queue_free()

    var base := Panel.new()
    base.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    base.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var style := StyleBoxFlat.new()
    style.bg_color = Color("15151d")
    style.border_color = Color("e7e7ef")
    style.set_border_width_all(3)
    style.corner_radius_top_left = 12
    style.corner_radius_top_right = 12
    style.corner_radius_bottom_left = 12
    style.corner_radius_bottom_right = 12
    base.add_theme_stylebox_override("panel", style)
    add_child(base)

    art_rect = TextureRect.new()
    art_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    art_rect.offset_left = 4
    art_rect.offset_top = 4
    art_rect.offset_right = -4
    art_rect.offset_bottom = -4
    art_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    art_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    art_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    if ResourceLoader.exists(str(card_data.get("art", ""))):
        art_rect.texture = load(str(card_data.get("art", "")))
    add_child(art_rect)

    dimmer = ColorRect.new()
    dimmer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    dimmer.color = Color(0.02, 0.02, 0.04, 0.12)
    dimmer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(dimmer)

    var top_strip := ColorRect.new()
    top_strip.position = Vector2(5, 5)
    top_strip.size = Vector2(140, 38)
    top_strip.color = Color(0.03, 0.03, 0.05, 0.82)
    top_strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(top_strip)

    id_label = Label.new()
    id_label.position = Vector2(9, 7)
    id_label.size = Vector2(60, 15)
    id_label.text = str(card_data.get("id", "HOR-???"))
    id_label.add_theme_font_size_override("font_size", 10)
    id_label.add_theme_color_override("font_color", Color("f2f2f5"))
    id_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(id_label)

    name_label = Label.new()
    name_label.position = Vector2(8, 20)
    name_label.size = Vector2(136, 19)
    name_label.text = str(card_data.get("name", "CARTE")).to_upper()
    name_label.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
    name_label.add_theme_font_size_override("font_size", 12)
    name_label.add_theme_color_override("font_color", Color.WHITE)
    name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(name_label)

    stats_panel = ColorRect.new()
    stats_panel.position = Vector2(4, 169)
    stats_panel.size = Vector2(142, 52)
    stats_panel.color = Color(0.025, 0.025, 0.04, 0.94)
    stats_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(stats_panel)

    attack_label = _stat_label("ATQ %d" % int(card_data.get("attack", 0)), Vector2(8, 174), Vector2(64, 20))
    defense_label = _stat_label("DÉF %d" % int(card_data.get("defense", 0)), Vector2(78, 174), Vector2(64, 20))
    threat_label = _stat_label("MENACE %d" % int(card_data.get("threat", 0)), Vector2(8, 196), Vector2(134, 19))
    threat_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

    selection_outline = Panel.new()
    selection_outline.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    selection_outline.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var select_style := StyleBoxFlat.new()
    select_style.bg_color = Color.TRANSPARENT
    select_style.border_color = Color("ffd04a")
    select_style.set_border_width_all(6)
    select_style.corner_radius_top_left = 14
    select_style.corner_radius_top_right = 14
    select_style.corner_radius_bottom_left = 14
    select_style.corner_radius_bottom_right = 14
    selection_outline.add_theme_stylebox_override("panel", select_style)
    selection_outline.visible = false
    add_child(selection_outline)

    back_panel = ColorRect.new()
    back_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    back_panel.color = Color("0d0d14")
    back_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(back_panel)

    var back_frame := Panel.new()
    back_frame.position = Vector2(10, 10)
    back_frame.size = Vector2(130, 205)
    back_frame.mouse_filter = Control.MOUSE_FILTER_IGNORE
    var back_style := StyleBoxFlat.new()
    back_style.bg_color = Color("171723")
    back_style.border_color = Color("6b2031")
    back_style.set_border_width_all(5)
    back_style.corner_radius_top_left = 15
    back_style.corner_radius_top_right = 15
    back_style.corner_radius_bottom_left = 15
    back_style.corner_radius_bottom_right = 15
    back_frame.add_theme_stylebox_override("panel", back_style)
    back_panel.add_child(back_frame)

    var back_title := Label.new()
    back_title.text = "HORRIVALS"
    back_title.position = Vector2(12, 80)
    back_title.size = Vector2(106, 28)
    back_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    back_title.add_theme_font_size_override("font_size", 18)
    back_title.add_theme_color_override("font_color", Color("f4f4f7"))
    back_frame.add_child(back_title)

    var back_sub := Label.new()
    back_sub.text = "CARTE IA"
    back_sub.position = Vector2(12, 111)
    back_sub.size = Vector2(106, 20)
    back_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    back_sub.add_theme_font_size_override("font_size", 11)
    back_sub.add_theme_color_override("font_color", Color("b9b9c7"))
    back_frame.add_child(back_sub)

func _stat_label(text_value: String, pos: Vector2, label_size: Vector2) -> Label:
    var label := Label.new()
    label.text = text_value
    label.position = pos
    label.size = label_size
    label.add_theme_font_size_override("font_size", 13)
    label.add_theme_color_override("font_color", Color.WHITE)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(label)
    return label

func set_face_up(value: bool) -> void:
    face_up = value
    if back_panel:
        back_panel.visible = not face_up

func set_selectable(value: bool) -> void:
    selectable = value
    if not value:
        set_selected(false)
    modulate = Color.WHITE if value else Color(0.72, 0.72, 0.76, 1.0)

func set_selected(value: bool) -> void:
    selected = value
    if selection_outline:
        selection_outline.visible = value
    if value and not _animating:
        _animate_to(home_position + Vector2(0, -18), home_rotation, Vector2(1.05, 1.05), 0.14)
    elif not _hovered and not _animating:
        _animate_to(home_position, home_rotation, home_scale, 0.14)

func set_home(pos: Vector2, rot := 0.0, scl := Vector2.ONE, snap := false) -> void:
    home_position = pos
    home_rotation = rot
    home_scale = scl
    if snap:
        position = pos
        rotation = rot
        scale = scl

func _on_mouse_entered() -> void:
    _hovered = true
    if selectable and not _animating and not selected:
        z_index = 20
        _animate_to(home_position + Vector2(0, -14), home_rotation * 0.3, Vector2(1.06, 1.06), 0.13)

func _on_mouse_exited() -> void:
    _hovered = false
    if selectable and not _animating and not selected:
        z_index = 0
        _animate_to(home_position, home_rotation, home_scale, 0.13)

func _on_gui_input(event: InputEvent) -> void:
    if not selectable or _animating:
        return
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        card_pressed.emit(self)
    elif event is InputEventScreenTouch and event.pressed:
        card_pressed.emit(self)

func _animate_to(target_pos: Vector2, target_rot: float, target_scale: Vector2, duration: float) -> void:
    var tween := create_tween().set_parallel(true)
    tween.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    tween.tween_property(self, "position", target_pos, duration)
    tween.tween_property(self, "rotation", target_rot, duration)
    tween.tween_property(self, "scale", target_scale, duration)

func animate_play_to(target: Vector2, flip_face_up := false) -> void:
    _animating = true
    z_index = 40
    if flip_face_up:
        var flip_out := create_tween()
        flip_out.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
        flip_out.tween_property(self, "scale:x", 0.04, 0.12)
        await flip_out.finished
        set_face_up(true)
        var flip_in := create_tween()
        flip_in.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
        flip_in.tween_property(self, "scale:x", 1.08, 0.18)
        await flip_in.finished
    var tween := create_tween().set_parallel(true)
    tween.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    tween.tween_property(self, "position", target, 0.34)
    tween.tween_property(self, "rotation", 0.0, 0.34)
    tween.tween_property(self, "scale", Vector2(1.08, 1.08), 0.34)
    await tween.finished
    _animating = false

func animate_attack_toward(target: Vector2) -> void:
    _animating = true
    var start := position
    var direction := (target - start).normalized()
    var windup := start - direction * 22.0
    var hit := start + direction * 68.0
    var t := create_tween()
    t.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
    t.tween_property(self, "position", windup, 0.10)
    t.set_trans(Tween.TRANS_EXPO).set_ease(Tween.EASE_IN)
    t.tween_property(self, "position", hit, 0.11)
    t.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
    t.tween_property(self, "position", start, 0.18)
    await t.finished
    _animating = false

func animate_hit() -> void:
    _animating = true
    var base_pos := position
    var t := create_tween()
    t.tween_property(self, "position", base_pos + Vector2(14, 0), 0.04)
    t.tween_property(self, "position", base_pos + Vector2(-12, 3), 0.04)
    t.tween_property(self, "position", base_pos + Vector2(8, -2), 0.04)
    t.tween_property(self, "position", base_pos, 0.06)
    await t.finished
    _animating = false

func animate_discard(target: Vector2) -> void:
    _animating = true
    set_selectable(false)
    var t := create_tween().set_parallel(true)
    t.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
    t.tween_property(self, "position", target, 0.36)
    t.tween_property(self, "rotation", rotation + deg_to_rad(28.0), 0.36)
    t.tween_property(self, "scale", Vector2(0.56, 0.56), 0.36)
    t.tween_property(self, "modulate:a", 0.15, 0.36)
    await t.finished
    visible = false
    _animating = false
