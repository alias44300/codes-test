# Jalon 1 — Décision finale

## Décision

**Jalon 1 validé sans micro-réglage du moteur.**

## Preuves

- 9 tests automatisés réussis ;
- 10 fenêtres indépendantes de 100 combats ;
- 1 000 combats terminés ;
- 3 000 rounds calculés ;
- 36 000 séquences calculées ;
- aucun crash ;
- Elias Vega : 503 avantages internes ;
- Bruno Kessler : 497 avantages internes ;
- coin rouge : 503 avantages internes ;
- coin bleu : 497 avantages internes ;
- écart moyen Vega moins Kessler : -0,72 ;
- écart moyen rouge moins bleu : +0,21.

Ces avantages sont des métriques internes du moteur. Ils ne constituent pas des décisions officielles, car les juges ne font pas partie du jalon 1.

## Lecture

Les deux profils restent tactiquement distincts sans qu’un profil domine structurellement l’autre. L’alternance des coins ne révèle aucun biais persistant. Les états physiques moyens restent hors saturation.

## Périmètre inchangé

Aucun juge, knockdown avancé, KO, TKO, écran Android ou APK n’a été ajouté pendant l’audit.

## Étape suivante autorisée

Le jalon 2 pourra traiter uniquement les chutes, le compte de l’arbitre, la récupération après chute et les arrêts KO/TKO.
