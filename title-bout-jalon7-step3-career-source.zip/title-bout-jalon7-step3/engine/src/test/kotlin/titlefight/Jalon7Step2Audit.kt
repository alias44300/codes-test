package titlefight

object Jalon7Step2Test {
    @JvmStatic
    fun main(args: Array<String>) {
        val boxers = OfficialRoster.cards
        check(boxers.size == 321)
        check(boxers.map { it.collectionId }.distinct().size == 321)
        check(boxers.first().collectionId == "BOX-001")
        check(boxers.last().collectionId == "BOX-321")
        check(boxers.map { it.weightClass }.toSet() == WeightClass.entries.toSet())
        check(boxers.groupingBy { it.weightClass }.eachCount()[WeightClass.HEAVYWEIGHT] == 41)
        check(boxers.groupingBy { it.weightClass }.eachCount().filterKeys { it != WeightClass.HEAVYWEIGHT }.values.all { it == 20 })
        check(boxers.all { it.profile.primaryStats.all { value -> value in 1..100 } })
        check(boxers.all { it.profile.secondaryStats.all { value -> value in 1..100 } })

        val ali = boxers.single { it.collectionId == "BOX-001" }
        val greb = boxers.single { it.collectionId == "BOX-103" }
        check(ali.name == "Muhammad Ali" && ali.overall == 100)
        check(greb.name == "Harry Greb" && greb.overall == 99)
        check(greb.weightClass == WeightClass.MIDDLEWEIGHT)
        check(OfficialRoster.search("pittsburgh windmill").single().collectionId == "BOX-103")
        check(OfficialRoster.search("poids moyens").size == 20)

        println("321 adversaires historiques validés")
        println("15 catégories validées")
        println("Aucun système de rareté dans le modèle Title Bout")
        println("Jalon 7 étape 2 corrigée : PASS")
    }
}
