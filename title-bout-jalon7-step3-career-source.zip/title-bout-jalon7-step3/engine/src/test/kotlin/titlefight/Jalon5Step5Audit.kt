package titlefight

import kotlin.math.abs
import kotlin.math.sqrt
import java.util.concurrent.CompletableFuture

data class WindowShareSummary(
    val id: String,
    val name: String,
    val style: BoxingStyle,
    val mean: Double,
    val minimum: Double,
    val maximum: Double,
    val standardDeviation: Double,
) {
    val spread: Double get() = maximum - minimum
}

data class Jalon5Step5Window(
    val window: Int,
    val seedStart: Long,
    val matrix: Jalon5Step3AuditResult,
) {
    val boxerMin: Double get() = matrix.boxers.minOf { it.nonDrawWinShare }
    val boxerMax: Double get() = matrix.boxers.maxOf { it.nonDrawWinShare }
    val styleMin: Double get() = matrix.styles.minOf { it.nonDrawWinShare }
    val styleMax: Double get() = matrix.styles.maxOf { it.nonDrawWinShare }
    val maxBoxerCornerGap: Double get() = matrix.boxers.maxOf { it.cornerGap }
    val structuralIntegrity: Boolean
        get() = matrix.matchups.size == 45 &&
            matrix.totalFights == 450 &&
            matrix.boxers.size == 10 &&
            matrix.styles.size == 7 &&
            matrix.redWins + matrix.blueWins + matrix.draws == matrix.totalFights &&
            matrix.ko + matrix.tko + matrix.decisions == matrix.totalFights &&
            matrix.reproducibilityMismatches == 0 &&
            matrix.invalidResults == 0 &&
            matrix.missingAppliedPlans == 0 &&
            matrix.planDecisionMismatches == 0 &&
            matrix.decisionsAfterStoppage == 0 &&
            matrix.legacyBehaviorFingerprintMismatches == 0
}

data class Jalon5Step5AuditResult(
    val windows: List<Jalon5Step5Window>,
    val aggregate: Jalon5Step3AuditResult,
    val identity: Jalon5Step2AuditResult,
    val boxerStability: List<WindowShareSummary>,
    val styleStability: List<WindowShareSummary>,
) {
    val totalFights: Int get() = windows.sumOf { it.matrix.totalFights }
    val reproducibilityChecks: Int get() = windows.sumOf { it.matrix.reproducibilityChecks }
    val reproducibilityMismatches: Int get() = windows.sumOf { it.matrix.reproducibilityMismatches }
    val maxWindowRedDeviation: Double get() = windows.maxOf { abs(it.matrix.redWinnerShare - 0.50) }
    val maxWindowBoxerCornerGap: Double get() = windows.maxOf { it.maxBoxerCornerGap }
    val maxAggregateBoxerCornerGap: Double get() = aggregate.boxers.maxOf { it.cornerGap }
    val maxBoxerWindowSpread: Double get() = boxerStability.maxOf { it.spread }
    val maxStyleWindowSpread: Double get() = styleStability.maxOf { it.spread }
    val maxBoxerWindowStdDev: Double get() = boxerStability.maxOf { it.standardDeviation }
    val maxStyleWindowStdDev: Double get() = styleStability.maxOf { it.standardDeviation }
    val allWindowsStructurallyValid: Boolean get() = windows.all { it.structuralIntegrity }
    val aggregateBoxersCompetitive: Boolean get() = aggregate.boxers.all { it.nonDrawWinShare in 0.30..0.70 }
    val aggregateStylesCompetitive: Boolean get() = aggregate.styles.all { it.nonDrawWinShare in 0.35..0.65 }
    val everyWindowContainsWinsAndLosses: Boolean
        get() = windows.all { window -> window.matrix.boxers.all { it.wins > 0 && it.losses > 0 } }
    val broadWindowBandsRespected: Boolean
        get() = windows.all { window ->
            window.matrix.boxers.all { it.nonDrawWinShare in 0.15..0.85 } &&
                window.matrix.styles.all { it.nonDrawWinShare in 0.20..0.80 }
        }
    val cornerNeutral: Boolean
        get() = aggregate.redWinnerShare in 0.48..0.52 &&
            maxWindowRedDeviation <= 0.05 &&
            maxAggregateBoxerCornerGap <= 0.08 &&
            maxWindowBoxerCornerGap <= 0.30
    val outcomesDiverse: Boolean
        get() = aggregate.ko > 0 && aggregate.tko > 0 && aggregate.decisions > 0 &&
            aggregate.draws > 0 && aggregate.stoppageShare in 0.001..0.03
    val identitiesStable: Boolean
        get() = identity.identityAccepted &&
            identity.indistinguishablePairs.isEmpty() &&
            maxBoxerWindowSpread <= 0.35 &&
            maxStyleWindowSpread <= 0.30 &&
            maxBoxerWindowStdDev <= 0.12 &&
            maxStyleWindowStdDev <= 0.10
    val accepted: Boolean
        get() = windows.size == 10 &&
            totalFights == 4_500 &&
            allWindowsStructurallyValid &&
            reproducibilityChecks == 900 &&
            reproducibilityMismatches == 0 &&
            aggregateBoxersCompetitive &&
            aggregateStylesCompetitive &&
            everyWindowContainsWinsAndLosses &&
            broadWindowBandsRespected &&
            cornerNeutral &&
            outcomesDiverse &&
            identitiesStable &&
            aggregate.invalidResults == 0 &&
            aggregate.missingAppliedPlans == 0 &&
            aggregate.planDecisionMismatches == 0 &&
            aggregate.decisionsAfterStoppage == 0 &&
            aggregate.legacyBehaviorFingerprintMismatches == 0
}

object Jalon5Step5Auditor {
    private const val WINDOW_COUNT = 10
    private const val SEED_PAIRS_PER_DUEL_PER_WINDOW = 5
    private const val REPRO_PAIRS_PER_DUEL_PER_WINDOW = 1
    private const val BASE_SEED = 202607215000L
    private const val WINDOW_SEED_STRIDE = 100_000_000L

    fun run(): Jalon5Step5AuditResult {
        val identityFuture = CompletableFuture.supplyAsync { Jalon5Step2Auditor.run() }
        val windows = (0 until WINDOW_COUNT).toList().parallelStream().map { index ->
            val seedStart = BASE_SEED + index * WINDOW_SEED_STRIDE
            Jalon5Step5Window(
                window = index + 1,
                seedStart = seedStart,
                matrix = Jalon5Step3Auditor.runWindow(
                    seedPairsPerDuel = SEED_PAIRS_PER_DUEL_PER_WINDOW,
                    seedStart = seedStart,
                    reproducibilityPairsPerDuel = REPRO_PAIRS_PER_DUEL_PER_WINDOW,
                ),
            )
        }.toList().sortedBy { it.window }
        val aggregate = aggregate(windows.map { it.matrix })
        val identity = identityFuture.join()
        return Jalon5Step5AuditResult(
            windows = windows,
            aggregate = aggregate,
            identity = identity,
            boxerStability = boxerStability(windows),
            styleStability = styleStability(windows),
        )
    }

    fun assertAccepted(result: Jalon5Step5AuditResult) {
        check(result.accepted)
        check(result.windows.size == WINDOW_COUNT)
        check(result.totalFights == 4_500)
        check(result.reproducibilityChecks == 900)
        check(result.reproducibilityMismatches == 0)
        check(result.aggregate.boxers.size == 10)
        check(result.aggregate.styles.size == 7)
        check(result.aggregateBoxersCompetitive)
        check(result.aggregateStylesCompetitive)
        check(result.cornerNeutral)
        check(result.outcomesDiverse)
        check(result.identitiesStable)
    }

    fun report(result: Jalon5Step5AuditResult): String = buildString {
        appendLine("AUDIT JALON 5 — ÉTAPE 5 FINALE")
        appendLine("Fenêtres indépendantes : ${result.windows.size}")
        appendLine("Combats : ${result.totalFights}")
        appendLine("Contrôles de reproductibilité : ${result.reproducibilityChecks}")
        appendLine("Écarts de reproductibilité : ${result.reproducibilityMismatches}")
        appendLine("Victoires rouge / bleu / nuls : ${result.aggregate.redWins} / ${result.aggregate.blueWins} / ${result.aggregate.draws}")
        appendLine("Part rouge parmi les vainqueurs : ${pct(result.aggregate.redWinnerShare)}")
        appendLine("Écart rouge maximal par fenêtre : ${pct(result.maxWindowRedDeviation)}")
        appendLine("Écart de coin maximal agrégé par boxeur : ${pct(result.maxAggregateBoxerCornerGap)}")
        appendLine("Écart de coin maximal dans une fenêtre : ${pct(result.maxWindowBoxerCornerGap)}")
        appendLine("KO / TKO / décisions : ${result.aggregate.ko} / ${result.aggregate.tko} / ${result.aggregate.decisions}")
        appendLine("Dispersion maximale d'un boxeur entre fenêtres : ${pct(result.maxBoxerWindowSpread)}")
        appendLine("Dispersion maximale d'un style entre fenêtres : ${pct(result.maxStyleWindowSpread)}")
        appendLine("Écart-type maximal boxeur / style : ${pct(result.maxBoxerWindowStdDev)} / ${pct(result.maxStyleWindowStdDev)}")
        appendLine("Identité statistique préservée : ${result.identity.identityAccepted}")
        appendLine("Audit final : ${if (result.accepted) "VALIDÉ" else "ÉCHEC"}")
        appendLine()
        appendLine("RÉSULTATS AGRÉGÉS PAR BOXEUR")
        result.aggregate.boxers.sortedByDescending { it.nonDrawWinShare }.forEach {
            appendLine("${it.fighterName} | ${it.style} | ${it.wins}-${it.losses}-${it.draws} | hors nuls ${pct(it.nonDrawWinShare)} | coin ${pct(it.cornerGap)}")
        }
        appendLine()
        appendLine("STABILITÉ ENTRE FENÊTRES")
        result.boxerStability.sortedByDescending { it.mean }.forEach {
            appendLine("${it.name} | moyenne ${pct(it.mean)} | min ${pct(it.minimum)} | max ${pct(it.maximum)} | écart-type ${pct(it.standardDeviation)}")
        }
    }

    fun windowsCsv(result: Jalon5Step5AuditResult): String = buildString {
        appendLine("window,seed_start,fights,red_wins,blue_wins,draws,red_winner_share,ko,tko,decisions,boxer_min,boxer_max,style_min,style_max,max_boxer_corner_gap,repro_checks,repro_mismatches,invalid_results,missing_plans,plan_mismatches,decisions_after_stoppage,accepted")
        result.windows.forEach { window ->
            appendLine(listOf(
                window.window,
                window.seedStart,
                window.matrix.totalFights,
                window.matrix.redWins,
                window.matrix.blueWins,
                window.matrix.draws,
                f(window.matrix.redWinnerShare),
                window.matrix.ko,
                window.matrix.tko,
                window.matrix.decisions,
                f(window.boxerMin),
                f(window.boxerMax),
                f(window.styleMin),
                f(window.styleMax),
                f(window.maxBoxerCornerGap),
                window.matrix.reproducibilityChecks,
                window.matrix.reproducibilityMismatches,
                window.matrix.invalidResults,
                window.matrix.missingAppliedPlans,
                window.matrix.planDecisionMismatches,
                window.matrix.decisionsAfterStoppage,
                window.structuralIntegrity,
            ).joinToString(","))
        }
    }

    fun stabilityCsv(result: Jalon5Step5AuditResult): String = buildString {
        appendLine("type,id,name,style,mean,minimum,maximum,spread,standard_deviation")
        result.boxerStability.forEach {
            appendLine("boxer,${it.id},${it.name},${it.style},${f(it.mean)},${f(it.minimum)},${f(it.maximum)},${f(it.spread)},${f(it.standardDeviation)}")
        }
        result.styleStability.forEach {
            appendLine("style,${it.id},${it.name},${it.style},${f(it.mean)},${f(it.minimum)},${f(it.maximum)},${f(it.spread)},${f(it.standardDeviation)}")
        }
    }

    private fun aggregate(results: List<Jalon5Step3AuditResult>): Jalon5Step3AuditResult {
        require(results.size == WINDOW_COUNT)
        val matchupRows = results.first().matchups.indices.map { index ->
            val rows = results.map { it.matchups[index] }
            val first = rows.first()
            MatchupMatrixRow(
                fighterAId = first.fighterAId,
                fighterAName = first.fighterAName,
                fighterAStyle = first.fighterAStyle,
                fighterBId = first.fighterBId,
                fighterBName = first.fighterBName,
                fighterBStyle = first.fighterBStyle,
                seedPairs = rows.sumOf { it.seedPairs },
                fights = rows.sumOf { it.fights },
                fighterAWins = rows.sumOf { it.fighterAWins },
                fighterBWins = rows.sumOf { it.fighterBWins },
                draws = rows.sumOf { it.draws },
                ko = rows.sumOf { it.ko },
                tko = rows.sumOf { it.tko },
                decisions = rows.sumOf { it.decisions },
                fighterAWinsAsRed = rows.sumOf { it.fighterAWinsAsRed },
                fighterAWinsAsBlue = rows.sumOf { it.fighterAWinsAsBlue },
                fighterBWinsAsRed = rows.sumOf { it.fighterBWinsAsRed },
                fighterBWinsAsBlue = rows.sumOf { it.fighterBWinsAsBlue },
                pairedSameWinner = rows.sumOf { it.pairedSameWinner },
                pairedDifferentWinner = rows.sumOf { it.pairedDifferentWinner },
                pairedContainsDraw = rows.sumOf { it.pairedContainsDraw },
            )
        }
        val boxerRows = BoxerCatalog.all.map { boxer ->
            val rows = results.map { result -> result.boxers.first { it.fighterId == boxer.id } }
            BoxerMatrixSummary(
                fighterId = boxer.id,
                fighterName = boxer.name,
                style = boxer.style,
                fights = rows.sumOf { it.fights },
                redAppearances = rows.sumOf { it.redAppearances },
                blueAppearances = rows.sumOf { it.blueAppearances },
                wins = rows.sumOf { it.wins },
                losses = rows.sumOf { it.losses },
                draws = rows.sumOf { it.draws },
                koWins = rows.sumOf { it.koWins },
                tkoWins = rows.sumOf { it.tkoWins },
                redWins = rows.sumOf { it.redWins },
                blueWins = rows.sumOf { it.blueWins },
            )
        }
        val styleRows = BoxingStyle.entries.map { style ->
            val rows = results.map { result -> result.styles.first { it.style == style } }
            StyleMatrixSummary(
                style = style,
                appearances = rows.sumOf { it.appearances },
                wins = rows.sumOf { it.wins },
                losses = rows.sumOf { it.losses },
                draws = rows.sumOf { it.draws },
            )
        }
        return Jalon5Step3AuditResult(
            seedPairsPerDuel = results.sumOf { it.seedPairsPerDuel },
            matchups = matchupRows,
            boxers = boxerRows,
            styles = styleRows,
            totalFights = results.sumOf { it.totalFights },
            redWins = results.sumOf { it.redWins },
            blueWins = results.sumOf { it.blueWins },
            draws = results.sumOf { it.draws },
            ko = results.sumOf { it.ko },
            tko = results.sumOf { it.tko },
            decisions = results.sumOf { it.decisions },
            reproducibilityChecks = results.sumOf { it.reproducibilityChecks },
            reproducibilityMismatches = results.sumOf { it.reproducibilityMismatches },
            invalidResults = results.sumOf { it.invalidResults },
            missingAppliedPlans = results.sumOf { it.missingAppliedPlans },
            planDecisionMismatches = results.sumOf { it.planDecisionMismatches },
            decisionsAfterStoppage = results.sumOf { it.decisionsAfterStoppage },
            legacyBehaviorFingerprintMismatches = results.sumOf { it.legacyBehaviorFingerprintMismatches },
            calibrationFlags = emptyList(),
        )
    }

    private fun boxerStability(windows: List<Jalon5Step5Window>): List<WindowShareSummary> =
        BoxerCatalog.all.map { boxer ->
            val values = windows.map { window -> window.matrix.boxers.first { it.fighterId == boxer.id }.nonDrawWinShare }
            summary(boxer.id, boxer.name, boxer.style, values)
        }

    private fun styleStability(windows: List<Jalon5Step5Window>): List<WindowShareSummary> =
        BoxingStyle.entries.map { style ->
            val values = windows.map { window -> window.matrix.styles.first { it.style == style }.nonDrawWinShare }
            summary(style.name, style.name, style, values)
        }

    private fun summary(id: String, name: String, style: BoxingStyle, values: List<Double>): WindowShareSummary {
        val mean = values.average()
        val variance = values.sumOf { (it - mean) * (it - mean) } / values.size
        return WindowShareSummary(
            id = id,
            name = name,
            style = style,
            mean = mean,
            minimum = values.minOrNull()!!,
            maximum = values.maxOrNull()!!,
            standardDeviation = sqrt(variance),
        )
    }

    private fun f(value: Double): String = "%.6f".format(java.util.Locale.ROOT, value)
    private fun pct(value: Double): String = "%.2f%%".format(java.util.Locale.ROOT, value * 100.0)
}

object Jalon5Step5AuditDemo {
    @JvmStatic
    fun main(args: Array<String>) {
        val result = Jalon5Step5Auditor.run()
        println(Jalon5Step5Auditor.report(result))
        if (!result.accepted) {
            error("L'audit final du jalon 5 ne respecte pas toutes les bandes d'acceptation.")
        }
    }
}

object Jalon5Step5WindowsCsvDemo {
    @JvmStatic fun main(args: Array<String>) = print(Jalon5Step5Auditor.windowsCsv(Jalon5Step5Auditor.run()))
}

object Jalon5Step5BoxersCsvDemo {
    @JvmStatic fun main(args: Array<String>) {
        val result = Jalon5Step5Auditor.run()
        print(Jalon5Step3Auditor.boxerCsv(result.aggregate))
    }
}

object Jalon5Step5StylesCsvDemo {
    @JvmStatic fun main(args: Array<String>) {
        val result = Jalon5Step5Auditor.run()
        print(Jalon5Step3Auditor.stylesCsv(result.aggregate))
    }
}

object Jalon5Step5StabilityCsvDemo {
    @JvmStatic fun main(args: Array<String>) = print(Jalon5Step5Auditor.stabilityCsv(Jalon5Step5Auditor.run()))
}

object Jalon5Step5Test {
    private val audit: Jalon5Step5AuditResult by lazy { Jalon5Step5Auditor.run() }

    @JvmStatic
    fun main(args: Array<String>) {
        finalAuditCoversTenIndependentWindows()
        finalAuditIsFullyReproducible()
        calibratedBoxersRemainCompetitive()
        calibratedStylesRemainCompetitive()
        finalAuditHasNoPersistentCornerBias()
        statisticalIdentitiesRemainStable()
        officialOutcomesRemainValidAndDiverse()
        println("7 tests finaux réussis")
    }

    private fun finalAuditCoversTenIndependentWindows() {
        check(audit.windows.size == 10)
        check(audit.windows.map { it.seedStart }.distinct().size == 10)
        check(audit.totalFights == 4_500)
        check(audit.windows.all { it.matrix.matchups.size == 45 })
        check(audit.allWindowsStructurallyValid)
    }

    private fun finalAuditIsFullyReproducible() {
        check(audit.reproducibilityChecks == 900)
        check(audit.reproducibilityMismatches == 0)
        check(audit.aggregate.legacyBehaviorFingerprintMismatches == 0)
    }

    private fun calibratedBoxersRemainCompetitive() {
        check(audit.aggregateBoxersCompetitive)
        check(audit.aggregate.boxers.all { it.wins > 0 && it.losses > 0 })
        check(audit.everyWindowContainsWinsAndLosses)
    }

    private fun calibratedStylesRemainCompetitive() {
        check(audit.aggregateStylesCompetitive)
        check(audit.aggregate.styles.all { it.wins > 0 && it.losses > 0 })
        check(audit.broadWindowBandsRespected)
    }

    private fun finalAuditHasNoPersistentCornerBias() {
        check(audit.cornerNeutral)
        check(audit.aggregate.redWinnerShare in 0.48..0.52)
        check(audit.maxAggregateBoxerCornerGap <= 0.08)
    }

    private fun statisticalIdentitiesRemainStable() {
        check(audit.identitiesStable)
        check(audit.identity.indistinguishablePairs.isEmpty())
        check(audit.maxBoxerWindowStdDev <= 0.12)
        check(audit.maxStyleWindowStdDev <= 0.10)
    }

    private fun officialOutcomesRemainValidAndDiverse() {
        check(audit.outcomesDiverse)
        check(audit.aggregate.invalidResults == 0)
        check(audit.aggregate.missingAppliedPlans == 0)
        check(audit.aggregate.planDecisionMismatches == 0)
        check(audit.aggregate.decisionsAfterStoppage == 0)
        Jalon5Step5Auditor.assertAccepted(audit)
    }
}
