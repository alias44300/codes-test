package androidx.compose.material3
import androidx.compose.foundation.BorderStroke
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow

class TextStyle
class Typography {
    val labelLarge = TextStyle()
    val headlineSmall = TextStyle()
    val titleMedium = TextStyle()
}
class ColorScheme(
    val primary: Color = Color(0),
    val onPrimary: Color = Color(0),
    val secondary: Color = Color(0),
    val tertiary: Color = Color(0),
    val background: Color = Color(0),
    val surface: Color = Color(0),
    val surfaceVariant: Color = Color(0),
    val onBackground: Color = Color(0),
    val onSurface: Color = Color(0),
    val onSurfaceVariant: Color = Color(0),
    val outlineVariant: Color = Color(0),
)
fun darkColorScheme(
    primary: Color = Color(0), onPrimary: Color = Color(0), secondary: Color = Color(0), tertiary: Color = Color(0),
    background: Color = Color(0), surface: Color = Color(0), surfaceVariant: Color = Color(0), onBackground: Color = Color(0),
    onSurface: Color = Color(0), onSurfaceVariant: Color = Color(0),
): ColorScheme = ColorScheme(primary,onPrimary,secondary,tertiary,background,surface,surfaceVariant,onBackground,onSurface,onSurfaceVariant)
fun lightColorScheme(
    primary: Color = Color(0), secondary: Color = Color(0), tertiary: Color = Color(0), background: Color = Color(0),
    surface: Color = Color(0), surfaceVariant: Color = Color(0), onBackground: Color = Color(0), onSurface: Color = Color(0), onSurfaceVariant: Color = Color(0),
): ColorScheme = ColorScheme(primary=primary,secondary=secondary,tertiary=tertiary,background=background,surface=surface,surfaceVariant=surfaceVariant,onBackground=onBackground,onSurface=onSurface,onSurfaceVariant=onSurfaceVariant)
object MaterialTheme {
    val colorScheme: ColorScheme = ColorScheme()
    val typography: Typography = Typography()
    @Composable operator fun invoke(colorScheme: ColorScheme = this.colorScheme, content: @Composable () -> Unit) { content() }
}
@Composable fun Surface(
    modifier: Modifier = Modifier,
    shape: Any? = null,
    color: Color = Color(0),
    tonalElevation: Dp = 0.dp,
    border: BorderStroke? = null,
    content: @Composable () -> Unit,
) { content() }

@Composable fun Surface(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Any? = null,
    color: Color = Color(0),
    tonalElevation: Dp = 0.dp,
    border: BorderStroke? = null,
    content: @Composable () -> Unit,
) { content() }
@Composable fun Text(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = TextStyle(),
    fontWeight: FontWeight? = null,
    color: Color = Color(0),
    fontSize: TextUnit = TextUnit(0f),
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow? = null,
    textAlign: TextAlign? = null,
) {}
@Composable fun LinearProgressIndicator(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = Color(0),
    trackColor: Color = Color(0),
) {}
@Composable fun HorizontalDivider(modifier: Modifier = Modifier, color: Color = Color(0)) {}
